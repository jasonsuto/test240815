package com.xweather.mapsgl.sources

import android.graphics.Bitmap
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.xweather.mapsgl.anim.TileRequestManager
import com.xweather.mapsgl.anim.TileRequestOptions
import com.xweather.mapsgl.events.DataSourceEvents
import com.xweather.mapsgl.events.trigger
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.network.Urls.Companion.mapsGLServer
import com.xweather.mapsgl.tiles.Tile
import com.xweather.mapsgl.tiles.TileCache
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.tiles.TileState
import com.xweather.mapsgl.types.DataSourceConsumer
import com.xweather.mapsgl.types.DataSourceKind
import com.xweather.mapsgl.types.URLRequest
import com.xweather.mapsgl.weather.XweatherAuthenticator
import java.util.Date

/**
 * ImageTileSource.kt
 *
 *   Adapted from IOS version
 *   @author by Jason Suto on 11/30/23.
 */

class ImageTileSource(
    override val id: String,
    private val typeString: String,
    val authenticator: XweatherAuthenticator?
) : TileSource<TileData>() {

    class MetadataSchema : SourceMetadataSchema() {
        init {
            maxZoom = 21.0f
            startDate = Date(System.currentTimeMillis() - (60 * 60 * 1000 * 24 * 3))
            endDate = Date(System.currentTimeMillis() + (60 * 60 * 1000 * 24 * 1))
        }
    }

    companion object {
        //TODO: Does having api event in companion object interfere when there a re multiple image tile sources?
        val _apiEvent = MutableLiveData<RasterTileApiEvent>(RasterTileApiEvent.Success(null))
        val apiEvent: LiveData<RasterTileApiEvent> = _apiEvent
        private var key: String = ""
        private val mapPrefixURL = "$mapsGLServer/tile"

        fun setKey(id: String?, secret: String?) {
            key = "${id}_${secret}"
        }
    }

    override var timeRange: ClosedRange<Date>? = null
    private var isStale = false
    private val TAG = "ImageTileSource"
    override val kind: DataSourceKind = DataSourceKind.RASTER
    override fun addConsumer(consumer: DataSourceConsumer) {}
    override fun removeConsumer(layerId: String) {}
    override var tileManager: TileRequestManager<TileData> = TileRequestManager(this)
    override var tileCache: TileCache<DataType> = TileCache()

    init {
        maxZoom = 7.0f
    }

    override fun appendTileUrlVariables(coord: TileCoord, vars: MutableMap<String, Any>) {
        authenticator?.appendTileCredentialVariables(vars)
    }

    /**
     *  Called from [TilePyramid].requestTiles(),
     *  This will eventually initiate the download of bitmaps.
     *
     */
    override suspend fun requestTiles(
        coord: TileCoord,
        options: TileRequestOptions,
        currentDate: String,
        fromAnimation: Boolean,
        intervals: List<String>?,
    ): Any {
        val urlDate = intervalToURLTime(currentDate)
        val tileUrl = makeTileURL(coord, mutableMapOf("time" to urlDate))
        val urlRequest = URLRequest(tileUrl.toString())

        prepareTileRequest(urlRequest, coord.time)

        if (tileCache.pendingCount == 0) {
            trigger(DataSourceEvents.LoadStart(sourceID = id))
            _shouldTriggerLoadCompleteEvent = true
        }

        coord.time = currentDate
        val tile = tileCache[coord] ?: TileType(coord).also { newTile ->
            newTile.time = currentDate
            newTile.coordHash = coord.hash()
            tileCache.updateTile(newTile, coord)
        }

        // don't fetch the tile if it's currently pending or if it's in a failed state and we aren't reloading
        if (options.checkPending) {
            if (!shouldRequestTile(tile, options.reload)) {
                return RequestTileSuccess.AlreadyExists()
            }
        }

        tileCache.setPending(true, tile)
        tile.state = TileState.Loading

        trigger(DataSourceEvents.TileLoadStart(id, tile))

        val tileResponse = tileManager.loadTile(coord, urlRequest /*, options*/)
        val data = tileResponse?.data as ByteArray
        val parsedBMP = parseTile(tile, data, tileResponse.headers)
        onTileLoaded(tile, parsedBMP)
        tile.state = TileState.Ready

        return RequestTileSuccess.alreadyExists //Todo: This should be returning RequestTileSuccess<TileData>
    }

    fun prepareTileRequest(request: URLRequest, timeString: String?) {
        //fixme: Is it inefficient to do this for each tile? is optimization worth the effort?
        request.method = "GET"
        request.headers["Content-Type"] = "application/json"
        request.headers["Access-Control-Request-Headers"] = "x-data-set-locs"
        val jsonArray = JsonArray()

        for (encodedDataset in datasets) {
            val jsonObject = JsonObject()
            jsonObject.addProperty("dataSetId", encodedDataset.code)

            if (encodedDataset.timeOffset == null) {
                jsonObject.addProperty("validTimes", timeString)
            } else { // TimeOffsets like in 1 and 24 hr time change
                val newTime = adjustDateBySeconds(timeString!!, encodedDataset.timeOffset!!.seconds)
                jsonObject.addProperty("validTimes", newTime)
            }
            jsonObject.addProperty("outputMin", 0)
            jsonObject.addProperty("outputMax", 255)
            jsonObject.addProperty("dataMin", encodedDataset.dataRange.start)
            jsonObject.addProperty("dataMax", encodedDataset.dataRange.endInclusive)
            jsonArray.add(jsonObject)
        }
        request.body = jsonArray.toString()//.replace("\"[[\\", "[").replace("\\\"]]\"","\"]")
    }

    /** Puts the data in tile.data and updates tilecache */
    private fun onTileLoaded(tile: TileType, data: Any) {

        if (pr.ON) pr.p(
            TAG,
            pr.tileReceived,
            "onTileLoaded() tile.coordHash: ${tile.coordHash}, data is null? ${data == null}   tile.data is null? ${tile.data == null}"
        )

        isStale = tileCache.isStale(tile)
        if (!isStale) {
            tileCache.setPending(false, tile)
        }

        val newTile = Tile<DataType>(TileCoord(tile.coord.x, tile.coord.y, tile.coord.z, time = tile.time))

        newTile.data = data as Bitmap

        tileCache.withBindListLock {
            if (!tileCache.bindList.contains(newTile.coordHash)) {
                tileCache.bindList.add(newTile.coordHash)
            }
        }
        //tileCache.bindQueue.add(newTile.coordHash)
        newTile.state = TileState.Ready
        if (isStale) {
            tileCache.setStale(false, newTile)
            //trigger(DataSourceEvents.TileDiscard(sourceID = id, tile = tile))
            return
        }
        if (pr.ON) pr.p(
            TAG,
            pr.tileReceived,
            "onTileLoaded() about to update tile ${newTile.coordHash}, data is null? ${newTile.data == null}"
        )
        tileCache.updateTile(newTile)
        val pendingTileCount = tileCache.pendingCount

        if (pendingTileCount == 0 && _shouldTriggerLoadCompleteEvent) {
            //println("$TAG onTileLoaded() triggering for $id")
            trigger(DataSourceEvents.LoadComplete(sourceID = id))
            _apiEvent.value = RasterTileApiEvent.Reload(true)
            _shouldTriggerLoadCompleteEvent = false
        }
    }
}

/**
 *  This will be merged with DataSourceEvents
 *
 *
 */
// was sealed, not compatible with certain versions of java
// https://stackoverflow.com/questions/73453524/what-is-causing-this-error-com-android-tools-r8-internal-nc-sealed-classes-are
open class RasterTileApiEvent {
    class Reload(var reloadNeeded: Boolean) : RasterTileApiEvent()
    class Success(var bitmapList: MutableList<BitmapPackage>?) : RasterTileApiEvent()
    class Error(val msg: String) : RasterTileApiEvent()
}

/**
 *  This is used for the early demo, will not be used in the
 *  final product
 *
 */
class BitmapPackage(val bitmap: Bitmap, val texNum: Int, val id: String)
