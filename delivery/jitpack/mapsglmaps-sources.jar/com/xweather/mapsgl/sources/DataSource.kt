package com.xweather.mapsgl.sources

import com.xweather.mapsgl.events.EventSource
import com.xweather.mapsgl.sources.types.Headers
import com.xweather.mapsgl.tiles.Tile
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.types.DataSourceConsumer
import com.xweather.mapsgl.types.DataSourceKind
import java.util.Date

/**
 * Runtime data provider backing one or more [com.xweather.mapsgl.layers.tile.MapLayer] instances.
 *
 * Created from a [com.xweather.mapsgl.sources.source.spec.SourceDescriptor] via
 * [com.xweather.mapsgl.map.MapController.addSource]. Subtypes include raster, encoded grid, vector, and GeoJSON sources.
 *
 * @property id Same id as the registered style source / descriptor.
 * @property kind High-level source family (raster, encoded, vector, …).
 * @property timeRange Optional interval filter for time-series products; drives tile requests with timeline state.
 * @property isReady `true` when metadata (and any bootstrap work) is available so layers can request tiles safely.
 */
interface DataSource : EventSource {
    val id: String
    val kind: DataSourceKind

    var timeRange: ClosedRange<Date>?

    var isReady: Boolean

    /** Register a layer that should receive updates when this source loads or changes. */
    fun addConsumer(consumer: DataSourceConsumer)

    /** Unregister a layer previously added with [addConsumer]. */
    fun removeConsumer(layerId: String)
}

/** Alias for [DataSource.kind] (matches JS naming `type`). */
val DataSource.type: DataSourceKind
    get() = this.kind

/**
 * Result of an internal tile request: either new [Data] or a signal that the tile is already cached.
 *
 * @param DataType Concrete tile payload type.
 */
open class RequestTileSuccess<DataType : TileData> {
    /** Successfully decoded tile ready for the cache / layer. */
    data class Data<DataType : TileData>(val data: DataType) : RequestTileSuccess<DataType>()

    /** Tile was already present; skip duplicate work. */
    class AlreadyExists : RequestTileSuccess<TileData>() {
    }

    companion object {
        val alreadyExists: Unit = Unit
    }
}

/**
 * Decodes raw HTTP bytes into a typed [TileData] subclass for a given source.
 */
interface TileDataParser {
    /** Parse downloaded bytes into [T], using optional headers and source metadata for context. */
    suspend fun <T : TileData, U> parse(
        tile: Tile<T>,
        data: ByteArray,
        headers: Headers?,
        metadata: SourceMetadata<SourceMetadataSchema>
    ): T
}