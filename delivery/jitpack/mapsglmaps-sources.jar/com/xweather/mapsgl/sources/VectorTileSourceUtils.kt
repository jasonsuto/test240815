package com.xweather.mapsgl.sources

import com.mapbox.geojson.Point
import com.xweather.mapsgl.tiles.LatLonBounds
import com.xweather.mapsgl.tiles.TileCoord
import kotlin.math.PI
import kotlin.math.atan
import kotlin.math.pow
import kotlin.math.sinh

// These functions were split off from VectorTileSource

fun calculateSignedArea(polygon: List<Point>): Double {
    if (polygon.size < 3) {
        return 0.0 // Not a polygon
    }

    var area = 0.0
    for (i in polygon.indices) {
        val p1 = polygon[i]
        val p2 = polygon[(i + 1) % polygon.size] // Wrap around for the last point

        // Using longitude for x, latitude for y
        area += (p1.longitude() * p2.latitude()) - (p2.longitude() * p1.latitude())
    }
    return area / 2.0
}

fun List<Point>.isClockwise(): Boolean {
    if (this.size < 3) return false // Or handle as desired for non-polygons
    return calculateSignedArea(this) < 0.0
}

/**
 * Checks if a polygon's vertices are in counter-clockwise (CCW) order.
 * Assumes longitude as x and latitude as y.
 * Conventionally, a positive signed area from the shoelace formula indicates CCW.
 */
fun List<Point>.isCounterClockwise(): Boolean {
    if (this.size < 3) return false // Or handle as desired for non-polygons
    return calculateSignedArea(this) > 0.0
}

/**
 * Reverses the list if its winding order is clockwise.
 * Useful for ensuring a polygon ring is counter-clockwise (e.g., GeoJSON outer rings).
 */
fun List<Point>.reversedIfClockwise(): List<Point> {
    //if(pr.ON) pr.p("VectorTileSource", pr.invVec2, "reversedIfClockwise() is clockwise?: ${this.isClockwise()}")
    return if (this.isClockwise()) this.asReversed() else this
}

/**
 * Reverses the list if its winding order is counter-clockwise.
 * Useful for ensuring a polygon ring is clockwise (e.g., GeoJSON inner rings/holes).
 */
fun List<Point>.reversedIfCounterClockwise(): List<Point> {
    return if (this.isCounterClockwise()) this.asReversed() else this
}

/**
 * Calculates the geographic latitude/longitude bounding box for a given tile.
 *
 * @param tile The tile coordinates (x, y, z).
 * @return LatLonBounds The geographic min/max latitude and longitude bounds of the tile.
 */
fun getLatLonBoundsOfTile(tile: TileCoord): LatLonBounds {
    val n = 2.0.pow(tile.z) // Number of tiles along one axis at this zoom level

    // Calculate North-West (top-left) corner's longitude and latitude
    val lonDegNw = tile.x / n * 360.0 - 180.0
    val latRadNw = atan(sinh(PI * (1.0 - 2.0 * tile.y / n)))
    val latDegNw = Math.toDegrees(latRadNw)

    // Calculate South-East (bottom-right) corner's longitude and latitude
    // The SE corner of the current tile (x,y) is the NW corner of the next tile (x+1, y+1)
    val lonDegSe = (tile.x + 1.0) / n * 360.0 - 180.0
    val latRadSe = atan(sinh(PI * (1.0 - 2.0 * (tile.y + 1.0) / n)))
    val latDegSe = Math.toDegrees(latRadSe)

    return LatLonBounds(
        lonDegNw,
        latDegSe,  // South-East latitude is the minimum latitude
        lonDegSe,
        latDegNw   // North-West latitude is the maximum latitude
    )
}

fun getTileBounds(tile: TileCoord): List<Point> {
    val n = 2.0.pow(tile.z) // Number of tiles along one axis at this zoom level

    // Calculate North-West (top-left) corner's longitude and latitude
    val lonDegNw = tile.x / n * 360.0 - 180.0
    val latRadNw = atan(sinh(PI * (1.0 - 2.0 * tile.y / n)))
    val latDegNw = Math.toDegrees(latRadNw)

    // Calculate South-East (bottom-right) corner's longitude and latitude
    // The SE corner of the current tile (x,y) is the NW corner of the next tile (x+1, y+1)
    val lonDegSe = (tile.x + 1.0) / n * 360.0 - 180.0
    val latRadSe = atan(sinh(PI * (1.0 - 2.0 * (tile.y + 1.0) / n)))
    val latDegSe = Math.toDegrees(latRadSe)

    return listOf(
        Point.fromLngLat(lonDegNw, latDegSe),
        Point.fromLngLat(lonDegSe, latDegSe),
        Point.fromLngLat(lonDegSe, latDegNw),
        Point.fromLngLat(lonDegNw, latDegNw),
        Point.fromLngLat(lonDegNw, latDegSe)
    )
}