package com.xweather.mapsgl.sources

import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.tiles.Tile
import com.xweather.mapsgl.tiles.TileCache
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.tiles.TileQuadrant
import com.xweather.mapsgl.tiles.TileState


class PaddingManager(val size: Int, val padding: Int, val tileCache: TileCache<DataType>, val id: String) {

    val TAG = "PaddingManager"
    private val paddedSize = size + padding + padding
    private val BYTESIZE = 4
    var d = 0
    var s = 0
    var stride = 0

    companion object {
        object position {
            const val TOP = 1
            const val RIGHT = 3
            const val BOTTOM = 5
            const val LEFT = 7
        }

    }


    private fun getDestinationData(tile: TileType): ByteArray {
        if (tile.encodedData?.paddedData != null) {
            return tile.encodedData!!.paddedData!!
        }
        if (pr.ON) pr.p(TAG, pr.blendEdges, "getDestinationData used native cache for ${tile.coordHash}")
        return tileCache.nativeCache.getData("$id${tile.coordHash}")!!
    }

    private fun getSourceData(tile: TileType): ByteArray {
        if (tile.encodedData?.paddedData != null) {
            return tile.encodedData!!.paddedData!!
        }

        return tileCache.nativeCache.getData("$id${tile.coordHash}")!!
    }


    fun blendEdges(tile: TileType, tileCache: TileCache<DataType>, testInt: Int) {
        if (pr.ON) pr.p(TAG, pr.blendEdges, "blendEdges() ($testInt) Handling neighbors for ${tile.coordHash}")
        val neighbors = tile.coord.getNeighbors()
        var neighborTile: Tile<DataType>?
        var neighborCoord: TileCoord?

        for (neighbor in neighbors) {
            neighborCoord = neighbors[neighbor.key]
            neighborTile = tileCache[neighborCoord!!]

            //if (neighborTile == null) { if (pr.ON) pr.p(TAG, pr.edgeBlend, "    ${neighbor.key} is null") }
            //else { if (pr.ON) pr.p(TAG, pr.edgeBlend, "   ${neighbor.key}   ${neighborTile!!.coordHash} state: ${neighborTile.state}")  }

            if (neighborTile != null) {

                if (pr.ON) pr.p(
                    TAG,
                    pr.blendEdges,
                    "       blendEdges() looking at neighbor: ${neighborTile.coordHash}  "
                )
            }

            if (false) {
                //neighborTile?.state = TileState.Initial // Toggle this to disable neighbor padding
                if (neighborTile?.state == TileState.Ready || neighborTile?.state == TileState.Processing) {
                    if (neighbor.key == TileQuadrant.MiddleRight) {
                        if (tile.blendQuadrants[position.RIGHT] < 2) {
                            //if (pr.ON) pr.p(TAG, pr.edgeBlend, "        copy to Down, from neighbor to this tile.")
                            copyFromRightTileToLeftTile(neighborTile, tile)
                        }
                        if (neighborTile.blendQuadrants[position.LEFT] < 2) {
                            copyFromLeftTileToRightTile(tile, neighborTile)
                            tileCache.updateTile(neighborTile)
                        }
                    }
                    if (neighbor.key == TileQuadrant.MiddleLeft) {
                        if (tile.blendQuadrants[position.LEFT] < 2) {
                            //if (pr.ON) pr.p(TAG, pr.edgeBlend, "        copy to Left, from neighbor to this tile.")
                            copyFromLeftTileToRightTile(neighborTile, tile)
                        }
                        if (neighborTile.blendQuadrants[position.RIGHT] < 2) {
                            copyFromRightTileToLeftTile(tile, neighborTile)
                            tileCache.updateTile(neighborTile)
                        }
                    } else if (neighbor.key == TileQuadrant.TopCenter) { // This is the one that is run at launch
                        if (pr.ON) pr.p(
                            TAG,
                            pr.blendEdges,
                            "         blendEdges() TopCenter T: ${tile.blendQuadrants[position.TOP]}  B: ${neighborTile.blendQuadrants[position.BOTTOM]}"
                        )
                        if (tile.blendQuadrants[position.TOP] < 2) {
                            //if (pr.ON) pr.p(TAG, pr.edgeBlend, "        copyFromUpperTileToLowerTile (neighbor to this)")
                            copyFromUpperTileToLowerTile(neighborTile, tile)
                        }
                        if (neighborTile.blendQuadrants[position.BOTTOM] < 2) {
                            //if (pr.ON) pr.p(TAG, pr.edgeBlend, "        copyFromLowerTileToUpperTile (this to neighbor)")
                            copyFromLowerTileToUpperTile(tile, neighborTile)
                            tileCache.updateTile(neighborTile)
                        }
                    } else if (neighbor.key == TileQuadrant.BottomCenter) {
                        if (pr.ON) pr.p(
                            TAG,
                            pr.blendEdges,
                            "         blendEdges() TopCenter B: ${tile.blendQuadrants[position.BOTTOM]}  T: ${neighborTile.blendQuadrants[position.TOP]}"
                        )
                        if (tile.blendQuadrants[position.BOTTOM] < 2) {
                            //if (pr.ON) pr.p(TAG, pr.edgeBlend, "        copyFromLowerTileToUpperTile, from neighbor to this tile.")
                            copyFromLowerTileToUpperTile(neighborTile, tile)
                        }
                        if (neighborTile.blendQuadrants[position.TOP] < 2) {
                            //if (pr.ON) pr.p(TAG, pr.edgeBlend, "        copyFromUpperTileToLowerTile, from this to neighbor tile.")
                            copyFromUpperTileToLowerTile(tile, neighborTile)
                            tileCache.updateTile(neighborTile)
                        }
                    }
                } // end neighbor loop
            }



            if (true) { //neighbor(s) not ready, copy edge pixels from self
                if (tile.blendQuadrants[1] == 0) {
                    padUp(tile)
                }
                if (tile.blendQuadrants[5] == 0) {
                    padDown(tile)
                }
                if (tile.blendQuadrants[7] == 0) {
                    padLeft(tile)
                }
                if (tile.blendQuadrants[3] == 0) {
                    padRight(tile)
                }

            } else if (false) {
                drawBorder(tile.encodedData!!.paddedData!!)
                tile.needsBind = true
            }
        }
    }

    private fun drawBorder(destData: ByteArray) {
        val borderWidth = DataPool.padding
        val width = DataPool.originalSize + borderWidth + borderWidth
        val height = DataPool.originalSize + borderWidth + borderWidth
        val bytesPerPixel = 4
        val rowStride = width * bytesPerPixel

        // Define the colors
        val redPixel = byteArrayOf(0xFF.toByte(), 0x00.toByte(), 0x00.toByte(), 0xFF.toByte())
        val blackPixel = byteArrayOf(0x00.toByte(), 0x00.toByte(), 0x00.toByte(), 0xFF.toByte())

        // 1. Draw Top (Red) and Bottom (Black)
        for (y in 0 until borderWidth) {
            val topRowOffset = y * rowStride
            val bottomRowOffset = (height - 1 - y) * rowStride

            for (x in 0 until width) {
                // Top border is Red
                redPixel.copyInto(destData, topRowOffset + (x * bytesPerPixel))
                // Bottom border is Black
                blackPixel.copyInto(destData, bottomRowOffset + (x * bytesPerPixel))
            }
        }

        // 2. Draw Left (Black) and Right (Red)
        // Skip the rows handled by top/bottom to maintain clean corners
        for (y in borderWidth until (height - borderWidth)) {
            val rowOffset = y * rowStride

            for (x in 0 until borderWidth) {
                val leftPixelOffset = rowOffset + (x * bytesPerPixel)
                val rightPixelOffset = rowOffset + (width - 1 - x) * bytesPerPixel

                // Left border is Black
                blackPixel.copyInto(destData, leftPixelOffset)
                // Right border is Red
                redPixel.copyInto(destData, rightPixelOffset)
            }
        }
    }

    //from gemini
    private fun copyFromUpperTileToLowerTile(sourceTile: TileType, destTile: TileType) {
        if (pr.ON) pr.p(TAG, pr.blendEdges, "    copyFromUpperTileToLowerTile() sz: ${size}  pdd: ${padding}")
        val source = getDestinationData(sourceTile)
        val dest = getDestinationData(destTile)

        val sourceStartY = (padding + size - padding) * (paddedSize * BYTESIZE) + (padding * BYTESIZE)
        val destStartY = 0 + (padding * BYTESIZE) // start after the left padding

        val rowWidthBytes = paddedSize * BYTESIZE

        for (y in 0 until padding) {
            val sourceYOffset = y * rowWidthBytes
            val destYOffset = y * rowWidthBytes

            val sourceIndex = sourceStartY + sourceYOffset
            val destIndex = destStartY + destYOffset
            if (sourceIndex + (size * BYTESIZE) <= source.size) {
                source.copyInto(
                    destination = dest,
                    destinationOffset = destIndex,
                    startIndex = sourceIndex,
                    endIndex = sourceIndex + (size * BYTESIZE)
                )
            }
        }
        destTile.blendQuadrants[position.TOP] = 2
        destTile.needsBind = true
    }

    private fun copyFromUpperTileToLowerTileOrig(sourceTile: TileType, destTile: TileType) {
        if (pr.ON) pr.p(TAG, pr.blendEdges, "    copyFromUpperTileToLowerTile() sz: ${size}  pdd: ${padding}")
        val source = getDestinationData(sourceTile)
        val dest = getDestinationData(destTile)

        val sourceStartY = paddedSize * BYTESIZE * size + padding * BYTESIZE
        val destStartY = padding * BYTESIZE

        for (y in 0 until padding) {
            val sourceYOffset = y * (size + padding + padding) * BYTESIZE
            val destYOffset = y * (size + padding + padding) * BYTESIZE

            val sourceIndex = sourceStartY + sourceYOffset
            val destIndex = destStartY + destYOffset

            source.copyInto(
                destination = dest,
                destinationOffset = destIndex,
                startIndex = sourceIndex,
                endIndex = sourceIndex + (size * BYTESIZE)
            )
        }

        destTile.blendQuadrants[position.TOP] = 2
        destTile.needsBind = true
    }

    //fixme: Test:
    private fun copyFromUpperTileToLowerTileTest(sourceTile: TileType, destTile: TileType) {
        if (pr.ON) pr.p(
            TAG,
            pr.blendEdges,
            "    copyFromUpperTileToLowerTile() (Filling Black) sz: ${size}  pdd: ${padding}"
        )

        // We only need the destination data now
        val dest = getDestinationData(destTile)

        // Calculate where the top padding area starts in the destination buffer
        // Usually, this starts at index 0 of the padded buffer
        val destStartY = 0
        val rowWidthBytes = (size + padding + padding) * BYTESIZE

        for (y in 0 until padding) {
            val rowOffset = y * rowWidthBytes

            for (x in 0 until (size + padding + padding)) {
                val pixelIndex = rowOffset + (x * BYTESIZE)

                dest[pixelIndex] = 0x99.toByte()     // R (White)
                dest[pixelIndex + 1] = 0xFF.toByte() // G (White)
                dest[pixelIndex + 2] = 0xFF.toByte() // B (White)

                //dest[pixelIndex] = 0x00.toByte()     // R
                //dest[pixelIndex + 1] = 0x00.toByte() // G
                //dest[pixelIndex + 2] = 0x00.toByte() // B

                dest[pixelIndex + 3] = 0xFF.toByte() // A (Opaque)
            }
        }

        destTile.blendQuadrants[position.TOP] = 2
        destTile.needsBind = true
    }

    // from gemini
    private fun copyFromLowerTileToUpperTile(sourceTile: TileType, destTile: TileType) {
        val dest = getDestinationData(destTile)
        val source = getDestinationData(sourceTile)

        val rowWidthBytes = paddedSize * BYTESIZE

        // The top-most edge of the source (lower) tile's real data
        // Skip the top padding rows, then skip the left padding pixels
        val sourceBaseIndex = (padding * rowWidthBytes) + (padding * BYTESIZE)

        // The bottom padding area of the destination (upper) tile
        // Skip all data rows (padding + size) to reach the bottom padding area
        val destBaseIndex = ((padding + size) * rowWidthBytes) + (padding * BYTESIZE)

        for (y in 0 until padding) {
            // Calculate exact offset for this specific row
            val currentSourceIndex = sourceBaseIndex + (y * rowWidthBytes)
            val currentDestIndex = destBaseIndex + (y * rowWidthBytes)

            // Safety check to prevent ArrayIndexOutOfBounds
            if (currentSourceIndex + (size * BYTESIZE) <= source.size &&
                currentDestIndex + (size * BYTESIZE) <= dest.size
            ) {

                source.copyInto(
                    destination = dest,
                    destinationOffset = currentDestIndex,
                    startIndex = currentSourceIndex,
                    endIndex = currentSourceIndex + (size * BYTESIZE)
                )
            }
        }

        destTile.blendQuadrants[position.BOTTOM] = 2
        destTile.needsBind = true
    }


    private fun copyFromLowerTileToUpperTileOrig(sourceTile: TileType, destTile: TileType) {

        val dest = getDestinationData(destTile)
        val source = getDestinationData(sourceTile)

        val copyWidth = size * BYTESIZE // Precompute the width to copy

        var sourceStartIndex = (paddedSize * BYTESIZE * padding) + (padding * BYTESIZE)
        var destStartIndex = (paddedSize * BYTESIZE * (size + padding)) + (padding * BYTESIZE)

        for (y in 0 until padding) {
            source.copyInto(
                destination = dest,
                destinationOffset = destStartIndex,
                startIndex = sourceStartIndex,
                endIndex = sourceStartIndex + copyWidth // Copy the entire row at once
            )

            sourceStartIndex += ((padding + padding) * BYTESIZE) // Move to the next row in source
            destStartIndex += ((padding + padding) * BYTESIZE) // Move to the next row in dest
        }

        destTile.blendQuadrants[position.BOTTOM] = 2
        destTile.needsBind = true
    }

    private fun copyFromRightTileToLeftTile(sourceTile: TileType, destTile: TileType) {

        val dest = getDestinationData(destTile)
        val source = getDestinationData(sourceTile)

        stride = ((size + padding) * BYTESIZE)

        d = (size + padding) * BYTESIZE
        for (y in 0 until padding) {
            s = (paddedSize * BYTESIZE * padding) + (padding * BYTESIZE)
            for (x in 0 until (padding * BYTESIZE)) {
                dest[d] = source[s]
                d++
                s++
            }
            d += stride
        }

        s = (paddedSize * BYTESIZE * padding) + (padding * BYTESIZE)
        d = (paddedSize * BYTESIZE * padding) + ((padding + size) * BYTESIZE)
        val stride = ((size + padding) * BYTESIZE)
        for (y in 0 until size) {
            for (x in 0 until (padding * BYTESIZE)) {
                dest[d] = source[s]
                d++
                s++
            }
            s += stride
            d += stride
        }

        //bottom
        d = (paddedSize * BYTESIZE * (size + padding)) + ((size + padding) * BYTESIZE)
        //top
        for (y in 0 until padding) {
            s = (paddedSize * BYTESIZE * (padding + size - 2)) + (padding * BYTESIZE)
            for (x in 0 until (padding * BYTESIZE)) {
                dest[d] = source[s]
                d++
                s++
            }
            d += stride
        }
        destTile.blendQuadrants[3] = 2
        destTile.needsBind = true
    }

    private fun copyFromLeftTileToRightTile(sourceTile: TileType, destTile: TileType) {
        val dest = getDestinationData(destTile)
        val source = getDestinationData(sourceTile)

        stride = ((size + padding) * BYTESIZE)

        d = 0

        //top
        for (y in 0 until padding) {
            s = (paddedSize * BYTESIZE * padding) + (size * BYTESIZE)
            for (x in 0 until (padding * BYTESIZE)) {
                dest[d] = source[s]
                d++
                s++
            }
            d += stride
        }

        //middle
        s = (paddedSize * BYTESIZE * padding) + (size * BYTESIZE)
        d = (paddedSize * BYTESIZE * padding)
        val paddingXByteSize = padding * BYTESIZE
        for (y in 0 until size) {
            for (x in 0 until (padding * BYTESIZE)) {
                dest[d] = source[s]
                d++
                s++
            }
            d += stride
            s += stride
        }

        //bottom
        d = (paddedSize * BYTESIZE * (padding + size))
        stride = ((size + padding) * BYTESIZE)
        for (y in 0 until padding) {
            s = (paddedSize * BYTESIZE * (padding + size - 1)) + (size * BYTESIZE)
            for (x in 0 until (padding * BYTESIZE)) {
                dest[d] = source[s]
                d++
                s++
            }
            d += stride
        }


        destTile.blendQuadrants[7] = 2
        destTile.needsBind = true

    }


    private fun padUpOld(destTile: TileType) { //slow but works
        val destData = destTile.encodedData!!.paddedData!!
        //val destData = getDestinationData(destTile)

        val sHolder = (paddedSize * BYTESIZE * (padding)) + (padding * BYTESIZE)
        var d = (padding * BYTESIZE)
        var s: Int
        for (y in 0 until padding) {
            s = sHolder
            for (x in 0 until (size * BYTESIZE)) {
                destData[d] = destData[s]
                //destData[d] =  0x44.toByte()
                s++
                d++
            }
            d += (padding * 2 * BYTESIZE)
        }

        s = (paddedSize * BYTESIZE * padding) + (padding * BYTESIZE) // upper left
        d = 0
        destData[d] = destData[s]
        destData[d + 1] = destData[s + 1]
        destData[d + 2] = destData[s + 2]
        destData[d + 3] = destData[s + 3]
        destData[d + 4] = destData[s]
        destData[d + 5] = destData[s + 1]
        destData[d + 6] = destData[s + 2]
        destData[d + 7] = destData[s + 3]

        d += (paddedSize * BYTESIZE)
        destData[d] = destData[s]
        destData[d + 1] = destData[s]
        destData[d + 2] = destData[s]
        destData[d + 3] = destData[s]
        destData[d + 4] = destData[s]
        destData[d + 5] = destData[s]
        destData[d + 6] = destData[s]
        destData[d + 7] = destData[s]

        s = (paddedSize * BYTESIZE * padding) + ((size + padding - 1) * BYTESIZE) //upper right
        d = ((size + padding) * BYTESIZE)
        destData[d] = destData[s]
        destData[d + 1] = destData[s + 1]
        destData[d + 2] = destData[s + 2]
        destData[d + 3] = destData[s + 3]
        destData[d + 4] = destData[s]
        destData[d + 5] = destData[s + 1]
        destData[d + 6] = destData[s + 2]
        destData[d + 7] = destData[s + 3]

        d += (paddedSize * BYTESIZE)
        destData[d] = destData[s]
        destData[d + 1] = destData[s + 1]
        destData[d + 2] = destData[s + 2]
        destData[d + 3] = destData[s + 3]
        destData[d + 4] = destData[s]
        destData[d + 5] = destData[s + 1]
        destData[d + 6] = destData[s + 2]
        destData[d + 7] = destData[s + 3]
        destTile.needsBind = true

        destTile.blendQuadrants[1] = 1
        destTile.needsBind = true
    }

    private fun padDownOld(destTile: TileType) {
        //val destData = getDestinationData(destTile) // This was being used until 250421
        val destData = destTile.encodedData!!.paddedData!!
        val sHolder = (paddedSize * BYTESIZE * (padding + size - 1)) + (padding * BYTESIZE)
        var d = (paddedSize * BYTESIZE * (padding + size)) + (padding * BYTESIZE)
        var s: Int
        for (y in 0 until padding) {
            s = sHolder
            //System.arraycopy(destTile.encodedData.paddedData, s, destTile.encodedData.paddedData, d, size * BYTESIZE)
            //d += (paddedSize * BYTESIZE)
            for (x in 0 until (size * BYTESIZE)) {
                destData[d] = destData[s]
                //destData[d] =  0x66.toByte()
                s++
                d++
            }
            d += (padding * 2 * BYTESIZE)
        }
        s = 0
        d = (paddedSize * BYTESIZE * (padding + size)) //lower left
        destData[d] = destData[s]
        destData[d + 1] = destData[s + 1]
        destData[d + 2] = destData[s + 2]
        destData[d + 3] = destData[s + 3]
        destData[d + 4] = destData[s]
        destData[d + 5] = destData[s + 1]
        destData[d + 6] = destData[s + 2]
        destData[d + 7] = destData[s + 3]
        d += (paddedSize * BYTESIZE)
        destData[d] = destData[s]
        destData[d + 1] = destData[s + 1]
        destData[d + 2] = destData[s + 2]
        destData[d + 3] = destData[s + 3]
        destData[d + 4] = destData[s]
        destData[d + 5] = destData[s + 1]
        destData[d + 6] = destData[s + 2]
        destData[d + 7] = destData[s + 3]

        s = (paddedSize * BYTESIZE) * (size + padding) + ((size + padding - 1) * BYTESIZE)
        d = (paddedSize * BYTESIZE) * (size + padding) + ((size + padding) * BYTESIZE)  //lower right
        destData[d] = destData[XweatherEncodedTileSource.s]
        destData[d + 1] = destData[s + 1]
        destData[d + 2] = destData[s + 2]
        destData[d + 3] = destData[s + 3]
        destData[d + 4] = destData[s]
        destData[d + 5] = destData[s + 1]
        destData[d + 6] = destData[s + 2]
        destData[d + 7] = destData[s + 3]
        d += (paddedSize * BYTESIZE)
        destData[d] = destData[s]
        destData[d + 1] = destData[s + 1]
        destData[d + 2] = destData[s + 2]
        destData[d + 3] = destData[s + 3]
        destData[d + 4] = destData[s]
        destData[d + 5] = destData[s + 1]
        destData[d + 6] = destData[s + 2]
        destData[d + 7] = destData[s + 3]

        destTile.blendQuadrants[5] = 1
        destTile.needsBind = true
    }

    private fun padLeftOld(destTile: TileType) {
        val destData = destTile.encodedData!!.paddedData!!
        s = (paddedSize * BYTESIZE * padding) + (padding * BYTESIZE)
        var d = (paddedSize * BYTESIZE * padding)

        for (y in 0 until size) {
            for (x in 0 until padding) {
                destData[d] = destData[s]
                destData[d + 1] = destData[s + 1]
                destData[d + 2] = destData[s + 2]
                destData[d + 3] = destData[s + 3]
                d += 4
            }
            s += (paddedSize) * BYTESIZE
            d += ((size + padding) * BYTESIZE)
        }

        destTile.blendQuadrants[7] = 1
        destTile.needsBind = true
    }

    private fun padRightOld(destTile: TileType) {
        val destData = destTile.encodedData!!.paddedData!!
        //val destData = getDestinationData(destTile)
        s = (paddedSize * BYTESIZE * padding) + (((size + padding - 1) * BYTESIZE))
        var d = (paddedSize * BYTESIZE * padding) + ((size + padding) * BYTESIZE)

        for (y in 0 until size) {
            for (x in 0 until padding) {
                destData[d] = destData[s]
                //destData[d] =  0x88.toByte()
                destData[d + 1] = destData[s + 1]
                destData[d + 2] = destData[s + 2]
                destData[d + 3] = destData[s + 3]

                d += 4
            }
            s += (paddedSize * BYTESIZE)
            d += ((size + padding) * BYTESIZE)
        }

        destTile.blendQuadrants[3] = 1
        destTile.needsBind = true
    }


    internal fun padRight(destTile: TileType) {
        val encodedData = destTile.encodedData ?: run {
            //Log.e(TAG, "padRight: encodedData is null for tile ${destTile.coordHash}. Cannot pad.")
            return
        }
        val destData = encodedData.paddedData ?: run {
            //Log.e(TAG, "padRight: paddedData is null for tile ${destTile.coordHash}. Cannot pad.")
            return
        }

        val paddedWidthBytes = paddedSize * BYTESIZE         // 516 * 4 = 2064
        val paddingBytes = padding * BYTESIZE             // 2 * 4 = 8
        val contentWidthBytes = size * BYTESIZE            // 512 * 4 = 2048
        val rightPaddingStartColOffset = paddingBytes + contentWidthBytes // 8 + 2048 = 2056

        for (y in 0 until size) { // y from 0 to 511
            val sourcePixelIndex = (padding + y) * paddedWidthBytes + paddingBytes + contentWidthBytes - BYTESIZE

            if (sourcePixelIndex < 0 || sourcePixelIndex + BYTESIZE > destData.size) {
                continue // Skip this row if source is invalid
            }

            val sourcePixelValueBytes = destData.sliceArray(sourcePixelIndex until sourcePixelIndex + BYTESIZE)

            // Iterate through the 'padding' columns in the right padding area for the current row
            for (x in 0 until padding) { // x from 0 to 1
                val destPixelIndex = (padding + y) * paddedWidthBytes + rightPaddingStartColOffset + (x * BYTESIZE)

                if (destPixelIndex >= 0 && destPixelIndex + BYTESIZE <= destData.size) {
                    sourcePixelValueBytes.copyInto(destData, destPixelIndex)
                } else {
                    //Log.e(TAG, "padRight: Destination pixel index $destPixelIndex out of bounds. y=$y, x=$x, tile=${destTile.coordHash}")
                }
            }
        }

        val sourceTopRightPixelIndex = padding * paddedWidthBytes + paddingBytes + contentWidthBytes - BYTESIZE
        val destTopRightAreaStartIndex = padding * paddedWidthBytes + rightPaddingStartColOffset
        fillCorner(destData, sourceTopRightPixelIndex, destTopRightAreaStartIndex, padding, paddedWidthBytes, BYTESIZE)
        val sourceBottomRightPixelIndex =
            (padding + size - 1) * paddedWidthBytes + paddingBytes + contentWidthBytes - BYTESIZE
        val destBottomRightAreaStartIndex = (padding + size) * paddedWidthBytes + rightPaddingStartColOffset
        fillCorner(
            destData,
            sourceBottomRightPixelIndex,
            destBottomRightAreaStartIndex,
            padding,
            paddedWidthBytes,
            BYTESIZE
        )
        destTile.blendQuadrants[3] = 1 // Mark right as padded from self
        destTile.needsBind = true
    }

    internal fun padLeft(destTile: TileType) {
        val encodedData = destTile.encodedData ?: run {
            //Log.e(TAG, "padLeft: encodedData is null for tile ${destTile.coordHash}. Cannot pad.")
            return
        }
        val destData = encodedData.paddedData ?: run {
            //Log.e(TAG, "padLeft: paddedData is null for tile ${destTile.coordHash}. Cannot pad.")
            return
        }

        val paddedWidthBytes = paddedSize * BYTESIZE
        val paddingBytes = padding * BYTESIZE

        for (y in 0 until size) {
            val sourcePixelIndex = (padding + y) * paddedWidthBytes + paddingBytes

            // Check bounds before reading the source pixel
            if (sourcePixelIndex < 0 || sourcePixelIndex + BYTESIZE > destData.size) {
                //Log.e(TAG, "padLeft: Source pixel index $sourcePixelIndex out of bounds for content copy. y=$y, tile=${destTile.coordHash}")
                continue // Skip this row if source is invalid
            }

            // Read the source pixel value (4 bytes) once for this row
            val sourcePixelValueBytes = destData.sliceArray(sourcePixelIndex until sourcePixelIndex + BYTESIZE)

            // Iterate through the 'padding' columns in the left padding area for the current row
            for (x in 0 until padding) {
                // Calculate the starting byte index for the current DESTINATION pixel in the padding area
                // Row index: padding + y
                // Column index: x
                val destPixelIndex = (padding + y) * paddedWidthBytes + (x * BYTESIZE)

                // Check bounds before writing
                if (destPixelIndex >= 0 && destPixelIndex + BYTESIZE <= destData.size) {
                    // Write the source pixel value to the destination padding pixel
                    sourcePixelValueBytes.copyInto(destData, destPixelIndex)
                    // For debugging: destData[destPixelIndex] = 0x55.toByte() // Set R channel to specific value
                } else {
                    //Log.e(TAG, "padLeft: Destination pixel index $destPixelIndex out of bounds. y=$y, x=$x, tile=${destTile.coordHash}")
                }
            }
        }

        val sourceTopLeftPixelIndex = padding * paddedWidthBytes + paddingBytes
        val destTopLeftAreaStartIndex = 0
        fillCorner(destData, sourceTopLeftPixelIndex, destTopLeftAreaStartIndex, padding, paddedWidthBytes, BYTESIZE)
        val sourceBottomLeftPixelIndex = (padding + size - 1) * paddedWidthBytes + paddingBytes
        val destBottomLeftAreaStartIndex = (padding + size) * paddedWidthBytes
        fillCorner(
            destData,
            sourceBottomLeftPixelIndex,
            destBottomLeftAreaStartIndex,
            padding,
            paddedWidthBytes,
            BYTESIZE
        )
        destTile.blendQuadrants[7] = 1 // Mark left as padded from self
        destTile.needsBind = true
    }


    internal fun padUp(destTile: TileType) {
        val encodedData = destTile.encodedData ?: run {
            //Log.e(TAG, "padUp: encodedData is null for tile ${destTile.coordHash}. Cannot pad.")
            return
        }
        val destData = encodedData.paddedData ?: run {
            //Log.e(TAG, "padUp: paddedData is null for tile ${destTile.coordHash}. Cannot pad.")
            return
        }

        val paddedWidthBytes = paddedSize * BYTESIZE         // 516 * 4 = 2064
        val contentWidthBytes = size * BYTESIZE            // 512 * 4 = 2048
        val paddingBytes = padding * BYTESIZE             // 2 * 4 = 8


        val sourceRowContentStartIndex = padding * paddedWidthBytes + paddingBytes

        for (y in 0 until padding) { // y = 0, 1

            val destRowContentStartIndex = y * paddedWidthBytes + paddingBytes

            try {
                // Copy the entire content width from the *first* content row to the destination padding row
                System.arraycopy(
                    destData,                 // Source array
                    sourceRowContentStartIndex, // Start pos in source (ALWAYS the first content row)
                    destData,                 // Destination array
                    destRowContentStartIndex, // Start pos in destination padding row
                    contentWidthBytes         // Number of bytes to copy (the content width)
                )

            } catch (e: IndexOutOfBoundsException) {
                //Log.e(TAG, "padUp: IndexOutOfBounds during main row copy for tile ${destTile.coordHash}. y=$y", e)
                return // Stop padding if an error occurs
            }
        }

        val sourceTopLeftPixelIndex = sourceRowContentStartIndex // Same as the start of the first content row's content
        val destTopLeftAreaStartIndex = 0

        fillCorner(destData, sourceTopLeftPixelIndex, destTopLeftAreaStartIndex, padding, paddedWidthBytes, BYTESIZE)
        val sourceTopRightPixelIndex = sourceRowContentStartIndex + contentWidthBytes - BYTESIZE
        val destTopRightAreaStartIndex = paddingBytes + contentWidthBytes

        fillCorner(destData, sourceTopRightPixelIndex, destTopRightAreaStartIndex, padding, paddedWidthBytes, BYTESIZE)

        destTile.blendQuadrants[1] = 1 // Mark top as padded from self
        destTile.needsBind = true      // Set only once at the end
    }

    internal fun padDown(destTile: TileType) {
        val encodedData = destTile.encodedData ?: run {
            //Log.e(TAG, "padDown: encodedData is null for tile ${destTile.coordHash}. Cannot pad.")
            return
        }
        val destData = encodedData.paddedData ?: run {
            //Log.e(TAG, "padDown: paddedData is null for tile ${destTile.coordHash}. Cannot pad.")
            return
        }

        val paddedWidthBytes = paddedSize * BYTESIZE
        val contentWidthBytes = size * BYTESIZE
        val paddingBytes = padding * BYTESIZE


        val sourceRowContentStartIndex = (padding + size - 1) * paddedWidthBytes + paddingBytes

        // Iterate through the 'padding' rows at the bottom
        for (y in 0 until padding) {
            // Calculate the starting byte index for the CONTENT area of the current DESTINATION padding row
            // Row index: padding + size + y
            // Column index (start of content): padding
            val destRowContentStartIndex = (padding + size + y) * paddedWidthBytes + paddingBytes

            try {
                // Copy the entire content width from the source row to the destination row
                System.arraycopy(
                    destData,                 // Source array
                    sourceRowContentStartIndex, // Start pos in source
                    destData,                 // Destination array
                    destRowContentStartIndex, // Start pos in destination
                    contentWidthBytes         // Number of bytes to copy
                )
                // Alternative using Kotlin extension (same effect):
                // destData.copyInto(
                //     destination = destData,
                //     destinationOffset = destRowContentStartIndex,
                //     startIndex = sourceRowContentStartIndex,
                //     endIndex = sourceRowContentStartIndex + contentWidthBytes
                // )
            } catch (e: IndexOutOfBoundsException) {
                //Log.e(TAG, "padDown: IndexOutOfBounds during main row copy for tile ${destTile.coordHash}. y=$y", e)
                return // Stop padding if an error occurs
            }
        }

        // --- 2. Pad the Corners ---

        // Bottom-Left Corner Padding
        // Source Pixel: Bottom-left pixel of the *content* area
        val sourceBottomLeftPixelIndex = (padding + size - 1) * paddedWidthBytes + paddingBytes
        // Destination Area Start: Top-left of the bottom-left *padding* square
        val destBottomLeftAreaStartIndex = (padding + size) * paddedWidthBytes

        fillCorner(
            destData,
            sourceBottomLeftPixelIndex,
            destBottomLeftAreaStartIndex,
            padding,
            paddedWidthBytes,
            BYTESIZE
        )

        // Bottom-Right Corner Padding
        // Source Pixel: Bottom-right pixel of the *content* area
        val sourceBottomRightPixelIndex =
            (padding + size - 1) * paddedWidthBytes + paddingBytes + contentWidthBytes - BYTESIZE
        // Destination Area Start: Top-left of the bottom-right *padding* square
        val destBottomRightAreaStartIndex = (padding + size) * paddedWidthBytes + paddingBytes + contentWidthBytes

        fillCorner(
            destData,
            sourceBottomRightPixelIndex,
            destBottomRightAreaStartIndex,
            padding,
            paddedWidthBytes,
            BYTESIZE
        )


        // --- 3. Update Tile State ---
        destTile.blendQuadrants[5] = 1 // Mark bottom as padded from self
        destTile.needsBind = true
    }

    internal fun fillCorner(
        destData: ByteArray,
        sourcePixelIndex: Int,
        destAreaStartIndex: Int,
        padding: Int,
        paddedWidthBytes: Int,
        bytesPerPixel: Int, // Should be BYTESIZE (4)
    ) {
        if (sourcePixelIndex < 0 || sourcePixelIndex + bytesPerPixel > destData.size) {
            //Log.e(TAG, "fillCorner($cornerName): Source pixel index $sourcePixelIndex out of bounds for tile $coordHash.")
            return
        }

        val pixelValue = destData.sliceArray(sourcePixelIndex until sourcePixelIndex + bytesPerPixel)

        for (y in 0 until padding) {
            for (x in 0 until padding) {
                val destIndex = destAreaStartIndex + (y * paddedWidthBytes) + (x * bytesPerPixel)

                if (destIndex >= 0 && destIndex + bytesPerPixel <= destData.size) {
                    pixelValue.copyInto(destData, destIndex)
                } else {
                    // Decide whether to continue or stop if one index is bad
                }
            }
        }
    }


}