package com.xweather.mapsgl.sources

import com.mapbox.maps.CoordinateBounds
import kotlin.math.max
import kotlin.math.pow

/**
 * Geographic rectangle in degrees (WGS84), same convention as Mapbox camera bounds.
 *
 * [fromMapboxUnwrappedCamera] rejects degenerate longitude spans that Mapbox occasionally returns
 * after zoom gestures (unwrapped corners collapse to a narrow strip while latitude stays wide),
 * which otherwise clips wind fill and encoded-grid symbols to a vertical band.
 */
data class VisibleGeoBounds(
    val west: Double,
    val south: Double,
    val east: Double,
    val north: Double,
) {
    companion object {
        /** Layer [LatLonBounds] fallback for gather; applies the same min lat span as [fromMapboxUnwrappedCamera]. */
        fun fromLatLonExtents(west: Double, south: Double, east: Double, north: Double): VisibleGeoBounds {
            val (s, n) = normalizedLatEdges(south, north)
            return VisibleGeoBounds(west, s, east, n)
        }

        fun fromMapboxUnwrappedCamera(
            bounds: CoordinateBounds,
            centerLongitude: Double,
            mapZoom: Double,
        ): VisibleGeoBounds {
            val w = bounds.west()
            val sRaw = bounds.south().coerceIn(-WEB_MERCATOR_MAX_LAT, WEB_MERCATOR_MAX_LAT)
            val e = bounds.east()
            val nRaw = bounds.north().coerceIn(-WEB_MERCATOR_MAX_LAT, WEB_MERCATOR_MAX_LAT)

            if (e < w) {
                val (s, n) = normalizedLatEdges(sRaw, nRaw)
                return VisibleGeoBounds(w, s, e, n)
            }

            val lonSpan = e - w
            val latSpan = nRaw - sRaw
            // When zoomed all the way out, Mapbox's "unwrapped" bounds can still report a
            // degenerate/narrow longitude span. That causes encoded-grid symbols/fills to be
            // clipped to a band and look like they don't cover the full map.
            //
            // Forcing worldLongitudeStrip at low zoom was disabled: it collapses the viewport to
            // [-180, 180] and breaks encoded tile / dateline behavior; keep Mapbox's raw span.
            /*
            if (mapZoom <= 1.5) {
                return worldLongitudeStrip(s, n)
            }
            */
            if (lonSpan < 30.0 && latSpan > 60.0) {
                return worldLongitudeStrip(sRaw, nRaw)
            }
            if (!lonSpan.isFinite() || !latSpan.isFinite() || latSpan <= 0.0 || lonSpan < 0.0) {
                return worldLongitudeStrip(sRaw, nRaw)
            }
            if (lonSpan <= 1e-9) {
                return expandLongitudeToMinSpan(centerLongitude, sRaw, nRaw, minExpectedLongitudeSpan(mapZoom))
            }

            val minLon = minExpectedLongitudeSpan(mapZoom)
            if (lonSpan < minLon && latSpan > lonSpan * 2.0) {
                return expandLongitudeToMinSpan(centerLongitude, sRaw, nRaw, minLon)
            }

            // When lonSpan > 360°, keep Mapbox's unwrapped corners (do not collapse to [-180, 180]).
            // Several visible world copies produce spans > 360°; stripping to one world hid gridded
            // symbols and sidecar tiles outside the first copy.

            val (s, n) = normalizedLatEdges(sRaw, nRaw)
            return VisibleGeoBounds(w, s, e, n)
        }
    }
}

/** Longitude in degrees to [-180, 180). */
private fun normalizeLongitudeDegrees(lon: Double): Double = (lon % 360.0 + 360.0 + 180.0) % 360.0 - 180.0

private const val WEB_MERCATOR_MAX_LAT: Double = 85.05112878

/**
 * Mapbox sometimes reports north == south (or non‑finite) for a frame at min zoom before the camera
 * fully settles. [com.xweather.mapsgl.sources.EncodedGridVectorTileSource.buildViewportGridPoints] then
 * sees zero Mercator height and returns no grid points, so instanced wind stays empty until the next pan.
 */
private fun normalizedLatEdges(south: Double, north: Double): Pair<Double, Double> {
    var s = south.coerceIn(-WEB_MERCATOR_MAX_LAT, WEB_MERCATOR_MAX_LAT)
    var n = north.coerceIn(-WEB_MERCATOR_MAX_LAT, WEB_MERCATOR_MAX_LAT)
    if (n < s) {
        val t = s
        s = n
        n = t
    }
    val minSpanDeg = 0.02
    if (n - s < minSpanDeg) {
        val mid = when {
            s.isFinite() && n.isFinite() -> ((s + n) / 2.0).coerceIn(-WEB_MERCATOR_MAX_LAT, WEB_MERCATOR_MAX_LAT)
            s.isFinite() -> s
            n.isFinite() -> n
            else -> 0.0
        }
        val half = minSpanDeg / 2.0
        s = (mid - half).coerceIn(-WEB_MERCATOR_MAX_LAT, WEB_MERCATOR_MAX_LAT)
        n = (mid + half).coerceIn(-WEB_MERCATOR_MAX_LAT, WEB_MERCATOR_MAX_LAT)
        if (n <= s) {
            s = -WEB_MERCATOR_MAX_LAT
            n = WEB_MERCATOR_MAX_LAT
        }
    }
    return s to n
}

private fun minExpectedLongitudeSpan(mapZoom: Double): Double {
    val z = mapZoom.coerceIn(0.0, 22.0)
    return max(360.0 / 2.0.pow(z) * 0.15, 5.0e-4)
}

private fun worldLongitudeStrip(south: Double, north: Double): VisibleGeoBounds {
    val (s, n) = normalizedLatEdges(south, north)
    return VisibleGeoBounds(-180.0, s, 180.0, n)
}

private fun expandLongitudeToMinSpan(
    centerLongitude: Double,
    south: Double,
    north: Double,
    minTotalSpan: Double,
): VisibleGeoBounds {
    val (sLat, nLat) = normalizedLatEdges(south, north)
    if (minTotalSpan >= 359.0) return worldLongitudeStrip(sLat, nLat)
    val half = minTotalSpan / 2.0
    val c = normalizeLongitudeDegrees(centerLongitude)
    var w = c - half
    var e = c + half
    if (e - w >= 359.0) return worldLongitudeStrip(sLat, nLat)
    while (w < -180.0) {
        w += 360.0
        e += 360.0
    }
    while (e > 180.0) {
        w -= 360.0
        e -= 360.0
    }
    if (e <= w) return worldLongitudeStrip(sLat, nLat)
    return VisibleGeoBounds(w, sLat, e, nLat)
}
