package com.xweather.mapsgl.sources.source.spec

import com.xweather.mapsgl.weather.XweatherAuthenticator
import com.xweather.mapsgl.coordinates.LatLonBounds
import com.xweather.mapsgl.types.DataSourceKind
import com.xweather.mapsgl.types.TileSize
import com.xweather.mapsgl.weather.EncodedDataset

// SourceDescriptor.kt

interface SourceDescriptor {
    val id: String
    val kind: DataSourceKind
}

val SourceDescriptor.type: DataSourceKind
    @Deprecated("Use `kind` instead.")
    get() = kind

data class ImageSourceDescriptor(
    override val id: String,
    var url: String? = null,
    var metadataUrl: String? = null,
    var minZoom: Float? = null,
    var maxZoom: Float? = null,
    var bounds: LatLonBounds? = null,
    var tileSize: TileSize? = null,
    var attribution: String? = null,
    var authenticator: XweatherAuthenticator? = null
) : SourceDescriptor {
    override val kind: DataSourceKind
        get() = DataSourceKind.RASTER
}

data class EncodedSourceDescriptor(
    override val id: String,
    var url: String? = null,
    var metadataUrl: String? = null,
    var minZoom: Float? = null,
    var maxZoom: Float? = null,
    var bounds: LatLonBounds? = null,
    var tileSize: TileSize? = null,
    var attribution: String? = null,
    var authenticator: XweatherAuthenticator? = null,
    var datasets: List<EncodedDataset>? = null
) : SourceDescriptor {
    override val kind: DataSourceKind
        get() = DataSourceKind.ENCODED
}

data class XweatherEncodedSourceDescriptor(
    override val id: String,
    var url: String?,
    var metadataUrl: String?,
    var minZoom: Float?,
    var maxZoom: Float?,
    var bounds: LatLonBounds?,
    var tileSize: TileSize?,
    var attribution: String?,
    var authenticator: XweatherAuthenticator?,
    var datasets: List<EncodedDataset>?
) : SourceDescriptor {
    override val kind: DataSourceKind
        get() = DataSourceKind.AERIS_ENCODED
}

/**
 * @param url Tile URL template. Always includes `{z}`, `{x}`, `{y}`; `{s}` is a subdomain index (1–4), see [com.xweather.mapsgl.sources.TileSource.makeTileURL].
 * If [authenticator] is an [com.xweather.mapsgl.weather.XweatherAuthenticator] (for example [com.xweather.mapsgl.weather.WeatherService.authenticator]),
 * these placeholders are also merged each request: `{accessKey}` (client id + `_` + secret), `{clientId}`, `{clientSecret}`,
 * and the documentation segment `[CLIENT_ID]_[CLIENT_SECRET]`.
 * When [authenticator] is null, [com.xweather.mapsgl.map.MapController.addSource] uses the controller's
 * [com.xweather.mapsgl.weather.WeatherService.authenticator] automatically.
 *
 * **Time in the path (Aeris / AMP-style vector tiles):** use a `{time::…}` token so each tile request uses
 * [com.xweather.mapsgl.sources.VectorTileSource.validTime] (driven by the map timeline), the same pattern as
 * `WeatherService.vectorTileURLPathTemplate` (`/{accessKey}/{code}/{z}/{x}/{y}/{time::utc:format[yyyyMMddhhmm00]}.pbf`).
 * That expands to a **14-digit** UTC offset (`yyyyMMddHHmm` plus a literal `00` suffix from the format string).
 * A hand-written **12-digit** segment (e.g. `202603061110`) is usually not the same offset the API expects and often yields
 * `missing_resource_error`. Use `…/0.pbf` only when the product docs say that offset selects the correct tiles.
 */
data class VectorSourceDescriptor(
    override val id: String,
    var url: String? = null,
    var metadataUrl: String? = null,
    var minZoom: Float? = null,
    var maxZoom: Float? = null,
    var bounds: LatLonBounds? = null,
    var tileSize: TileSize? = null,
    var attribution: String? = null,
    var authenticator: XweatherAuthenticator? = null,
) : SourceDescriptor {
    override val kind: DataSourceKind
        get() = DataSourceKind.VECTOR
}

/**
 * Configuration for a GeoJSON-backed source. At runtime, [com.xweather.mapsgl.map.MapController.addSource]
 * creates a [com.xweather.mapsgl.sources.GeoJSONSource]; use [com.xweather.mapsgl.map.MapController.getSource] and cast
 * to that type to set [com.xweather.mapsgl.sources.GeoJSONSource.data] or adjust [com.xweather.mapsgl.sources.GeoJSONSource.url]
 * after registration.
 */
data class GeoJSONSourceDescriptor(
    override val id: String,
    var url: String? = null,
    var metadataUrl: String? = null,
    var minZoom: Float? = null,
    var maxZoom: Float? = null,
    var bounds: LatLonBounds? = null,
    var tileSize: TileSize? = null,
    var attribution: String? = null,
    var authenticator: XweatherAuthenticator? = null,
) : SourceDescriptor {
    override val kind: DataSourceKind
        get() = DataSourceKind.GEOJSON
}