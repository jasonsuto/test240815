package com.xweather.mapsgl.sources.utils

import com.google.gson.JsonObject
import com.google.gson.JsonPrimitive
import com.mapbox.geojson.Feature
import com.mapbox.geojson.Point
import kotlin.math.cos

class FeatureCluster {
    fun clusterPoints(
        features: List<Feature>,
        maxDistanceKilometers: Double
    ): List<Feature> {
        val kilometersPerDegreeLatitude = 40000.0 / 360.0
        val grid = mutableMapOf<String, MutableList<Point>>()
        val clustered = mutableListOf<Feature>()

        fun key(coordinate: Point): String {
            val latDegrees = maxDistanceKilometers / kilometersPerDegreeLatitude
            val lonDegrees =
                maxDistanceKilometers / (kilometersPerDegreeLatitude * cos(Math.toRadians(coordinate.latitude())))
            val x = (coordinate.longitude() / lonDegrees).toInt()
            val y = (coordinate.latitude() / latDegrees).toInt()
            return "$x:$y"
        }

        val pointToFeature = mutableMapOf<Point, Feature>()
        for (feature in features) {
            val geometry = feature.geometry() ?: continue
            if (geometry !is Point) continue
            val k = key(geometry)
            grid.getOrPut(k) { mutableListOf() }.add(geometry)
            pointToFeature[geometry] = feature
        }

        for ((_, points) in grid) {
            val avgLon = points.map { it.longitude() }.average()
            val avgLat = points.map { it.latitude() }.average()
            val clusterPoint = Point.fromLngLat(avgLon, avgLat)

            val clusterProperties = JsonObject()
            clusterProperties.add("cluster", JsonPrimitive(true))
            clusterProperties.add("point_count", JsonPrimitive(points.size))

            // Collect and accumulate properties
            val accumulator = points.mapNotNull { pointToFeature[it]?.properties() }
                .mapNotNull { json -> Accumulator.accumulate(jsonToMap(json)) }
                .reduceOrNull { acc1, acc2 -> Accumulator.merge(acc1, acc2) }

            accumulator?.let {
                val finalized = Accumulator.finalize(it)
                if (finalized is Map<*, *>) {
                    for ((key, value) in finalized) {
                        if (key is String && value != null) {
                            // Convert value to JsonPrimitive with type handling
                            when (value) {
                                is Boolean -> clusterProperties.add(key, JsonPrimitive(value))
                                is Number -> clusterProperties.add(key, JsonPrimitive(value))
                                is String -> clusterProperties.add(key, JsonPrimitive(value))
                                else -> clusterProperties.add(key, JsonPrimitive(value.toString()))
                            }
                        }
                    }
                }
            }

            clustered.add(Feature.fromGeometry(clusterPoint, clusterProperties))
        }

        return clustered
    }

    /**
     * Removes features that are within [thresholdMeters] of each other, optimized with a spatial index.
     *
     * This version approximates proximity checks using Euclidean distance in degrees for performance.
     * For precise calculations, replace the approxDistance block with Turf distance.
     */
    fun deduplicateClosePoints(
        features: List<Feature>,
        maxDistanceKilometers: Double
    ): List<Feature> {
        if (features.size < 2) return features

        val retained = mutableListOf<Feature>()
        val grid = mutableMapOf<Pair<Int, Int>, MutableList<Point>>()

        val index = mutableListOf<Pair<Point, Feature>>()
        val thresholdDegrees = (maxDistanceKilometers * 1000.0) / 111_000.0 // rough approximation
        val cellSize = thresholdDegrees

        val thresholdSquared = cellSize * cellSize

        for (feature in features) {
            val point = feature.geometry() as? Point ?: continue
            val lng = point.longitude()
            val lat = point.latitude()

            val col = (lng / cellSize).toInt()
            val row = (lat / cellSize).toInt()
            val key = col to row

            // Search current and neighboring grid cells for close matches
            var isDuplicate = false
            for (dCol in -1..1) {
                for (dRow in -1..1) {
                    val neighborKey = (col + dCol) to (row + dRow)
                    val neighborPoints = grid[neighborKey] ?: continue

                    for (other in neighborPoints) {
                        val dx = other.longitude() - lng
                        val dy = other.latitude() - lat
                        val distSquared = dx * dx + dy * dy
                        if (distSquared < thresholdSquared) {
                            isDuplicate = true
                            break
                        }
                    }
                    if (isDuplicate) break
                }
            }

            if (!isDuplicate) {
                retained.add(feature)
                grid.getOrPut(key) { mutableListOf() }.add(point)
            }
        }

        return retained.toList()
    }

    // Recursively convert a JsonObject to a Map<String, Any?>
    private fun jsonToMap(json: JsonObject): Map<String, Any?> {
        val map = mutableMapOf<String, Any?>()
        for ((key, value) in json.entrySet()) {
            map[key] = when {
                value.isJsonPrimitive -> {
                    val primitive = value.asJsonPrimitive
                    when {
                        primitive.isBoolean -> primitive.asBoolean
                        primitive.isNumber -> primitive.asNumber
                        primitive.isString -> primitive.asString
                        else -> null
                    }
                }

                value.isJsonObject -> jsonToMap(value.asJsonObject)
                value.isJsonArray -> value.asJsonArray.mapNotNull { el ->
                    when {
                        el.isJsonPrimitive -> {
                            val p = el.asJsonPrimitive
                            when {
                                p.isBoolean -> p.asBoolean
                                p.isNumber -> p.asNumber
                                p.isString -> p.asString
                                else -> null
                            }
                        }

                        el.isJsonObject -> jsonToMap(el.asJsonObject)
                        else -> null
                    }
                }

                else -> null
            }
        }
        return map
    }
}