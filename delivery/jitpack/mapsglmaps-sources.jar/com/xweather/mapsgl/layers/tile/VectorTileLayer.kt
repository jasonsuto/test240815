package com.xweather.mapsgl.layers.tile

import com.mapbox.maps.ScreenCoordinate
import com.xweather.mapsgl.data.series.AnyTimeSeries
import com.xweather.mapsgl.data.series.MAX_REQUEST_INTERVALS
import com.xweather.mapsgl.data.series.TiledTimeSeriesDataProvider
import com.xweather.mapsgl.data.series.TimeSeriesDataProvider
import com.xweather.mapsgl.gl.math.PowerTable.Companion.powerTableI
import com.xweather.mapsgl.layers.FeatureQueryResult
import com.xweather.mapsgl.map.mapbox.MapboxMapController
import com.xweather.mapsgl.renderers.LayerRenderContext
import com.xweather.mapsgl.renderers.LayerRenderer
import com.xweather.mapsgl.renderers.TileLayerRenderer
import com.xweather.mapsgl.sources.EncodedTileSource
import com.xweather.mapsgl.sources.TileSource
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.VectorLayerPaint
import com.xweather.mapsgl.tiles.LatLonBounds
import com.xweather.mapsgl.tiles.TileBounds
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.tiles.TileData
import kotlinx.coroutines.CoroutineScope
import kotlin.math.floor

/**
 * VectorTileLayer.kt
 *
 * @author Jason Suto 5/26/25
 *
 */

// TODO: subclass TileLayer for now until all of the layer stuff can be refactored
@Suppress("Dokka")
open class VectorTileLayer(
    id: String,
    source: TileSource<TileData>,
    paint: VectorLayerPaint,
    tileLayerRenderer: TileLayerRenderer<TileData, LayerRenderContext<Any>>,
    zoomOffset: Int,
    externalScope: CoroutineScope
) : TileLayer(
    id,
    source,
    paint,
    tileLayerRenderer as TileLayerRenderer<TileData, LayerRenderContext<Any>>,
    zoomOffset,
    externalScope
) {
    private val TAG = "VectorTileLayer"

    init {
        this.paint = paint
    }

    var sourceLayer: String? = null
    var filter: Expression? = null
    /**
     * When true, [com.xweather.mapsgl.map.mapbox.MapboxMapController.addToMap] does not add a Mapbox vector style layer;
     * geometry is used only for GLES stencil (custom mask coordinator, geo mask paths).
     */
    var stencilOnly: Boolean = false
    override lateinit var timing: LayerTiming

    override var timeSeries: AnyTimeSeries? = null

    override var invertMaskLayer: Boolean
        get() = TODO("Not yet implemented")
        set(value) {}
    override var renderer: LayerRenderer<Any>
        get() = TODO("Not yet implemented")
        set(value) {}

    /** Returns the time series data provider to use for animating the layer, if any.
     * @internal
     */
    override fun createTimeSeriesDataProvider(): TimeSeriesDataProvider<TileLayer>? {
        val provider = TiledTimeSeriesDataProvider(this)
        if (source is EncodedTileSource) {
            provider.maxIntervalsPerRequest = Math.min(
                MAX_REQUEST_INTERVALS.toInt(),
                floor(/*source.maxTextureSize*/ 2048.0 / source.tileSize.width).toInt()
            )
        }

        return provider
    }

    override var sourceEventHandlers: MutableList<MapLayer.SourceEventHandler> = mutableListOf()

    override fun getVisibleTileCoords(
        latLonBounds: LatLonBounds,
        tileBounds: TileBounds,
        zoom: Double,
        fromGetRenderables: Boolean,
    ): List<TileCoord> {
        val coords: MutableList<TileCoord> = mutableListOf()
        var zoomVar = tileBounds.zoom.coerceIn(
            floor(source.minZoom).toInt(),
            floor(source.maxZoom).toInt()
        )
        for (y in tileBounds.top..tileBounds.bottom) {
            for (x in tileBounds.left..tileBounds.right) {
                if (x < 0) {
                    coords.add(TileCoord(x + powerTableI[zoomVar], y, zoomVar))
                } else if (x >= powerTableI[zoomVar]) {
                    coords.add(TileCoord(x - powerTableI[zoomVar], y, zoomVar))
                } else {
                    coords.add(TileCoord(x, y, zoomVar))
                }
            }
        }
        return coords
    }

    /**
     * Queries features for this layer within a given geometry.
     */
    override fun queryFeatures(
        zoomVar: Int,
        latTile: Int,
        lonTile: Int,
        latPix: Int,
        lonPix: Int,
        queryLon: Double?,
        queryLat: Double?,
    ): MutableList<String> {
        val returnString = mutableListOf("EMPTY STRING", "")
        return returnString
    }


    /**
     * Returns the features from this layer that intersect the current on‑screen viewport.
     */
    suspend fun getVisibleFeatures(): HashMap<String, FeatureQueryResult>? {
        // Example assumes a viewport property exists on the layer

        if (mapController is MapboxMapController) {
            val mBController = mapController as MapboxMapController as MapboxMapController

            val topLeft = ScreenCoordinate(0.0, 0.0)
            val bottomRight = ScreenCoordinate(
                mBController.mapView.width.toDouble(),
                mBController.mapView.height.toDouble()
            )
            val returnMap =
                (mapController as MapboxMapController).queryFeaturesInBox(
                    topLeft,
                    bottomRight,
                    listOf(this),
                    onTouch = false
                )
            return returnMap

        }

        return null
    }

    override fun onRemove() {}
}

