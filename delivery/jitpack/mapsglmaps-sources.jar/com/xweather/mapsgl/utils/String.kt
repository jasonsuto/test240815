package com.xweather.mapsgl.utils

import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.Date

fun String.replaceVars(variables: Map<String, Any?> = emptyMap(), urlEncoded: Boolean = false): String {
    var result = this

    // Aeris / xWeather docs often show a literal path segment; replace when accessKey is supplied (e.g. from authenticator).
    variables["accessKey"]?.toString()?.let { accessKey ->
        result = result.replace("[CLIENT_ID]_[CLIENT_SECRET]", accessKey)
    }

    result = result.replaceSubSequence("{s::", "}") { match ->
        val options = match.second.split(",")
        options.random()
    }

    for (key in listOf("time", "date", "startDate", "endDate")) {
        result = result.replaceSubSequence("{$key::", "}") { match ->
            val value = variables[key]
            if (value is Date) {
                value.convertedTo(match.second)
            } else {
                match.first // keep original token if no valid date
            }
        }
    }

    variables.forEach { (key, value) ->
        result = result.replace("{$key}", if (urlEncoded) URLEncoder.encode(value.toString(), StandardCharsets.UTF_8.name()) else value.toString())
    }

    return result
}

fun String.replaceSubSequence(
    prefix: String,
    suffix: String,
    maxReplacements: Int = Int.MAX_VALUE,
    replacement: (Pair<String, String>) -> String
): String {
    var result = this
    var searchIndex = 0
    var replacementCount = 0

    while (replacementCount < maxReplacements) {
        val prefixIndex = result.indexOf(prefix, searchIndex)
        if (prefixIndex == -1) break
        val suffixIndex = result.indexOf(suffix, prefixIndex + prefix.length)
        if (suffixIndex == -1) break

        val wholeMatch = result.substring(prefixIndex, suffixIndex + suffix.length)
        val innerMatch = result.substring(prefixIndex + prefix.length, suffixIndex)
        val replacementString = replacement(wholeMatch to innerMatch)

        result = result.replaceRange(prefixIndex, suffixIndex + suffix.length, replacementString)
        searchIndex = prefixIndex + replacementString.length
        replacementCount++
    }

    return result
}