package com.xweather.mapsgl.utils

import org.json.JSONArray
import java.text.SimpleDateFormat
import java.time.ZoneOffset
import java.util.Date
import java.util.Locale
import java.util.Calendar
import java.util.TimeZone
import kotlin.math.floor
import kotlin.math.min
import java.util.regex.Pattern

fun relativeTimeToDate(relativeDate: Date, str: String): Date {
        return if (str == "now") {
            relativeDate
        } else {
            val seconds = relativeTimeToSeconds(str)
            Date(relativeDate.time + (seconds.toLong() * 1000))
        }
    }

    fun relativeTimeToSeconds(str: String): Double {
        //Implement your logic to convert relative time strings (e.g., "10s", "5m", "2h") to seconds.
        //This function requires more detailed implementation based on your specific relative time string format.
        TODO("Implement relative time string parsing to seconds")
    }


fun reduceDatesToRange(dates: List<Date>, start: Date?, end: Date?, totalIntervals: Int): List<Date> {
    if (start == null || end == null) {
        return emptyList()
    }

    val datesInRange = dates.filter { d -> d >= start && d <= end }
    if (datesInRange.size <= totalIntervals) {
        return datesInRange
    }

    val step = datesInRange.size.toDouble() / (totalIntervals - 1)
    val result = mutableListOf<Date>()

    for (i in 0 until totalIntervals) {
        val index = min(floor(i * step).toInt(), datesInRange.size - 1)
        result.add(datesInRange[index])
    }
    return result
}


private val isoDateStrRegex: Pattern = Pattern.compile(
    "^(\\d{4})-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01])" +
            "(?:T([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)(?:\\.(\\d{1,}))?(Z|[+-]([01]\\d|2[0-3]):([0-5]\\d))?)?$"
)

private fun isString(value: Any?): Boolean = value is String

private fun isNumber(value: Any?): Boolean = value is Number

private fun isDate(value: Any?): Boolean = value is Date

private fun isoStringToDate(isoString: String): Date? {
    val matcher = isoDateStrRegex.matcher(isoString)
    if (!matcher.matches()) {
        return null
    }
    try {
        //return SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.getDefault()).parse(isoString.replace("Z", "+00:00"))
        return SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.getDefault()).parse(isoString)
    } catch (e: Exception){
        return null
    }
}


private fun toUTCDate(date: Date): Date {
    val instant = date.toInstant()
    return Date.from(instant.atOffset(ZoneOffset.UTC).toInstant())
}

fun toDate(value: Any?, utc: Boolean = false): Date? {
    if (isString(value) && isoDateStrRegex.matcher(value as String).matches()) {
        return isoStringToDate(value)
    }

    if (isString(value) || isNumber(value)) {
        val date = Date((value as? String)?.toLongOrNull() ?: (value as? Number)?.toLong() ?: 0)
        return if (utc) toUTCDate(date) else date
    }

    if (isDate(value)) return value as Date?
    return null
}


fun convertToDates(ar: List<Any?> = emptyList(), utc: Boolean = true): List<Date> {
    return ar.mapNotNull { toDate(it, utc) }
        .sortedBy { it.time }
}

fun parseDateArrayFromString(input: String): List<Date> {
    val result = mutableListOf<Date>()
    val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssX", Locale.US)

    val jsonArray = JSONArray(input)
    for (i in 0 until jsonArray.length()) {
        val dateStr = jsonArray.optString(i)
        try {
            val date = dateFormat.parse(dateStr)
            if (date != null) {
                result.add(date)
            }
        } catch (e: Exception) {
            // Log or ignore parse errors
        }
    }

    return result
}

fun formatDateArrayToString(dates: List<Date>): String {
    val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssX", Locale.US)
    dateFormat.timeZone = TimeZone.getTimeZone("UTC")

    val quotedDates = dates.map { "\"${dateFormat.format(it)}\"" }
    return "[${quotedDates.joinToString(",")}]"
}

fun Date.convertedTo(format: String = "", timeZone: TimeZone = TimeZone.getDefault()): String {
    var workingFormat = format
    val calendar = Calendar.getInstance().apply {
        this.timeZone = timeZone
        this.time = this@convertedTo
    }

    if (workingFormat.endsWith("iso")) {
        val isoFormatter = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US)
        isoFormatter.timeZone = TimeZone.getTimeZone("UTC")
        return isoFormatter.format(this)
    }

    if (workingFormat.startsWith("utc:")) {
        calendar.timeZone = TimeZone.getTimeZone("UTC")
        workingFormat = workingFormat.removePrefix("utc:")
    }

    if (workingFormat == "epoch") {
        return (this.time * 1000).toLong().toString()
    }

    val formatMatch = Regex("""^format\[(\w+)]""").find(workingFormat)
    if (formatMatch != null) {
        var result = formatMatch.groupValues[1]

        val components = mapOf<String, (Date, Calendar) -> String>(
            "yyyy" to { date, cal -> cal.get(Calendar.YEAR).toString() },
            "MM" to { date, cal -> cal.get(Calendar.MONTH).plus(1).toString().padStart(2, '0') },
            "dd" to { date, cal -> cal.get(Calendar.DAY_OF_MONTH).toString().padStart(2, '0') },
            "hh" to { date, cal -> cal.get(Calendar.HOUR_OF_DAY).toString().padStart(2, '0') },
            "mm" to { date, cal -> cal.get(Calendar.MINUTE).toString().padStart(2, '0') }
        )

        for ((code, formatter) in components) {
            result = result.replace(code, formatter(this, calendar))
        }

        return result
    }

    return this.toString()
}