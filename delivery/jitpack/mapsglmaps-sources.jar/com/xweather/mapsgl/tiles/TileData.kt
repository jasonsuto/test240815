package com.xweather.mapsgl.tiles

interface TileData {
    fun init(byteArrayOf: ByteArray)
}

