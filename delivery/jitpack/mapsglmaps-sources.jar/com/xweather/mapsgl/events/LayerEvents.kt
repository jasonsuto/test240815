import com.xweather.mapsgl.events.Event
import com.xweather.mapsgl.events.EventCustom
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.tiles.TileProtocol

data class LayerEvents(
    val show: ShowEvent,
    val hide: HideEvent,
    val tileLoad: TileLoadEvent,
    val tileError: TileErrorEvent,
    val tileDiscard: TileDiscardEvent,
    val loadStart: LoadStartEvent,
    val loadComplete: LoadCompleteEvent,
    //val paintChange: PaintChangeEvent,
    val samplePaintChange: SamplePaintChangeEvent
) {

    /** Triggered when the layer becomes visible. **/
    data class Show(val id: String = "show") : Event {
    }

    /** Triggered when the layer is hidden. **/
    data class Hide(val id: String = "hide") : Event {
    }

    /** Triggered when the layer is ready. **/
    data class Ready(val id: String = "ready") : Event {
    }

    data class ShowEvent(val tile: TileProtocol<TileData>) : EventCustom {
        override val id: String = "show"
    }

    data class HideEvent(val tile: TileProtocol<TileData>) : EventCustom {
        override val id: String = "hide"
    }

    data class TileLoadEvent(val tile: TileProtocol<TileData>) : EventCustom {
        override val id: String = "tile:load"
    }

    data class TileErrorEvent(val tile: TileProtocol<TileData>) : EventCustom {
        override val id: String = "tile:error"
    }

    data class TileDiscardEvent(val tile: TileProtocol<TileData>) : EventCustom {
        override val id: String = "tile:discard"
    }

    data class LoadStartEvent(val tile: TileProtocol<TileData>) : EventCustom {
        override val id: String = "load:start"
    }

    data class LoadCompleteEvent(val tile: TileProtocol<TileData>) : EventCustom {
        override val id: String = "load:complete"
    }

    //data class PaintChangeEvent(val tile: TileProtocol<TileData>) : EventCustom {
    //    override val id: String = "paint:change"
    // }

    /** Triggered when the layer's paint properties change **/
    data class SamplePaintChangeEvent(
        val property: String,      // Important: Add property name
        val value: Any? = null     // Important: Add the new value
    ) : EventCustom {
        override val id: String = "PAINT_CHANGE"
    }
}