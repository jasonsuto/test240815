package com.xweather.mapsgl.events

import com.xweather.mapsgl.data.series.TimeInterval
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.tiles.Tile
import com.xweather.mapsgl.tiles.TileData
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.filterIsInstance
import java.util.Date

open class EventDispatcher {

    private val TAG = "EventDispatcher"

    val eventFlow = MutableSharedFlow<Event>()

    inline fun <reified EventType : Event> publisher(eventType: Class<EventType>): Flow<EventType> {
        return eventFlow.filterIsInstance()
    }

    fun trigger(event: Event) {
        if (pr.ON) pr.p(TAG, pr.trigger,"trigger(event: Event): $event")
        eventFlow.tryEmit(event)
    }
    fun trigger(event: Event, datesArray: Array<Date>) {
        //todo: do something with date array
        if (pr.ON) pr.p(TAG, pr.trigger,"trigger() event: $event, Array<Date>: $datesArray")
        eventFlow.tryEmit(event)
    }

    fun trigger(event: Event, datesList: List<Date>) {
        //todo: do something with date array
        if (pr.ON) pr.p(TAG, pr.trigger,"trigger() event: $event, List<Date>: $datesList")
        eventFlow.tryEmit(event)
    }

    fun trigger(event: Event, intervalArray: MutableList<TimeInterval>, placeHolder: Int) {
        //todo: do something with intervalArray
        if (pr.ON) pr.p(TAG, pr.trigger,"trigger() event: $event, MutableList<TimeInterval>: $intervalArray   placeholder: $placeHolder")
        eventFlow.tryEmit(event)
    }


    fun trigger(event: Event, valueMap: Map <String, Tile<TileData>>) {
        if (pr.ON) pr.p(TAG, pr.trigger,"trigger() event: $event, Map <String, Tile<TileData>>: $valueMap")
        eventFlow.tryEmit(event)
    }




    fun triggerAny(event: Event, data: Any){
        if (pr.ON) pr.p(TAG, pr.trigger,"triggerAny() event: $event, Any: $data")

        //todo: do something with valueMap
        eventFlow.tryEmit(event)
    }

    /*
        fun trigger(event: Event, valueMap: Map <String, Any?>) {
            //todo: do something with valueMap
            eventFlow.tryEmit(event)
        }*/
    /**
     * Remove the event handler(s) for one or more events.
     *
     * @param eventType The event type to remove the listener for.
     * @param callback The specific callback to remove, or null to remove all listeners of the given type.
     * @return The current EventDispatcher instance for chaining.
     */
    fun <EventType : Any> off(eventType: EventType, callback: Listener<EventType>? = null): EventDispatcher {
        val eventListeners = listeners[eventType]

        if(eventListeners == null)
            return this

        if (callback == null) {
            eventListeners.clear()
            listeners.remove(eventType)
        } else {
            eventListeners.remove(callback)
            if (eventListeners.isEmpty()) {
                listeners.remove(eventType)
            }
        }
        return this
    }

    /** Register an event handler function for one or more events.
     * @template EventType
     * @param {EventType} type
     * @param {EventsMap[EventType]} callback
     * @param {Partial<Options>} [options]
     * @param {object} [context]
     * @returns {this}
     * @memberof EventDispatcher
     */
    fun <EventType : Enum<EventType>> on2(
        type: EventType,
        callback: EventSource/*<MyEvent>*/, //was eventListener
        options: Options?,
        context: Any?
    ): EventDispatcher {
        //println("Registered event $type with callback and options $options with context $context")
        return this
    }

    // Example using a data class if the keys are known at compile time
    data class MyRecord(val key1: String, val key2: Int)


    class EventsMap : Record<String, Any> {
        override val entries: Set<Map.Entry<String, Any>>
            get() = TODO("Not yet implemented")
        override val keys: Set<String>
            get() = TODO("Not yet implemented")
        override val size: Int
            get() = TODO("Not yet implemented")
        override val values: Collection<Any>
            get() = TODO("Not yet implemented")

        override fun containsKey(key: String): Boolean {
            TODO("Not yet implemented")
        }

        override fun containsValue(value: Any): Boolean {
            TODO("Not yet implemented")
        }

        override fun get(key: String): Any? {
            TODO("Not yet implemented")
        }

        override fun isEmpty(): Boolean {
            TODO("Not yet implemented")
        }
    }

    fun <EventType : Enum<EventType>> on(
        type: EventType,
        callback: MyEventListener<Any>,
        options: Options? = null,
        context: Any? = null
    ): EventDispatcher {
        return this
    }

    fun setNeedsUpdate() {
        TODO("Not yet implemented")
    }

    interface MyEventListener<T> : EventSource { //was event listener
        fun onEvent(data: T)
    }

    //===========================================================================================================
    //===========================================================================================================
    //MOVED FROM Animation



/*
    fun triggerDatesList(event: String, dates: List<Date>) {
        //Todo: adapt to use dates
        if(pr.ON) pr.p("Animation EventDispatcher", pr.trigger, "triggerDatesList(event: $event List<Date>: $dates)")
        listeners[event]?.forEach { listener ->
            //if(pr.ON) pr.p("EventDispatcher", pr.animationEvent, "listener(${data})")
            listener(event)
        }
    }
*/




    // mapOf("tile" to value))
}