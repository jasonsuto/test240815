package com.xweather.mapsgl.events

class MapControllerEvents {
    companion object {
        const val LAYER_ADDED = "layer:added" // in use
        const val LAYER_REMOVED = "layer:removed" // in use

        //const val LOAD_PROGRESS = "load:progress"
        //const val LOAD_COMPLETE = "load:complete"
        internal const val VISIBILITY_CHANGED = "visibility:changed" // in use
        internal const val VECTOR_LAYER_ADDED = "vectorLayer:added" // in use
    }
}