package com.xweather.mapsgl.events

import com.xweather.mapsgl.sources.DataType
import com.xweather.mapsgl.sources.ImageTileSource
import com.xweather.mapsgl.sources.SourceMetadata
import com.xweather.mapsgl.sources.TileType
import com.xweather.mapsgl.tiles.TileProtocol

/**
 *  DataSourceEvents.kt
 *
 *  Created by Jason Suto on 01/09/24.
 *  Based on the IOS version.
 *  IOS version uses structs instead of classes and objects
 */

object DataSourceEvents {
    /// Triggered when the data source begins requesting metadata.
    object MetadataLoadStart : Event {
        const val id = "metadata:load:start"
    }

    /** Triggered when the data source metadata has loaded. **/
    class MetadataLoad(val metadata: SourceMetadata<ImageTileSource.MetadataSchema>) : Event {
        val id = "metadata:load"
    }

    /** Triggered when the data source metadata has failed to load. **/
    object MetadataError : Event {
        const val id = "metadata:error"
    }

    /** Triggered when the data source data layout information has changed. **/
    object MetadataLayout : Event {
        const val id = "metadata:layout"
    }

    /** Triggered when the data source data has changed. **/
    object DataChange : Event {
        const val id = "data:change"
    }

    /** Triggered when a tile is added to the cache. **/
    class TileAdd(val tile: TileProtocol<DataType>? = null) : Event {
        //val id = "tile:add"
    }

    /** Triggered when a tile is removed from the cache. **/
    object TileRemove : Event {
        //const val id = "tile:remove"
    }

    /** Triggered when a tile is requested by the source. **/
    object TileRequest : Event {
        //const val id = "tile:request"
    }

    /** Triggered when a tile has been loaded. **/
    class TileLoad(val sourceID: String = "tile:load", val tile: TileProtocol<DataType>? = null, pending: Int? = null) :
        Event {

    }

    /** Triggered when a tile request has started. **/
    class TileLoadStart(val sourceID: String? = null, val tile: TileType? = null) : Event {
        val id = "tile:load:start"
    }

    /** Triggered when a tile request has completed. **/
    class TileLoadComplete(val id: String = "tile:load:complete", val tile: TileProtocol<DataType>? = null) : Event {
        val sourceID: String? = null
    }

    /** Triggered when a tile failed to load. */
    class TileError(
        val id: String = "tile:error",
        val sourceID: String? = null,
        val tile: TileProtocol<DataType>? = null,
        val error: Error? = null
    ) : Event {}

    /** Triggered when a tile is discarded by the source.*/
    class TileDiscard(
        val id: String = "tile:discard",
        val tile: TileProtocol<DataType>? = null,
        sourceID: String? = id
    ) : Event {

    }

    /** Triggered when a source begins loading tiles.*/
    class LoadStart(val sourceID: String? = null) : Event {
        val id = "load:start"
    }

    /** Triggered when a source has completed loading all tiles. **/
    class LoadComplete(val sourceID: String? = null) : Event {
        val id = "load:complete"
    }
}