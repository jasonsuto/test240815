package com.xweather.mapsgl.events

import kotlinx.coroutines.flow.Flow

const val TAG = "EventSource"

typealias Record<K, T> = Map<K, T>

typealias Listener<EventType> = (EventType) -> Unit
val listeners: MutableMap<Any, MutableList<Listener<*>>> = mutableMapOf()
data class MyEvent(val message: String)
typealias BaseEventsMap<E> = Map<String, (E) -> Any?>
typealias MyEvents = BaseEventsMap<MyEvent>

data class Options(
    val validEventTypes: List<Any>, // Since string and regex are possible type in JS
    val triggerLastEvent: Boolean = false // default value of false
)

interface EventSource {
    val eventDispatcher: EventDispatcher
}

inline fun <reified EventType : Event> EventSource.publisher(eventType: Class<EventType>): Flow<EventType> {
    return eventDispatcher.publisher(eventType)
}

suspend inline fun <reified EventType : Event> EventSource.subscribe(
    eventType: Class<EventType>,
    crossinline handler: (EventType) -> Unit
) {
    return publisher(eventType).collect { event -> handler(event) }
}

fun <EventType : Event> EventSource.trigger(event: EventType) {
    eventDispatcher.trigger(event)
}

interface Event

interface Cancellable {
    fun cancel()
}
