package com.xweather.mapsgl.style

import com.mapbox.maps.extension.style.layers.properties.generated.LineJoin
import com.xweather.mapsgl.Partial
import com.xweather.mapsgl.types.InterpolationMode
import com.xweather.mapsgl.types.ColorBand
import com.xweather.mapsgl.types.DataQuality
import com.xweather.mapsgl.types.Point
import com.xweather.mapsgl.types.SampleChannel
import com.xweather.mapsgl.types.Size
import com.xweather.mapsgl.types.math_type.ValueRange

val SupportedSymbolAnchors = listOf(
    "top-left", "top", "top-right", "left", "center", "right", "bottom-left", "bottom", "bottom-right"
)

//typealias SymbolAnchor = SupportedSymbolAnchors[number]
data class ColorMaskOptions(
    val channel: ColorBand,
    val value: Int,
    val colorscale: ColorScaleSpec
)

data class ColorScaleSpec(
    val stops: List<Number /*| String*/>,
    val positions: List<Number>,
    val interval: Int,
    val range: ValueRange,
    val normalized: Boolean,
    val interpolate: Boolean,
//val masks: List<ColorMaskOptions>
)

enum class ParticleDensity(val value: Float) {
    /**
     * Falls back to the count value.
     */
    COUNT(0.0f),

    /**
     * Least amount of particles will be rendered. This density setting may not provide enough speed and direction
     * information on the map since coverage is minimal.
     */
    MINIMAL(12.0f), //.5 8

    /**
     * Slightly less particle density than `normal`, allowing the most visibility to content underneath while
     * providing good speed and direction information.
     */
    LOW(30.0f),//.1 // 24

    /**
     * Provides a good amount of particles and speed and direction information while still allowing a good portion
     * of content underneath to remain visible.
     */
    NORMAL(60.0f), // 48.0

    /**
     * Slightly higher particle density than `normal` while still allowing some content underneath to remain visible.
     */
    HIGH(90.0f), // 76.0

    /**
     * Highest density that will essentially fill the layer with particle data, preventing content underneath from
     * being visible. Note that overall map performance may be affected with this setting for some hardware
     * configurations.
     */
    EXTREME(142.0f), //128
}

enum class ParticleKind {
    CIRCLE(),
    BAR()
}

class ParticleTrailLength(val value: Float) {
    companion object {
        /** .962 **/
        const val SHORT = .962

        /** .97 **/
        const val NORMAL = .97

        /** .9783 **/
        const val LONG = .9773
    }

    /** .962 **/
    // SHORT(.962f),

    /** .97 **/
    //NORMAL(.97f),

    /** .9783 **/
    //LONG(.9783f)
}


//typealias TextureAtlasType = "image" | "sdf"
data class TextureAtlasItem(
    val x: Int,
    val y: Int,
    val width: Int,
    val height: Int,
    val anchorX: Int,
    val anchorY: Int,
    val mask: Boolean
)

data class TextureAtlas(
    val columns: Int,
    val rows: Int,
    val interval: Int,
    val sdfMax: ValueRange?,
    val sdfSoft: ValueRange?
)

//data class StyleExpression(
//    val property: String,
//    val evaluator: ((Any) -> Any)?
//)

data class RasterStyleSpec(
    val opacity: Double
)

data class FillStyleSpec(
    //val color: String | Color | StyleExpression,
    val opacity: Double
)

data class StrokeStyleSpec(
    val opacity: Double,
    val thickness: Int,
    val lineJoin: LineJoin,
//val lineCap: LineCap
)

data class CircleStyleSpec(
    val radius: Int
)

data class SymbolStyleSpec(
    val size: Size,
    // val anchor: SymbolAnchor,
    val offset: Point,
    val rotation: Double,
    // val blending: Blending,
    val animated: Boolean,
    val shader: String,
    val uniforms: Map<String, Any>,
    val factor: Double,
    val pitchWithMap: Boolean,
    val rotateWithMap: Boolean,
    val billboard: Boolean,
    val atlas: TextureAtlas
)

data class GridStyleSpec(
    //val symbol: "arrow" | "wind-barb",
    val size: Int,
    val spacing: Int
)

data class ExpressionOperation(
    val dataRange: ValueRange,
    val value: ((Map<String, Int>) -> Int),
    val chunk: String
)

data class SampleStyleSpec(
    //val expression: SampleExpression,
    val expressionOperation: Partial<ExpressionOperation>,
    val channel: SampleChannel /*| List<ColorBand>*/,
    val quality: DataQuality,
    val interpolation: InterpolationMode,
    val smoothing: Int,
    val colorscale: Partial<ColorScaleSpec>,
    val opacity: Double,
    val multiband: Boolean,
    val offset: Int,
    val meld: Boolean,
    val drawRange: ValueRange
)

data class ParticleStyleSpec(
    // val type: "circle" | "bar",
    val count: Int,
    val density: ParticleDensity,
    val size: Int,
    val speed: Int,
    val trails: Boolean,
    val trailsFade: Int,
    val dropRate: Int,
    val dropRateBump: Int
)

data class HeatmapStyleSpec(
    val color: List<Number /*| String*/>,
    val radius: Int,
    val blur: Int,
    val intensity: Int,
    val weight: Int,
    val opacity: Double
)

data class ContourStyleSpec(
    val interval: Int,
    val majorInterval: Int,
    val width: Int,
    val majorWidth: Int,
    val scale: Int,
    val offset: Int
)

interface TextStyleSpec {
    val label: String
}

interface PaintStyleSpec {
    val opacity: Double
    val raster: RasterStyleSpec?
    val fill: FillStyleSpec?
    val stroke: StrokeStyleSpec?
    val circle: CircleStyleSpec?
    val symbol: SymbolStyleSpec?
    val grid: GridStyleSpec?
    val sample: SampleStyleSpec?
    val particle: ParticleStyleSpec?
    val heatmap: HeatmapStyleSpec?
    val contour: ContourStyleSpec?
    val text: TextStyleSpec?
}
