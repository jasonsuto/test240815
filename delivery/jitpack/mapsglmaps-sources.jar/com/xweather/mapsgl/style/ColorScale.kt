package com.xweather.mapsgl.style

import androidx.annotation.Keep
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import com.xweather.mapsgl.anim.EasingCurve
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.types.math_type.ValueRange
import java.lang.Double.max
import kotlin.math.round
import android.graphics.Color as AndroidColor

//data class ColorStop(val value: Double, val color: Color)

@Keep
data class ColorStop(
    val value: Double,
    val color: Color
) { // <<<< 'color' is of type androidx.compose.ui.graphics.Color

    /**
     * Secondary constructor that accepts a hex color string.
     *
     * @param value The numeric stop value.
     * @param hexColor The color as a hex string (e.g., "#RRGGBB" or "#AARRGGBB").
     */
    constructor(value: Double, hexColor: String) : this(
        value = value,
        // The result of this expression is an androidx.compose.ui.graphics.Color
        color = Color(AndroidColor.parseColor(hexColor.ensureHexPrefix()))
    )
}

// Helper extension function to ensure the hex string starts with '#'
// This can be placed in the same file or a utility file.
private fun String.ensureHexPrefix(): String {
    return if (this.startsWith("#")) this else "#$this"
}


class ColorScale(/*colors: List<Int>*/) {


    var mode: String = "rgb"
    var spread: Double = 0.0
    var _range = ValueRange(0.0, 1.0, "")

    /** The position of each color, each of which can be an actual data value or a value normalized to 0…1. */
    var _domain: List<Double> = listOf(0.0, 1.0)
    var _colors: MutableList<DataColorScale.RGB> = mutableListOf()
    var _breaks: MutableList<Double> = mutableListOf()
    var _pos: MutableList<Double> = mutableListOf()
    var _cache: MutableMap<Double, DataColorScale.RGB> = mutableMapOf()
    var _correctLightness: Boolean = false

    var unitText: String = "left blank in constructor"
    var colors: List<Color> = listOf(Color.White, Color.Black)
        private set


    var tMapDomain: (Double) -> Double = { it }


    var domain: List<Double> = listOf(0.0, 1.0)
        private set

    var stops: List<Double> = emptyList()
        private set

    var positions: List<Double> = listOf(0.0, 1.0)
        private set

    var range: ClosedRange<Double> = 0.0..1.0
        private set

    //private val colors: IntArray = colors.toIntArray()


    constructor(colors: List<Color>, domain: List<Double>? = null, stops: List<Double>? = null) : this() {
        setColors(colors)
        domain?.let { setDomain(it) }
        stops?.let {
            setStops(it)
        }
    }

    constructor(
        colorStops: List<ColorStop>,
        range: ClosedRange<Double>? = null,
        normalized: Boolean = false,
        positions: List<Double>? = null
    ) : this() {
        var scaleStops = colorStops.toMutableList()
        if (range != null && scaleStops.isNotEmpty()) {
            val stopsInRange = scaleStops.withIndex()
                .filter { range.contains(it.value.value) }

            val newStops = stopsInRange.map { it.value }.toMutableList()

            stopsInRange.firstOrNull()?.let { start ->
                if (start.value.value != range.start) {
                    val offsetIdx = max(0.0, (start.index - 1).toDouble()).toInt()
                    newStops.add(0, ColorStop(range.start, scaleStops[offsetIdx].color))
                }
            }

            stopsInRange.lastOrNull()?.let { end ->
                if (end.value.value != range.endInclusive) {
                    val offsetIdx = minOf(end.index + 1, scaleStops.size - 1)
                    newStops.add(ColorStop(range.endInclusive, scaleStops[offsetIdx].color))
                }
            }

            if (normalized) {
                scaleStops = newStops.map { stop ->
                    val normalizedValue = lerp(range.start, range.endInclusive, stop.value)
                    ColorStop(normalizedValue, stop.color)
                }.toMutableList()
            } else {
                scaleStops = newStops
            }
        }

        setColors(scaleStops.map { it.color })
        val knotValues = scaleStops.map { it.value }
        setDomain(knotValues)
        // [colorForValue] segments use [_breaks] paired with [colors]; without this, [_breaks] stays empty
        // and every lookup returns only the first knot color (e.g. solid gray precip legends).
        _breaks = knotValues.toMutableList()
        positions?.let { setPositions(it) }
        if (range != null) {
            this.range = range
        }

    }

    constructor(options: ColorScaleOptions) : this(
        colorStops = colorStopsFromOptionsStops(options.stops),
        range = options.range,
        normalized = options.normalized,
        positions = options.positions
    ) {
    }


    fun setPositions(positions: List<Double>) {
        if (positions.size != this.colors.size) {
            println("Error: Total positions must match total colors.")
            return
        }
        this.positions = positions
        this._cache.clear()
    }


    fun setDomain(domain: List<Double>) {
        _domain = domain
    }

    fun setStops(stops: List<Double>) {
        if (pr.ON) pr.p("ColorScale", pr.legendView, "setStops() stops size: ${stops.size}")
        if (stops.isEmpty()) return

        val sortedStops = stops.distinct().sorted()
        this.stops = sortedStops
        this._breaks = sortedStops.toMutableList()
        if (pr.ON) pr.p("ColorScale", pr.legendView, "setStops() setting breaks to : ${this._breaks}")
        // When stops are set, the domain should span the min and max of the stops.
        setDomain(listOf(sortedStops.first(), sortedStops.last()))
    }

    fun colorForValue(value: Double): Int {
        // Clamp the value to the current domain of the scale
        val clampedValue = value.coerceIn(_domain.firstOrNull() ?: value, _domain.lastOrNull() ?: value)

        // Ensure we have at least two breaks to form a segment. If not, we can't interpolate.
        if (_breaks.size < 2) {
            // Return the first color, or a default, as there are no segments to interpolate between.
            val color = colors.firstOrNull() ?: Color.Transparent
            return color.toArgb() // Convert Compose Color to an Int
        }

        // Find the correct segment the value falls into
        val index = _breaks.indexOfFirst { it >= clampedValue }.let {
            if (it == -1) {
                // Value is past the last break, so it belongs to the last segment.
                _breaks.size - 2
            } else {
                // Found a break, the segment is the one before it. Clamp to 0.
                maxOf(0, it - 1)
            }
        }
        // --- END OF FIX ---

        // if (pr.ON) pr.p("ColorStops", pr.legendView, "colorForValue() breaks: ${_breaks.size}  colors: ${colors.size}")

        // [_breaks] and [colors] must stay aligned (N breaks ⇒ N colors at knots). If they diverged, clamp.
        val maxSegStart = minOf(colors.size, _breaks.size) - 2
        val safeIndex = if (maxSegStart >= 0) index.coerceIn(0, maxSegStart) else 0

        val segmentStartValue = _breaks[safeIndex]
        val segmentEndValue = _breaks[safeIndex + 1]

        val startColor = colors[safeIndex]
        val endColor = colors[safeIndex + 1]

        // Calculate the interpolation factor (t) within the segment
        val t = if (segmentEndValue == segmentStartValue) {
            0.0 // Avoid division by zero if segment has no length
        } else {
            ((clampedValue - segmentStartValue) / (segmentEndValue - segmentStartValue)).coerceIn(0.0, 1.0)
        }

        // Interpolate between the start and end colors
        val red = startColor.red + t * (endColor.red - startColor.red)
        val green = startColor.green + t * (endColor.green - startColor.green)
        val blue = startColor.blue + t * (endColor.blue - startColor.blue)
        val alpha = startColor.alpha + t * (endColor.alpha - startColor.alpha)

        // Convert the interpolated float RGBA values back to an Android integer color
        return AndroidColor.argb(
            (alpha * 255).toInt(),
            (red * 255).toInt(),
            (green * 255).toInt(),
            (blue * 255).toInt()
        )
    }

    /**
     * Discrete/stepped color lookup for legend sampling.
     *
     * Unlike [colorForValue], this does not interpolate between the two colors that bound the
     * value; it returns the start color of the segment the value falls into.
     */
    private fun colorForValueNoBlend(value: Double): Int {
        val clampedValue = value.coerceIn(_domain.firstOrNull() ?: value, _domain.lastOrNull() ?: value)
        if (_breaks.size < 2) {
            return colors.firstOrNull()?.toArgb() ?: Color.Transparent.toArgb()
        }

        // If we're at (or beyond) the last break, use the last color.
        // This matches stepped legends where the upper bound should land on the final swatch.
        val lastBreak = _breaks.last()
        if (clampedValue >= lastBreak) {
            return colors.lastOrNull()?.toArgb() ?: Color.Transparent.toArgb()
        }

        val index = _breaks.indexOfFirst { it >= clampedValue }.let {
            if (it == -1) _breaks.size - 2 else maxOf(0, it - 1)
        }

        return colors.getOrNull(index)?.toArgb()
            ?: colors.lastOrNull()?.toArgb()
            ?: Color.Transparent.toArgb()
    }

    fun getColor(value: Double, bypassMap: Boolean = false): DataColorScale.RGB {
        return DataColorScale.RGB(1, 1, 1)
    }

    /**
     * Returns a distinct set of colors instead of a continuous gradient.
     * @param value
     */
    fun breaks(value: Any?) {
        if (value is Array<*> && value.isArrayOf<Number>()) {
            _breaks = value.toList() as MutableList<Double>
            if (pr.ON) pr.p("ColorScale", pr.legendView, "breaks() 1 _breaks: ${_breaks}")
            _domain = listOf(value.first(), value.last()) as List<Double>
        } else {
            val num = value as Number
            var min = Double.MAX_VALUE
            var max = Double.MIN_VALUE
            // get min/max from domain
            for (i in _domain.indices) {
                min = minOf(min, _domain[i])
                max = maxOf(max, _domain[i])
            }
            if (num.toDouble() == 0.0) {
                _breaks = listOf(min, max) as MutableList<Double>
                if (pr.ON) pr.p("ColorScale", pr.legendView, "breaks() 2 _breaks: ${_breaks}")
            } else {
                // create breaks of equal distance
                val limits = mutableListOf<Double>()
                limits.add(min)
                for (i in 1 until num.toInt()) {
                    limits.add(min + ((i.toDouble() / num.toDouble()) * (max - min)))
                }
                limits.add(max)

                _breaks = limits
                if (pr.ON) pr.p("ColorScale", pr.legendView, "breaks() 3 _breaks: ${_breaks}")
            }
        }
    }

    fun getColors(total: Int, out: String = "hex"): List<DataColorScale.RGB> {
        // if no arguments are given, return the original colors that were provided
        return if (total == 1) {
            listOf(getColor(0.5))
        } else if (total > 1) {
            val dm = _domain[0]
            val dd = _domain[1] - dm
            (0 until total).map { getColor(dm + ((it.toDouble() / (total - 1)) * dd)) }
        } else {
            _colors.toList()
        }
    }

    fun domain(domain: MutableList<Double>): Any {
        if (domain.size == 0) {
            return this._domain
        }
        //val domainList = domain
        val min = domain.first()
        val max = domain.last()
        val k = this._colors.size
        this._pos = mutableListOf()
        if ((domain.size == k) && (min != max)) {
            // update positions
            domain.forEach { d ->
                this._pos.add((d - min) / (max - min))
            }
        } else {
            for (c in 0 until k) {
                this._pos.add(c.toDouble() / (k - 1))
            }
            if (domain.size > 2) {
                // set domain map
                val tOut = domain.mapIndexed { i, d -> i.toDouble() / (domain.size - 1) }
                val tBreaks = domain.map { d -> (d - min) / (max - min) }
            }
        }
        this._domain = listOf(min, max)
        this._range = ValueRange(min, max, "")
        return this
    }


    /**
     * Generates a color ramp based on the color scale and the provided options.
     */
    fun getRamp(
        range: ClosedRange<Double>? = null,
        totalColors: Int = 0,
        interval: Double = 0.0,
        breaks: List<Double>? = null,
        interpolate: Boolean = true, // <--- This now controls the sampling logic
        normalized: Boolean = false,
        easing: EasingCurve? = null
    ): ColorRampResult {
        if (pr.ON) pr.p("ColorScale", pr.legendView, "getRamp()")

        val scale = this.clone()
        val easingFunc = easing ?: { it }
        val min = range?.start ?: scale._range.min
        val max = range?.endInclusive ?: scale._range.max

        val entries = mutableListOf<ColorRampResult.Entry>()
        var calculatedBreaks: MutableList<Double> = mutableListOf()

        // 1. Determine Breaks/Intervals logic
        if (interval > 0 || !breaks.isNullOrEmpty()) {
            if (!breaks.isNullOrEmpty()) {
                calculatedBreaks.addAll(breaks)
            } else {
                var value = nearestInterval(min, interval, roundUp = true)
                if (min < value) calculatedBreaks.add(min)
                while (value <= max) {
                    calculatedBreaks.add(value)
                    value += interval
                }
                // For stepped legends (interpolate=false), do NOT add an extra breakpoint at
                // `max` when `max` isn't on an interval boundary. Example:
                // range=0.0..14.26, interval=1.0 => breaks should be 0..14 (14 intervals).
                if (interpolate && (calculatedBreaks.lastOrNull() ?: min) < max) {
                    calculatedBreaks.add(max)
                }
            }
            calculatedBreaks = calculatedBreaks.map { nearestInterval(it, 0.001) }.toMutableList()
        } else if (!interpolate) {
            // If not interpolating and no specific breaks provided, use the scale's own breaks or domain
            calculatedBreaks = (if (_breaks.isNotEmpty()) _breaks else _domain).toMutableList()
        }

        // If we're doing discrete steps with an explicit interval, resample colors so the
        // breakpoints and swatch colors stay aligned.
        //
        // Important: we intentionally sample using the *blended* color lookup here, then
        // quantize by rendering in stepped/no-blend mode. This ensures `interval=1.0`
        // over 0.0..14.26 actually produces visible additional steps, rather than collapsing
        // back to the original (sparse) input ColorStops.
        val legendScale: ColorScale = if (!interpolate && interval > 0.0 && calculatedBreaks.isNotEmpty()) {
            val resampledScale = scale.clone()

            // Create one swatch per breakpoint so that each step is constant.
            // We sample using the original scale's blended lookup, then quantize.
            val resampledColors = calculatedBreaks.map { br ->
                Color(resampledScale.colorForValue(br))
            }
            resampledScale.setColors(resampledColors)
            resampledScale._breaks = calculatedBreaks.toMutableList()
            val d0 = calculatedBreaks.first()
            val d1 = calculatedBreaks.last()
            resampledScale.setDomain(listOf(d0, d1))
            resampledScale._range = ValueRange(d0, d1, "")
            resampledScale
        } else {
            // Never replace [_breaks] with interval-derived breaks while interpolating: [colors] still match the
            // original stops only (e.g. swell period layer uses interval=1 for raster, legend merges that into
            // BarLegendItem — setStops would create 25 breaks vs 9 colors → IndexOutOfBounds in [colorForValue]).
            if (calculatedBreaks.isNotEmpty() && !interpolate) {
                scale.setStops(calculatedBreaks)
            }
            scale
        }

        // 2. Generate Ramp Entries
        if (totalColors > 1) {
            for (i in 0 until totalColors) {
                // Determine the boundaries of this specific segment
                val segmentStart = i.toDouble() / totalColors
                val segmentEnd = (i.toDouble() + 1.0) / totalColors

                // If not interpolating, sample exactly in the middle of the segment (e.g. 0.5, 1.5, 2.5)
                // This ensures colorForValue returns a solid color for that block.
                val samplePos = if (!interpolate) {
                    (segmentStart + segmentEnd) / 2.0
                } else {
                    i.toDouble() / (totalColors - 1)
                }

                // Map position to the actual value range (e.g., 1 to 12)
                val t = if (calculatedBreaks.isNotEmpty() || !interpolate) samplePos else easingFunc(samplePos)
                val value = lerp(min, max, t)

                // Get the color. Since 'value' is a midpoint, colorForValue
                // will return the solid color for that index in the scale.
                val colorInt = if (!interpolate) {
                    legendScale.colorForValueNoBlend(value)
                } else {
                    scale.colorForValue(value)
                }

                /**
                 * IMPORTANT: 'drawPos' must be the START of the segment.
                 * This tells the Legend View: "From this position until the next entry, use this color."
                 */
                val drawPos = if (!interpolate) segmentStart else i.toDouble() / (totalColors - 1)

                entries.add(ColorRampResult.Entry(value, Color(colorInt), drawPos))
            }

            // Add a final entry at 1.0 to "close" the last solid color block
            if (!interpolate && entries.isNotEmpty()) {
                val lastColor = entries.last().color
                entries.add(ColorRampResult.Entry(max, lastColor, 1.0))
            }
        } else {
            val samples = if (calculatedBreaks.size >= 2) calculatedBreaks else scale._domain
            samples.forEach { s ->
                val pos = ((s - min) / (max - min).takeIf { it != 0.0 }!! ?: 1.0).coerceIn(0.0, 1.0)
                val colorInt = if (!interpolate) legendScale.colorForValueNoBlend(s) else scale.colorForValue(s)
                entries.add(ColorRampResult.Entry(s, Color(colorInt), pos))
            }
        }

        return ColorRampResult(
            stops = entries.filter { it.value in (min - 0.001)..(max + 0.001) },
            valueForPosition = { position ->
                val t = easingFunc(position)
                lerp(min, max, t)
            },
            positionForValue = { value ->
                if (max == min) 0.0 else ((value - min) / (max - min)).coerceIn(0.0, 1.0)
            }
        )
    }

    fun getRamp260204(
        range: ClosedRange<Double>? = null,
        totalColors: Int = 0,
        interval: Double = 0.0,
        breaks: List<Double>? = null,
        interpolate: Boolean = true,
        normalized: Boolean = false,
        easing: EasingCurve? = null
    ): ColorRampResult {
        if (pr.ON) pr.p("ColorScale", pr.legendView, "getRamp()")
        println(">>> ColorScale getRamp() breaks: ${breaks}")
        println(">>> ColorScale getRamp() inverval: ${interval}")
        println(">>> ColorScale getRamp() scale._domain: ${this._domain}")


        val scale = this.clone()
        val easingFunc = easing ?: { it }
        val min = range?.start ?: scale._range.min
        val max = range?.endInclusive ?: scale._range.max

        val entries = mutableListOf<ColorRampResult.Entry>()
        var calculatedBreaks: MutableList<Double> = mutableListOf()

        // 1. Determine Breaks/Intervals logic (Logic from JS)
        if (!interpolate) {
            calculatedBreaks = scale._domain.toMutableList()
        } else if (interval > 0 || !breaks.isNullOrEmpty()) {
            if (!breaks.isNullOrEmpty()) {
                calculatedBreaks.addAll(breaks)
            } else {
                var value = nearestInterval(min, interval, roundUp = true)
                if (min < value) calculatedBreaks.add(min)
                while (value <= max) {
                    calculatedBreaks.add(value)
                    value += interval
                }
                if ((calculatedBreaks.lastOrNull() ?: min) < max) calculatedBreaks.add(max)
            }
            // Sanitize breaks for precision
            calculatedBreaks = calculatedBreaks.map { nearestInterval(it, 0.001) }.toMutableList()
        }

        println(">>> ColorScale getRamp() calculated Breaks: ${calculatedBreaks}")
        // Apply breaks to the scale if they exist
        if (calculatedBreaks.isNotEmpty()) {
            scale.setStops(calculatedBreaks)
        }

        // 2. Generate Ramp Entries
        if (totalColors > 1) {
            for (i in 0 until totalColors) {
                val pos = i.toDouble() / (totalColors - 1)

                /**
                 * KEY ADJUSTMENT: Match JS Logic
                 * If breaks are defined, we use linear interpolation (pos).
                 * Otherwise, we apply the easing function (resampleFn).
                 */
                val t = if (calculatedBreaks.isNotEmpty()) pos else easingFunc(pos)

                val value = lerp(min, max, t)
                //println("ColorScale: getRamp() calling colorForValue() $i / ${totalColors}")
                val colorInt = if (!interpolate) {
                    scale.colorForValueNoBlend(value)
                } else {
                    scale.colorForValue(value)
                }

                // Note: We store 'pos' as the position, not 't', to keep the bar mapping linear
                entries.add(ColorRampResult.Entry(value, Color(colorInt), pos))
            }
        } else {
            // Fallback: use stops or domain if no totalColors requested
            val samples = if (calculatedBreaks.size > 2) calculatedBreaks else scale._domain
            samples.forEach { s ->
                val pos = ((s - min) / (max - min).takeIf { it != 0.0 }!!).coerceIn(0.0, 1.0)
                val colorInt = if (!interpolate) scale.colorForValueNoBlend(s) else scale.colorForValue(s)
                entries.add(ColorRampResult.Entry(s, Color(colorInt), pos))
            }
        }

        // 3. Return result with closures matching JS getValue/getPosition
        /*
        for (entry in entries) {
            println(">>> ColorScale getRamp() returning entries: ${entry}")
        }
        println(">>> ColorScale getRamp() inside of : $min - $max")
        */
        return ColorRampResult(
            stops = entries.filter { it.value in min..max },
            valueForPosition = { position ->
                // JS: getValue = (position) => lerp(min, max, resampleFn(position))
                val t = easingFunc(position)
                lerp(min, max, t)
            },
            positionForValue = { value ->
                // Basic linear mapping of value to 0..1 space
                if (max == min) 0.0 else ((value - min) / (max - min)).coerceIn(0.0, 1.0)
            }
        )
    }

    // You will also need these helper methods, likely in the same file or a utility file.
    private fun clone(): ColorScale {
        val newScale = ColorScale()
        newScale.mode = this.mode
        newScale.spread = this.spread
        newScale._range = this._range // ValueRange is a data class, so this is a shallow copy
        newScale._domain = this._domain.toList() // Create a new list instance
        newScale._colors = this._colors.toMutableList() // Create a new mutable list
        if (pr.ON) pr.p("ColorScale", pr.legendView, "clone() setting breaks to : ${this._breaks}")
        newScale._breaks = this._breaks.toMutableList() // Create a new mutable list
        newScale._pos = this._pos.toMutableList() // Create a new mutable list
        newScale._cache = this._cache.toMutableMap() // Create a new mutable map
        newScale._correctLightness = this._correctLightness

        // Copy public-facing properties as well
        newScale.colors = this.colors.toList() // Create a new list
        newScale.tMapDomain = this.tMapDomain // Copy the function reference
        newScale.domain = this.domain.toList() // Create a new list
        newScale.stops = this.stops.toList() // Create a new list
        newScale.positions = this.positions.toList() // Create a new list
        newScale.range = this.range // ClosedRange is immutable

        return newScale
    }

    private fun lerp(start: Double, end: Double, t: Double): Double {
        return start * (1.0 - t) + end * t
    }


    fun setColors(colors: List<Color>) {
        var adjustedColors = colors
        if (adjustedColors.isEmpty()) {
            adjustedColors = listOf(Color.White, Color.Black)
        } else if (adjustedColors.size == 1) {
            adjustedColors = listOf(adjustedColors.first(), adjustedColors.first())
        }
        this.colors = adjustedColors
        this.positions = defaultPositions(forCount = adjustedColors.size)
        this._cache.clear()
    }


    companion object {
        fun nearestInterval(value: Double, interval: Double, roundUp: Boolean = false): Double {
            if (interval == 0.0) return value
            val halfInterval = if (roundUp) interval else interval / 2.0
            return round((value + halfInterval) / interval) * interval
        }

        fun defaultPositions(forCount: Int): List<Double> {
            val safeCount = max(forCount.toDouble(), 2.0).toInt()
            val denominator = (safeCount - 1).toDouble()
            return (0 until safeCount).map { it.toDouble() / denominator }
        }

        fun lerpInverse(min: Double, max: Double, value: Double): Double {
            val delta = max - min
            return if (delta == 0.0) 0.0 else (value - min) / delta
        }
    }
}


/**
 * A data class that holds the result of generating a color ramp from a `ColorScale`.
 * It contains the generated color stops and functions to map between values and positions.
 *
 * @property stops A list of `Entry` objects, each representing a specific color at a specific value and position.
 * @property valueForPosition A function that returns a data value for a given normalized position (0.0 to 1.0).
 * @property positionForValue A function that returns a normalized position (0.0 to 1.0) for a given data value.
 */
data class ColorRampResult(
    val stops: List<Entry>,
    val valueForPosition: (position: Double) -> Double,
    val positionForValue: (value: Double) -> Double
) {
    /**
     * Represents a single point within the generated color ramp.
     *
     * @property value The data value at this point in the ramp.
     * @property color The `Color` at this point in the ramp.
     * @property position The normalized position (0.0 to 1.0) of this point in the ramp.
     */
    data class Entry(
        val value: Double,
        val color: Color,
        val position: Double
    )
}