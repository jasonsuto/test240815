package com.xweather.mapsgl.geometry

import com.xweather.mapsgl.types.Point

class SizeDouble(val width: Double, val height: Double = width)

class BoundsDouble(left: Double, right: Double, top: Double, bottom: Double) {
    var left = 0.0
    var right = 0.0
    var top = 0.0
    var bottom = 0.0

    val size: SizeDouble
        get() = SizeDouble(right - left, bottom - top)

    val center: Point
        get() {
            val size = size
            return Point(left + (size.width / 2), top + (size.height / 2))
        }

    init {
        this.left = left
        this.right = right
        this.top = top
        this.bottom = bottom
    }
}