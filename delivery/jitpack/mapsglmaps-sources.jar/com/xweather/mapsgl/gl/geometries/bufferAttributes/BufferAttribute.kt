package com.xweather.mapsgl.gl.geometries

import android.opengl.GLES31
import com.xweather.mapsgl.gl.geometries.bufferAttributes.AttributeDataType
import com.xweather.mapsgl.gl.geometries.bufferAttributes.IBufferAttribute

open class BufferAttribute<T>(
    override var data: T,
    override var byteLength: Int,
    override var type: AttributeDataType = AttributeDataType.Float,
    override var stride: Int = 0,
    override var offset: Int? = 0,
    override var normalized: Boolean? = false,
    override var divisor: Int? = 0
) : IBufferAttribute<T> {

    var buffer = IntArray(1)
    override val bufferId: Int
        get() {
            return buffer[0]
        }

    override var id: Int? = 0
    override var target: Int? = 0
    override var needsUpdate: Boolean? = false
    var dynamic: Boolean? = false
    var instanced: Boolean? = false

    init {
        instanced = divisor?.let { it > 0 }
    }

    // number of entries consider multi-values to make up a stride ex: (x,y, uv.x, uv.y)
    override val count: Int
        get() {
            return stride?.let { byteLength / typeByteWidth / it } ?: 0
        }

    override val glType: Int
        get() {
            return when (type) {
                AttributeDataType.FloatBuffer,
                AttributeDataType.Float -> GLES31.GL_FLOAT

                AttributeDataType.IntBuffer,
                AttributeDataType.Int -> GLES31.GL_INT

                AttributeDataType.Short,
                AttributeDataType.ShortBuffer -> GLES31.GL_SHORT

//            AttributeDataType.ByteBuffer
                else -> GLES31.GL_BYTE
            }
        }

    override val typeByteWidth: Int
        get() {
            return when (type) {
                AttributeDataType.FloatBuffer,
                AttributeDataType.Float -> FLOAT_WIDTH

                AttributeDataType.IntBuffer,
                AttributeDataType.Int -> INT_WIDTH

                AttributeDataType.ByteBuffer -> BYTE_WIDTH

                AttributeDataType.Long,
                AttributeDataType.LongBuffer -> LONG_WIDTH

                AttributeDataType.Short,
                AttributeDataType.ShortBuffer -> SHORT_WIDTH
            }
        }

    companion object {
        val LONG_WIDTH = 8
        val FLOAT_WIDTH = 4
        val INT_WIDTH = 4
        val SHORT_WIDTH = 2
        val BYTE_WIDTH = 1
    }
}

