package com.xweather.mapsgl.gl.geometries

import com.xweather.mapsgl.gl.geometries.bufferAttributes.AttributeKey
import com.xweather.mapsgl.gl.geometries.bufferAttributes.IBufferAttribute
import com.xweather.mapsgl.gl.worldObjects.DrawMode
import java.nio.FloatBuffer

class QuadGeometry() :
    AbstractGeometry(),
    Geometry {

    lateinit var buffer: FloatBuffer

    /**
     * Width along the x axis. Default value is `1`.
     *
     * @type {number}
     * @memberof PlaneGeometryOpts
     */
    open var width: Int = 0

    /**
     * Height along the y axis. Default value is `1`.
     *
     * @type {number}
     * @memberof PlaneGeometryOpts
     */
    var height: Int = 0

    /**
     * Number of horizontal segments. Default value is `1`.
     *
     * @type {number}
     * @memberof PlaneGeometryOps
     */
    var widthSegments: Int = 0

    /**
     * Number of vertical segments. Default value is `1`.
     *
     * @type {number}
     * @memberof PlaneGeometryOps
     */
    var heightSegments: Int = 0

    init {
        width = 1
        height = 1
        widthSegments = 1
        heightSegments = 1

        val colors = arrayListOf(
            1.0f, 0.0f, 0.0f, 0.5f,
            0.0f, 1.0f, 0.0f, 0.5f,
            1.0f, 0.0f, 1.0f, 0.5f,
        )
        setColor(colors.toFloatArray())

        val uvs = arrayListOf(1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f, 1.0f) //DRAW FULL TEXTURE
        setUVs(uvs.toFloatArray())
    }

    fun initVerticesWithZoom(vertices: FloatArray) {
        // if (map[AttributeKey.Position] == null)
        setVertices(vertices)
    }

    override val id: Int
        get() = TODO("Not yet implemented")
    override var map: HashMap<AttributeKey, IBufferAttribute<*>>
        get() = TODO("Not yet implemented")
        set(value) {}
    override val drawMode: DrawMode?
        get() = TODO("Not yet implemented")
    override val drawRange: DrawRange?
        get() = TODO("Not yet implemented")
    override val instanced: Instanced?
        get() = TODO("Not yet implemented")

    override lateinit var geometryBuffer: FloatBuffer
    override val bounds = GeometryBounds()

    override fun setVertices(vertices: FloatArray) {
        // Vertices
        val stride = 2
        val byteLength: Int = vertices.size * BufferAttribute.FLOAT_WIDTH
        geometryBuffer = getFloatBufferFromFloatArray(vertices)
    }
}