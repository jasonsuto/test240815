package com.xweather.mapsgl.gl.geometries.bufferAttributes

interface IBufferAttribute<T> {
    var id: Int?
    var data: T
    var byteLength: Int
    var type: AttributeDataType
    var stride: Int
    var offset: Int?
    var normalized: Boolean?
    var target: Int?    // ex. GLES31.GL_TEXTURE_2D
    var divisor: Int?
    var needsUpdate: Boolean?

    val count: Int
    val typeByteWidth: Int
    val glType: Int
    val bufferId: Int?
}

enum class AttributeDataType() {
    Long,
    Float,
    Int,
    Short,

    // byte buffer containing above types
    LongBuffer,
    FloatBuffer,
    IntBuffer,
    ShortBuffer,
    ByteBuffer
}

enum class AttributeKey() {
    Position,
    UV,
    Index,
    Normal,
    Color,
}