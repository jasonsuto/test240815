package com.xweather.mapsgl.gl.programs

import com.xweather.mapsgl.gl.geometries.bufferAttributes.AttributeKey
import com.xweather.mapsgl.gl.geometries.bufferAttributes.IBufferAttribute
import com.xweather.mapsgl.gl.worldObjects.IMesh
import com.xweather.mapsgl.gl.worldObjects.cameras.ICamera

interface IRasterTileProgram {

    var matrixArray: FloatArray?

    var handle: Int?
    fun createHandle()
    fun deleteHandle()

    fun bind(): Boolean
    fun unbind()

    fun dispose()

    fun setupShaderInputs(
        map: HashMap<AttributeKey, IBufferAttribute<*>>,
        iResolution: IntArray,
        iChannels: IntArray,
        iChannelResolutions: Array<IntArray>
    )

    fun setupModelViewProjectMatrix(camera: ICamera, mesh: IMesh)
}