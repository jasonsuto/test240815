package com.xweather.mapsgl.gl.programs

import android.content.Context
import com.xweather.mapsgl.gl.geometries.bufferAttributes.AttributeKey
import com.xweather.mapsgl.gl.geometries.bufferAttributes.IBufferAttribute

/*
 * TODO Follow Nick's WebGL as reference
 *  https://bitbucket.org/hamweather/webgl-core/src/master/src/core/Program.ts
 */
class BoxProgram(
    context: Context, vertPath: String, fragPath: String, vertexShader: Int?,
    fragmentShader: Int?, expression: String, type: Int
) :
    TriangleProgram(context, vertPath, fragPath, expression, type)/*, Program*/ {

    override fun setUniform(name: String, value: Any) {
        TODO("Not yet implemented")
    }
}