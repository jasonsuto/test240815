package com.xweather.mapsgl.gl.programs

import android.content.Context
import android.opengl.GLES31
import com.xweather.mapsgl.gl.geometries.bufferAttributes.AttributeKey
import com.xweather.mapsgl.gl.geometries.bufferAttributes.IBufferAttribute

/*
 * TODO Follow Nick's WebGL as reference
 *  https://bitbucket.org/hamweather/webgl-core/src/master/src/core/Program.ts
 */
open class PlaneProgram(
    context: Context, vertPath: String, fragPath: String, vertexShader: Int?,
    fragmentShader: Int?, expression: String, type: Int
) :
    TriangleProgram(context, vertPath, fragPath, expression, type)/*, Program*/ {

    override fun setupShaderInputs(
        map: HashMap<AttributeKey, IBufferAttribute<*>>,
        iResolution: IntArray,
        iChannels: IntArray,
        iChannelResolutions: Array<IntArray>
    ) {
        super.setupShaderInputs(map, iResolution, iChannels, iChannelResolutions)

        handle?.let { hd ->
            for (i in iChannels.indices) {
                val j = iChannels[i]
                val location = GLES31.glGetUniformLocation(hd, "iChannel$j")
                GLES31.glActiveTexture(GLES31.GL_TEXTURE0 + j)
                GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, iChannels[i])
                GLES31.glUniform1i(location, j)
            }
        }
    }

    override fun setUniform(name: String, value: Any) {
        TODO("Not yet implemented")
    }
}