package com.xweather.mapsgl.gl

import android.opengl.GLES31
import android.opengl.Matrix
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.gl.math.Matrix4
import com.xweather.mapsgl.gl.programs.RasterTileProgram
import com.xweather.mapsgl.gl.util.Map3D
import com.xweather.mapsgl.gl.worldObjects.Mesh
import com.xweather.mapsgl.gl.worldObjects.MeshInfo
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera
import com.xweather.mapsgl.map.mapbox.CameraSync
import com.xweather.mapsgl.style.ContourLayerPaint
import com.xweather.mapsgl.style.LayerPaint
import com.xweather.mapsgl.style.ParticleLayerPaint
import com.xweather.mapsgl.style.SampleLayerPaint
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.floor

/**
 *   ContourRenderPass.kt
 *
 *  A `ContourRenderPass` draws a list of Meshes that share the same `RenderMaterial`/`RenderShader`
 *  and the same `GeometryVertexElementLayout` and thus all can use the same `RenderPipeline`
 *  @author Jason Suto 02/05/26.
 */

class ContourRenderPass(
    override val label: String,
    override var meshes: List<Mesh>?,
    override var meshInfoList: List<MeshInfo>?
) : RenderPass(label, meshes, meshInfoList) {

    override var id: String = label
    private var modelMatrixHandle = 0
    private var projectionMatrixHandle = 0
    private val matrixArray = FloatArray(16)
    private val cameraArray = FloatArray(16)
    private val projectionMatrixArray = FloatArray(16)
    private val modelViewMatrixArray = FloatArray(16)
    private val checkErrorString = "glUniformMatrix4fv"
    private val checkErrorUse = "glUseProgram"
    private lateinit var progPtr: RasterTileProgram
    private var currentMesh: Mesh? = null
    private var scale = 1f
    private var newX = 0
    private var newY = 0
    private var altDataZoom = 1
    override val map3D = Map3D<Int, String>()
    override var hashString: String? = null
    override lateinit var sampleStyle: LayerPaint  //RasterStyle //was sampleStyle
    override var debugLast = -1L
    override var lastMeshCount = 0

    //var lastTime = System.currentTimeMillis()-1000L
    override var currentTime = 0L

    override var initialized = false
    private val shouldDisplayRawColors = false

    /**
     * Errors that can occur during the rendering process.
     */
    sealed class Error {
        object MustSupplyAtLeastOneMesh : Error()
        object NewElementsDontMatchVertexDescriptor : Error()
        object CouldntCreateCommandEncoder : Error()
    }

    /**
     * Prepared members of the `RenderPass`.
     */

    constructor(
        label: String = "null",
        paint: LayerPaint //PaintStyle
    ) : this(
        label,
        null,
        null,
    ) {

        if (paint is ParticleLayerPaint) {
            sampleStyle = paint
        } else if (paint is SampleLayerPaint) {
            sampleStyle = paint
        } else {
            sampleStyle = paint as ContourLayerPaint
        }
    }

    /**
     *
     * Should loop through renderables and call draw() on each.
     *
     * Called from TileLayerRenderer.draw()
     *
     */
    override fun render(texHashMap: HashMap<String, Int>, camera: Camera) {
        var phaseAString = ""
        var phaseBString = ""
        var finalMeld = 0f
        val layerInfo = Timeline.sourceTimeHash[label]

        val viewportMeshes = meshInfoList.orEmpty()
        if (layerInfo != null) {
            if (pr.ON) pr.p(TAG, pr.noLoad, "render() layerInfo was NOT null, using layerInfo")
            val resolved = if (viewportMeshes.isNotEmpty()) {
                applyLayerViewportPlayback(layerInfo, viewportMeshes, texHashMap)
            } else {
                val target = layerInfo.computeGlobalAnimationTarget()
                LayerDrawPhases(target.phaseA, target.phaseB, target.meld).also {
                    layerInfo.commitDisplayPhases(it.phaseA, it.phaseB, it.meld, true, null)
                }
            }
            phaseAString = Timeline.getTimeString(0, resolved.phaseA)
            phaseBString = Timeline.getTimeString(1, resolved.phaseB)
            finalMeld = resolved.meld
        } else {
            if (pr.ON) pr.p(TAG, pr.noLoad, "render() layerInfo was  null, falling back to TimeLine", 2)
            if (Timeline.currentPhaseA < Timeline.timeStrings.size && Timeline.currentPhaseB < Timeline.timeStrings.size) {
                phaseAString = Timeline.timeStrings[Timeline.currentPhaseA]
                phaseBString = Timeline.timeStrings[Timeline.currentPhaseB]
                finalMeld = Timeline.dataMeld
            }
        }

        if (meshes != null && meshes!!.isNotEmpty()) {
            currentMesh = meshes!!.first()

            //if (pr.ON) pr.p(TAG, pr.noLoad, "render() about to assign progPtr")
            progPtr = (currentMesh!!.program as RasterTileProgram)
            progPtr.bind().also { checkError(checkErrorUse) }// Add program to OpenGL ES environment
            progPtr.useOncePerFrame()
            progPtr.use()
            progPtr.useContour()
            progPtr.setColorBandTexture()
            progPtr.setMeld(finalMeld)

            currentTime = System.currentTimeMillis()

            GLES31.glUniform1i(progPtr.singlePointModeLoc, 0)
            GLES31.glUniform1i(progPtr.useRawColorsLocation, if (shouldDisplayRawColors) 1 else 0)
            RenderPass.bindRasterTileVertexAttributes(progPtr)
            val mapboxProj = CameraSync.mapboxProjectionMatrix
            val mapboxMv = CameraSync.mapboxModelViewMatrix
            val useMapboxNativeMv =
                mapboxProj != null && mapboxMv != null && mapboxProj.size >= 16 && mapboxMv.size >= 16
            if (useMapboxNativeMv) {
                System.arraycopy(mapboxProj, 0, projectionMatrixArray, 0, 16)
                System.arraycopy(mapboxMv, 0, cameraArray, 0, 16)
            } else {
                matrixToFloatArray(camera.projectionMatrix, projectionMatrixArray)
                matrixToFloatArray(camera.viewMatrix, cameraArray)
            }

            projectionMatrixHandle = GLES31.glGetUniformLocation(progPtr.programInt, "projectionMatrix")
                .also { checkError("glGetUniformLocation") }
            GLES31.glUniformMatrix4fv(projectionMatrixHandle, 1, false, projectionMatrixArray, 0)
                .also { checkError("glUniformMatrix4fv") }

            modelMatrixHandle = GLES31.glGetUniformLocation(progPtr.programInt, "modelViewMatrix")
                .also { checkError("glGetUniformLocation") }
            progPtr.useOncePerFrame()
            progPtr.setColorBandTexture()
            sampleStyle.let { progPtr.setOpacity(it.opacity) }


            // if (pr.ON) {
            // if (lastMeshCount != meshInfoList!!.size) {
            //     pr.p(TAG, pr.tileCount, "render() meshInfoList.size: ${meshInfoList!!.size}")
            lastMeshCount = meshInfoList!!.size
            // }
            // }

            if (true /*|| phaseA < Timeline.timeStrings.size*/) {
                GLES31.glViewport(0, 0, camera.resX, camera.resY)
                if (stencilBeforeTile != null) {
                    stencilPassBegin?.invoke()
                }
                meshInfoList?.forEach { meshInfo ->
                    if (true /*|| searchKey == meshInfo.hashCode*/) {

                        Matrix.setIdentityM(matrixArray, 0); // initialize to identity matrix
                        val mapZoomNow =
                            CameraSync.customLayerRenderZoom ?: CameraSync.mapZoom
                        val overscale = if (useMapboxNativeMv) {
                            CameraSync.tileRasterOverscale(mapZoomNow, meshInfo.z.toInt())
                        } else {
                            1f
                        }
                        Matrix.scaleM(matrixArray, 0, 512f * overscale, 512f * overscale, 1f)
                        Matrix.translateM(matrixArray, 0, meshInfo.x, meshInfo.y, 0f)
                        Matrix.multiplyMM(modelViewMatrixArray, 0, cameraArray, 0, matrixArray, 0) //works
                        GLES31.glUniformMatrix4fv(
                            modelMatrixHandle,
                            1,
                            false,
                            modelViewMatrixArray,
                            0
                        )

                        datelineAdjustment(meshInfo)
                        //val hashKey = "${meshInfo.hashCode}${Timeline.timeStrings[phaseA]}"
                        val hashKey = "${meshInfo.hashCode}${phaseAString}"
                        //val hashKey =  "0:0/0/0/[\"2025-04-22T21:00:00Z\"]"

                        texHashMap[hashKey]?.let { // found ideal tile for phase A

                            if (pr.ON) pr.p(TAG, pr.noLoad, "render() found Ideal for phaseA: ${hashKey}")

                            progPtr.updateTexture1Size(1f, 1f, 0f, 0f)
                            var hash2: String? = "${meshInfo.hashCode}${phaseBString}"
                            if (texHashMap[hash2] != null) { //found full version of both textures
                                if (pr.ON) pr.p(TAG, pr.downloadRequest, "h2: $hash2 found, trying to draw!")
                                progPtr.updateTexture2Size(1f, 1f, 0f, 0f)
                                currentMesh?.draw2Textures(it, texHashMap[hash2]!!)
                                //println("$TAG, render() draw $it, ${texHashMap[hash2]}")
                            } else {
                                if (pr.ON) pr.p(TAG, pr.downloadRequest, "h2: ${hash2} NOT FOUND found")
                                hash2 = determinePartial(meshInfo, texHashMap, phaseBString, 2)
                                if (hash2 != null) {
                                    pr.p(TAG, pr.tilePick, "render() A drawing 2 tiles ", 2)
                                    currentMesh?.draw2Textures(it, texHashMap[hash2]!!)
                                    //println("$TAG, render() draw $it, ${texHashMap[hash2]}")
                                } else if (finalMeld != 1f) {
                                    pr.p(TAG, pr.rasterPart, "render() A drawing 1st tile ", 2)
                                    currentMesh?.draw(it)
                                    //println("$TAG, render() draw $it")
                                } else {
                                    pr.p(
                                        TAG,
                                        pr.rasterPart,
                                        "render() A wanted to draw last tile, can only find first: ",
                                        2
                                    )
                                    //println("$TAG, render() draw $it")
                                    currentMesh?.draw(it)
                                }
                            }
                        } ?: run { //Display lower-res texture if available. Also accounts for world-wrap


                            if (pr.ON) pr.p(TAG, pr.noLoad, "render() DID NOT find Ideal for phaseA: ${hashKey}")

                            val meshString1 = determinePartial(meshInfo, texHashMap, phaseAString, 1)

                            var meshString2: String? =
                                "${meshInfo.hashCode}${phaseBString}" // the exact tile
                            if (texHashMap[meshString2] == null) { // if exact tile not found, use partial
                                meshString2 = determinePartial(meshInfo, texHashMap, phaseBString, 2)
                            } else {
                                progPtr.updateTexture2Size(1f, 1f, 0f, 0f)
                            }
                            if (meshString1 != null) {
                                if (meshString2 != null) {
                                    if (pr.ON) pr.p(TAG, pr.rasterPart, "B1 draw 2")
                                    currentMesh?.draw2Textures(texHashMap[meshString1]!!, texHashMap[meshString2]!!)
                                } else {
                                    if (texHashMap.containsKey(meshString1)) {
                                        pr.p(TAG, pr.rasterPart, "render() B2 drawing 1st tile ", 2)
                                        currentMesh?.draw(texHashMap[meshString1]!!)
                                    } else {
                                    }
                                }
                            } else { // Used in case of the timeline being all the way at the right end, just draw the last interval
                                if (texHashMap[meshString2] != null) {
                                    if (finalMeld == 1f) {
                                        determinePartial(
                                            meshInfo,
                                            texHashMap,
                                            phaseBString,
                                            1
                                        ) // 250424 fix for raster tiles when meld is 1.0
                                    }
                                    currentMesh?.draw2Textures(texHashMap[meshString2]!!, texHashMap[meshString2]!!)
                                } else {
                                    pr.p(TAG, pr.flicker, "render() NOT DRAWING ANYTHING", 2)
                                }
                            }
                        } // end run
                        stencilAfterTile?.invoke()
                    } // MATCH TOUCH TILE
                } // end for each

            }      // end if(phaseA < Timeline.times!!.size){


            progPtr.unbind()
        } // end  if (meshes != null && meshes!!.isNotEmpty()) {
        //if(pr.ON)pr.p(TAG, pr.trackRender,"render() exited")
    } // end render()

    private fun determinePartial(
        meshInfo: MeshInfo,
        texHashMap: HashMap<String, Int>,
        currentPhaseString: String,
        textureNumber: Int
    ): String? {
        scale = 1.0f //was .5f. Changed to fix low-res accross the dateline.
        altDataZoom = floor(meshInfo.z  /*- 1*/).toInt()
        var partialHashString: String
        while (altDataZoom > -1) {
            if (pr.ON) pr.p(TAG, pr.partial, "render() in the loop, altDataZoom:$altDataZoom")
            newX = (meshInfo.x * scale).toInt()
            newY = (meshInfo.y * scale).toInt()
            //consider trying to give this it's own String, may fix when pulls wrong tile?
            partialHashString = "0:${(altDataZoom)}/${newX}/${newY}/${currentPhaseString}"
            //if(pr.ON) pr.p(TAG, pr.obs_play, "hashString: ${hashString3}")

            if (texHashMap[partialHashString] != null) {
                updateTextureSizes(meshInfo, scale, newX, newY, textureNumber)
                return partialHashString as String
            } else {
                altDataZoom--
            }
            scale *= .5f
        }
        return null
    }

    /** Used to calculate the scale value for the texture in the shader. Used for tile partial scaling **/
    override fun updateTextureSizes(mInfo: MeshInfo, scale: Float, nX: Int, nY: Int, textureNumber: Int) {
        var xOffs = (mInfo.x * scale) - nX
        while (xOffs < 0f) xOffs += 1f // To handle wrapping around date line
        while (xOffs >= 1f) xOffs -= 1f
        val yOffs = (mInfo.y * scale) - nY
        if (textureNumber == 1) {
            progPtr.updateTexture1Size(scale, scale, xOffs, yOffs)
        } else {
            progPtr.updateTexture2Size(scale, scale, xOffs, yOffs)
        }
    }

    /** Puts a given Matrix4 into a given FloatArray
     * @return FloatArray
     */
    override fun matrixToFloatArray(m: Matrix4, r: FloatArray): FloatArray { //reuse existing array
        r[0] = m.elements[0]; r[1] = m.elements[1]; r[2] = m.elements[2]; r[3] = m.elements[3]
        r[4] = m.elements[4]; r[5] = m.elements[5]; r[6] = m.elements[6]; r[7] = m.elements[7]
        r[8] = m.elements[8]; r[9] = m.elements[9]; r[10] = m.elements[10]; r[11] = m.elements[11]
        r[12] = m.elements[12]; r[13] = m.elements[13]; r[14] = m.elements[14]; r[15] = m.elements[15]
        return r
    }

    private fun checkError(cmd: String? = null) {
        if (true /*BuildConfig.DEBUG*/) {
            when (val error = GLES31.glGetError()) {
                GLES31.GL_NO_ERROR -> {/*println("TAG $cmd -> no error")*/
                }

                GLES31.GL_INVALID_ENUM -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_ENUM")
                GLES31.GL_INVALID_VALUE -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_VALUE")
                GLES31.GL_INVALID_OPERATION -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_OPERATION")
                GLES31.GL_INVALID_FRAMEBUFFER_OPERATION -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_FRAMEBUFFER_OPERATION")
                GLES31.GL_OUT_OF_MEMORY -> throw RuntimeException("$cmd -> error in gl: GL_OUT_OF_MEMORY")
                else -> throw RuntimeException("$cmd -> error in gl: $error")
            }
        }
    }

    /**
     * Finds the two values in a sorted list that a target value falls between,
     * and calculates the fractional distance between them.
     *
     * @param targetValue The long value to locate within the list.
     * @param sortedList The sorted list of longs to search within.
     * @return An [InterpolationResult] containing the lower and upper bound values and the fraction (0.0f to 1.0f).
     *         Returns null if the list has fewer than two elements or the target is outside the list's range.
     */
    override fun findInterpolationValues(targetValue: Long, sortedList: List<Long>): InterpolationResult? {
        // We need at least two points to form a range.
        if (sortedList.size < 2) {
            return null
        }

        // Use binarySearch to find the index or the insertion point.
        val searchResult = sortedList.binarySearch(targetValue)

        if (searchResult >= 0) {
            // Exact match found. The value is exactly on a point, so the fraction is 0.
            val value = sortedList[searchResult]
            return InterpolationResult(value, value, 0.0f, searchResult, searchResult)
        }

        // The value was not found. Convert the negative searchResult to an insertion point.
        val insertionPoint = -(searchResult + 1)

        // Handle edge cases: target is outside the entire range of the list.
        if (insertionPoint == 0 || insertionPoint == sortedList.size) {
            return null // Target is before the first element or after the last one.
        }

        // The target is between two elements.
        val lowerIndex = insertionPoint - 1
        val upperIndex = insertionPoint
        val lowerBound = sortedList[lowerIndex]
        val upperBound = sortedList[upperIndex]

        // Prevent division by zero if the bounds are identical.
        val range = (upperBound - lowerBound).toFloat()
        if (range == 0f) {
            return InterpolationResult(lowerBound, upperBound, 0.0f, lowerIndex, upperIndex)
        }

        // Calculate the fractional position of the target within the range.
        val position = (targetValue - lowerBound).toFloat()
        val fraction = position / range

        return InterpolationResult(
            lowerBound,
            upperBound,
            fraction.coerceIn(0.0f, 1.0f),
            lowerIndex,
            upperIndex
        )
    }

    companion object {
        /**
         * Checks if a `Mesh` element conforms to the given `GeometryVertexElementLayout`.
         */
        private fun meshesElementConforms(element: Mesh /*geometryVertexElementLayout: GeometryVertexElementLayout*/): Boolean {
            //return element.geometry.vertexElementLayout == geometryVertexElementLayout
            return true
        }

        /**
         * Checks if all `Mesh` elements conform to the given `GeometryVertexElementLayout`.
         */
        private fun meshesElementsConform(elements: Collection<Mesh>/*, geometryVertexElementLayout: GeometryVertexElementLayout*/): Boolean {
            //return elements.all { meshesElementConforms(it, geometryVertexElementLayout) }
            return true
        }

        /**
         * Filters out `Mesh` elements that do not conform to the given `GeometryVertexElementLayout`.
         */
        private fun conformingMeshesElements(elements: Collection<Mesh>/*, geometryVertexElementLayout: GeometryVertexElementLayout*/): List<Mesh>? {
            //return elements.filter { meshesElementConforms(it, geometryVertexElementLayout) }
            return null
        }

        private const val TAG = "RenderPass"
        private const val BYTES_PER_FLOAT = 4
        const val COORDS_PER_VERTEX = 2
        private const val NUM_TILES = 1
        private const val VERTEX_COUNT = NUM_TILES * 4
        const val VERTEX_STRIDE = COORDS_PER_VERTEX * BYTES_PER_FLOAT
        const val TEXTURE_SIZE = 2
        const val TEXTURE_STRIDE = TEXTURE_SIZE * BYTES_PER_FLOAT
        //private var textureAlpha = .5f

        private val vertexArray = UnitQuad2DGeometry.genQuad1x1()
        val vertexBuffer =
            ByteBuffer.allocateDirect(VERTEX_COUNT * COORDS_PER_VERTEX * BYTES_PER_FLOAT).run {
                order(ByteOrder.nativeOrder())// use the device hardware's native byte order
                asFloatBuffer()       // create a floating point buffer from the ByteBuffer
            }
        private val textureArray = UnitQuad2DGeometry.genTexCoords1Quad()
        val textureCoordinatesBuffer = ByteBuffer.allocateDirect(textureArray.size * 4).run {
            order(ByteOrder.nativeOrder())
            asFloatBuffer()
        }

        init {
            vertexBuffer.apply {
                clear()
                put(vertexArray)
                rewind()
            }

            textureCoordinatesBuffer.apply {
                clear()
                put(textureArray)
                rewind()
                // position(0)
            }
        }
    }

    /**  Fix for not finding tiles across dateline (-180 or 180) **/
    private fun datelineAdjustment(meshInfo: MeshInfo) {
        if (pr.ON) pr.p(
            TAG,
            pr.hashmapLong,
            "datelineAdjustment(), hashString: ${hashString}    meshInfo.hashcode:, ${meshInfo.hashCode}  "
        )
        val n = powerTableI[meshInfo.z.toInt()]
        if (n <= 0) return
        var x = meshInfo.x
        while (x < 0f) x += n
        while (x >= n) x -= n
        meshInfo.x = x
        meshInfo.hashCode = "0:${meshInfo.z.toInt()}/${meshInfo.x.toInt()}/${meshInfo.y.toInt()}"
    }


    /**  Fix for not finding tiles across dateline (-180 or 180) **/
    private val powerTableI = intArrayOf(
        1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048,
        4096, 8192, 16384, 32768, 65536, 131072, 262144, 524288, 1048576, 2097152, 4194304
    )
}
