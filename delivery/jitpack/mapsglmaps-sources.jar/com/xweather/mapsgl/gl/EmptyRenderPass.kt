package com.xweather.mapsgl.gl

import com.xweather.mapsgl.gl.programs.RasterTileProgram
import com.xweather.mapsgl.gl.worldObjects.Mesh
import com.xweather.mapsgl.gl.worldObjects.MeshInfo
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera
import com.xweather.mapsgl.style.GridLayerPaint
import com.xweather.mapsgl.style.LayerPaint
import com.xweather.mapsgl.style.ParticleLayerPaint
import com.xweather.mapsgl.style.RasterLayerPaint
import com.xweather.mapsgl.style.SampleLayerPaint

open class EmptyRenderPass(
    override val label: String,
    override var meshes: List<Mesh>?,
    override var meshInfoList: List<MeshInfo>?
) : RenderPass(label, meshes, meshInfoList) {

    override var id: String = label
    private var modelMatrixHandle = 0
    private var projectionMatrixHandle = 0
    private val matrixArray = FloatArray(16)
    private val cameraArray = FloatArray(16)
    private val projectionMatrixArray = FloatArray(16)
    private val modelViewMatrixArray = FloatArray(16)
    private val checkErrorString = "glUniformMatrix4fv"
    private val checkErrorUse = "glUseProgram"
    private lateinit var progPtr: RasterTileProgram
    private var currentMesh: Mesh? = null
    private var scale = 1f
    private var newX = 0
    private var newY = 0
    private var altDataZoom = 1

    private var frozenForIncomplete: Boolean = false
    private var lastStablePhaseAString: String? = null
    private var freezeHoldFrames: Int = 0
    private val freezeHoldFramesMax: Int = 6

    override var initialized = false
    private val shouldDisplayRawColors = false

    sealed class Error {
        object MustSupplyAtLeastOneMesh : Error()
        object NewElementsDontMatchVertexDescriptor : Error()
        object CouldntCreateCommandEncoder : Error()
    }

    constructor(
        label: String = "null",
        paint: LayerPaint
    ) : this(
        label,
        null,
        null,
    ) {
        if (paint is ParticleLayerPaint) {
            sampleStyle = paint as ParticleLayerPaint
        } else if (paint is SampleLayerPaint) {
            sampleStyle = paint
        } else if (paint is GridLayerPaint) {
            sampleStyle = paint as GridLayerPaint
        } else {
            sampleStyle = paint as RasterLayerPaint
        }
    }

    override fun render(texHashMap: HashMap<String, Int>, camera: Camera) {
    }
}

