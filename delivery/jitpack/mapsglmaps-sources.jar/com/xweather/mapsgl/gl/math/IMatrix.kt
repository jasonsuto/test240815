package com.xweather.mapsgl.gl.math

interface IMatrix {
    var elements: ArrayList<Float>
    fun isEqual(m: IMatrix): Boolean
    fun clone(): IMatrix
    fun toArray(array: ArrayList<Float>, offset: Int = 0): ArrayList<Float>
    fun fromArray(array: List<Float>, offset: Int = 0): IMatrix
}