package com.xweather.mapsgl.gl.math

interface IVector {
    fun fromArray(array: FloatArray, offset: Int = 0): IVector
    fun toArray(array: FloatArray, offset: Int = 0): FloatArray
    fun length(): Float
    fun copy(v: IVector): IVector
    fun clone(): IVector
    fun add(v3: IVector): IVector
    fun addScalar(s: Float): IVector
    fun subtract(v: IVector): IVector
    fun subtractScalar(s: Float): IVector
    fun multiply(v: IVector): IVector
    fun multiplyScalar(s: Float): IVector
    fun divide(v: IVector): IVector
    fun divideScalar(s: Float): IVector
    fun distanceTo(v: IVector): Float
    fun dot(v: IVector): Float
    fun isEqual(v: IVector): Boolean
    fun lerp(v: IVector, factor: Float): IVector
    fun normalize(): IVector
    fun scale(v: Float): IVector
    fun applyMatrix4(m: Matrix4): IVector
}