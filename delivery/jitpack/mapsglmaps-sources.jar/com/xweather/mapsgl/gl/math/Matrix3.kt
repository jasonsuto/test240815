package com.xweather.mapsgl.gl.math

/*
 * 3x3 Matrix
 */
class Matrix3 : AbstractMatrix(), IMatrix {

    companion object {
        private val IDENTITY_ELEMENTS = listOf(
            1.0f, 0.0f, 0.0f,
            0.0f, 1.0f, 0.0f,
            0.0f, 0.0f, 1.0f
        )
        private val ZERO_ELEMENTS = listOf(
            0.0f, 0.0f, 0.0f,
            0.0f, 0.0f, 0.0f,
            0.0f, 0.0f, 0.0f
        )

        fun identity() = Matrix3().insertElements(IDENTITY_ELEMENTS)
        fun zero() = Matrix3().insertElements(ZERO_ELEMENTS)
        fun copy(m: Matrix3) = m.clone() as Matrix3
    }

    init {
        elements.addAll(IDENTITY_ELEMENTS)
    }

    fun set(
        m00: Float, m10: Float, m20: Float,
        m01: Float, m11: Float, m21: Float,
        m02: Float, m12: Float, m22: Float
    ): Matrix3 {
        this.elements.clear()
        return insertElements(
            listOf(
                m00, m10, m20,
                m01, m11, m21,
                m02, m12, m22
            )
        )
    }

    fun determinant() = elements[0] * (elements[4] * elements[8] - elements[5] * elements[7]) -
            elements[1] * (elements[3] * elements[8] - elements[5] * elements[6]) +
            elements[2] * (elements[3] * elements[7] - elements[4] * elements[6])

    private fun insertElements(list: List<Float>): Matrix3 {
        var matrix = Matrix3()
        matrix.elements.clear()
        matrix.elements.addAll(list)
        return matrix
    }

    /*
     * TODO Verify math correctness
     */
    fun invert(): Matrix3? {
        // determinant 0 => no inverse
        val d = determinant()
        if (d != 0f) {
            val mm0 = elements[4] * elements[8] - elements[5] * elements[7]
            val mm1 = elements[3] * elements[8] - elements[5] * elements[6]
            val mm2 = elements[3] * elements[7] - elements[4] * elements[6]
            // 2nd row
            val mm3 = elements[1] * elements[8] - elements[2] * elements[7]
            val mm4 = elements[0] * elements[8] - elements[2] * elements[6]
            val mm5 = elements[0] * elements[7] - elements[1] * elements[6]
            // 3rd row
            val mm6 = elements[1] * elements[5] - elements[2] * elements[4]
            val mm7 = elements[0] * elements[5] - elements[2] * elements[3]
            val mm8 = elements[0] * elements[4] - elements[1] * elements[3]

            val list =
                listOf(
                    d * mm0,
                    -d * mm1,
                    d * mm2,
                    -d * mm3,
                    d * mm4,
                    -d * mm5,
                    d * mm6,
                    -d * mm7,
                    d * mm8
                )
            val m = Matrix3().fromArray(list) as Matrix3
            return m.transpose()
        }
        return null
    }

    /*
     * https://github.com/graphitemaster/normals_revisited
     */
    fun getNormalMatrix(m: Matrix4): Matrix4? {
        val inv = m.invert()
        return inv?.transpose()
    }

    fun rotate(radians: Double) = insertElements(
        listOf(
            Math.cos(radians).toFloat(),
            Math.sin(radians).toFloat() * -1f,
            0.0f,

            Math.sin(radians).toFloat(),
            Math.cos(radians).toFloat(),
            0.0f,

            0.0f,
            0.0f,
            1.0f
        )
    )

    fun scale(v2: Vector2) = insertElements(
        listOf(
            v2.x,
            0.0f,
            0.0f,

            0.0f,
            v2.y,
            0.0f,

            0.0f,
            0.0f,
            1.0f
        )
    )

    fun scaleScalar(s: Float) = insertElements(
        listOf(
            s * this.elements[0],
            this.elements[1],
            this.elements[2],

            this.elements[3],
            s * this.elements[4],
            this.elements[5],

            this.elements[6],
            this.elements[7],
            this.elements[8],
        )
    )

    fun translate(v2: Vector2) = insertElements(
        listOf(
            1.0f,
            0.0f,
            v2.x,

            0.0f,
            1.0f,
            v2.y,

            0.0f,
            0.0f,
            1.0f,
        )
    )

    fun transpose() = insertElements(
        listOf(
            this.elements[0],
            this.elements[3],
            this.elements[6],

            this.elements[1],
            this.elements[4],
            this.elements[7],

            this.elements[2],
            this.elements[5],
            this.elements[8],
        )
    )

    fun multiply(m: Matrix3) = insertElements(
        listOf(
            this.elements[0] * m.elements[0] + this.elements[1] * m.elements[3] + this.elements[2] * m.elements[6],
            this.elements[0] * m.elements[1] + this.elements[1] * m.elements[4] + this.elements[2] * m.elements[7],
            this.elements[0] * m.elements[2] + this.elements[1] * m.elements[5] + this.elements[2] * m.elements[8],

            this.elements[3] * m.elements[0] + this.elements[4] * m.elements[3] + this.elements[5] * m.elements[6],
            this.elements[3] * m.elements[1] + this.elements[4] * m.elements[4] + this.elements[5] * m.elements[7],
            this.elements[3] * m.elements[2] + this.elements[4] * m.elements[5] + this.elements[5] * m.elements[8],

            this.elements[6] * m.elements[0] + this.elements[7] * m.elements[3] + this.elements[8] * m.elements[6],
            this.elements[6] * m.elements[1] + this.elements[7] * m.elements[4] + this.elements[8] * m.elements[7],
            this.elements[6] * m.elements[2] + this.elements[7] * m.elements[5] + this.elements[8] * m.elements[8],
        )
    )

    fun multiplyScalar(s: Float) = insertElements(
        listOf(
            this.elements[0] * s,
            this.elements[1] * s,
            this.elements[2] * s,

            this.elements[3] * s,
            this.elements[4] * s,
            this.elements[5] * s,

            this.elements[6] * s,
            this.elements[7] * s,
            this.elements[8] * s
        )
    )

    override fun toString() = "${elements[0]}, ${elements[1]}, ${elements[2]}, " +
            "${elements[3]}, ${elements[4]}, ${elements[5]}, " +
            "${elements[6]}, ${elements[7]}, ${elements[8]}"
}