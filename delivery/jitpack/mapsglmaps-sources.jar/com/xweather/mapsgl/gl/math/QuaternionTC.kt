package com.xweather.mapsgl.gl.math

/**
 * Implementation of a quaternion that is used to represent rotations.
 *
 * @see https://en.wikipedia.org/wiki/Quaternion
 * @see https://en.wikipedia.org/wiki/Quaternions_and_spatial_rotation
 */
class QuaternionTC(var x: Float = 1f, var y: Float = 1f, var z: Float = 1f, var w: Float = 1f) {
    fun fromArray(array: FloatArray, offset: Int = 0): QuaternionTC {
        this.x = array[offset + 0];
        this.y = array[offset + 1];
        this.z = array[offset + 2];
        this.w = array[offset + 3];
        this.triggerChange();
        return this;
    }

    fun toArray(array: FloatArray, offset: Int = 0): FloatArray {
        array[offset + 0] = this.x;
        array[offset + 1] = this.y;
        array[offset + 2] = this.z;
        array[offset + 3] = this.w;
        return array;
    }

    fun triggerChange() {
        /*
         * TODO Callback
         */
    }

    fun fromAxisAngle(axis: Vector3, radians: Float): QuaternionTC {
        val rad = radians * 0.5
        val s = Math.sin(rad).toFloat()
        x = s * axis.x
        y = s * axis.y
        z = s * axis.z
        w = Math.cos(rad).toFloat()
        return this
    }

    fun fromEuler(e: Euler): QuaternionTC {
        val halfToRad = ((0.5 * Math.PI) / 180.0).toFloat()
        val xx = e.x * halfToRad
        val yy = e.y * halfToRad
        val zz = e.z * halfToRad
        val sx = Math.sin(xx.toDouble());
        val cx = Math.cos(xx.toDouble());
        val sy = Math.sin(yy.toDouble());
        val cy = Math.cos(yy.toDouble());
        val sz = Math.sin(zz.toDouble());
        val cz = Math.cos(zz.toDouble());
        return QuaternionTC(
            (sx * cy * cz - cx * sy * sz).toFloat(),
            (cx * sy * cz + sx * cy * sz).toFloat(),
            (cx * cy * sz - sx * sy * cz).toFloat(),
            (cx * cy * cz + sx * sy * sz).toFloat()
        )
    }

    fun fromRotationMatrix(): QuaternionTC {
        // quat.f
        return this;
    }

    fun set(x: Float, y: Float, z: Float, w: Float): QuaternionTC {
        this.x = x
        this.y = y
        this.z = z
        this.w = w
        this.triggerChange();
        return this;
    }

    fun length() = Vector4(x, y, z, w).length()

    fun clone() = QuaternionTC(this.x, this.y, this.z, this.w)

    fun copy(q: QuaternionTC): QuaternionTC {
        this.x = q.x
        this.y = q.y
        this.z = q.z
        this.w = q.w
        this.triggerChange();
        return this;
    }

    fun isEqual(q: QuaternionTC) = (this.x == q.x && this.y == q.y && this.z == q.z && this.w == q.w)

    // Modifiers

    fun identity(): QuaternionTC {
        this.x = 0f
        this.y = 0f
        this.z = 0f
        this.w = 1f
        return QuaternionTC(x, y, z, w)
    }

    fun invert(): QuaternionTC {
        val dot = x * x + y * y + z * z + w * w;
        val invDot = if (dot != 0f) {
            1.0f
        } else {
            0f
        };
        // TODO: Would be faster to return [0,0,0,0] immediately if dot == 0
        return QuaternionTC(
            -x * invDot,
            -y * invDot,
            -z * invDot,
            w * invDot
        )
    }

    fun normalize(): QuaternionTC {
        val v4 = Vector4(x, y, z, w).normalize()
        return QuaternionTC(v4.x, v4.y, v4.z, v4.w)
    }

    // Operations

    fun dot(q: QuaternionTC) = q.x * x + y * y + z * z + w * w;

    // Utilities

    fun angleTo(q: QuaternionTC): Float {
        val dotproduct = x * q.x + y * q.y + z * q.z + w * q.w;
        return Math.acos(2.0 * dotproduct * dotproduct - 1f).toFloat();
    }

}