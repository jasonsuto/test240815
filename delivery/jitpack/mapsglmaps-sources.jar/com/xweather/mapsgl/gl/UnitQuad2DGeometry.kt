package com.xweather.mapsgl.gl

/**
 *  UnitQuad2DGeometry.kt
 *
 *  This is greatly simplified for now, the main purpose is to get the geometry out
 *  of the MapBoxLayerHost
 *
 * Will be based on the IOS version
 *  @author Jason Suto 01/16/24.
 *
 */
class UnitQuad2DGeometry {

    companion object {
        fun genQuad(
            xStart: Float,
            yStart: Float,
            xEnd: Float,
            yEnd: Float,
        ): FloatArray {
            println("UnitQuad2DG. genQuad() xStart:${xStart.toInt()} to ${xEnd.toInt()}  (${(xEnd - xStart).toInt()}),\n ${yStart.toInt()} to ${yEnd.toInt()}")
            return floatArrayOf(xStart, yStart, xStart, yEnd, xEnd, yStart, xEnd, yEnd)
        }

        fun genQuad1x1(): FloatArray { // This is how IOS sorts it.

            return floatArrayOf(0f, 0f, 0f, 1f, 1f, 0f, 1f, 1f)
        }

        fun genTexCoords1Quad(): FloatArray {
            return floatArrayOf(0f, 1f, 0f, 0f, 1f, 1f, 1f, 0f)
        }

        fun genPaddedTexCoords1Quad(truncatedPixelsPerSide: Float, paddedSize: Float = 0f): FloatArray {
            val v1 = (truncatedPixelsPerSide / paddedSize)
            val v2 = 1f - (truncatedPixelsPerSide / paddedSize)
            return floatArrayOf(v1, v2, v1, v1, v2, v2, v2, v1)
        } // to get rid of seams

        fun genColorArray(): FloatArray { //Used for testing color pointers
            return floatArrayOf(
                1.0f, 0.0f, 0.0f, 0.5f,
                1.0f, 0.0f, 0.0f, 0.5f,
                1.0f, 0.0f, 0.0f, 0.5f,
                1.0f, 0.0f, 0.0f, 0.5f,
                //right
                1.0f, 0.0f, 0.0f, 0.5f,
                1.0f, 0.0f, 0.0f, 0.5f,
                1.0f, 0.0f, 0.0f, 0.5f,
                1.0f, 0.0f, 0.0f, 0.5f,
                //up
                1.0f, 0.0f, 0.0f, 0.5f,
                1.0f, 0.0f, 0.0f, 0.5f,
                1.0f, 0.0f, 0.0f, 0.5f,
                1.0f, 0.0f, 0.0f, 0.5f
            )
        }
    }
}