package com.xweather.mapsgl.gl

import android.opengl.EGL14
import android.opengl.EGLContext
import android.opengl.GLES20
import android.opengl.GLES30
import android.opengl.GLES31
import android.opengl.Matrix
import com.xweather.mapsgl.anim.LayerAnimationTarget
import com.xweather.mapsgl.anim.LayerTimeline
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.data.TileList
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.gl.math.Matrix4
import com.xweather.mapsgl.gl.programs.RasterTileProgram
import com.xweather.mapsgl.gl.util.Map3D
import com.xweather.mapsgl.gl.worldObjects.Mesh
import com.xweather.mapsgl.gl.worldObjects.MeshInfo
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera
import com.xweather.mapsgl.map.mapbox.CameraSync
import com.xweather.mapsgl.map.mapbox.GlStencilMaskRendererHolder
import com.xweather.mapsgl.map.mapbox.meshTileXYForEncodedLookup
import com.xweather.mapsgl.style.LayerPaint
import com.xweather.mapsgl.style.ParticleLayerPaint
import com.xweather.mapsgl.style.RasterLayerPaint
import com.xweather.mapsgl.style.SampleLayerPaint
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.floor

/**
 *   RenderPass.kt
 *
 *  A `RenderPass` draws a list of Meshes that share the same `RenderMaterial`/`RenderShader`
 *  and the same `GeometryVertexElementLayout` and thus all can use the same `RenderPipeline`
 *  @author Jason Suto 02/05/24.
 */

open class RenderPass(
    open val label: String,
    open var meshes: List<Mesh>?,
    open var meshInfoList: List<MeshInfo>?
) {

    open var id: String = label
    private var modelMatrixHandle = 0
    private var projectionMatrixHandle = 0
    private val matrixArray = FloatArray(16)
    private val cameraArray = FloatArray(16)
    private val projectionMatrixArray = FloatArray(16)
    private val modelViewMatrixArray = FloatArray(16)
    private val checkErrorString = "glUniformMatrix4fv"
    private val checkErrorUse = "glUseProgram"
    private lateinit var progPtr: RasterTileProgram
    private var currentMesh: Mesh? = null
    private var scale = 1f
    private var newX = 0
    private var newY = 0
    private var altDataZoom = 1
    open val map3D = Map3D<Int, String>()
    open var hashString: String? = null
    open lateinit var sampleStyle: LayerPaint  //RasterStyle //was sampleStyle
    open var debugLast = -1L
    open var lastMeshCount = 0

    /**
     * Optional per-tile hooks for GLES stencil masking on encoded weather layers.
     * Invoked after the tile [modelViewMatrixArray] is computed and before any `Mesh.draw` for that tile.
     */
    var stencilBeforeTile: ((
        meshInfo: MeshInfo,
        projectionMatrix: FloatArray,
        modelViewMatrix: FloatArray,
    ) -> Unit)? =
        null
    var stencilAfterTile: (() -> Unit)? = null

    /** Optional once-per-frame hook before the tile loop (stencil is reset per tile when [stencilBeforeTile] is set; see [com.xweather.mapsgl.map.mapbox.GlStencilMaskRenderer.clearStencilForWeatherTileScreenBounds]). */
    var stencilPassBegin: (() -> Unit)? = null

    /**
     * Optional once-per-frame hook to build a JS-style viewport mask texture ([com.xweather.mapsgl.map.mapbox.GlTextureMaskBuilder])
     * before the weather tile loop. When set, [stencilBeforeTile] should remain null.
     */
    var textureMaskBeforeTileLoop: ((
        meshInfoList: List<MeshInfo>,
        projectionMatrix: FloatArray,
        modelViewBase: FloatArray,
        viewportWidth: Int,
        viewportHeight: Int,
    ) -> Unit)? = null

    /** Set by [textureMaskBeforeTileLoop] to bind on the weather program for this frame. */
    var textureMaskBind: ((
        program: RasterTileProgram,
        viewportWidth: Int,
        viewportHeight: Int,
    ) -> Unit)? = null

    //var lastTime = System.currentTimeMillis()-1000L
    open var currentTime = 0L

    open var initialized = false
    private val shouldDisplayRawColors = false

    private fun weatherDebugMatchesMesh(meshInfo: MeshInfo): Boolean {
        if (WEATHER_DEBUG_TARGETS.isEmpty()) return false
        val key = weatherDebugKey(meshInfo)
        return WEATHER_DEBUG_TARGETS.split(',').any { it.trim() == key }
    }

    private fun weatherDebugKey(meshInfo: MeshInfo): String {
        val zInt = meshInfo.z.toInt()
        val nx = normalizedTileXForTextureHash(meshInfo)
        return "$zInt/$nx/${meshInfo.y.toInt()}"
    }

    /**
     * Errors that can occur during the rendering process.
     */
    sealed class Error {
        object MustSupplyAtLeastOneMesh : Error()
        object NewElementsDontMatchVertexDescriptor : Error()
        object CouldntCreateCommandEncoder : Error()
    }

    /**
     * Prepared members of the `RenderPass`.
     */

    constructor(
        label: String = "null",
        paint: LayerPaint //PaintStyle
    ) : this(
        label,
        null,
        null,
    ) {

        if (pr.ON) pr.p(TAG, pr.waaveRenderpath, ">> renderpass label is $label")

        if (paint is ParticleLayerPaint) {
            sampleStyle = paint as ParticleLayerPaint
        } else if (paint is SampleLayerPaint) {
            sampleStyle = paint
        } else {
            sampleStyle = paint as RasterLayerPaint
        }
    }

    /**
     *
     * Should loop through renderables and call draw() on each.
     *
     * Called from TileLayerRenderer.draw()
     *
     */
    open fun render(texHashMap: HashMap<String, Int>, camera: Camera) {
        var phaseAString = ""
        var phaseBString = ""
        var finalMeld = 0f
        val layerInfo = Timeline.sourceTimeHash[label]
        val viewportMeshes = meshInfoList.orEmpty()

        if (layerInfo != null) {
            if (pr.ON) pr.p(TAG, pr.noLoad, "render() layerInfo was NOT null, using layerInfo")
            val resolved = if (viewportMeshes.isNotEmpty()) {
                applyLayerViewportPlayback(layerInfo, viewportMeshes, texHashMap)
            } else {
                val target = layerInfo.computeGlobalAnimationTarget()
                LayerDrawPhases(target.phaseA, target.phaseB, target.meld).also {
                    layerInfo.commitDisplayPhases(it.phaseA, it.phaseB, it.meld, true, null)
                }
            }
            phaseAString = Timeline.getTimeString(0, resolved.phaseA)
            phaseBString = Timeline.getTimeString(1, resolved.phaseB)
            finalMeld = resolved.meld
        } else {
            if (pr.ON) pr.p(TAG, pr.noLoad, "render() layerInfo was  null, falling back to TimeLine", 2)
            if (Timeline.currentPhaseA < Timeline.timeStrings.size && Timeline.currentPhaseB < Timeline.timeStrings.size) {
                phaseAString = Timeline.timeStrings[Timeline.currentPhaseA]
                phaseBString = Timeline.timeStrings[Timeline.currentPhaseB]
                finalMeld = Timeline.dataMeld
            }
            if (viewportMeshes.isNotEmpty()) {
                val timelineLongA = Timeline.timeLongs.getOrElse(Timeline.currentPhaseA) { 0L }
                val timelineLongB = Timeline.timeLongs.getOrElse(Timeline.currentPhaseB) { timelineLongA }
                val targetLong = (timelineLongA + (timelineLongB - timelineLongA) * finalMeld).toLong()
                val target = LayerAnimationTarget(phaseAString, phaseBString, finalMeld, targetLong)
                // Snapshot global timeline lists; they are mutated off the GL thread when valid
                // times update, so passing the raw references can race with downstream indexed reads.
                val resolved = resolveLayerViewportDrawPhases(
                    viewportMeshes = viewportMeshes,
                    texHashMap = texHashMap,
                    sourceId = null,
                    target = target,
                    intervalStrings = safeSnapshotInterval(Timeline.timeStrings),
                    intervalLongs = safeSnapshotInterval(Timeline.timeLongs),
                    retainPhases = emptyList(),
                )
                phaseAString = resolved.phaseA
                phaseBString = resolved.phaseB
                finalMeld = resolved.meld
            }
        }

        if (meshes != null && meshes!!.isNotEmpty()) {

            currentMesh = meshes!!.first()

            //if (pr.ON) pr.p(TAG, pr.noLoad, "render() about to assign progPtr")
            progPtr = (currentMesh!!.program as RasterTileProgram)
            progPtr.bind().also { checkError(checkErrorUse) }// Add program to OpenGL ES environment
            progPtr.useOncePerFrame()
            progPtr.use()
            progPtr.setColorBandTexture()

            currentTime = System.currentTimeMillis()

            GLES31.glUniform1i(progPtr.singlePointModeLoc, 0)
            GLES31.glUniform1i(progPtr.useRawColorsLocation, if (shouldDisplayRawColors) 1 else 0)
            // GLES 3.x: vertex attributes must come from buffer objects; client-side pointers are invalid.
            bindRasterTileVertexAttributes(progPtr)
            // In Mapbox [CustomLayerHost], use native projection + model-view from the same frame as
            // the basemap so encoded rasters sit on the map surface under pitch/bearing. Mixing
            // Mapbox P with [camera.viewMatrix] (or the inverse) leaves a separate "floating" plane.
            val mapboxProj = CameraSync.mapboxProjectionMatrix
            val mapboxMv = CameraSync.mapboxModelViewMatrix
            val useMapboxNativeMv =
                mapboxProj != null && mapboxMv != null && mapboxProj.size >= 16 && mapboxMv.size >= 16
            if (useMapboxNativeMv) {
                System.arraycopy(mapboxProj, 0, projectionMatrixArray, 0, 16)
                System.arraycopy(mapboxMv, 0, cameraArray, 0, 16)
            } else {
                matrixToFloatArray(camera.projectionMatrix, projectionMatrixArray)
                matrixToFloatArray(camera.viewMatrix, cameraArray)
            }

            projectionMatrixHandle = GLES31.glGetUniformLocation(progPtr.programInt, "projectionMatrix")
                .also { checkError("glGetUniformLocation") }
            GLES31.glUniformMatrix4fv(projectionMatrixHandle, 1, false, projectionMatrixArray, 0)
                .also { checkError("glUniformMatrix4fv") }

            modelMatrixHandle = GLES31.glGetUniformLocation(progPtr.programInt, "modelViewMatrix")
                .also { checkError("glGetUniformLocation") }
            progPtr.useOncePerFrame()
            progPtr.setColorBandTexture()
            sampleStyle.let { progPtr.setOpacity(it.opacity) }


            // if (pr.ON) {
            // if (lastMeshCount != meshInfoList!!.size) {
            //     pr.p(TAG, pr.tileCount, "render() meshInfoList.size: ${meshInfoList!!.size}")
            lastMeshCount = meshInfoList!!.size
            // }
            // }

            if (true /*|| phaseA < Timeline.timeStrings.size*/) {
                GLES31.glViewport(0, 0, camera.resX, camera.resY)
                stencilPassBegin?.invoke()
                meshInfoList?.let { infos ->
                    textureMaskBeforeTileLoop?.invoke(
                        infos,
                        projectionMatrixArray,
                        cameraArray,
                        camera.resX,
                        camera.resY,
                    )
                }
                if (textureMaskBind != null) {
                    textureMaskBind?.invoke(progPtr, camera.resX, camera.resY)
                } else {
                    progPtr.bindTextureMask(0, camera.resX, camera.resY, enabled = false, invert = false)
                }
                progPtr.setMeld(finalMeld)
                meshInfoList?.forEach { meshInfo ->
                    if (true /*|| searchKey == meshInfo.hashCode*/) {
                        Matrix.setIdentityM(matrixArray, 0); // initialize to identity matrix
                        val mapZoomNow =
                            CameraSync.customLayerRenderZoom ?: CameraSync.mapZoom
                        val overscale = if (useMapboxNativeMv) {
                            CameraSync.tileRasterOverscale(mapZoomNow, meshInfo.z.toInt())
                        } else {
                            1f
                        }
                        Matrix.scaleM(matrixArray, 0, 512f * overscale, 512f * overscale, 1f)
                        Matrix.translateM(matrixArray, 0, meshInfo.x, meshInfo.y, 0f)
                        Matrix.multiplyMM(modelViewMatrixArray, 0, cameraArray, 0, matrixArray, 0) //works
                        GLES31.glUniformMatrix4fv(
                            modelMatrixHandle,
                            1,
                            false,
                            modelViewMatrixArray,
                            0
                        )

                        if (stencilBeforeTile != null) {
                            // Must reset stencil for each tile; otherwise REPLACE/INCR from earlier tiles
                            // leaves ref=2 in framebuffer pixels and weather draws "masked" worldwide.
                            // Scissor to the tile quad’s screen bounds — a full FBO stencil clear per tile
                            // was tens of clears per frame and dominated pan cost even with cached road VBOs.
                            GlStencilMaskRendererHolder.renderer.clearStencilForWeatherTileScreenBounds(
                                projectionMatrixArray,
                                modelViewMatrixArray,
                                camera.resX,
                                camera.resY,
                            )
                        }
                        stencilBeforeTile?.invoke(
                            meshInfo,
                            projectionMatrixArray,
                            modelViewMatrixArray,
                        )
                        // Stencil / mask code binds other VBOs; restore quad attribs before draw.
                        bindRasterTileVertexAttributes(progPtr)

                        datelineAdjustment(meshInfo)
                        val hashKey = "${meshInfo.hashCode}${phaseAString}"
                        //val hashKey =  "0:0/0/0/[\"2025-04-22T21:00:00Z\"]"

                        texHashMap[hashKey]?.let { // found ideal tile for phase A
                            if (weatherDebugMatchesMesh(meshInfo)) {
                                System.out.println("[WeatherDebug][GL] draw exact key=${weatherDebugKey(meshInfo)} phaseA=$phaseAString phaseB=$phaseBString meld=$finalMeld")
                            }

                            if (pr.ON) pr.p(TAG, pr.noLoad, "render() found Ideal for phaseA: ${hashKey}")

                            progPtr.updateTexture1Size(1f, 1f, 0f, 0f)
                            var hash2: String? = "${meshInfo.hashCode}${phaseBString}"
                            if (texHashMap[hash2] != null) { //found full version of both textures
                                if (pr.ON) pr.p(TAG, pr.downloadRequest, "h2: $hash2 found, trying to draw!")
                                progPtr.updateTexture2Size(1f, 1f, 0f, 0f)
                                currentMesh?.draw2Textures(it, texHashMap[hash2]!!)
                                //println("$TAG, render() draw $it, ${texHashMap[hash2]}")
                            } else {
                                if (pr.ON) pr.p(TAG, pr.downloadRequest, "h2: ${hash2} NOT FOUND found")
                                hash2 = determinePartial(meshInfo, texHashMap, phaseBString, 2)
                                if (hash2 != null) {
                                    pr.p(TAG, pr.tilePick, "render() A drawing 2 tiles ", 2)
                                    currentMesh?.draw2Textures(it, texHashMap[hash2]!!)
                                    //println("$TAG, render() draw $it, ${texHashMap[hash2]}")
                                } else if (finalMeld != 1f) {
                                    pr.p(TAG, pr.rasterPart, "render() A drawing 1st tile ", 2)
                                    currentMesh?.draw(it)
                                    //println("$TAG, render() draw $it")
                                } else {
                                    pr.p(
                                        TAG,
                                        pr.rasterPart,
                                        "render() A wanted to draw last tile, can only find first: ",
                                        2
                                    )
                                    //println("$TAG, render() draw $it")
                                    currentMesh?.draw(it)
                                }
                            }
                        } ?: run { //Display lower-res texture if available. Also accounts for world-wrap


                            if (pr.ON) pr.p(TAG, pr.noLoad, "render() DID NOT find Ideal for phaseA: ${hashKey}")

                            val meshString1 = determinePartial(meshInfo, texHashMap, phaseAString, 1)

                            var meshString2: String? =
                                "${meshInfo.hashCode}${phaseBString}" // the exact tile
                            if (texHashMap[meshString2] == null) { // if exact tile not found, use partial
                                meshString2 = determinePartial(meshInfo, texHashMap, phaseBString, 2)
                            } else {
                                progPtr.updateTexture2Size(1f, 1f, 0f, 0f)
                            }
                            if (meshString1 != null) {
                                if (meshString2 != null) {
                                    if (weatherDebugMatchesMesh(meshInfo)) {
                                        System.out.println("[WeatherDebug][GL] draw partial+exact key=${weatherDebugKey(meshInfo)} a=$meshString1 b=$meshString2 meld=$finalMeld")
                                    }
                                    if (pr.ON) pr.p(TAG, pr.rasterPart, "B1 draw 2")
                                    currentMesh?.draw2Textures(texHashMap[meshString1]!!, texHashMap[meshString2]!!)
                                } else {
                                    if (texHashMap.containsKey(meshString1)) {
                                        if (weatherDebugMatchesMesh(meshInfo)) {
                                            System.out.println("[WeatherDebug][GL] draw partial-only key=${weatherDebugKey(meshInfo)} a=$meshString1 meld=$finalMeld")
                                        }
                                        pr.p(TAG, pr.rasterPart, "render() B2 drawing 1st tile ", 2)
                                        currentMesh?.draw(texHashMap[meshString1]!!)
                                    } else {
                                    }
                                }
                            } else { // Used in case of the timeline being all the way at the right end, just draw the last interval
                                if (texHashMap[meshString2] != null) {
                                    if (weatherDebugMatchesMesh(meshInfo)) {
                                        System.out.println("[WeatherDebug][GL] draw phaseB fallback key=${weatherDebugKey(meshInfo)} b=$meshString2 meld=$finalMeld")
                                    }
                                    if (finalMeld == 1f) {
                                        determinePartial(
                                            meshInfo,
                                            texHashMap,
                                            phaseBString,
                                            1
                                        ) // 250424 fix for raster tiles when meld is 1.0
                                    }
                                    currentMesh?.draw2Textures(texHashMap[meshString2]!!, texHashMap[meshString2]!!)
                                } else {
                                    if (weatherDebugMatchesMesh(meshInfo)) {
                                        System.out.println("[WeatherDebug][GL] no drawable texture key=${weatherDebugKey(meshInfo)} phaseA=$phaseAString phaseB=$phaseBString meld=$finalMeld")
                                    }
                                    pr.p(TAG, pr.flicker, "render() NOT DRAWING ANYTHING", 2)
                                }
                            }
                        } // end run
                        stencilAfterTile?.invoke()
                    } // MATCH TOUCH TILE
                } // end for each

            }      // end if(phaseA < Timeline.times!!.size){


            progPtr.unbind()
        } // end  if (meshes != null && meshes!!.isNotEmpty()) {
        //if(pr.ON)pr.p(TAG, pr.trackRender,"render() exited")
    } // end render()

    private fun determinePartial(
        meshInfo: MeshInfo,
        texHashMap: HashMap<String, Int>,
        currentPhaseString: String,
        textureNumber: Int
    ): String? {
        val startAltDataZoom = floor(meshInfo.z /*- 1*/).toInt()
        val zInt = startAltDataZoom
        val (childX, childY) = meshTileXYForEncodedLookup(meshInfo, zInt)
        altDataZoom = startAltDataZoom
        var partialHashString: String
        while (altDataZoom > -1) {
            if (pr.ON) pr.p(TAG, pr.partial, "render() in the loop, altDataZoom:$altDataZoom")

            // Avoid float rounding drift when walking the mip/partial chain.
            val shift = startAltDataZoom - altDataZoom
            val divisor = 1 shl shift
            newX = Math.floorDiv(childX, divisor)
            newY = Math.floorDiv(childY, divisor)
            //consider trying to give this it's own String, may fix when pulls wrong tile?
            partialHashString = "0:${altDataZoom}/${newX}/${newY}/${currentPhaseString}"
            //if(pr.ON) pr.p(TAG, pr.obs_play, "hashString: ${hashString3}")

            if (texHashMap[partialHashString] != null) {
                val localScale = 1.0f / divisor.toFloat()
                updateTextureSizes(meshInfo, localScale, newX, newY, textureNumber)
                return partialHashString as String
            } else {
                altDataZoom--
            }
        }
        return null
    }

    /** Used to calculate the scale value for the texture in the shader. Used for tile partial scaling **/
    open fun updateTextureSizes(mInfo: MeshInfo, scale: Float, nX: Int, nY: Int, textureNumber: Int) {
        var xOffs = (mInfo.x * scale) - nX
        while (xOffs < 0f) xOffs += 1f // To handle wrapping around date line
        while (xOffs >= 1f) xOffs -= 1f
        val yOffs = (mInfo.y * scale) - nY
        if (textureNumber == 1) {
            progPtr.updateTexture1Size(scale, scale, xOffs, yOffs)
        } else {
            progPtr.updateTexture2Size(scale, scale, xOffs, yOffs)
        }
    }

    /** Puts a given Matrix4 into a given FloatArray
     * @return FloatArray
     */
    open fun matrixToFloatArray(m: Matrix4, r: FloatArray): FloatArray { //reuse existing array
        r[0] = m.elements[0]; r[1] = m.elements[1]; r[2] = m.elements[2]; r[3] = m.elements[3]
        r[4] = m.elements[4]; r[5] = m.elements[5]; r[6] = m.elements[6]; r[7] = m.elements[7]
        r[8] = m.elements[8]; r[9] = m.elements[9]; r[10] = m.elements[10]; r[11] = m.elements[11]
        r[12] = m.elements[12]; r[13] = m.elements[13]; r[14] = m.elements[14]; r[15] = m.elements[15]
        return r
    }

    private fun checkError(cmd: String? = null) {
        if (true /*BuildConfig.DEBUG*/) {
            when (val error = GLES31.glGetError()) {
                GLES31.GL_NO_ERROR -> {/*println("TAG $cmd -> no error")*/
                }

                GLES31.GL_INVALID_ENUM -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_ENUM")
                GLES31.GL_INVALID_VALUE -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_VALUE")
                GLES31.GL_INVALID_OPERATION -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_OPERATION")
                GLES31.GL_INVALID_FRAMEBUFFER_OPERATION -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_FRAMEBUFFER_OPERATION")
                GLES31.GL_OUT_OF_MEMORY -> throw RuntimeException("$cmd -> error in gl: GL_OUT_OF_MEMORY")
                else -> throw RuntimeException("$cmd -> error in gl: $error")
            }
        }
    }

    /**
     * Finds the two values in a sorted list that a target value falls between,
     * and calculates the fractional distance between them.
     *
     * @param targetValue The long value to locate within the list.
     * @param sortedList The sorted list of longs to search within.
     * @return An [InterpolationResult] containing the lower and upper bound values and the fraction (0.0f to 1.0f).
     *         Returns null if the list has fewer than two elements or the target is outside the list's range.
     */
    open fun findInterpolationValues(targetValue: Long, sortedList: List<Long>): InterpolationResult? {
        // We need at least two points to form a range.
        if (sortedList.size < 2) {
            return null
        }

        // Use binarySearch to find the index or the insertion point.
        val searchResult = sortedList.binarySearch(targetValue)

        if (searchResult >= 0) {
            // Exact match found. The value is exactly on a point, so the fraction is 0.
            val value = sortedList[searchResult]
            return InterpolationResult(value, value, 0.0f, searchResult, searchResult)
        }

        // The value was not found. Convert the negative searchResult to an insertion point.
        val insertionPoint = -(searchResult + 1)

        // Handle edge cases: target is outside the entire range of the list.
        if (insertionPoint == 0 || insertionPoint == sortedList.size) {
            return null // Target is before the first element or after the last one.
        }

        // The target is between two elements.
        val lowerIndex = insertionPoint - 1
        val upperIndex = insertionPoint
        val lowerBound = sortedList[lowerIndex]
        val upperBound = sortedList[upperIndex]

        // Prevent division by zero if the bounds are identical.
        val range = (upperBound - lowerBound).toFloat()
        if (range == 0f) {
            return InterpolationResult(lowerBound, upperBound, 0.0f, lowerIndex, upperIndex)
        }

        // Calculate the fractional position of the target within the range.
        val position = (targetValue - lowerBound).toFloat()
        val fraction = position / range

        return InterpolationResult(
            lowerBound,
            upperBound,
            fraction.coerceIn(0.0f, 1.0f),
            lowerIndex,
            upperIndex
        )
    }

    protected data class LayerDrawPhases(val phaseA: String, val phaseB: String, val meld: Float)

    protected fun meshInfoToTileHashShort(meshInfo: MeshInfo): String {
        val zInt = meshInfo.z.toInt()
        val nx = normalizedTileXForTextureHash(meshInfo)
        return "0:$zInt/$nx/${meshInfo.y.toInt()}"
    }

    protected fun meshInfoToExactHashKey(meshInfo: MeshInfo, phaseString: String): String {
        return "${meshInfoToTileHashShort(meshInfo)}/$phaseString"
    }

    protected fun meshInfoHasDrawableTexture(
        meshInfo: MeshInfo,
        phaseString: String,
        texHashMap: HashMap<String, Int>,
    ): Boolean {
        if (phaseString.isEmpty()) return false
        if (texHashMap.containsKey("${meshInfo.hashCode}$phaseString")) return true
        if (texHashMap.containsKey(meshInfoToExactHashKey(meshInfo, phaseString))) return true
        val startAltDataZoom = floor(meshInfo.z).toInt()
        var alt = startAltDataZoom
        while (alt > -1) {
            val shift = startAltDataZoom - alt
            val divisor = 1 shl shift
            val nx = normalizedTileXForTextureHash(meshInfo)
            val newX = Math.floorDiv(nx, divisor)
            val newY = Math.floorDiv(meshInfo.y.toInt(), divisor)
            val partialHashString = "0:$alt/$newX/$newY/$phaseString"
            if (texHashMap.containsKey(partialHashString)) return true
            alt--
        }
        return false
    }

    protected fun phasePendingForTile(
        meshInfo: MeshInfo,
        phaseString: String,
    ): Boolean {
        if (phaseString.isEmpty()) return false
        return TileList.pendingList.containsTimeInTile(label, meshInfoToTileHashShort(meshInfo), phaseString)
    }

    protected fun encodedBindPendingForTile(
        sourceId: String?,
        meshInfo: MeshInfo,
        phaseString: String,
    ): Boolean {
        if (sourceId.isNullOrEmpty() || phaseString.isEmpty()) return false
        return Timeline.isEncodedBindPending(
            sourceId,
            meshInfoToTileHashShort(meshInfo),
            phaseString,
        )
    }

    protected fun meshReadyForTargetPhase(
        meshInfo: MeshInfo,
        phaseString: String,
        texHashMap: HashMap<String, Int>,
        sourceId: String?,
    ): Boolean {
        if (phaseString.isEmpty()) return false
        if (phasePendingForTile(meshInfo, phaseString)) return false
        if (encodedBindPendingForTile(sourceId, meshInfo, phaseString)) return false
        return meshInfoHasDrawableTexture(meshInfo, phaseString, texHashMap)
    }

    protected fun allViewportMeshesReadyForPhase(
        viewportMeshes: List<MeshInfo>,
        phaseString: String,
        texHashMap: HashMap<String, Int>,
        sourceId: String?,
    ): Boolean {
        if (phaseString.isEmpty() || viewportMeshes.isEmpty()) return false
        return viewportMeshes.all { mesh ->
            meshReadyForTargetPhase(mesh, phaseString, texHashMap, sourceId)
        }
    }

    protected fun allViewportMeshesReadyForAnimation(
        viewportMeshes: List<MeshInfo>,
        texHashMap: HashMap<String, Int>,
        sourceId: String?,
        targetPhaseA: String,
        targetPhaseB: String,
        targetMeld: Float,
    ): Boolean {
        if (viewportMeshes.isEmpty()) return true
        val interpolating = targetMeld > 0f && targetMeld < 1f && targetPhaseA != targetPhaseB
        return if (interpolating) {
            allViewportMeshesReadyForPhase(viewportMeshes, targetPhaseA, texHashMap, sourceId) &&
                allViewportMeshesReadyForPhase(viewportMeshes, targetPhaseB, texHashMap, sourceId)
        } else {
            val phase = if (targetMeld <= 0f) targetPhaseA else targetPhaseB
            allViewportMeshesReadyForPhase(viewportMeshes, phase, texHashMap, sourceId)
        }
    }

    /**
     * Defensively copies [source] into an immutable [List]. The backing list may live on
     * [LayerTimeline] or [Timeline] and be mutated off the GL render thread (insertions in
     * [com.xweather.mapsgl.tiles.TilePyramid], clear/refresh in
     * [LayerTimeline.refreshSparseLists]). Iterating it directly here races and can throw
     * [ConcurrentModificationException] or [IndexOutOfBoundsException]. Retry once on
     * concurrent change; fall back to empty if we still cannot get a stable copy.
     */
    private fun <T> safeSnapshotInterval(source: List<T>): List<T> {
        repeat(2) {
            try {
                return ArrayList(source)
            } catch (_: ConcurrentModificationException) {
            } catch (_: IndexOutOfBoundsException) {
            } catch (_: ArrayIndexOutOfBoundsException) {
            } catch (_: NullPointerException) {
            }
        }
        return emptyList()
    }

    /**
     * Latest interval (chronological, at or before [targetLong]) where every viewport tile is ready.
     */
    protected fun findLatestViewportCompletePhaseAtOrBefore(
        viewportMeshes: List<MeshInfo>,
        texHashMap: HashMap<String, Int>,
        sourceId: String?,
        intervalStrings: List<String>,
        intervalLongs: List<Long>,
        targetLong: Long,
    ): String? {
        var latest: String? = null
        val size = minOf(intervalStrings.size, intervalLongs.size)
        for (i in 0 until size) {
            val timeLong = intervalLongs.getOrNull(i) ?: break
            if (timeLong > targetLong) break
            val phase = intervalStrings.getOrNull(i) ?: break
            if (phase.isNotEmpty() && allViewportMeshesReadyForPhase(viewportMeshes, phase, texHashMap, sourceId)) {
                latest = phase
            }
        }
        return latest
    }

    protected fun displayPhaseForTarget(targetPhaseA: String, targetPhaseB: String, targetMeld: Float): String {
        return if (targetMeld <= 0f) targetPhaseA else targetPhaseB
    }

    /** True if at least one viewport tile has a bound texture for [phaseString] (ignores pending flags). */
    protected fun anyViewportMeshHasDrawablePhase(
        viewportMeshes: List<MeshInfo>,
        phaseString: String,
        texHashMap: HashMap<String, Int>,
    ): Boolean {
        if (phaseString.isEmpty()) return false
        return viewportMeshes.any { mesh ->
            meshInfoHasDrawableTexture(mesh, phaseString, texHashMap)
        }
    }

    /** Latest viewport-complete interval in [intervalStrings] (any time). */
    protected fun findLatestViewportCompletePhase(
        viewportMeshes: List<MeshInfo>,
        texHashMap: HashMap<String, Int>,
        sourceId: String?,
        intervalStrings: List<String>,
    ): String? {
        var latest: String? = null
        for (phase in intervalStrings) {
            if (phase.isNotEmpty() && allViewportMeshesReadyForPhase(viewportMeshes, phase, texHashMap, sourceId)) {
                latest = phase
            }
        }
        return latest
    }

    /**
     * Subset of [intervalStrings] / [intervalLongs] whose tiles are fully viewport-ready.
     * Used so playback can keep advancing through loaded intervals instead of freezing on one
     * while waiting for the global target's exact pair to finish downloading.
     */
    protected data class ReadyPlaybackList(val strings: List<String>, val longs: List<Long>)

    protected fun buildReadyPlaybackList(
        viewportMeshes: List<MeshInfo>,
        texHashMap: HashMap<String, Int>,
        sourceId: String?,
        intervalStrings: List<String>,
        intervalLongs: List<Long>,
    ): ReadyPlaybackList {
        val size = minOf(intervalStrings.size, intervalLongs.size)
        if (size == 0) return ReadyPlaybackList(emptyList(), emptyList())
        val strings = ArrayList<String>(size)
        val longs = ArrayList<Long>(size)
        for (i in 0 until size) {
            val phase = intervalStrings.getOrNull(i) ?: break
            val timeLong = intervalLongs.getOrNull(i) ?: break
            if (phase.isEmpty()) continue
            if (allViewportMeshesReadyForPhase(viewportMeshes, phase, texHashMap, sourceId)) {
                strings.add(phase)
                longs.add(timeLong)
            }
        }
        return ReadyPlaybackList(strings, longs)
    }

    /**
     * Builds draw phases from the viewport-ready interval subset for the current [targetLong],
     * letting the layer animate through loaded frames while the global timeline advances.
     */
    protected fun drawPhasesFromReadyList(
        ready: ReadyPlaybackList,
        targetLong: Long,
    ): LayerDrawPhases? {
        if (ready.strings.isEmpty()) return null
        if (ready.strings.size == 1) {
            val only = ready.strings.first()
            return LayerDrawPhases(only, only, 0f)
        }
        if (targetLong <= ready.longs.first()) {
            val first = ready.strings.first()
            return LayerDrawPhases(first, first, 0f)
        }
        if (targetLong >= ready.longs.last()) {
            val last = ready.strings.last()
            return LayerDrawPhases(last, last, 0f)
        }
        var lower = 0
        for (i in 1 until ready.longs.size) {
            if (ready.longs[i] > targetLong) {
                lower = i - 1
                break
            }
            lower = i
        }
        val upper = (lower + 1).coerceAtMost(ready.longs.lastIndex)
        if (lower == upper) {
            val phase = ready.strings[lower]
            return LayerDrawPhases(phase, phase, 0f)
        }
        val lowerLong = ready.longs[lower]
        val upperLong = ready.longs[upper]
        val range = (upperLong - lowerLong).toFloat()
        val meld = if (range <= 0f) {
            0f
        } else {
            ((targetLong - lowerLong).toFloat() / range).coerceIn(0f, 1f)
        }
        return LayerDrawPhases(ready.strings[lower], ready.strings[upper], meld)
    }

    /**
     * Freezes this layer on the first viewport-complete interval until the global animation target
     * is ready for every visible tile. Writes the result back to [LayerTimeline].
     */
    protected fun applyLayerViewportPlayback(
        layerInfo: LayerTimeline,
        viewportMeshes: List<MeshInfo>,
        texHashMap: HashMap<String, Int>,
    ): LayerDrawPhases {
        val target = layerInfo.computeGlobalAnimationTarget()
        // Snapshot the layer's interval lists once on the GL thread; they are mutated off-thread
        // (TilePyramid insertions, LayerTimeline.refreshSparseLists clear/repopulate). Passing the
        // live references to downstream indexed reads is what previously caused
        // IndexOutOfBoundsException in buildReadyPlaybackList.
        val intervalStrings = safeSnapshotInterval(
            layerInfo.playbackTimeStrings().ifEmpty { layerInfo.reqStrings }
        )
        val intervalLongs = safeSnapshotInterval(
            layerInfo.playbackTimeLongs().ifEmpty { layerInfo.reqLongs }
        )
        val retainPhases = layerInfo.retainPhaseCandidates()
        val resolved = resolveLayerViewportDrawPhases(
            viewportMeshes = viewportMeshes,
            texHashMap = texHashMap,
            sourceId = layerInfo.id,
            target = target,
            intervalStrings = intervalStrings,
            intervalLongs = intervalLongs,
            retainPhases = retainPhases,
        )
        val ready = allViewportMeshesReadyForAnimation(
            viewportMeshes,
            texHashMap,
            layerInfo.id,
            target.phaseA,
            target.phaseB,
            target.meld,
        )
        val holdPhase = if (ready) {
            null
        } else {
            resolveViewportHoldPhase(
                viewportMeshes,
                texHashMap,
                layerInfo.id,
                target,
                intervalStrings,
                intervalLongs,
                retainPhases,
            )
        }
        layerInfo.commitDisplayPhases(
            resolved.phaseA,
            resolved.phaseB,
            resolved.meld,
            ready,
            holdPhase,
        )
        if (layerInfo.updateStaggeredPlaybackState { phase ->
                allViewportMeshesReadyForPhase(viewportMeshes, phase, texHashMap, layerInfo.id)
            }
        ) {
            // Fill pass downloads odd intervals in the background; only schedule while playing so
            // pausing does not immediately enqueue a new HTTP wave the user did not ask for.
            if (Timeline.isGloballyPlaying) {
                Timeline.requestStaggeredFillDownload(layerInfo.id)
            }
        }
        return resolved
    }

    /**
     * Keeps the frame the user was already seeing (e.g. timeline stopped on a loaded interval)
     * instead of blanking while a new target loads.
     */
    protected fun pickDrawableRetainPhase(
        viewportMeshes: List<MeshInfo>,
        texHashMap: HashMap<String, Int>,
        sourceId: String?,
        retainPhases: List<String>,
    ): String? {
        for (phase in retainPhases) {
            if (phase.isEmpty()) continue
            if (allViewportMeshesReadyForPhase(viewportMeshes, phase, texHashMap, sourceId) ||
                anyViewportMeshHasDrawablePhase(viewportMeshes, phase, texHashMap)
            ) {
                return phase
            }
        }
        return null
    }

    protected fun resolveViewportHoldPhase(
        viewportMeshes: List<MeshInfo>,
        texHashMap: HashMap<String, Int>,
        sourceId: String?,
        target: LayerAnimationTarget,
        intervalStrings: List<String>,
        intervalLongs: List<Long>,
        retainPhases: List<String>,
    ): String? {
        pickDrawableRetainPhase(viewportMeshes, texHashMap, sourceId, retainPhases)?.let { return it }

        if (Timeline.isAtEndPosition()) {
            val displayPhase = displayPhaseForTarget(target.phaseA, target.phaseB, target.meld)
            if (allViewportMeshesReadyForPhase(viewportMeshes, displayPhase, texHashMap, sourceId)) {
                return displayPhase
            }
            if (anyViewportMeshHasDrawablePhase(viewportMeshes, displayPhase, texHashMap)) {
                return displayPhase
            }
            // Last interval not drawable yet — keep the latest frame we can actually show.
            return findLatestViewportCompletePhaseAtOrBefore(
                viewportMeshes,
                texHashMap,
                sourceId,
                intervalStrings,
                intervalLongs,
                target.targetLong,
            ) ?: findLatestViewportCompletePhase(viewportMeshes, texHashMap, sourceId, intervalStrings)
        }
        return findLatestViewportCompletePhaseAtOrBefore(
            viewportMeshes,
            texHashMap,
            sourceId,
            intervalStrings,
            intervalLongs,
            target.targetLong,
        ) ?: findLatestViewportCompletePhase(viewportMeshes, texHashMap, sourceId, intervalStrings)
    }

    /**
     * Per-layer viewport gating: global timeline keeps advancing, but the layer holds on the latest
     * viewport-complete interval at or before the target until the target is fully ready. At the
     * end of the timeline, the target (last) interval is shown even while tiles finish loading.
     */
    protected fun resolveLayerViewportDrawPhases(
        viewportMeshes: List<MeshInfo>,
        texHashMap: HashMap<String, Int>,
        sourceId: String?,
        target: LayerAnimationTarget,
        intervalStrings: List<String>,
        intervalLongs: List<Long>,
        retainPhases: List<String>,
    ): LayerDrawPhases {
        if (viewportMeshes.isEmpty()) {
            return LayerDrawPhases(target.phaseA, target.phaseB, target.meld)
        }
        if (allViewportMeshesReadyForAnimation(
                viewportMeshes,
                texHashMap,
                sourceId,
                target.phaseA,
                target.phaseB,
                target.meld,
            )
        ) {
            return LayerDrawPhases(target.phaseA, target.phaseB, target.meld)
        }
        val holdPhase = resolveViewportHoldPhase(
            viewportMeshes,
            texHashMap,
            sourceId,
            target,
            intervalStrings,
            intervalLongs,
            retainPhases,
        )
        if (holdPhase.isNullOrEmpty()) {
            pickDrawableRetainPhase(viewportMeshes, texHashMap, sourceId, retainPhases)?.let { retained ->
                return LayerDrawPhases(retained, retained, 0f)
            }
            val displayTarget = displayPhaseForTarget(target.phaseA, target.phaseB, target.meld)
            if (anyViewportMeshHasDrawablePhase(viewportMeshes, displayTarget, texHashMap)) {
                return LayerDrawPhases(displayTarget, displayTarget, 0f)
            }
            return LayerDrawPhases(target.phaseA, target.phaseB, 0f)
        }
        return LayerDrawPhases(holdPhase, holdPhase, 0f)
    }

    companion object {
        /**
         * Checks if a `Mesh` element conforms to the given `GeometryVertexElementLayout`.
         */
        private fun meshesElementConforms(element: Mesh /*geometryVertexElementLayout: GeometryVertexElementLayout*/): Boolean {
            //return element.geometry.vertexElementLayout == geometryVertexElementLayout
            return true
        }

        /**
         * Checks if all `Mesh` elements conform to the given `GeometryVertexElementLayout`.
         */
        private fun meshesElementsConform(elements: Collection<Mesh>/*, geometryVertexElementLayout: GeometryVertexElementLayout*/): Boolean {
            //return elements.all { meshesElementConforms(it, geometryVertexElementLayout) }
            return true
        }

        /**
         * Filters out `Mesh` elements that do not conform to the given `GeometryVertexElementLayout`.
         */
        private fun conformingMeshesElements(elements: Collection<Mesh>/*, geometryVertexElementLayout: GeometryVertexElementLayout*/): List<Mesh>? {
            //return elements.filter { meshesElementConforms(it, geometryVertexElementLayout) }
            return null
        }

        private const val TAG = "RenderPass"
        // Comma-separated "z/x/y" weather tiles to trace draw decisions.
        private const val WEATHER_DEBUG_TARGETS = "6/19/21,6/19/22,6/20/21,6/20/22,6/19/23,6/20/23"
        private const val BYTES_PER_FLOAT = 4
        const val COORDS_PER_VERTEX = 2
        private const val NUM_TILES = 1
        private const val VERTEX_COUNT = NUM_TILES * 4
        const val VERTEX_STRIDE = COORDS_PER_VERTEX * BYTES_PER_FLOAT
        const val TEXTURE_SIZE = 2
        const val TEXTURE_STRIDE = TEXTURE_SIZE * BYTES_PER_FLOAT
        //private var textureAlpha = .5f

        private val rasterQuadVboLock = Any()
        private var rasterQuadPosVbo: Int = 0
        private var rasterQuadTexVbo: Int = 0

        /**
         * EGL context the cached [rasterQuadPosVbo] / [rasterQuadTexVbo] handles were generated in.
         * GL buffer names are scoped to their owning context, so a second `MapView` (e.g. in
         * another activity) seeing the cached integers will bind something unrelated — typically a
         * Mapbox-owned buffer — and tile draws read garbage vertex data, making the layer invisible
         * even though basemap tiles render normally. Re-allocate whenever the current context
         * differs from this snapshot. We do *not* rely on [notifyRasterQuadVbosContextLost] alone:
         * Mapbox v11 preserves the old context across activity pause and only fires `contextLost`
         * on view detach, which is too late.
         */
        private var rasterQuadVboContext: EGLContext? = null

        /** GLES3 requires VBO-backed attributes for the unit quad used by raster/sample layers. */
        fun bindRasterTileVertexAttributes(prog: RasterTileProgram) {
            synchronized(rasterQuadVboLock) {
                val currentContext = EGL14.eglGetCurrentContext()
                val sameContext = rasterQuadPosVbo != 0
                    && rasterQuadVboContext != null
                    && rasterQuadVboContext == currentContext
                    && currentContext != EGL14.EGL_NO_CONTEXT
                if (!sameContext) {
                    val ids = IntArray(2)
                    GLES31.glGenBuffers(2, ids, 0)
                    rasterQuadPosVbo = ids[0]
                    rasterQuadTexVbo = ids[1]
                    rasterQuadVboContext = currentContext
                    val posBytes = VERTEX_COUNT * COORDS_PER_VERTEX * BYTES_PER_FLOAT
                    GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, rasterQuadPosVbo)
                    vertexBuffer.position(0)
                    GLES31.glBufferData(GLES31.GL_ARRAY_BUFFER, posBytes, vertexBuffer, GLES31.GL_STATIC_DRAW)
                    val texBytes = VERTEX_COUNT * TEXTURE_SIZE * BYTES_PER_FLOAT
                    GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, rasterQuadTexVbo)
                    textureCoordinatesBuffer.position(0)
                    GLES31.glBufferData(GLES31.GL_ARRAY_BUFFER, texBytes, textureCoordinatesBuffer, GLES31.GL_STATIC_DRAW)
                    GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, 0)
                }
            }
            // Stencil renderer uses attribute location 0 and disables it in cleanup.
            // Re-enable both raster attributes before each tile draw to avoid invisible quads.
            GLES31.glEnableVertexAttribArray(prog.positionHandle)
            GLES31.glEnableVertexAttribArray(prog.texPositionHandle)
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, rasterQuadPosVbo)
            GLES31.glVertexAttribPointer(
                prog.positionHandle,
                COORDS_PER_VERTEX,
                GLES31.GL_FLOAT,
                false,
                VERTEX_STRIDE,
                0,
            )
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, rasterQuadTexVbo)
            GLES31.glVertexAttribPointer(
                prog.texPositionHandle,
                TEXTURE_SIZE,
                GLES31.GL_FLOAT,
                false,
                TEXTURE_STRIDE,
                0,
            )
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, 0)
        }

        /** Invalidate cached quad VBO names after EGL/GL context loss (handles are not portable). */
        fun notifyRasterQuadVbosContextLost() {
            synchronized(rasterQuadVboLock) {
                rasterQuadPosVbo = 0
                rasterQuadTexVbo = 0
                rasterQuadVboContext = null
            }
        }

        private val vertexArray = UnitQuad2DGeometry.genQuad1x1()
        val vertexBuffer =
            ByteBuffer.allocateDirect(VERTEX_COUNT * COORDS_PER_VERTEX * BYTES_PER_FLOAT).run {
                order(ByteOrder.nativeOrder())// use the device hardware's native byte order
                asFloatBuffer()       // create a floating point buffer from the ByteBuffer
            }
        private val textureArray = UnitQuad2DGeometry.genTexCoords1Quad()
        val textureCoordinatesBuffer = ByteBuffer.allocateDirect(textureArray.size * 4).run {
            order(ByteOrder.nativeOrder())
            asFloatBuffer()
        }

        init {
            vertexBuffer.apply {
                clear()
                put(vertexArray)
                rewind()
            }

            textureCoordinatesBuffer.apply {
                clear()
                put(textureArray)
                rewind()
                // position(0)
            }
        }
    }

    /**
     * Maps a possibly multi-world tile column [MeshInfo.x] into `[0, n)` for cache/texture hash keys.
     * Single ±n wraps are insufficient (e.g. `x = -8`, `n = 4` stays negative).
     */
    private fun normalizedTileXForTextureHash(mi: MeshInfo): Int {
        val zInt = mi.z.toInt()
        val n = powerTableI[zInt]
        if (n <= 0) return floor(mi.x.toDouble()).toInt()
        var x = floor(mi.x.toDouble()).toInt()
        x %= n
        if (x < 0) x += n
        return x
    }

    /**  Fix for not finding tiles across dateline (-180 or 180) **/
    private fun datelineAdjustment(meshInfo: MeshInfo) {
        if (pr.ON) pr.p(
            TAG,
            pr.hashmapLong,
            "datelineAdjustment(), hashString: ${hashString}    meshInfo.hashcode:, ${meshInfo.hashCode}  "
        )
        val n = powerTableI[meshInfo.z.toInt()]
        if (n <= 0) return
        var x = meshInfo.x
        while (x < 0f) x += n
        while (x >= n) x -= n
        meshInfo.x = x
        // Keep hash format consistent with `TileCoord.hash()` when time is empty:
        // "wrap:z/x/y/" (note trailing slash).
        meshInfo.hashCode = "0:${meshInfo.z.toInt()}/${meshInfo.x.toInt()}/${meshInfo.y.toInt()}/"
    }


    /**  Fix for not finding tiles across dateline (-180 or 180) **/
    private val powerTableI = intArrayOf(
        1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048,
        4096, 8192, 16384, 32768, 65536, 131072, 262144, 524288, 1048576, 2097152, 4194304
    )
}

fun getMaxFragmentTextureUnits(): Int {
    val params = IntArray(1)
    // Try GLES30 first if available, otherwise fallback or assume GLES20 context
    // In a real app, you'd know your GLES context version.
    try {
        GLES30.glGetIntegerv(GLES30.GL_MAX_TEXTURE_IMAGE_UNITS, params, 0)
        if (GLES30.glGetError() == GLES30.GL_NO_ERROR) {
            return params[0]
        }
    } catch (e: Throwable) {
        // GLES30 might not be available or context not 3.0
    }

    // Fallback to GLES20 if GLES30 query failed or not applicable
    GLES20.glGetIntegerv(GLES20.GL_MAX_TEXTURE_IMAGE_UNITS, params, 0)
    return params[0]
}

data class InterpolationResult(
    val lowerBound: Long,
    val upperBound: Long,
    val fraction: Float,
    val aInt: Int,
    val bInt: Int
)