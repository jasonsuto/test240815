package com.xweather.mapsgl.network

class Urls {
    internal companion object{
        //const val mapsGLServer="https://dev.v1.api.mapsgl.aerisapi.com" //sometimes this one doesn't work...
        //const val mapsGLServer = "https://staging.v1.api.mapsgl.aerisapi.com"
        const val mapsGLServer = "https://prod.v1.api.mapsgl.aerisapi.com"
        const val ampServer = "https://maps.aerisapi.com"
    }
}
