package com.xweather.mapsgl.coordinates

/**
 *  MapBounds.kt
 *
 *  @author Jason Suto 12/22/23.
 *
 *  Adapted from IOS version
 *  A 2D coordinate on a map or the world, in one of many `CoordinateSpace`s or zoom levels of some.
 *  Not intended to represent a `zoomLevel` as a 3rd dimension— this is where on the 2D map you are, with any `CoordinateSpace` zoom levels already figured in.
 *  (Any potential 3rd dimension would be altitude.)
 *
 */

typealias LatLonBounds = MapBounds<LatitudeLongitudeCoordinateSpace>

class MapBounds<Space : MapCoordinateSpace>(
    var southWestExtent: CoordinateValue, var northEastExtent: CoordinateValue
) {
    lateinit var space: Space

    constructor(
        southWestExtent: CoordinateValue, northEastExtent: CoordinateValue, space: Space
    ) : this(southWestExtent, northEastExtent) {
    }

    constructor(sw: MapCoordinate<Space>, ne: MapCoordinate<Space>) : this(sw.value, ne.value) {
        this.space = sw.space
    }

    val southWestCoordinate: MapCoordinate<Space>
        get() = MapCoordinate(southWestExtent, space)


    val northEastCoordinate: MapCoordinate<MapCoordinateSpace>
        get() = MapCoordinate(northEastExtent, space)

    /**
     * Initializes a `MapBounds` with the given south-west and north-east coordinates and the specified coordinate space.
     * Throws an error if the given coordinates are in different spaces.
     */

    class MapBounds<LatitudeLongitude : MapCoordinateSpace> {

        constructor(
            southWestExtent: MapCoordinate<LatitudeLongitude>, northEastExtent: MapCoordinate<LatitudeLongitude>
        ) {
            this(southWestExtent.value, northEastExtent.value, LatitudeLongitude())
        }

        private operator fun invoke(
            mapCoordinateValue: MapCoordinateValue,
            mapCoordinateValue1: MapCoordinateValue,
            latitudeLongitude: com.xweather.mapsgl.coordinates.LatitudeLongitude
        ) {

        }
    }

    val southExtent: Scalar
        get() = southWestExtent.y
    val northExtent: Scalar
        get() = northEastExtent.y
    val westExtent: Scalar
        get() = southWestExtent.x
    val eastExtent: Scalar
        get() = northEastExtent.x

}

fun init(
    southWestExtent: MapCoordinate<LatitudeLongitude>, northEastExtent: MapCoordinate<LatitudeLongitude>
): MapBounds<LatitudeLongitude> {
    return MapBounds(southWestExtent.value, northEastExtent.value, LatitudeLongitude())
}
