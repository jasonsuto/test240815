package com.xweather.mapsgl.controls.legend

import com.xweather.mapsgl.style.ColorScaleOptions
import com.xweather.mapsgl.style.ColorStop


// Assuming ColorScaleOptions and ColorMaskOptions are defined like this.
// You should adjust them to match your actual data structures.
data class ColorScaleOptionsLegendDisabled(
    val stops: List<ColorStop>,
    val range: ClosedRange<Float>? = null
) {
    var normalized: Boolean = true
    var interpolate: Boolean = true
    var interval: Double = 0.0
    var positions: List<Double> = mutableListOf()
}

data class ColorMaskOptions(var colorScale: ColorScaleOptions)


/**
 * Describes how a color scale is configured, which can either be a single scale
 * or a collection of scales for specific data masks.
 */
sealed class ColorScaleSpecification {

    /** A single, global color scale. */
    data class Single(val scale: ColorScaleOptions) : ColorScaleSpecification()

    /** A set of color scales, each corresponding to a data mask. */
    data class Masked(val masks: List<ColorMaskOptions>) : ColorScaleSpecification()

    /**
     * Applies a transformation to the ColorScaleOptions within the specification and returns a new,
     * updated ColorScaleSpecification instance.
     *
     * @param body A lambda function that receives the `ColorScaleOptions` to modify
     * and an optional `ColorMaskOptions` if the specification is of type `Masked`.
     * @return A new `ColorScaleSpecification` with the transformations applied.
     */
    fun mapColorScaleOptions(body: (options: ColorScaleOptions, mask: ColorMaskOptions?) -> ColorScaleOptions): ColorScaleSpecification {
        return when (this) {
            is Single -> {
                // Apply the transformation to the single scale.
                val newScale = body(this.scale, null)
                Single(newScale)
            }

            is Masked -> {
                // Map over each mask, apply the transformation, and create a new list.
                val newMasks = this.masks.map { mask ->
                    val newScale = body(mask.colorScale, mask)
                    mask.copy(colorScale = newScale)
                }
                Masked(newMasks)
            }
        }
    }
}
