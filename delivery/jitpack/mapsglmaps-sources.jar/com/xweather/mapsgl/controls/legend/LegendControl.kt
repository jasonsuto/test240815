package com.xweather.mapsgl.controls.legend

import android.graphics.Color
import android.os.Looper
import androidx.annotation.Keep
import androidx.annotation.MainThread
import androidx.core.view.isNotEmpty
import androidx.core.view.isVisible
import com.mapbox.maps.MapView
import com.xweather.mapsgl.controls.legend.Point.PointLegend
import com.xweather.mapsgl.controls.legend.bar.BarLegend
import com.xweather.mapsgl.map.MeasurementUnits
import com.xweather.mapsgl.map.MeasurementUnits.Companion.isMetric


/**
 * The `LegendControl` acts as a high-level manager for map legends within a Mapbox environment.
 *
 * It coordinates the lifecycle, visual state, and unit synchronization (Metric/Imperial) of legends.
 * This class handles:
 * - **Shared Legends:** Uses reference counting to ensure a single legend ID can be used by
 *   multiple layers, only removing the UI when the last layer is removed.
 * - **Unit Conversion:** Supports dynamic toggling between Imperial and Metric units across
 *   all hosted legends.
 * - **UI Management:** Automatically manages a [LegendContainerView], including the
 *   injection of separators and specialized [LegendView] instances.
 *
 * @property backgroundColor The background color of the legend container.
 * @property units The current [MeasurementUnits] applied to all legends.
 * @property toggleUnitsOnTap If true, clicking the legend container toggles unit systems.
 * @property isHidden External control for the visibility of the legend container.
 */
@Keep
class LegendControl(/*var mapView: MapView? = null*/) {

    var mapView: MapView? = null
    private var legendTitleColor: androidx.compose.ui.graphics.Color = androidx.compose.ui.graphics.Color.Black
    private var legendLabelColor: Int = Color.BLACK


    var backgroundColor: androidx.compose.ui.graphics.Color = androidx.compose.ui.graphics.Color.Transparent
        set(value) {
            field = value
            if (::containerView.isInitialized) {
                containerView.setBackgroundColor(value)
            }
        }
        get() = field

    /**
     * Returns the [LegendContainerView] associated with this control.
     * This view acts as the visual parent for all individual legend items.
     */
    fun getView(): LegendContainerView {
        return containerView
    }

    @Keep
    lateinit var containerView: LegendContainerView


    /**
     * Initializes the control by associating it with a [MapView] and inflating the [LegendContainerView].
     * Must be called before adding legends to the map.
     */
    internal fun setup(mapView: MapView) {
        this.mapView = mapView
        containerView = LegendContainerView(mapView.context)
        containerView.isVisible = true

        containerView.setOnClickListener {
            toggleUnits()
        }
    }

    /**
     * Units applied to the hosted legends. Updating this value propagates the new units
     * to each registered legend.
     */
    var units: MeasurementUnits = MeasurementUnits.IMPERIAL
        private set

    /**
     * Indicates whether tapping the legend view toggles between metric and imperial units.
     * This state should be used by the UI to add a click handler.
     */
    var toggleUnitsOnTap: Boolean = true

    /**
     * Controls the visibility of the legend container. The container should also be hidden
     * if there are no legends to display.
     */
    var isHidden: Boolean = false

    /**
     * The currently active legends, mapped by their unique ID.
     * This list should be observed by the UI to render the correct legends.
     */
    var legends: Map<String, Legend> = emptyMap()
        private set

    // Internal state to manage how many layers are referencing a single legend.
    private val legendRefCounts = mutableMapOf<String, Int>()

    /**
     * Toggles the measurement units between METRIC and IMPERIAL if `toggleUnitsOnTap` is true.
     * This function is intended to be called by the UI (e.g., from a click listener).
     */
    fun toggleUnits() {
        if (toggleUnitsOnTap) {
            units = if (units == MeasurementUnits.IMPERIAL) {
                MeasurementUnits.METRIC
            } else {
                MeasurementUnits.IMPERIAL
            }
            legends.values.forEach { containerView.updateLegend(it.units(units)) }
        }
    }

    private fun setLegendTitleColor(titleColor: androidx.compose.ui.graphics.Color) {
        legendTitleColor = titleColor

        for (i in 0 until containerView.childCount) {
            val child = containerView.getChildAt(i)
            if (child is LegendView) {
                child.legend?.let { legend ->
                    legend.titleColorValue = legendTitleColor
                    child.setLegend(legend)
                }
            }
        }
    }

    private fun setLegendLabelColor(labelColor: Int) {
        if (containerView == null) return

        legendLabelColor = labelColor


        for (i in 0 until containerView.childCount) {
            val child = containerView.getChildAt(i)

            if (child is LegendView) {
                child.legend?.let { legend ->
                    if (legend is PointLegend) {
                        legend.labelColor = androidx.compose.ui.graphics.Color(legendLabelColor)
                        child.setLegend(legend)
                    }

                }
            }
        }
    }

    /**
     * Adds a legend to the container.
     *
     * Implementation Details:
     * - Increments a reference count for the legend ID.
     * - If it's a new ID, it determines the initial unit system (Metric vs Imperial)
     *   by inspecting the [BarLegend] items or falling back to the global control unit.
     * - Injects a [LegendView] and manages vertical separators.
     *
     * @param legend The legend data to be visualized.
     */
    fun add(legend: Legend) {

        val id = legend.id
        val currentRefCount = legendRefCounts.getOrDefault(id, 0)
        legendRefCounts[id] = currentRefCount + 1

        if (currentRefCount > 0) {
            return
        }

        // Determine the initial unit system for this specific legend without changing the control's state.
        val initialUnits = (legend as? BarLegend<*>)
            ?.items?.firstOrNull()?.labels?.currentUnits
            ?.let { unit -> if (isMetric(unit)) MeasurementUnits.METRIC else MeasurementUnits.IMPERIAL }
            ?: this.units // Fallback to the control's current unit system.

        val legendWithUnits = legend.units(initialUnits)
        legends = legends + (id to legendWithUnits)

        val newLegendView = mapView?.let {
            LegendView(it.context).apply {
                tag = legendWithUnits.id
                setLegend(legendWithUnits)

                // Add these lines to prevent the view from intercepting clicks
                isClickable = false
                isFocusable = false
                // This ensures children inside the LegendView also don't steal clicks
                this.descendantFocusability = android.view.ViewGroup.FOCUS_BLOCK_DESCENDANTS
            }
        }

        if (newLegendView != null) {
            if (containerView.isNotEmpty()) {
                val separator = containerView.createSeparator()
                containerView.addView(separator)
            }

            containerView.addView(newLegendView)
        }
    }

    /**
     *  Removes a legend it from the UI if no longer needed.
     *
     * This function implements a reference-counting mechanism to allow multiple map layers
     * to share the same legend. The legend's visual components are only removed from the
     * [containerView] when its reference count reaches zero, or if [force] is set to true.
     *
     *
     * @param id The unique identifier of the legend to be removed.
     * @param force If true, immediately removes the legend from the UI and cache,
     *              ignoring the current reference count.
     */
    fun removeLegend(id: String, force: Boolean = false) {

        val currentRefCount = legendRefCounts.getOrDefault(id, 1)
        val newRefCount = currentRefCount - 1

        if (!force && newRefCount > 0) {
            legendRefCounts[id] = newRefCount
            return
        }

        if (id == "alerts") {
            //  view!!.removeOnLayoutChangeListener(alertLayoutListener)
        }

        legends[id]?.let { legendToRemove ->
            // --- START: SMARTER REMOVAL LOGIC ---
            val viewToRemove = containerView.findViewWithTag<LegendView>(legendToRemove.id) ?: return@let
            val indexToRemove = containerView.indexOfChild(viewToRemove)

            // Prepare the layout listener that will fix the container's position after removal.
            //fixme: Removed this to test 1.4.0
            /*
            val layoutListener = createRemoveLayoutListener()
            view!!.addOnLayoutChangeListener(layoutListener)
            */
            // If the legend is the FIRST item (index 0) AND there are more items after it,
            // remove the separator that comes AFTER it.
            if (indexToRemove == 0 && containerView!!.childCount > 1) {
                // The separator is at the next index (1).
                val separatorToRemove = containerView!!.getChildAt(1)
                containerView!!.removeView(separatorToRemove)
                containerView!!.removeView(viewToRemove)
            }
            // If the legend is NOT the first item, remove the separator BEFORE it.
            else if (indexToRemove > 0) {
                // The separator is at the index just before the legend view.
                val separatorToRemove = containerView!!.getChildAt(indexToRemove - 1)
                containerView!!.removeView(separatorToRemove)
                containerView!!.removeView(viewToRemove)
            }
            // Otherwise, it's the only item in the container, so just remove it.
            else {
                containerView!!.removeView(viewToRemove)
            }
            // --- END: SMARTER REMOVAL LOGIC ---
        }

        legends = legends - id
        legendRefCounts.remove(id)
    }

    // Helper for creating the listener to avoid duplicate code
    //fixme: commented this out to fix for 1.4.0
    /*
    private fun createRemoveLayoutListener(): View.OnLayoutChangeListener {
        val heightBefore = view!!.height
        return object : View.OnLayoutChangeListener {
            override fun onLayoutChange(v: View?, l: Int, t: Int, r: Int, b: Int, ol: Int, ot: Int, or: Int, ob: Int) {
                val heightAfter = view!!.height
                val heightDifference = heightBefore - heightAfter
                if (heightDifference > 0) {
                    // containerView!!.y += heightDifference
                }
                view!!.removeOnLayoutChangeListener(this)
            }
        }
    } */

    /**
     * Updates the data of an existing legend without changing its position in the UI.
     *
     * This is typically used when the underlying data source (e.g., a weather layer)
     * changes its range or units, requiring the visual scale to refresh.
     *
     * @param legend The updated legend instance.
     */
    fun update(legend: Legend) {

        if (legends.containsKey(legend.id)) {
            //println(">>> LegendControl.update() legend.units = ${legend.units}")

            val legendWithUnits = legend.units(legend.units)
            legends = legends + (legend.id to legendWithUnits)

            //println(">>> LegendControl.update() this.units = ${this.units}")
            //legends.values.forEach { containerView.updateLegend(it.units(units)) }
            containerView.updateLegend(legendWithUnits)
        }
    }

    /**
     * Retrieves the currently active [Legend] instance for the given identifier.
     *
     * @param id The unique identifier of the legend.
     * @return The [Legend] object if found, or null otherwise.
     */
    fun getLegend(id: String): Legend? {
        return legends[id]
    }

    /**
     * Defines a contract for a UI component (usually an Activity or Fragment)
     * capable of hosting a [LegendControl].
     */
    interface Host {
        /** The currently installed legend control, if present. */
        val legendControl: LegendControl?

        /** Installs the provided legend control into the host environment. */
        @MainThread
        fun add(legendControl: LegendControl)

        /** Removes an installed legend control from the host environment. */
        @MainThread
        fun removeLegendControl()
    }


    /**
     * A lifecycle utility that facilitates the "Try Install" pattern between a [Host] and a [LegendControl].
     *
     * It ensures that the control is initialized only on the Main thread and manages
     * ownership state to prevent memory leaks or duplicate installations.
     *
     * @param provider A lambda returning the [Host] responsible for displaying the legend.
     */
    class Coordinator(private val provider: () -> Host?) {
        private var isInstalled = false
        private var isControlOwned = false

        val legendControl: LegendControl?
            get() = provider()?.legendControl

        init {
            // Ensure this is only called from the main thread
            check(Looper.myLooper() == Looper.getMainLooper()) {
                "Coordinator must be initialized on the main thread"
            }
        }

        /**
         * Connects the Coordinator to the Host, creating and installing a
         * `LegendControl` if one doesn't already exist.
         *
         * @return The active `LegendControl` instance, or `null` if the host is unavailable.
         */
        @MainThread
        fun tryInstall(): LegendControl? {
            val host = provider() ?: return null
            if (isInstalled) return host.legendControl

            isControlOwned = host.legendControl == null
            val control = host.legendControl ?: LegendControl() // Creates a default instance if needed
            host.add(control)
            isInstalled = true
            return control
        }

        /**
         * Disconnects the `LegendControl` from the host. If the coordinator created
         * the control (`isControlOwned`), it will be fully removed.
         */
        @MainThread
        fun teardown() {
            val host = provider()
            if (!isInstalled || host?.legendControl == null) {
                return
            }
            if (isControlOwned) {
                host.removeLegendControl()
            }
            isInstalled = false
        }
    }


    companion object {
        /**
         * Describes a host capable of installing or removing a `LegendControl`.
         * This is the Kotlin equivalent of the `Host` protocol.
         */
        interface Host {
            /** The currently installed legend control, if present. */
            val legendControl: LegendControl?

            /** Installs the provided legend control into the host environment. */
            @MainThread
            fun add(legendControl: LegendControl)

            /** Removes an installed legend control from the host environment. */
            @MainThread
            fun removeLegendControl()
        }


    }
    // --- END OF ADDED CODE ---
}
