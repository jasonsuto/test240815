package com.xweather.mapsgl.controls.legend

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.xweather.mapsgl.controls.legend.Point.PointLegend
import com.xweather.mapsgl.controls.legend.Point.PointLegendItem
import com.xweather.mapsgl.controls.legend.bar.BarLegend
import com.xweather.mapsgl.controls.legend.bar.BarLegendItem
import com.xweather.mapsgl.extensions.Dimension
import com.xweather.mapsgl.map.MeasurementUnits
import com.xweather.mapsgl.style.LayerPaint

/**
 * A data class holding default styling values for a legend component.
 */
data class LegendDefaults(

    val titleFontWeight: FontWeight = FontWeight.Bold,
    val titleColor: Color = Color.Black, // Equivalent to UIColor.label in light mode
    val backgroundColor: Color = Color.White, // Equivalent to UIColor.systemBackground in light mode
    val margins: PaddingValues = PaddingValues(horizontal = 3.dp, vertical = 4.dp),
    val insets: PaddingValues = PaddingValues(8.dp),
    val cornerRadius: Dp = 8.dp

) {
    companion object {
        val titleFontSize: TextUnit = 12.sp
        val titleFontWeight = FontWeight.Bold
        val titleColor: Color = Color.Black
    }
}

/**
 * Describes the data and view-building hooks required for a legend.
 * This is designed to be implemented by a data-holding class, often a data class,
 * which can then be rendered by a Composable function.
 */
interface Legend {
    /**
     * Unique identifier used to register and manage the legend instance.
     */
    val id: String

    var titleColorValue: Color

    /**
     * Display title rendered above the legend content.
     */
    var title: String?

    /** The size of the Title Text **/
    var titleFontSize: TextUnit

    /**
     * Units used when formatting any measurement values displayed by the legend.
     */
    val units: MeasurementUnits

    /**
     * Allows an implementing class to create a new version of itself with an updated title.
     * @return A new instance of the Legend with the updated title.
     */
    fun title(newValue: String?): Legend

    /**
     * Allows an implementing class to create a new version of itself with updated units.
     * @return A new instance of the Legend with the updated units.
     */
    fun units(newValue: MeasurementUnits): Legend

    //fun items(newItems: List<BarLegendItem<UnitConcentrationMass>>)
    fun items(newItems: List<BarLegendItem<Dimension>>): BarLegend<*>
    fun items(newItems: List<PointLegendItem>): PointLegend
    fun updateFromPaint(paint: LayerPaint): Legend
    fun titleColor(color: androidx.compose.ui.graphics.Color): Legend {
        titleColorValue = color
        return this
    }

}

