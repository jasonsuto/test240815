package com.xweather.mapsgl.anim

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
/** @suppress **/
class AnimationLoop {
    /** @suppress **/
    private val loop: RenderLoop
    private val animations: MutableSet<Animation> = mutableSetOf()

    constructor() {
        loop = RenderLoop(this::tick)
    }

    fun add(animation: Animation) {
        if (!animations.contains(animation)) {
            animations.add(animation)
            loop.start()
        }
    }

    fun remove(animation: Animation) {
        if (animations.contains(animation)) {
            animations.remove(animation)
        }
        if (animations.size == 0) {
            loop.stop()
        }
    }

    private fun tick(elapsedTime: Double) {
        animations.forEach { animation ->
            animation.tick(elapsedTime)
        }
    }
}

/** @suppress **/
class RenderLoop(private var callback: ((elapsedTime: Double) -> Unit)? = null, private var autoStart: Boolean = true) {
    private var handle: Int? = null
    private var clock: Double = 0.0
    private var running: Boolean = false
    private var job: Job? = null
    //private var isRunning: Boolean = false //Needs to be updated by methods such as play(), pause() etc.
    val elapsedTime: Double
        get() = clock

    init {
        if (autoStart) {
            start()
        }
    }

    fun start() {
        if (!running) {
            running = true
           // handle = window.requestAnimationFrame { tick() }
        }
    }

    fun stop() {
        if (running) {
            running = false
          //  handle?.let { window.cancelAnimationFrame(it) }
            handle = null
        }
    }

    fun dispose() {
        stop()
        callback = null
    }

    private fun tick() {
        job = CoroutineScope(Dispatchers.Main).launch { // Dispatchers.Main for UI updates
            while (running) {
                delay(16) // ~60fps. Adjust as needed.
                callback?.invoke(elapsedTime) // Safe call operator in case callback is null
            }
        }
    }

}
