package com.xweather.mapsgl.anim

import java.util.Date

/** Variables to be passed to the MapController constructor to modify timeline settings.
 * @suppress
 * **/
open class AnimationOptions {

    /**
     * A flag to enable or disable the pre-fetching of animation data for the
     * current timeline range.
     *
     * When set to `true`, the system will attempt to cache tiles for the visible
     * viewport across the active time range to ensure playback is ready when the user plays the animation.
     */
    @set:JvmName("setShouldPreloadData") // Helps IDE resolution in mixed environments
    @get:JvmName("getShouldPreloadData")
    var shouldPreloadData: Boolean = false
        /** @param value Set to true to begin pre-fetching tiles for the timeline range. */
        set(value) {
            if (field != value) {
                field = value
                // Trigger an update on the listener if it exists
                onPreloadChanged?.invoke(value)
            }
        }

    // A callback to notify MapController or others
    internal var onPreloadChanged: ((Boolean) -> Unit)? = null

    // Public properties that will hold the final Date values
    open var start: Date = Date()
    open var end: Date = Date(Date().time + (3600 * 1000 * 24))

    /** The total time (in seconds) it takes to complete one full cycle of the animation from start to end. */
    open var duration: Double = 2.0

    /** The amount of time (in seconds) to wait before starting the animation for the first time. */
    open var delay: Double = 0.0

    /** The amount of time (in seconds) to pause at the end of the timeline before the animation loops or stops. */
    open var endDelay: Double = 1.0

    /** If `true`, the animation will begin playing automatically as soon as the timeline is initialized and data is available. */
    var autoPlay: Boolean

    /** Whether the animation should restart from the beginning once it reaches the end of the timeline. */
    open var repeat: Boolean = true

    /** Whether the timeline and its associated animation logic are active. If `false`, the timeline will remain static. */
    open var enabled: Boolean = true

    /**
     * A multiplier for the playback speed.
     * For example, 2.0 will play the animation at double speed, while 0.5 will play it at half speed.
     */
    open var timeScale: Double = 1.0

    /**
     * If `true`, the timeline will not progress automatically based on time.
     * Progression must be handled manually by updating the current time or frame index.
     */
    open var manualAdvance: Boolean = false

    /**
     * If `true`, every time the animation is started or resumed, it will reset to the
     * [start] date instead of resuming from the last played position.
     */
    open var alwaysPlayFromBeginning: Boolean = false

    /** @internal Internal unique identifier for this animation options instance. */
    internal open var id: String = ""

    /** @internal Internal flag used to trigger a single, non-persistent pre-fetch of tile data. */
    internal var forcePreloadOneTime = false


    // --- Primary Constructor (using Date objects) ---
    constructor(
        start: Date = Date(),
        end: Date = Date(Date().time + (1000L * 3600 * 24)),
        duration: Double = 2.0,
        delay: Double = 0.0,
        endDelay: Double = 1.0,
        autoPlay: Boolean = false,
        repeat: Boolean = true,
        enabled: Boolean = true,
        manualAdvance: Boolean = false,
        alwaysPlayFromBeginning: Boolean = false,
    ) {
        this.start = start
        this.end = end
        this.duration = duration
        this.delay = delay
        this.endDelay = endDelay
        this.autoPlay = autoPlay
        this.repeat = repeat
        this.enabled = enabled
        this.manualAdvance = manualAdvance
        this.alwaysPlayFromBeginning = alwaysPlayFromBeginning


        // Validate that end date is after start date
        if (this.end.before(this.start)) {
            System.err.println("AnimationOptions Warning: End date is before start date. Adjusting end date to be start + 24 hours.")
            this.end = Date(this.start.time + (1000L * 3600 * 24))
        }
    }

    // --- Secondary Constructor (using String for start and end) ---
    constructor(
        start: String,
        end: String,
        duration: Double = 2.0,
        delay: Double = 0.0,
        endDelay: Double = 1.0,
        autoPlay: Boolean = false,
        repeat: Boolean = true,
        enabled: Boolean = true,
    ) : this( // Delegate to the primary (Date-based) constructor
        // Call helper function to parse/default start date
        start = TimeConverter.stringToDate(start)!!,
        end = TimeConverter.stringToDate(end)!!,
        duration = duration, delay = delay, endDelay = endDelay, autoPlay = autoPlay,
        repeat = repeat, enabled = enabled
    )
    // Body is empty

    // --- Secondary Constructor (String for start, Date for end) ---
    constructor(
        start: String,
        end: Date,
        duration: Double = 2.0,
        delay: Double = 0.0,
        endDelay: Double = 1.0,
        autoPlay: Boolean = false,
        repeat: Boolean = true,
        enabled: Boolean = true,
    ) : this(
        start = TimeConverter.stringToDate(start)!!,
        end = end, // Pass Date directly
        duration = duration, delay = delay, endDelay = endDelay, autoPlay = autoPlay,
        repeat = repeat, enabled = enabled,
    )
    // Body is empty

    // --- Secondary Constructor (Date for start, String for end) ---
    constructor(
        start: Date,
        end: String,
        duration: Double = 2.0,
        delay: Double = 0.0,
        endDelay: Double = 1.0,
        autoPlay: Boolean = false,
        repeat: Boolean = true,
        enabled: Boolean = true,
    ) : this(
        start = start, // Pass Date directly
        end = TimeConverter.stringToDate(end)!!, // Pass start date for default end calc
        duration = duration, delay = delay, endDelay = endDelay, autoPlay = autoPlay,
        repeat = repeat, enabled = enabled,
    )
}
