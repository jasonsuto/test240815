package com.xweather.mapsgl.anim

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Formats timeline instants for on-screen labels using the device timezone and `en` locale,
 * matching MapsGL JS examples (`toLocaleDateString('en')` / `toLocaleTimeString('en')`).
 *
 * Tile requests still use UTC ISO strings from [Timeline.formatDateToUTCString].
 */
object TimelineDisplayFormatter {
    private val locale = Locale.US

    private val startEndFormatter = SimpleDateFormat("MM/dd/yyyy h:mm a", locale)
    private val currentTimeFormatter = SimpleDateFormat("h:mm a", locale)
    private val currentDateFormatter = SimpleDateFormat("EEE, MMM d", locale)

    fun formatStartEnd(date: Date): String = startEndFormatter.format(date)

    fun formatCurrentTime(date: Date): String = currentTimeFormatter.format(date)

    fun formatCurrentDate(date: Date): String = currentDateFormatter.format(date)

    /** JS operational examples (`timeZone: 'UTC'`) — optional explicit UTC labels. */
    fun formatCurrentTimeUtc(date: Date): String =
        SimpleDateFormat("h:mm a", locale).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(date)

    fun formatCurrentDateUtc(date: Date): String =
        SimpleDateFormat("EEE, MMM d", locale).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(date)
}
