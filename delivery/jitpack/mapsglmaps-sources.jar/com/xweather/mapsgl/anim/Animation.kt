package com.xweather.mapsgl.anim

import com.xweather.mapsgl.data.series.TimeInterval
import com.xweather.mapsgl.events.Event
import com.xweather.mapsgl.events.TimeSeriesEvent
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.tiles.Tile
import com.xweather.mapsgl.tiles.TileData
import kotlinx.coroutines.flow.MutableSharedFlow
import java.util.Date

/** @suppress **/
val Loop = AnimationLoop()

/**  @suppress  **/
@Suppress("Dokka")
open class Animation : EventDispatcher {
    private val TAG1 = "Animation"
    internal open lateinit var opts: AnimationOptions
    internal var lastInterval = 0

    class AnimationDefaults : AnimationOptions() {
        internal override var id: String = "" // Or null if String is nullable in your AnimationOptions
        override var enabled: Boolean = true

        /** Whether the animation should begin playing immediately. */
        val autoplay: Boolean = false
        override var duration: Double = 1.0
        override var delay: Double = 0.0
        override var endDelay: Double = 1.0
        override var timeScale: Double = 1.0

        /** Whether the animation should restart after completing playback. */
        override var repeat: Boolean = true
        override var manualAdvance: Boolean = false
    }

    constructor() : super()

    constructor(animationOpts: AnimationOptions) : super() {
        _enabled = animationOpts.enabled
        opts = animationOpts
        if (opts.autoPlay) {
            setTimeout({
                play(null, false)
            }, 1000)
        }
    }


    companion object {
        var lastTime: String = ""


    }

    internal val _config: State<AnimationOptions> = State(AnimationDefaults() as AnimationOptions)
    internal var _state: AnimationState = AnimationState.initial

    internal var _active = false
    internal var _enabled = true
    internal var _elapsed = 0.0
    internal var _lastElapsed = -1.0
    internal var timeline: Timeline? = null
    private var _startPosition = 0.0

    internal var pendingCount = 0
    internal var lastPendingCount = 0

    /**
     * Whether the animation should always play from the beginning. When false, the animation will resume from its
     * current position when restarted. Defaults to `false`.
     */
    val alwaysPlayFromBeginning: Boolean
        get() = _config.value.alwaysPlayFromBeginning

    val id: String
        get() = _config.value.id

    val config: State<AnimationOptions>
        get() = _config

    val state: AnimationState
        get() = _state

    var enabled: Boolean
        get() = _enabled
        set(value) {
            _enabled = value
        }


    /** Duration the animation should take to complete, in seconds. */
    var duration: Double = 0.0
    // get() = _config.value.duration

    /** Duration to wait before starting the animation, in seconds. */
    var delay: Double = 0.0
        get() = field
        set(value) {
            field = value
            //_config.setState(_config.value.copy(delay = value))
        }

    private var delayCounter = 0.0


    /** Duration to hold the end of the animation before repeating, in seconds. */
    var endDelay: Double = 0.0
        get() = field
        set(value) {
            field = value
            //  _config.setState(_config.value.copy(endDelay = value))
        }


    val totalDuration: Double
        get() = delay + duration + endDelay

    val elapsedTime: Double
        get() = _elapsed

    open val position: Double
        get() {
            if (_elapsed < delay) {
                return 0.0
            }
            if (_elapsed >= delay + duration) {
                return 1.0
            }
            return clamp((_elapsed - delay) / duration, 0.0, 1.0)
        }

    internal val totalPosition: Double
        get() = clamp(_elapsed / totalDuration, 0.0, 1.0)

    val isAnimating: Boolean
        get() = _state == AnimationState.playing

    val isPaused: Boolean
        get() = _state == AnimationState.paused

    val isActive: Boolean
        get() = isAnimating || isPaused

    /**
     * Begins playing the animation. If the animation is currently paused, it will restart playback from the beginning.
     * @param position - The position to start the animation at, as a value between `0` and `1`, where `0` is the
     * beginning of the animation and `1` is the end. Defaults to `0`.
     */
    open fun play(positionInput: Double? = null, startImmediately: Boolean) {

        if (isActive || !enabled) return

        var position = positionInput
        if (position == null) {
            position = if (this.alwaysPlayFromBeginning) 0.0 else this.position
        }
        position = clamp(position, 0.0, 1.0)

        _active = true
        _state = AnimationState.playing
        _startPosition = position

        // don't run internal render loop if animation belongs to a parent timeline
        // since the timeline controls advancing each animation; also don't run via render
        // loop if we're manually advancing from some external loop
        if (timeline == null && config.value.manualAdvance != true) {
            Loop.add(this)
        }

        advance(0.0, position == 1.0)
        val event = eventPayload()

        triggerAny(AnimationEvent.play, event)

    }


    internal fun checkInterval() {
        if (Timeline.timeStrings.isNotEmpty()) {
            //if(pr.ON) pr.p(TAG, pr.timeLineListener, "checkInterval() not empty")
            if (Timeline.timeStrings.size > Timeline.currentPhaseA) { // Removed equal sign to fix crash when using fire layer
                //if( Timeline.times.size >= Timeline.currentPhaseA ){
                if (Timeline.timeStrings[Timeline.currentPhaseA] != lastTime) {
                    //if(pr.ON) pr.p(TAG, pr.timeLineListener, "checkInterval() times not equal, old:$lastTime, new: ${Timeline.times[Timeline.currentPhaseA]}")
                    lastTime = Timeline.timeStrings[Timeline.currentPhaseA]
                    triggerAny(AnimationEvent.INTERVAL_CHANGE, eventPayload())
                }
            }
        }
    }

    open fun pause() {
        if (_state == AnimationState.playing) {
            _state = AnimationState.paused
            triggerAny(AnimationEvent.PAUSE, eventPayload())
        }
    }

    open fun resume() {
        if (_state == AnimationState.paused) {
            _state = AnimationState.playing
            triggerAny(AnimationEvent.RESUME, eventPayload())
        }
    }

    open fun stop() {
        if (!isActive) return
        if (pr.ON) pr.p(TAG, pr.timeMove, "stop(): Stopping")
        _active = false
        _state = AnimationState.stopped
        advanceToStopPosition()
        if (timeline == null) {
            Loop.remove(this)
        }
        triggerAny(AnimationEvent.stop, eventPayload())
    }

    open fun restart() {
        _elapsed = 0.0
        if (timeline == null) {
            Loop.add(this)
        }
        triggerAny(AnimationEvent.RESTART, eventPayload())
    }

    open fun reset() {
        if (_state == AnimationState.playing) {
            stop()
        } else {
            advanceToStopPosition()
        }
        triggerAny(AnimationEvent.RESET, eventPayload())
    }

    open fun toggle() {
        if (_active) {
            if (isAnimating) {
                pause()
            } else {
                resume()
            }
        }
    }

    fun enable() {
        _enabled = true
    }

    fun disable() {
        _enabled = false
    }

    open fun goTo(position: Double, useTotalDuration: Boolean = false) {
        advance(position, useTotalDuration)
    }

    internal fun proxyEvents(target: EventDispatcher, omitEvents: List<String> = emptyList()) {
        val events = listOf(
            AnimationEvent.play,
            AnimationEvent.stop,
            AnimationEvent.PAUSE,
            AnimationEvent.RESUME,
            AnimationEvent.RESTART,
            AnimationEvent.RESET,
            AnimationEvent.advance
        )
        events.filter { !omitEvents.contains(it) }
            .forEach { name ->
                on(name) { e ->
                    target.triggerAny(name, e) //Fixme: Not sure if this is the correct trigger for this
                }
            }
    }

    internal open fun advance(progress: Double, useTotalDuration: Boolean = false) {
        val position = clamp(progress, 0.0, 1.0)
        _elapsed = if (useTotalDuration) {
            // if (pr.ON) pr.p("Animation", pr.timeMove, "advance($progress, $useTotalDuration) _elapsed: $_elapsed")
            (totalDuration * position)
        } else {
            (delay + (duration * position))
        }
        if (pr.ON) pr.p("Animation", pr.timeMove, "advance()  position: $position, totalDuration: $totalDuration")
        if (pr.ON) pr.p("Animation", pr.timeMove, "advance()  delay: $delay, duration: $duration")
        if (pr.ON) pr.p("Animation", pr.timeMove, "advance($progress, $useTotalDuration) _elapsed: $_elapsed")
        //val payload = eventPayload()

        //triggerAny(AnimationEvent.advance, progress)
        triggerAny(AnimationEvent.advance, progress)
    }

    internal fun tick(elapsedTime: Double) {
        if (_lastElapsed < 0) {
            _lastElapsed = elapsedTime
        }
        val lastElapsed = _lastElapsed
        _lastElapsed = elapsedTime
        if (_state != AnimationState.playing) return
        val delta = elapsedTime - lastElapsed
        _elapsed += delta
        _elapsed = Math.min(_elapsed, totalDuration)
        val progress = totalPosition
        if (progress == 1.0) {
            if (pr.ON) pr.p("Animation", pr.timeMove, "tick($elapsedTime) A calling advance()")
            advance(progress)
            if (_config.value.repeat) {
                restart()
            } else {
                stop()
            }
        } else {
            if (pr.ON) pr.p("Animation", pr.timeMove, "tick($elapsedTime) B calling advance()")
            advance(progress)
        }
    }

    internal fun calculateProgressBetweenDates(startDate: Date, endDate: Date, middleDate: Date): Double {
        val startTime = startDate.time
        val endTime = endDate.time
        val middleTime = middleDate.time

        // Check if middleDate is before startDate or after endDate
        if (middleTime < startTime) {
            return 0.0
        } else if (middleTime > endTime) {
            return 1.0
        }

        val totalDuration = endTime - startTime
        val progressDuration = middleTime - startTime

        return progressDuration.toDouble() / totalDuration.toDouble()
    }

    internal open fun eventPayload(): Map<String, Any> {
        return mapOf(
            "position" to position,
            "totalPosition" to totalPosition
        )
    }

    internal open fun advanceToStopPosition() {
        advance(0.0)
    }
}


/**
 * @suppress This class is for internal use or experimental and should not be part of the public documentation.
 */
open class AnimationOptionsInternal(
    /** The unique identifier for the animation.  */
    internal open val id: String = "",

    /** Whether the animation is enabled. */
    open val enabled: Boolean = true,

    /** Whether the animation should autoplay when instantiated. */
    open val autoplay: Boolean = false,

    /** The duration of the animation in seconds. */
    open val duration: Double = 1.0,

    /** The delay before the animation starts in seconds. */
    open val delay: Double = 0.0,

    /** The delay after the animation ends in seconds. */
    open val endDelay: Double = 1.0,

    /** The time scale factor for the animation.  */
    open val timeScale: Double = 1.0,

    /** Whether the animation should repeat.  */
    open val repeat: Boolean = true,

    /** Whether the animation's progress is managed either manually or by an external source.  */
    open var manualAdvance: Boolean = false,

    var alwaysPlayFromBeginning: Boolean = true,

    )

/** @suppress **/
enum class AnimationState {
    initial,
    playing,
    paused,
    stopped,
    loading,
    ready,
}

/** @suppress **/
class AnimationEvent {
    companion object {
        /** Triggered when the animation begins playback. */
        const val play = "play"

        /** Triggered when the animation is stopped. */
        const val stop = "stop"

        /** Triggered when the animation is paused. */
        const val PAUSE = "pause"

        /** Triggered when the animation resumes playback from a paused state. */
        const val RESUME = "resume"

        /** Triggered when the animation restarts from the beginning.*/
        const val RESTART = "restart"

        /** Triggered when the animation is reset. */
        const val RESET = "reset"

        /** Triggered when the animation advances its playhead during playback. */
        const val advance = "advance"

        /** Triggered when the start or end date of the timeline changes. */
        const val range_change = "range:change"

        const val INTERVAL_CHANGE = "interval:change"

        const val TIMELINE_CHANGE = "timeline:change"
    }
}

/** @suppress **/
open class EventDispatcher {
    open val TAG = "EventDispatcher"
    private val listeners: MutableMap<String, MutableList<(Any) -> Unit>> = mutableMapOf()

    fun on(event: String, listener: (Any) -> Unit) {
        //if (pr.ON) pr.p(TAG, pr.trigger, "on(event:{$event} listener:${listener})")
        if (!listeners.containsKey(event)) {
            listeners[event] = mutableListOf()
        }
        listeners[event]?.add(listener)
    }

    fun off(event: String, listener: (Any) -> Unit) {
        listeners[event]?.remove(listener)
    }

    val eventFlow = MutableSharedFlow<Event>()

    fun triggerAny(event: String, data: Any) {
        if (pr.ON) pr.p(TAG, pr.trigger, "triggerAny(event:$event, data: ${data})")
        if (pr.ON) pr.p(TAG, pr.trigger, "trigger() listeners[] size: ${listeners.size}  ")
        listeners[event]?.forEach { listener ->
            if (pr.ON) pr.p(TAG, pr.trigger, "listener(${data})")
            listener(data)
        }
    }

    fun trigger(event: String) {
        if (pr.ON) pr.p(TAG, pr.trigger, "trigger(String:$event, data: ${event})")
        if (pr.ON) pr.p(TAG, pr.trigger, "trigger(event:{$event})")
        listeners[event]?.forEach { listener ->
            listener(event)
        }
    }

    fun trigger(event: Event) {
        if (pr.ON) pr.p(TAG, pr.trigger, "trigger(event: ${event})")
        eventFlow.tryEmit(event)
    }

    fun trigger(event: TimeSeriesEvent, dates: Array<Date>) {
        //Todo: adapt to use dates
        if (pr.ON) pr.p(TAG, pr.trigger, "trigger(event: $event Array<Date>:$dates)")
        eventFlow.tryEmit((event))
    }

    fun triggerDates(event: String, dates: Map<String, Date>) {
        //Todo: adapt to use dates
        if (pr.ON) pr.p(TAG, pr.trigger, "trigger(event: $event Array<Date>:$dates)")
        listeners[event]?.forEach { listener ->
            //if(pr.ON) pr.p("EventDispatcher", pr.animationEvent, "listener(${data})")
            listener(event)
        }
    }

    fun triggerDatesArray(event: String, dates: Array<Date>) {
        //Todo: adapt to use dates
        listeners[event]?.forEach { listener ->
            if (pr.ON) pr.p(
                "Animation EventDispatcher",
                pr.trigger,
                "triggerDatesList(event: $event List<Date>: $dates)"
            )
            //if(pr.ON) pr.p("EventDispatcher", pr.animationEvent, "listener(${data})")
            listener(event)
        }
    }

    fun triggerDatesList(event: String, dates: List<Date>) {
        //Todo: adapt to use dates
        if (pr.ON) pr.p("Animation EventDispatcher", pr.trigger, "triggerDatesList(event: $event List<Date>: $dates)")
        listeners[event]?.forEach { listener ->
            //if(pr.ON) pr.p("EventDispatcher", pr.animationEvent, "listener(${data})")
            listener(event)
        }
    }

    /** Renamed from trigger in js since type-erasure caused signature clash **/
    fun trigger(event: Event, intervalArray: MutableList<TimeInterval>, placeHolder: Int) {
        if (pr.ON) pr.p("Animation EventDispatcher", pr.trigger, "trigger(event: $event intervalArray: $intervalArray)")
        //todo: do something with intervalArray
        eventFlow.tryEmit(event)
    }

    fun trigger(event: Event, valueMap: Map<String, Tile<TileData>>) {
        if (pr.ON) pr.p(TAG, pr.trigger, "trigger() event: $event, Map <String, Tile<TileData>>: $valueMap")
        eventFlow.tryEmit(event)
    }

}

/** @suppress **/
class State<T>(initialValue: T) {
    var value: T = initialValue
        private set

    fun setState(newState: T) {
        value = newState
    }

    fun getState(): T {
        return value
    }
}
/*
object Loop {
    private val animations: MutableList<Animation> = mutableListOf()

    fun add(animation: Animation) {
        animations.add(animation)
    }

    fun remove(animation: Animation) {
        animations.remove(animation)
    }
}*/

fun clamp(value: Double, min: Double, max: Double): Double {
    return when {
        value < min -> min
        value > max -> max
        else -> value
    }
}

fun setTimeout(action: () -> Unit, delay: Int) {
    // Implement setTimeout function here
}








