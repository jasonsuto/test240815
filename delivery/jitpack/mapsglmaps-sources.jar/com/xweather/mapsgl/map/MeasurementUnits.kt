package com.xweather.mapsgl.map

import androidx.annotation.Keep
import com.xweather.mapsgl.extensions.Dimension
import com.xweather.mapsgl.extensions.UnitConcentrationMass
import com.xweather.mapsgl.extensions.UnitDuration
import com.xweather.mapsgl.extensions.UnitHeight
import com.xweather.mapsgl.extensions.UnitHeightDifference
import com.xweather.mapsgl.extensions.UnitLength
import com.xweather.mapsgl.extensions.UnitPressure
import com.xweather.mapsgl.extensions.UnitProportion
import com.xweather.mapsgl.extensions.UnitRadarReflectivity
import com.xweather.mapsgl.extensions.UnitSpeed
import com.xweather.mapsgl.extensions.UnitTemperature


/**
 * Describes the unit set used to format map/legend values across various measurement types.
 *
 * This class holds specific unit instances (like UnitTemperature.celsius) for each measurement
 * category. The 'metric' and 'imperial' companion objects provide pre-configured sets.
 */
@Keep
data class MeasurementUnits(
    // Categories of measurements supported by MeasurementUnits.
    val temperature: UnitTemperature,
    val temperatureDelta: UnitTemperature,
    val speed: UnitSpeed,
    val distance: UnitLength,
    //val height: UnitLength,
    //val precipitation: UnitLength,
    val snowfall: UnitLength,
    //val direction: UnitAngle,
    val precipitationRate: UnitLength,
    //val time: UnitDuration,
    val rate: UnitSpeed,
    val intensity: UnitRadarReflectivity,
    val concentration: UnitConcentrationMass,
    val ratio: UnitProportion,
    val duration: UnitDuration,
    val height: UnitHeight,
    val length: UnitLength,
    val none: Dimension,
    val heightDifference: UnitHeightDifference,
    val pressure: UnitPressure
) {
    /**
     * Defines the category of measurement, such as temperature, speed, or distance.
     * This allows the system to know what kind of unit to look up.
     */
    enum class MeasurementType {
        TEMPERATURE,

        //PERCENTAGE,
        TEMPERATURE_DELTA,
        SPEED,
        PRESSURE,
        DISTANCE,
        HEIGHT,
        PRECIPITATION,
        SNOWFALL,
        DIRECTION,
        TIME,
        RATE,
        INTENSITY,
        CONCENTRATION,
        RATIO,
        DURATION,
        NONE,
        HEIGHT_DIFFERENCE,
        LENGTH
    }

    /**
     * Returns the unit-convertable Dimension instance associated with the requested measurement category.
     *
     * @param measurement The measurement category to resolve.
     * @return A Dimension describing the configured measurement category.
     */
    fun dimension(forType: MeasurementType): Dimension {

        val result = when (forType) {
            MeasurementType.TEMPERATURE -> temperature
            MeasurementType.TEMPERATURE_DELTA -> temperatureDelta
            MeasurementType.SPEED -> speed
            MeasurementType.PRESSURE -> temperature//pressure
            MeasurementType.DISTANCE -> distance
            MeasurementType.HEIGHT -> height
            MeasurementType.PRECIPITATION -> precipitationRate//precipitation
            MeasurementType.SNOWFALL -> snowfall
            MeasurementType.DIRECTION -> temperature//direction
            MeasurementType.TIME -> temperature//time
            MeasurementType.RATE -> rate
            MeasurementType.INTENSITY -> intensity
            MeasurementType.CONCENTRATION -> concentration
            MeasurementType.RATIO -> ratio
            MeasurementType.DURATION -> duration
            MeasurementType.NONE -> none
            MeasurementType.HEIGHT_DIFFERENCE -> heightDifference
            MeasurementType.LENGTH -> length
        }
        ///println(">>> Legend requesting dimension for $forType. Returning ${result.symbol}")
        return result
    }

    /**
     * Returns the unit-convertable Dimension configured for the requested measurement, cast to the desired type.
     *
     * @param T The expected Dimension subclass (e.g., UnitTemperature).
     * @param forType The measurement category to resolve.
     * @return The associated dimension if it can be cast to `T`; otherwise `null`.
     */
    inline fun <reified T : Dimension> dimensionAs(forType: MeasurementType): T? {
        return dimension(forType) as? T
    }

    @Keep
    companion object {


        fun isMetric(unit: Dimension): Boolean {
            return when (unit) {
                is UnitTemperature.Celsius -> true
                is UnitLength.Centimeters -> true
                is UnitLength.Millimeters -> true
                is UnitLength.Kilometers -> true
                is UnitLength.Meters -> true
                is UnitSpeed.KilometersPerHour -> true
                is UnitHeight.Meters -> true
                is UnitPressure.Millibars -> true
                // Add other metric types here...
                else -> false
            }
        }


        /** Preconfigured unit mappings using the metric system. */
        val METRIC = MeasurementUnits(
            temperature = UnitTemperature.celsius,
            temperatureDelta = UnitTemperature.celsius,
            speed = UnitSpeed.kilometersPerHour,
            distance = UnitLength.kilometers,
            snowfall = UnitLength.centimeters,        // Moved up to match constructor
            precipitationRate = UnitLength.millimeters, // Moved down to match constructor
            rate = UnitSpeed.kilometersPerHour,
            intensity = UnitRadarReflectivity.dbz,
            concentration = UnitConcentrationMass.microgramsPerCubicMeter,
            ratio = UnitProportion.percent,
            duration = UnitDuration.minute,
            height = UnitHeight.meters,
            length = UnitLength.meters,
            none = UnitLength.none,
            heightDifference = UnitHeightDifference.meters,
            pressure = UnitPressure.millibars
        )

        /** Preconfigured unit mappings using the imperial system. */
        val IMPERIAL = MeasurementUnits(
            temperature = UnitTemperature.fahrenheit,
            temperatureDelta = UnitTemperature.fahrenheit,
            speed = UnitSpeed.milesPerHour,
            distance = UnitLength.miles,
            snowfall = UnitLength.inches,           // Moved up to match constructor
            precipitationRate = UnitLength.inches,    // Moved down to match constructor
            rate = UnitSpeed.milesPerHour,
            intensity = UnitRadarReflectivity.dbz,
            ratio = UnitProportion.percent,
            concentration = UnitConcentrationMass.microgramsPerCubicMeter,
            duration = UnitDuration.minute,
            height = UnitHeight.feet,
            length = UnitLength.feet,
            none = UnitLength.none,
            heightDifference = UnitHeightDifference.feet,
            pressure = UnitPressure.inchesOfMercury
        )
    }
}


/*
package com.xweather.mapsgl.map


enum class MeasurementUnits {
    METRIC,
    IMPERIAL;

    /**
     * Defines the category of measurement, such as temperature, speed, or distance.
     * This allows the system to know what kind of unit to look up.
     */
    enum class MeasurementType {
        TEMPERATURE,
        WIND_SPEED,
        PRECIPITATION,
        DISTANCE,
        PRESSURE,
        PERCENTAGE,
        SNOWFALL,
    }
} */