package com.xweather.mapsgl.map.mapbox

import com.mapbox.maps.CanonicalTileID
import com.mapbox.maps.CustomGeometrySourceOptions
import com.mapbox.maps.MapboxMap
import com.mapbox.maps.TileOptions
import com.mapbox.maps.extension.style.sources.CustomGeometrySource
import com.mapbox.maps.toCameraOptions
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.sources.DataType
import com.xweather.mapsgl.sources.VectorTileSource
import com.xweather.mapsgl.sources.VisibleGeoBounds
import com.xweather.mapsgl.tiles.Tile
import com.xweather.mapsgl.tiles.TileCoord
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.ConcurrentHashMap
import java.util.logging.Logger
import kotlin.math.roundToInt

class MapboxVectorSourceAdapter(
    private val source: VectorTileSource,
    private val map: MapboxMap
) {
    private val batchInvalidateMutex = Mutex()
    private val lastTileFeatureSignatures = ConcurrentHashMap<String, Int>()
    @Volatile
    private var lastCameraSnapshotMs: Long = 0L
    @Volatile
    private var lastCameraSnapshotZoom: Double? = null
    @Volatile
    private var lastCameraSnapshotBounds: VisibleGeoBounds? = null

    private fun q(v: Double, scale: Double): Int = (v * scale).roundToInt()

    /**
     * Lightweight fingerprint for tile payload change detection.
     * Samples a subset of features to reduce CPU while still detecting timeline-driven value changes.
     */
    private fun featureSignature(features: List<com.mapbox.geojson.Feature>): Int {
        var h = 17
        h = 31 * h + features.size
        if (features.isEmpty()) return h
        val sampleCount = 256
        val stride = (features.size / sampleCount).coerceAtLeast(1)
        var i = 0
        while (i < features.size) {
            val f = features[i]
            val p = f.geometry() as? com.mapbox.geojson.Point
            if (p != null) {
                h = 31 * h + q(p.longitude(), 1000.0)
                h = 31 * h + q(p.latitude(), 1000.0)
            }
            h = 31 * h + q(f.getNumberProperty("speed")?.toDouble() ?: 0.0, 10.0)
            h = 31 * h + q(f.getNumberProperty("dir")?.toDouble() ?: 0.0, 2.0)
            h = 31 * h + q(f.getNumberProperty("shaderR")?.toDouble() ?: 0.0, 1.0)
            h = 31 * h + q(f.getNumberProperty("shaderG")?.toDouble() ?: 0.0, 1.0)
            h = 31 * h + q(f.getNumberProperty("shaderB")?.toDouble() ?: 0.0, 1.0)
            h = 31 * h + q(f.getNumberProperty("hasSample")?.toDouble() ?: 0.0, 10.0)
            i += stride
        }
        return h
    }
    suspend fun makeSource(): CustomGeometrySource {
        if (pr.ON) pr.p("MapboxVectorSourceAdapter", pr.adminLayers, "makeSource entered() ")
        withContext(Dispatchers.IO) {
            try {
                source.fetchMetadata(null, null)
                if (pr.ON) pr.p("MapboxVectorSourceAdapter", pr.adminLayers, "fetchTileFunction()called fetchMetaData")
            } catch (e: Exception) {
                if (pr.ON) pr.p(
                    "MapboxVectorSourceAdapter",
                    pr.adminLayers,
                    "fetchTileFunction() tileID: ${e.localizedMessage}"
                )
                println("Failed to fetch metadata for vector tile source: ${e.localizedMessage}")
            }
        }

        return CustomGeometrySource(
            source.id,
            CustomGeometrySourceOptions.Builder()
                .fetchTileFunction { tileID ->

                    if (pr.ON) pr.p("MapboxVectorSourceAdapter", pr.adminLayers, "fetchTileFunction() tileID: $tileID")
                    CoroutineScope(Dispatchers.Default).launch {
                        try {
                            Timeline.incrementPendingVectorDownloads()
                            val now = System.currentTimeMillis()
                            val snapshotAgeMs = now - lastCameraSnapshotMs
                            val (mapZoomForDensity, visibleBounds) =
                                if (snapshotAgeMs in 0..100 && lastCameraSnapshotZoom != null && lastCameraSnapshotBounds != null) {
                                    lastCameraSnapshotZoom to lastCameraSnapshotBounds
                                } else {
                                    val snap = withContext(Dispatchers.Main) {
                                        runCatching {
                                            val zoom = map.cameraState.zoom
                                            val b =
                                                map.coordinateBoundsForCameraUnwrapped(map.cameraState.toCameraOptions())
                                            val vb =
                                                VisibleGeoBounds.fromMapboxUnwrappedCamera(
                                                    b,
                                                    map.cameraState.center.longitude(),
                                                    zoom,
                                                )
                                            zoom to vb
                                        }.getOrNull() ?: (null to null)
                                    }
                                    if (snap.first != null && snap.second != null) {
                                        lastCameraSnapshotMs = now
                                        lastCameraSnapshotZoom = snap.first
                                        lastCameraSnapshotBounds = snap.second
                                    }
                                    snap
                                }
                            val data = source.requestTile(
                                tileID.x,
                                tileID.y,
                                tileID.z.toInt(),
                                mapZoomForDensity,
                                visibleBounds,
                            )
                            val tile = Tile<DataType>(coord = TileCoord(tileID.x, tileID.y, tileID.z.toInt(), 0, ""))
                            tile.data = data

                            data?.let {
                                val tileKey = "${tileID.z}/${tileID.x}/${tileID.y}"
                                val sig = featureSignature(it.features)
                                lastTileFeatureSignatures[tileKey] = sig
                                // Always push: after remove/re-add the style layer may drop CustomGeometrySource
                                // payloads even when features are unchanged (see alerts blank until pan/zoom).
                                withContext(Dispatchers.Main) {
                                    map.setStyleCustomGeometrySourceTileData(
                                        source.id,
                                        tileID,
                                        it.features
                                    )
                                }
                            }
                            source.dlCount++
                            Timeline.decrementPendingVectorDownloads()
                        } catch (e: Exception) {
                            Logger.getLogger("MapboxVectorSourceAdapter").severe(e.localizedMessage)
                        }
                    }
                }
                .cancelTileFunction { tileID ->
                    source.abortTile(tileID.x, tileID.y, tileID.z.toInt())
                }
//                .minZoom(source.minZoom.toInt().toByte())
                .minZoom(0)
                .maxZoom(source.maxZoom.toInt().toByte())
                .tileOptions(TileOptions.Builder().build())
                .build()
        )
    }

    fun invalidate(x: Int, y: Int, z: Int) {
        CoroutineScope(Dispatchers.Default).launch(Dispatchers.Main) {
            try {
                val tileID = CanonicalTileID(z.toByte(), x, y)
                lastTileFeatureSignatures.remove("${tileID.z}/${tileID.x}/${tileID.y}")
                map.invalidateStyleCustomGeometrySourceTile(source.id, tileID)
            } catch (e: Exception) {
                Logger.getLogger("MapboxVectorSourceAdapter").severe(e.localizedMessage)
            }
        }
    }

    /**
     * Single Main dispatcher coroutine, sequential native calls — avoids hundreds of parallel launches from
     * [EncodedGridVectorTileSource.invalidate].
     */
    fun invalidateTilesBatch(coords: List<Triple<Int, Int, Int>>) {
        if (coords.isEmpty()) return
        CoroutineScope(Dispatchers.Default).launch(Dispatchers.Main) {
            batchInvalidateMutex.withLock {
                try {
                    for ((x, y, z) in coords) {
                        val tileID = CanonicalTileID(z.toByte(), x, y)
                        lastTileFeatureSignatures.remove("${tileID.z}/${tileID.x}/${tileID.y}")
                        map.invalidateStyleCustomGeometrySourceTile(source.id, tileID)
                    }
                } catch (e: Exception) {
                    Logger.getLogger("MapboxVectorSourceAdapter").severe(e.localizedMessage)
                }
            }
        }
    }
}