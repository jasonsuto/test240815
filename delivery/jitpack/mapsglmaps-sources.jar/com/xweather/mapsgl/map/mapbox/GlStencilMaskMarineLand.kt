package com.xweather.mapsgl.map.mapbox

import kotlin.math.abs

/**
 * Shared thresholds and UV area math for marine [com.xweather.mapsgl.layers.spec.MaskLayerKind.LAND] GLES
 * stencil (water mesh path). Kept in one place so [GlStencilMaskRenderer] and
 * [GlStencilMaskTileCache.predictMarineLandStencilOutcome] stay aligned.
 */
internal object GlStencilMaskMarineLand {
    const val MIN_ZOOM_FOR_LAND_STENCIL = 1
    const val MIN_WATER_UV_AREA_FOR_LAND_MASK = 7.5e-5f
    const val MAX_WATER_UV_AREA_FOR_LAND_MASK = 0.995f

    /**
     * Below this summed absolute triangle area in tile UV [0,1]², explicit `water` polygons cover a small
     * fraction of the tile. Used only for diagnostics ([predictMarineLandStencilOutcome]).
     */
    const val SPARSE_WATER_COVERAGE_HEURISTIC_UV_AREA = 0.12f

    /** Water mesh below this UV area has no reliable mask — tile is hidden (fail closed). */
    fun isEffectivelyEmptyWaterMask(waterUvArea: Float): Boolean =
        waterUvArea < MIN_WATER_UV_AREA_FOR_LAND_MASK

    fun waterMeshUvArea(mesh: GlStencilMaskTileCache.CpuMesh): Float {
        val v = mesh.vertices
        // `limit()` is the count of valid floats; the pooled buffer's `capacity()` may be
        // larger because [DirectFloatBufferPool] hands out bucketed allocations. Iterating to
        // capacity would read uninitialised tail bytes from the previous owner.
        val len = v.limit()
        var i = 0
        var area = 0.0
        while (i + 5 < len) {
            // Absolute `get(int)` reads don't move the buffer's position, so this is safe even
            // if another thread is uploading the same buffer via `glBufferData` (which reads
            // from position 0 too).
            val x0 = v.get(i).toDouble()
            val y0 = v.get(i + 1).toDouble()
            val x1 = v.get(i + 2).toDouble()
            val y1 = v.get(i + 3).toDouble()
            val x2 = v.get(i + 4).toDouble()
            val y2 = v.get(i + 5).toDouble()
            val twice = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0)
            area += abs(twice) * 0.5
            i += 6
        }
        return area.toFloat()
    }
}

/**
 * Predicted outcome for marine land masking (water mesh → stencil) on a weather tile.
 */
internal sealed class MarineLandStencilPrediction {

    /**
     * Stencil mask geometry will be drawn; weather is clipped to land (stencil 0 after water write).
     * @param likelyIncompleteOceanStencil `true` when water UV coverage is sparse or mesh comes from an
     * ancestor remap — common cases for missing marine over open ocean at some zooms.
     */
    data class WillStencil(
        val normalizedKey: String,
        val storageKey: String,
        val waterUvArea: Float,
        val usesAncestorRemap: Boolean,
        val likelyIncompleteOceanStencil: Boolean,
    ) : MarineLandStencilPrediction()

    /**
     * No explicit `water` polygons in the MVT for this tile. [MaskLayerKind.LAND] treats the tile as
     * all land (fail open); [MaskLayerKind.WATER] treats it as all water (fail open) so open-ocean
     * MAPSGL tiles without a `water` layer are not hidden.
     */
    data object AllLandNoWaterGeometry : MarineLandStencilPrediction()

    /** Land mask only: `water` covers nearly the entire tile — hide weather (ocean tile). */
    sealed class FailClosed : MarineLandStencilPrediction() {
        data object ZoomBelowMinimum : FailClosed()
    }
}
