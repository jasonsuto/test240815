package com.xweather.mapsgl.map.mapbox

import android.util.Log
import com.mapbox.geojson.Feature
import com.xweather.mapsgl.layers.spec.StencilLayerMaskSpec
import com.xweather.mapsgl.layers.spec.StencilMaskCombineMode
import com.xweather.mapsgl.tiles.LatLonBounds
import com.xweather.mapsgl.layers.tile.VectorTileLayer
import com.xweather.mapsgl.map.MapController
import com.xweather.mapsgl.sources.GeoJSONSource
import com.xweather.mapsgl.sources.VectorTileSource
import com.xweather.mapsgl.style.FillLayerPaint
import com.xweather.mapsgl.style.LineLayerPaint
import com.xweather.mapsgl.style.StyleValue
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.weather.WeatherSource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

/**
 * Registers MVT parse dependencies and tile listeners so [StencilLayerMaskSpec] layers fill
 * [MapController.glStencilMaskTileCache] with per–style-layer stencil geometry.
 */
internal object GlStencilCustomMaskCoordinator {

    private const val TAG = "GlStencilCustomMask"
    /**
     * Parallelism cap for **vector** stencil mesh builds (motorway ribbons, etc.). Panning pulls
     * many new tiles at once; keeping this too low queues work faster than workers can drain and
     * the mask lags the camera. Four workers stay below typical `Dispatchers.Default` pool depth
     * while cutting backlog on multi-core devices; each job still holds at most one in-flight
     * mesh buffer at a time.
     */
    private val stencilMeshBuildDispatcher = Dispatchers.Default.limitedParallelism(4)
    private val stencilMeshBuildScope = CoroutineScope(SupervisorJob() + stencilMeshBuildDispatcher)

    private data class Registration(
        val undo: List<() -> Unit>,
        val maskVectorLayerIds: Set<String>,
        var clipFillLayerIds: List<String>,
        var clipBounds: LatLonBounds?,
        var combineMode: StencilMaskCombineMode,
    )

    private val registrations = ConcurrentHashMap<String, Registration>()

    /**
     * Bumped every time [refreshPaint] re-snapshots the paint for a mask vector layer. Each
     * [buildStencilTileListener] closure captures the generation in effect when it was built; a
     * queued build that finishes with a stale generation aborts before writing to the mesh
     * cache. That lets us cheaply invalidate "old paint" builds that were in flight when the user
     * changed e.g. line thickness, instead of letting them race the new builds and clobber the
     * cache with the previous geometry.
     *
     * The same generation feeds the per-tile dedup key so a stale build doesn't block a fresh
     * build for the same `(maskLayerId, coordHash)` — see [pendingBuildKeys].
     */
    private val maskLayerGeneration = ConcurrentHashMap<String, Int>()

    /**
     * Tracks `(generation, maskLayerId, coordHash)` for **builds that have already been queued
     * or built**. Entries are added when a listener fire is admitted and **never removed on
     * completion** — once we've produced a stencil mesh for a given paint generation we don't
     * want to produce it again, ever.
     *
     * This is critical: Mapbox calls our `fetchTileFunction` (the cached-tile early-return path
     * in [VectorTileSource.requestTile]) on every render frame for every visible tile, the VBO
     * upload throttle requests another repaint after every batch, and the prefetcher runs for
     * the same tiles the replay just hit. The original "remove on `finally`" form let every
     * completed build re-open its slot, the next render frame slipped through dedup, and the
     * loop sustained itself indefinitely — that's what produced the 10-minute freeze + OOM on
     * Demo 3 slider commits (every cycle through the loop allocated a ~1 MB `FloatArray` mesh).
     *
     * Including the generation in the key means a paint change always gets through cleanly: the
     * new generation produces a distinct key set, so the new-paint builds queue while old-paint
     * keys sit harmlessly in the set. Old-gen entries are pruned on the next [refreshPaint] for
     * the affected mask layer (see below) so the set can't grow without bound.
     */
    private val pendingBuildKeys = ConcurrentHashMap.newKeySet<String>()

    private fun pendingBuildKey(generation: Int, maskLayerId: String, coordHash: String): String =
        "$generation\u0000$maskLayerId\u0000$coordHash"

    /**
     * `(maskLayerId, coordHash) → List<LinePath>` cache for line-style masks. `extractLinePathsTileUv`
     * walks every MVT line geometry, projects each vertex to tile-UV, and chunks pieces — none of
     * which depends on the line paint (thickness / cap / join). Caching here means a slider
     * commit only redoes the cheap `emitLineRibbonFromPath` step instead of the full
     * MVT-geometry → tile-UV path-extraction pass for every cached tile.
     *
     * Cache keys use the `(layerId, coordHash)` from the mask side so two weather layers that
     * share the same vector layer + tile still share one extraction.
     *
     * Invalidated by [unregister] (forgets every entry for the mask) and bounded by the cached
     * MVT tile count — i.e. the same set of tiles that already populates [VectorTileSource]'s
     * `vectorTileCache`, so we never grow unbounded vs. that source.
     */
    private val cachedLinePaths = ConcurrentHashMap<String, List<GlStencilMaskMeshBuilder.LinePath>>()

    private fun linePathCacheKey(maskLayerId: String, coordHash: String): String =
        "$maskLayerId\u0000$coordHash"

    /**
     * Style-native `base.osm` is never wired to [VectorTileSource.requestTile] (see [MapboxMapController.addToMap]);
     * GLES stencil MVT bytes load only on [GlStencilOsm.SOURCE_ID]. Custom mask listeners must attach there when
     * the mask layer nominally references `base.osm`.
     */
    private fun vectorTileSourceForCustomStencil(
        controller: MapController,
        nominal: VectorTileSource,
    ): VectorTileSource? {
        val isBaseOsmNominal =
            nominal.id == WeatherSource.SourceCode.base_osm.value ||
                nominal.id == WeatherSource.SourceCode.base_osm.toString()
        if (!isBaseOsmNominal) {
            return nominal
        }
        val desc = GlStencilOsm.sourceDescriptor(controller.service)
        if (!controller.hasSource(desc.id)) {
            controller.addSource(desc)
        }
        (controller as? MapboxMapController)?.ensureGlStencilBaseOsmFetchLayer()
        return controller.getSource(desc.id) as? VectorTileSource
    }

    private fun clipContextFromSpec(
        controller: MapController,
        spec: StencilLayerMaskSpec,
    ): Pair<List<String>, LatLonBounds?> {
        val fillIds = spec.layers.mapNotNull { ref ->
            val vl = controller.layers[ref.layerId] as? VectorTileLayer ?: return@mapNotNull null
            if (vl.paint is FillLayerPaint && vl.source is GeoJSONSource) ref.layerId else null
        }
        return fillIds to spec.clipBounds
    }

    private fun collectClipPolygonRings(
        controller: MapController,
        cache: GlStencilMaskTileCache,
        coord: TileCoord,
        fillLayerIds: List<String>,
    ): List<FloatArray> {
        if (fillLayerIds.isEmpty()) return emptyList()
        val rings = ArrayList<FloatArray>()
        for (layerId in fillLayerIds) {
            val vl = controller.layers[layerId] as? VectorTileLayer ?: continue
            val geo = vl.source as? GeoJSONSource ?: continue
            val seq = geo.geoJsonStencilSequence
            val feats = cache.getOrComputeGeoJsonStencilFilteredFeatures(
                layerId,
                seq,
                vl.filter,
            ) { geo.data?.features().orEmpty() }
            rings.addAll(GlStencilMaskMeshBuilder.extractPolygonExteriorRingsTileUv(coord, feats))
        }
        return rings
    }

    private fun lineHalfWidthUv(vl: VectorTileLayer): Float {
        val paint = vl.paint
        if (paint is LineLayerPaint) {
            val t = when (val th = paint.stroke.thickness) {
                is StyleValue.Constant -> th.value
                else -> 2.0
            }
            return (t / 400.0).toFloat().coerceIn(0.001f, 0.05f)
        }
        return 0.003f
    }

    fun register(
        controller: MapController,
        weatherLayerId: String,
        spec: StencilLayerMaskSpec,
        replayOnly: Boolean = false,
    ) {
        unregister(controller, weatherLayerId, clearMeshCache = !replayOnly)
        val undo = mutableListOf<() -> Unit>()
        val maskIds = mutableSetOf<String>()
        val sourcesToTouch = mutableSetOf<VectorTileSource>()
        val (clipFillIds, clipBounds) = clipContextFromSpec(controller, spec)
        val combineMode = spec.mode

        for (ref in spec.layers) {
            val vl = controller.layers[ref.layerId] as? VectorTileLayer
            if (vl == null) {
                Log.w(TAG, "stencilLayerMask: no vector layer with id \"${ref.layerId}\"")
                continue
            }
            val sl = vl.sourceLayer
            if (sl.isNullOrEmpty()) {
                Log.w(TAG, "stencilLayerMask: layer \"${vl.id}\" needs a non-null sourceLayer for MVT stencil")
                continue
            }
            val nominal = vl.source as? VectorTileSource
            if (nominal == null) {
                Log.w(TAG, "stencilLayerMask: layer \"${vl.id}\" must use a VectorTileSource")
                continue
            }
            val vts = vectorTileSourceForCustomStencil(controller, nominal)
            if (vts == null) {
                Log.w(
                    TAG,
                    "stencilLayerMask: no MVT source for layer \"${vl.id}\" (nominal=${nominal.id})",
                )
                continue
            }
            maskIds.add(vl.id)
            sourcesToTouch.add(vts)
            undo.add(vts.addStencilParseLayerDependency(sl))
            val listenerId = "stencil_${weatherLayerId}_${vl.id}"
            undo.add(
                vts.addCustomStencilTileListener(
                    listenerId,
                    buildStencilTileListener(
                        controller,
                        weatherLayerId,
                        vl,
                        sl,
                        clipFillIds,
                        clipBounds,
                        combineMode,
                    ),
                ),
            )
        }

        if (undo.isEmpty()) return

        registrations[weatherLayerId] =
            Registration(undo, maskIds, clipFillIds, clipBounds, combineMode)
        for (src in sourcesToTouch) {
            src.replayCustomStencilFeedsFromCachedVectorTiles()
            if (!replayOnly) {
                src.invalidate()
            }
        }
    }

    /**
     * Update the existing registration for [weatherLayerId] so its tile listeners pick up the
     * *current* paint of each mask vector layer (e.g. a new line thickness / cap / join), then
     * replay cached MVT features through the new closures so already-loaded tiles rebuild their
     * stencil meshes with the new paint.
     *
     * Unlike [register] this path performs **zero** [VectorTileSource.invalidate] calls. The
     * normal register flow ends up firing `invalidate()` ~6 times per refresh (parse-dependency
     * add/remove, listener add/remove, plus an explicit invalidate per source); each invalidate
     * expires every cached tile in the source and forces Mapbox to call back into
     * `parseVectorTile`, which re-decodes the MVT bytes from scratch and refires the listeners.
     * For a stencil-mask demo with ~50–200 cached tiles that turned a width-slider change into a
     * minute-long freeze followed by OOM.
     *
     * No-ops if [weatherLayerId] wasn't registered. Callers should fall back to [register] in
     * that case (or for spec changes that alter the set of mask layers).
     */
    fun refreshPaint(controller: MapController, weatherLayerId: String, spec: StencilLayerMaskSpec) {
        val t0 = System.nanoTime()
        Log.d(TAG, "refreshPaint: ENTER weatherLayerId=$weatherLayerId specLayers=${spec.layers.size}")
        val reg = registrations[weatherLayerId]
        if (reg == null) {
            Log.d(TAG, "refreshPaint: EXIT (no registration) weatherLayerId=$weatherLayerId")
            return
        }
        val (clipFillIds, clipBounds) = clipContextFromSpec(controller, spec)
        reg.clipFillLayerIds = clipFillIds
        reg.clipBounds = clipBounds
        reg.combineMode = spec.mode
        // Bump the generation BEFORE installing the new listener: any in-flight build queued by
        // the previous listener will see the new value and abort instead of writing its now-stale
        // mesh into the cache.
        reg.maskVectorLayerIds.forEach { maskId ->
            maskLayerGeneration.merge(maskId, 1) { old, _ -> old + 1 }
            // Prune dedup entries for previous generations of this mask so the set stays bounded
            // by `(cachedTiles × activeMasks)` rather than growing by ~19 entries per slider
            // commit. We can't accidentally drop a still-valid build: the new-gen builds use a
            // distinct key, and any old-gen build still running will harmlessly find its key
            // missing (it's a finally-less coroutine, so re-adding the key on a future fire is
            // already blocked by the generation check inside the build).
            val maskInfix = "\u0000$maskId\u0000"
            pendingBuildKeys.removeIf { it.contains(maskInfix) }
        }
        val sourcesToReplay = mutableSetOf<VectorTileSource>()
        for (ref in spec.layers) {
            val vl = controller.layers[ref.layerId] as? VectorTileLayer ?: continue
            if (!reg.maskVectorLayerIds.contains(vl.id)) continue
            val sl = vl.sourceLayer
            if (sl.isNullOrEmpty()) continue
            val nominal = vl.source as? VectorTileSource ?: continue
            val vts = vectorTileSourceForCustomStencil(controller, nominal) ?: continue
            sourcesToReplay.add(vts)
            val listenerId = "stencil_${weatherLayerId}_${vl.id}"
            vts.replaceCustomStencilTileListenerWithoutInvalidate(
                listenerId,
                buildStencilTileListener(
                    controller,
                    weatherLayerId,
                    vl,
                    sl,
                    reg.clipFillLayerIds,
                    reg.clipBounds,
                    reg.combineMode,
                ),
            )
        }
        Log.d(TAG, "refreshPaint: listeners swapped, sourcesToReplay=${sourcesToReplay.size}")
        // Drop GPU buffers for these mask layers so the next draw rebuilds VBOs from the new CPU
        // meshes (without this, [GlStencilMaskRenderer.ensureVbo] keeps the prior VBO content
        // even though the [GlStencilMaskTileCache.CpuMesh] entry was replaced). We also have to
        // evict the ancestor-remap cache: when the camera is at a finer zoom than the cached MVT
        // tiles (very common — e.g. Demo 3's MVT cache at z=3 viewed at z=4), the renderer goes
        // through [GlStencilMaskTileCache.getCpuMeshForCustomMask]'s ancestor walk and stores the
        // child's remapped triangles in `customRemappedFromAncestor` keyed by `mask|childKey_aDZ`.
        // Those entries don't reference the parent `CpuMesh` so a put on the parent doesn't
        // invalidate them; without this explicit eviction the renderer keeps returning the OLD
        // remapped vertices and the new line width never reaches the screen.
        reg.maskVectorLayerIds.forEach { maskId ->
            GlStencilMaskRendererHolder.renderer.releaseGpuForMaskLayerId(maskId)
            controller.glStencilMaskTileCache.invalidateCustomRemappedFor(maskId)
        }
        for (src in sourcesToReplay) {
            val tileCount = src.cachedVectorTileCount()
            Log.d(
                TAG,
                "refreshPaint: replay source=${src.id} cachedTiles=$tileCount weatherLayerId=$weatherLayerId " +
                    "pendingBuilds=${pendingBuildKeys.size}",
            )
            val tr0 = System.nanoTime()
            src.replayCustomStencilFeedsFromCachedVectorTiles()
            Log.d(TAG, "refreshPaint: replay done source=${src.id} ms=${(System.nanoTime() - tr0) / 1_000_000}")
        }
        Log.d(TAG, "refreshPaint: EXIT weatherLayerId=$weatherLayerId totalMs=${(System.nanoTime() - t0) / 1_000_000}")
    }

    /**
     * Build the per-tile listener that consumes parsed MVT features for [vl] (a mask vector
     * layer) and queues a stencil-mesh build keyed by the mask layer id. Extracted so both
     * [register] and [refreshPaint] use identical mesh-build semantics.
     *
     * The captured `lineHalfWidth` / `lineStyle` / `isLineMask` are snapshotted at call-time, so
     * a paint change requires producing a new listener (which [refreshPaint] does); the listener
     * itself does no paint reads to keep the per-tile hot path allocation-free.
     */
    private fun buildStencilTileListener(
        controller: MapController,
        weatherLayerId: String,
        vl: VectorTileLayer,
        sl: String,
        clipFillLayerIds: List<String>,
        clipBounds: LatLonBounds?,
        combineMode: StencilMaskCombineMode,
    ): (TileCoord, String, List<Feature>) -> Unit {
        val maskLayerId = vl.id
        val isLineMask = vl.paint is LineLayerPaint
        val lineStyle = if (isLineMask) {
            GlStencilMaskMeshBuilder.lineRibbonStyleFromLineLayerPaint(vl.paint as LineLayerPaint)
        } else {
            null
        }
        val lineHalfWidth = if (isLineMask) lineHalfWidthUv(vl) else 0.003f
        // Snapshot the generation at listener-build time so every build queued through *this*
        // closure carries the same tag; a later [refreshPaint] increments the live counter,
        // which lets in-flight builds detect that they're stale before writing to the cache.
        val builtForGeneration = maskLayerGeneration.computeIfAbsent(maskLayerId) { 0 }
        return listener@{ coord, coordHash, feats ->
            val key = pendingBuildKey(builtForGeneration, maskLayerId, coordHash)
            // Same `(generation, mask, tile)` already queued → skip the redundant build. Mapbox
            // re-fires the listener on every cached-tile early-return; without this guard a
            // sustained burst of fires (timeline, repaints, viewport churn) piles up identical
            // builds that all produce the same mesh.
            if (!pendingBuildKeys.add(key)) {
                return@listener
            }
            stencilMeshBuildScope.launch {
                // MVT listeners can run on Mapbox threads during pan; keep tagging + line-path
                // extraction + ribbon emission off that path so dense road tiles (Demo 3) don't
                // hitch the map before the coroutine even starts.
                try {
                    val reg = registrations[weatherLayerId]
                    if (reg == null || !reg.maskVectorLayerIds.contains(maskLayerId)) {
                        return@launch
                    }
                    if (maskLayerGeneration[maskLayerId] != builtForGeneration) {
                        return@launch
                    }
                    val tagged = feats.asSequence()
                        .filter {
                            val tag = featureLayerTag(it)
                            tag == sl || tag == "${sl}::inverted"
                        }
                        .filter { StencilMaskFilter.matches(it, vl.filter) }
                        .toList()
                    // No `finally { pendingBuildKeys.remove(key) }` here — see [pendingBuildKeys] kdoc.
                    val tb0 = System.nanoTime()
                    val tri = if (isLineMask && lineStyle != null) {
                        val cacheKey = linePathCacheKey(maskLayerId, coordHash)
                        // Pull paths from cache if we've already extracted them for this
                        // (mask, tile) — paint changes don't affect the path topology, so the
                        // expensive `extractLinePathsTileUv` walk only needs to happen once.
                        val paths = cachedLinePaths[cacheKey] ?: run {
                            val freshly = GlStencilMaskMeshBuilder.extractLinePathsTileUv(coord, tagged)
                            cachedLinePaths[cacheKey] = freshly
                            freshly
                        }
                        // Clip line geometry to fill polygons only for ALL (intersection). ANY
                        // (union) must keep roads outside the area mask (e.g. motorways in Mexico
                        // when CONUS is the fill layer).
                        val clipRings = if (
                            clipBounds == null &&
                            combineMode == StencilMaskCombineMode.ALL &&
                            clipFillLayerIds.isNotEmpty()
                        ) {
                            collectClipPolygonRings(
                                controller,
                                controller.glStencilMaskTileCache,
                                coord,
                                clipFillLayerIds,
                            )
                        } else {
                            emptyList()
                        }
                        GlStencilMaskMeshBuilder.buildLineRibbonTileUvTrianglesFromPaths(
                            paths,
                            lineHalfWidth,
                            lineStyle,
                            coord,
                            clipBounds,
                            clipRings,
                        )
                    } else {
                        GlStencilMaskMeshBuilder.buildTileUvTriangles(coord, tagged)
                    }
                    val buildMs = (System.nanoTime() - tb0) / 1_000_000
                    val triVertexFloats = tri?.limit() ?: 0
                    if (buildMs > 50) {
                        Log.d(
                            TAG,
                            "buildTile slow: layer=$maskLayerId coord=${coord.hash()} feats=${tagged.size} " +
                                "verts=${triVertexFloats / 2} buildMs=$buildMs",
                        )
                    }
                    // Re-check after the build (which may have run for tens of ms): the user can
                    // change the paint mid-build, and we don't want to overwrite the new mesh.
                    if (maskLayerGeneration[maskLayerId] != builtForGeneration) {
                        // The build's `FloatBuffer` is pool-backed — if we throw it away now
                        // without recycling, the pool never reclaims it and the next mesh has
                        // to grow a fresh direct buffer.
                        tri?.let { DirectFloatBufferPool.releaseDeferred(it) }
                        return@launch
                    }
                    val normHash = normalizeStencilTileKey(coordHash)
                    // Remaps keyed under this parent cannot exist until an exact mesh for this tile
                    // was already in the cache (the ancestor walk needs `t[parent]`). Evicting
                    // descendants on *every* first `put` therefore only tore down unrelated remaps
                    // built from coarser ancestors in rare orderings, and — worse — on the common
                    // first zoom into a parent/child pair it briefly left finer tiles with neither a
                    // fresh remap nor their own MVT yet (~one tile of stencil flicker).
                    val hadExistingParentMesh =
                        controller.glStencilMaskTileCache.getExactCustomMaskMesh(maskLayerId, normHash) != null
                    if (tri != null) {
                        controller.glStencilMaskTileCache.putCustomMaskMesh(
                            maskLayerId,
                            coordHash,
                            GlStencilMaskTileCache.CpuMesh(tri, triVertexFloats / 2),
                        )
                    } else {
                        controller.glStencilMaskTileCache.removeCustomMaskTile(maskLayerId, coordHash)
                    }
                    // Remapped stencil geometry is keyed per *child* tile (`mask|0:z/x/y_a{dz}_v4`).
                    // Only evict entries derived from this parent when we **replace** an existing
                    // parent mesh so child remaps recompute from the new geometry. First-time puts
                    // skip eviction — see [hadExistingParentMesh]. [removeCustomMaskTile] already
                    // invalidates descendants when geometry is removed.
                    if (tri != null && hadExistingParentMesh) {
                        controller.glStencilMaskTileCache.invalidateCustomRemappedDescendantsOfParentTile(
                            maskLayerId,
                            normHash,
                        )
                    }
                    // Nudge Mapbox to render again so the renderer notices the new
                    // [GlStencilMaskTileCache.CpuMesh] identity and re-uploads the VBO. The single
                    // [com.mapbox.maps.MapboxMap.triggerRepaint] that [MapboxMapController.refreshCustomStencilMask]
                    // fires happens *before* any of these N builds complete — without this nudge
                    // the new mesh just sits in the cache until the user pans. The
                    // [MapboxMapController.requestRepaintCoalesced] helper folds 19 concurrent
                    // build completions into at most one queued repaint, so the cascade that
                    // produced the old rebuild loop (one trigger per build × dedup-less listener)
                    // can't recur.
                    if (controller.useGlTextureMaskFbo) {
                        controller.glTextureMaskBuilder.markDirty()
                    }
                    (controller as? MapboxMapController)?.requestRepaintCoalesced()
                } catch (t: Throwable) {
                    // The build threw — pull the key so a future fire can retry. We don't allow
                    // retries for successful builds (that's the whole point of permanent dedup),
                    // but a thrown build leaves us with no mesh in the cache and silently
                    // dropping the key would mean nothing is ever rendered for this tile.
                    pendingBuildKeys.remove(key)
                    Log.w(TAG, "buildStencilTileListener: build failed for $maskLayerId/$coordHash", t)
                }
            }
        }
    }

    fun unregister(
        controller: MapController?,
        weatherLayerId: String,
        clearMeshCache: Boolean = true,
    ) {
        val reg = registrations.remove(weatherLayerId) ?: return
        reg.undo.forEach { it() }
        reg.maskVectorLayerIds.forEach { maskId ->
            if (clearMeshCache) {
                controller?.glStencilMaskTileCache?.clearCustomMaskKind(maskId)
            }
            GlStencilMaskRendererHolder.renderer.releaseGpuForMaskLayerId(maskId)
            // Force any in-flight build to abort: it will fail the generation check at the top of
            // its block and exit before doing the expensive mesh assembly.
            maskLayerGeneration.merge(maskId, 1) { old, _ -> old + 1 }
            // Drop any cached path extractions for this mask. Keeping them would only ever leak
            // memory: the same `(maskLayerId, coordHash)` can't come back without a fresh
            // `register`, and the next register's listener will re-populate the cache anyway.
            val pathPrefix = "$maskId\u0000"
            cachedLinePaths.keys.removeIf { it.startsWith(pathPrefix) }
            // Same idea for dedup keys (`gen\u0000maskId\u0000coord`) — match the mask-id chunk
            // anywhere in the key since the generation prefix is variable.
            val dedupInfix = "\u0000$maskId\u0000"
            pendingBuildKeys.removeIf { it.contains(dedupInfix) }
        }
    }
}
