package com.xweather.mapsgl.map.mapbox

import com.google.gson.GsonBuilder
import com.google.gson.JsonObject
import com.mapbox.geojson.*
import com.mapbox.geojson.gson.GeoJsonAdapterFactory
import no.ecc.vectortile.VectorTileDecoder
import org.json.JSONArray
import org.json.JSONObject
import com.mapbox.geojson.Point as MBPoint
import com.mapbox.geojson.Polygon as MBPolygon
import com.mapbox.geojson.LineString as MBLineString
import com.mapbox.geojson.MultiPoint as MBMultiPoint
import com.mapbox.geojson.MultiPolygon as MBMultiPolygon
import com.mapbox.geojson.MultiLineString as MBMultiLineString
import com.mapbox.geojson.Geometry as MapboxGeometry
import org.locationtech.jts.geom.Point
import org.locationtech.jts.geom.Polygon
import org.locationtech.jts.geom.LineString
import org.locationtech.jts.geom.MultiPoint
import org.locationtech.jts.geom.MultiPolygon
import org.locationtech.jts.geom.MultiLineString
import com.xweather.mapsgl.tiles.TileCoord

object MapboxVectorFeature {
    fun from(coord: TileCoord, vtFeature: VectorTileDecoder.Feature, attributes: Map<String, *>? = null): Feature {
        val geometry = vtFeature.geometry
        val featureProperties = attributes ?: vtFeature.attributes
        val extent = vtFeature.extent ?: 4096

        val mapboxGeometry: MapboxGeometry = when (geometry) {
            is Point -> {
                val (lon, lat) = tileLocalXYToLngLat(geometry.x, geometry.y, coord)
                MBPoint.fromLngLat(lon, lat)
            }
            is MultiPoint -> MBMultiPoint.fromLngLats(
                geometry.coordinates.map {
                    val (lon, lat) = tileLocalXYToLngLat(it.x, it.y, coord)
                    MBPoint.fromLngLat(lon, lat)
                }
            )
            is LineString -> MBLineString.fromLngLats(
                geometry.coordinates.map {
                    val (lon, lat) = tileLocalXYToLngLat(it.x, it.y, coord)
                    MBPoint.fromLngLat(lon, lat)
                }
            )
            is MultiLineString -> MBMultiLineString.fromLineStrings(
                (0 until geometry.numGeometries).map { i ->
                    val line = geometry.getGeometryN(i) as LineString
                    MBLineString.fromLngLats(
                        line.coordinates.map {
                            val (lon, lat) = tileLocalXYToLngLat(it.x, it.y, coord)
                            MBPoint.fromLngLat(lon, lat)
                        }
                    )
                }
            )
            is Polygon -> {
                // Exterior ring
                val exterior = geometry.exteriorRing.coordinates.map {
                    val (lon, lat) = tileLocalXYToLngLat(it.x, it.y, coord)
                    MBPoint.fromLngLat(lon, lat)
                }.let { ring ->
                    // ensure closed
                    if (ring.isNotEmpty() && ring.first() != ring.last()) ring + ring.first() else ring
                }

                // Holes
                val holes: List<List<MBPoint>> = (0 until geometry.numInteriorRing).map { i ->
                    geometry.getInteriorRingN(i).coordinates.map {
                        val (lon, lat) = tileLocalXYToLngLat(it.x, it.y, coord)
                        MBPoint.fromLngLat(lon, lat)
                    }.let { ring ->
                        // ensure closed
                        if (ring.isNotEmpty() && ring.first() != ring.last()) ring + ring.first() else ring
                    }
                }

                // (Optional) normalize orientation: outer CCW, holes CW
                fun isCW(r: List<MBPoint>): Boolean {
                    var s = 0.0
                    for (k in 0 until r.size - 1) {
                        val a = r[k];
                        val b = r[k + 1]
                        s += (b.longitude() - a.longitude()) * (b.latitude() + a.latitude())
                    }
                    return s > 0
                }

                val ext = if (isCW(exterior)) exterior.reversed() else exterior
                val holesOriented = holes.map { r -> if (isCW(r)) r else r.reversed() }

                MBPolygon.fromLngLats(listOf(ext) + holesOriented)
            }
            is MultiPolygon -> {
                MBMultiPolygon.fromPolygons(
                    (0 until geometry.numGeometries).map { i ->
                        val jtsPoly = geometry.getGeometryN(i) as Polygon

                        val exterior = jtsPoly.exteriorRing.coordinates.map {
                            val (lon, lat) = tileLocalXYToLngLat(it.x, it.y, coord, extent)
                            MBPoint.fromLngLat(lon, lat)
                        }.let { ring ->
                            // ensure closed
                            if (ring.isNotEmpty() && ring.first() != ring.last()) ring + ring.first() else ring
                        }

                        val holes = (0 until jtsPoly.numInteriorRing).map { h ->
                            jtsPoly.getInteriorRingN(h).coordinates.map {
                                val (lon, lat) = tileLocalXYToLngLat(it.x, it.y, coord, extent)
                                MBPoint.fromLngLat(lon, lat)
                            }.let { ring ->
                                // ensure closed
                                if (ring.isNotEmpty() && ring.first() != ring.last()) ring + ring.first() else ring
                            }
                        }

                        MBPolygon.fromLngLats(listOf(exterior) + holes)
                    }
                )
            }
            else -> throw IllegalArgumentException("Unsupported geometry type: ${geometry.geometryType}")
        }

        // Convert vtFeature.attributes to a JSONObject-like map for flexible property parsing
        val properties = JSONObject()
        for (key in featureProperties.keys) {
            val value = featureProperties[key]
            // Parse stringified JSON objects/arrays
            val parsedValue = if (value is String) {
                val trimmed = value.trim()
                try {
                    when {
                        trimmed.startsWith("{") && trimmed.endsWith("}") -> JSONObject(
                            trimmed
                        )

                        trimmed.startsWith("[") && trimmed.endsWith("]") -> JSONArray(
                            trimmed
                        )

                        else -> value
                    }
                } catch (e: Exception) {
                    value
                }
            } else {
                value
            }
            properties.put(key, parsedValue)
        }

        // Mapbox `fromGeometry` requires properties to be provided as `JsonObject`, so recursively convert values.
        val geoJsonProps = convertJsonObjectToGeoJson(properties)

        return Feature.fromGeometry(mapboxGeometry, geoJsonProps, vtFeature.id.toString())
    }

    private fun convertJsonObjectToGeoJson(json: JSONObject): JsonObject {
        val gson = GsonBuilder()
            .registerTypeAdapterFactory(GeoJsonAdapterFactory.create())
            .create()

        val map = mutableMapOf<String, Any?>()

        for (key in json.keys()) {
            map[key] = convertJsonValue(json.get(key))
        }

        return gson.toJsonTree(map).asJsonObject
    }

    private fun convertJsonValue(value: Any?): Any? {
        return when (value) {
            is JSONObject -> {
                val nestedMap = mutableMapOf<String, Any?>()
                for (key in value.keys()) {
                    nestedMap[key] = convertJsonValue(value.get(key))
                }
                nestedMap
            }

            is JSONArray -> {
                val list = mutableListOf<Any?>()
                for (i in 0 until value.length()) {
                    list.add(convertJsonValue(value.get(i)))
                }
                list
            }

            JSONObject.NULL -> null
            else -> value
        }
    }

    // Helper function to convert tile local coordinates to geographic coordinates
    private fun tileLocalXYToLngLat(x: Double, y: Double, coord: TileCoord, extent: Int = 4096): Pair<Double, Double> {
        val lon = (x / extent + coord.x) / (1 shl coord.z) * 360.0 - 180.0
        val n = Math.PI - 2.0 * Math.PI * (y / extent + coord.y) / (1 shl coord.z)
        val lat = Math.toDegrees(Math.atan(Math.sinh(n)))
        return Pair(lon, lat)
    }
}