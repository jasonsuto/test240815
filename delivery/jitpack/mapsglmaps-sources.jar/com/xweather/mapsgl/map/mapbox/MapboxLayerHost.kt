package com.xweather.mapsgl.map.mapbox

import android.content.Context
import android.opengl.GLES31
import com.mapbox.maps.BuildConfig
import com.mapbox.maps.CustomLayerHost
import com.mapbox.maps.CustomLayerRenderParameters
import com.mapbox.maps.logD
import com.mapbox.maps.logW
import com.xweather.mapsgl.gl.RenderPass
import com.xweather.mapsgl.gl.RenderPass.Companion
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.layers.tile.MapLayer
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera
import com.xweather.mapsgl.renderers.LayerRenderContext
import com.xweather.mapsgl.sources.DataType
import com.xweather.mapsgl.sources.type
import com.xweather.mapsgl.tiles.Tile
import com.xweather.mapsgl.tiles.TileData

/**
 *  MapboxLayerHost.kt
 *
 *  @author Jason Suto 11/30/23.
 */
class MapboxLayerHost(
    private val context: Context,
    private val mapLayer: MapLayer<TileData, LayerRenderContext<Any>>, //private?
) : CustomLayerHost {

    companion object {
        private const val TAG = "MapboxLayerHost"
        private const val BYTES_PER_FLOAT = 4
        private var programInt = 0

        private fun checkError(cmd: String? = null) {
            if (BuildConfig.DEBUG) {
                when (val error = GLES31.glGetError()) {
                    GLES31.GL_NO_ERROR -> {
                        logD(TAG, "$cmd -> no error")
                    }

                    GLES31.GL_INVALID_ENUM -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_ENUM")
                    GLES31.GL_INVALID_VALUE -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_VALUE")
                    GLES31.GL_INVALID_OPERATION -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_OPERATION")
                    GLES31.GL_INVALID_FRAMEBUFFER_OPERATION -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_FRAMEBUFFER_OPERATION")
                    GLES31.GL_OUT_OF_MEMORY -> throw RuntimeException("$cmd -> error in gl: GL_OUT_OF_MEMORY")
                    else -> throw RuntimeException("$cmd -> error in gl: $error")
                }
            }
        }
    }

    var id = mapLayer.id
    lateinit var camera: Camera
    var hashMap = hashMapOf<String, Int>()
    var needToBindTextures = false
    lateinit var currentTime: String
    lateinit var nextTime: String
    //private lateinit var copyMap: MutableMap<String, Tile<DataType>>



    init{
        if(pr.ON) pr.p("LHost", pr.lHost, "init() for ${mapLayer.id}")

    }

    private var _showLayer: Boolean = true
    var showLayer: Boolean
        get() = _showLayer
        set(value) {
            _showLayer = value
        }

    fun setTexturesToBind(doBind: Boolean = true) {
        needToBindTextures = doBind
    }

    override fun initialize() {
        if(pr.ON) pr.p("LayerHost", pr.lHost, "initialize() for ${mapLayer.id}")
        mapLayer.source.tileCache.oneTimeCacheSetup()
    }


    override fun render(parameters: CustomLayerRenderParameters) {
        //if(pr.ON) pr.p(TAG, pr.dataPool, "render() showLayer: $showLayer  needToBindTextures:$needToBindTextures")
        if (_showLayer) {
            CustomLayerMatrixBridge.pushToCameraSync(parameters)
            try {
                if (needToBindTextures) {
                    bindTextures(mapLayer.source.id)
                }
                mapLayer.prerender(1.0)
                mapLayer.render(hashMap, camera)
            } finally {
                CustomLayerMatrixBridge.clearCameraSync()
            }
        }

    }

     fun bindTextures(sourceId: String? = null) {
        hashMap = mapLayer.source.tileCache.bindTextures(sourceId)
        //if(pr.ON) pr.p(TAG, pr.threadDL, "bindTextures() camera bounds is ${camera.bounds}")
        if(pr.ON) pr.p(TAG, pr.flicker, "bindTextures() size: ${mapLayer.source.tileCache.bindList.size}")
        val moreToBind = mapLayer.source.tileCache.bindList.isNotEmpty()
        setTexturesToBind(moreToBind)
        // bindTextures() only uploads up to maxBindsPerFrame tiles per call; when the map is idle,
        // Mapbox may not render again, so loading state (Timeline pending / progress UI) can stick
        // until the camera moves. Request another frame until the bind queue is drained.
        if (moreToBind) {
            mapLayer.mapController?.redraw()
        }
    }

    override fun contextLost() {
        logW(TAG, "contextLost")
        programInt = 0
        GlStencilMaskRendererHolder.renderer.onContextLost()
        RenderPass.notifyRasterQuadVbosContextLost()
    }

    override fun deinitialize() {
        if (programInt != 0) {
            // Disable vertex array
            //GLES31.glDisableVertexAttribArray(programPtr.positionHandle)
            //GLES31.glDisableVertexAttribArray(programPtr.colorHandle)
            //GLES31.glDeleteShader(vertexShader)
            //GLES31.glDeleteShader(fragmentShader)
            GLES31.glDeleteProgram(programInt)
            programInt = 0
        }
    }

    private fun checkCompileStatus(shader: Int) {
        if (BuildConfig.DEBUG) {
            val isCompiled = IntArray(1)
            GLES31.glGetShaderiv(shader, GLES31.GL_COMPILE_STATUS, isCompiled, 0)
            if (isCompiled[0] == GLES31.GL_FALSE) {
                val infoLog = GLES31.glGetShaderInfoLog(programInt)
                throw RuntimeException("checkCompileStatus error: $infoLog")
            }
        }
    }

    fun setLayerHostCamera(camera: Camera) {
        this.camera = camera
    }
}
