package com.xweather.mapsgl.map.mapbox

import com.mapbox.geojson.Feature
import com.xweather.mapsgl.layers.tile.VectorTileLayer
import com.xweather.mapsgl.map.MapController
import com.xweather.mapsgl.sources.GeoJSONSource
import com.xweather.mapsgl.tiles.TileCoord
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

/**
 * Builds GeoJSON-driven custom stencil meshes off the render thread.
 *
 * [TileLayerRenderer] used to run [GlStencilMaskMeshBuilder.buildTileUvTriangles] (and line-ribbon
 * variants) synchronously inside `stencilBeforeTile` on the GL thread. Large GeoJSON fills (e.g.
 * CONUS) could block frames; **vector road masks** are built separately in
 * [GlStencilCustomMaskCoordinator]. This coordinator only affects GeoJSON-driven mask layers when
 * [com.xweather.mapsgl.layers.spec.StencilMaskCombineMode] is not the sequential ALL path.
 */
internal object GlStencilGeoJsonMaskMeshCoordinator {

    private val dispatcher = Dispatchers.Default.limitedParallelism(2)
    private val scope = CoroutineScope(SupervisorJob() + dispatcher)
    private val pendingKeys = ConcurrentHashMap.newKeySet<String>()

    private fun pendingKey(maskLayerId: String, meshStencilKey: String, seq: Int): String =
        "$seq\u0000$maskLayerId\u0000$meshStencilKey"

    fun cancelPendingForMaskLayer(maskLayerId: String) {
        val needle = "\u0000$maskLayerId\u0000"
        pendingKeys.removeIf { it.contains(needle) }
    }

    fun cancelAllPendingGeoJsonStencilBuilds() {
        pendingKeys.clear()
    }

    /**
     * Queues a background triangulation when the exact mesh for this tile + [seq] is missing or
     * stale. Duplicate in-flight work for the same key is ignored.
     *
     * @param lineRibbonStyle non-null only for line-style mask layers; fill masks use null.
     */
    fun requestMeshIfNeeded(
        controller: MapController,
        cache: GlStencilMaskTileCache,
        maskLayerId: String,
        meshStencilKey: String,
        meshCoord: TileCoord,
        filteredFeatures: List<Feature>,
        seq: Int,
        lineHalfWidthUv: Float,
        lineRibbonStyle: GlStencilMaskMeshBuilder.LineRibbonStyle?,
    ) {
        val exact = cache.getExactCustomMaskMesh(maskLayerId, meshStencilKey)
        if (exact != null &&
            exact.geoJsonStencilSequence >= 0 &&
            exact.geoJsonStencilSequence == seq
        ) {
            return
        }
        val pk = pendingKey(maskLayerId, meshStencilKey, seq)
        if (!pendingKeys.add(pk)) return
        val featsSnapshot = ArrayList(filteredFeatures)
        scope.launch {
            try {
                val tri = if (lineRibbonStyle != null) {
                    GlStencilMaskMeshBuilder.buildLineRibbonTileUvTriangles(
                        meshCoord,
                        featsSnapshot,
                        lineHalfWidthUv,
                        lineRibbonStyle,
                    )
                } else {
                    GlStencilMaskMeshBuilder.buildTileUvTriangles(meshCoord, featsSnapshot)
                }
                controller.mapView.post {
                    pendingKeys.remove(pk)
                    val vl = controller.layers[maskLayerId] as? VectorTileLayer
                    val geo = vl?.source as? GeoJSONSource
                    if (geo == null || geo.geoJsonStencilSequence != seq) {
                        tri?.let { DirectFloatBufferPool.releaseDeferred(it) }
                        return@post
                    }
                    if (tri != null) {
                        cache.putCustomMaskMesh(
                            maskLayerId,
                            meshStencilKey,
                            GlStencilMaskTileCache.CpuMesh(
                                tri,
                                tri.limit() / 2,
                                geoJsonStencilSequence = seq,
                            ),
                        )
                    } else {
                        cache.removeCustomMaskTile(maskLayerId, meshStencilKey)
                    }
                    if (controller.useGlTextureMaskFbo) {
                        controller.glTextureMaskBuilder.markDirty()
                    }
                    (controller as? MapboxMapController)?.requestRepaintCoalesced()
                }
            } catch (_: Throwable) {
                pendingKeys.remove(pk)
            }
        }
    }
}
