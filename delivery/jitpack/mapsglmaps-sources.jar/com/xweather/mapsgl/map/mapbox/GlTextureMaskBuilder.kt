package com.xweather.mapsgl.map.mapbox

import android.opengl.GLES31
import android.opengl.Matrix
import com.xweather.mapsgl.gl.programs.RasterTileProgram
import com.xweather.mapsgl.gl.worldObjects.MeshInfo
import com.xweather.mapsgl.layers.spec.StencilLayerMaskSpec
import com.xweather.mapsgl.layers.spec.StencilMaskCombineMode
import com.xweather.mapsgl.layers.tile.VectorTileLayer
import com.xweather.mapsgl.map.MapController
import com.xweather.mapsgl.sources.GeoJSONSource
import com.xweather.mapsgl.style.FillLayerPaint
import com.xweather.mapsgl.style.LineLayerPaint
import com.xweather.mapsgl.style.StyleValue
import com.xweather.mapsgl.tiles.TileCoord

/**
 * Builds a viewport-sized R8 mask texture (JS `renderTarget` / `tMask`) once per dirty frame.
 * Weather tiles sample this texture instead of rewriting stencil every tile every frame.
 */
internal class GlTextureMaskBuilder {

    private val fbo = GlTextureMaskFramebuffer()
    private val matrixArray = FloatArray(16)
    private val modelViewMatrixArray = FloatArray(16)

    @Volatile
    var dirty: Boolean = true

    private var lastBuiltWidth = 0
    private var lastBuiltHeight = 0
    private var lastSpecKey: String? = null
    private var lastMeshSignature: String? = null
    private var lastMaskMeshReadinessKey: String? = null
    private val lastProjection = FloatArray(16)
    private val lastModelViewBase = FloatArray(16)
    private var hasLastMatrices = false

    var lastInvert: Boolean = false
        private set

    fun markDirty() {
        dirty = true
        lastSpecKey = null
        lastMaskMeshReadinessKey = null
    }

    fun colorTextureId(): Int = fbo.colorTextureId()

    fun needsRebuild(
        spec: StencilLayerMaskSpec,
        meshInfos: List<MeshInfo>,
        projection: FloatArray,
        modelViewBase: FloatArray,
        viewportWidth: Int,
        viewportHeight: Int,
        cache: GlStencilMaskTileCache,
        renderer: GlStencilMaskRenderer,
    ): Boolean {
        if (dirty) return true
        if (!fbo.matchesSize(viewportWidth, viewportHeight)) return true
        val specKey = specKey(spec)
        if (specKey != lastSpecKey) return true
        val sig = meshSignature(meshInfos)
        if (sig != lastMeshSignature) return true
        val readiness = maskMeshReadinessKey(spec, meshInfos, cache, renderer)
        if (readiness != lastMaskMeshReadinessKey) return true
        if (!hasLastMatrices ||
            !matricesEqual(projection, lastProjection) ||
            !matricesEqual(modelViewBase, lastModelViewBase)
        ) {
            return true
        }
        return false
    }

    /**
     * Rebuilds the mask FBO when [needsRebuild] is true. Returns whether a valid mask texture exists.
     */
    fun rebuildIfNeeded(
        mc: MapController,
        spec: StencilLayerMaskSpec,
        meshInfos: List<MeshInfo>,
        projection: FloatArray,
        modelViewBase: FloatArray,
        viewportWidth: Int,
        viewportHeight: Int,
        rasterProgram: RasterTileProgram,
    ): Boolean {
        val renderer = GlStencilMaskRendererHolder.renderer
        val cache = mc.glStencilMaskTileCache
        if (!needsRebuild(
                spec,
                meshInfos,
                projection,
                modelViewBase,
                viewportWidth,
                viewportHeight,
                cache,
                renderer,
            )
        ) {
            return fbo.colorTextureId() != 0
        }
        if (viewportWidth < 1 || viewportHeight < 1) return false

        fbo.ensureSize(viewportWidth, viewportHeight)
        if (fbo.colorTextureId() == 0) return false

        val slotIds = spec.layers.map { it.layerId }
        val useSequentialAll =
            spec.mode == StencilMaskCombineMode.ALL && !spec.invert
        val sequentialAllLayerOrder: List<String> = if (useSequentialAll) {
            slotIds.sortedBy { lid ->
                val vl = mc.layers[lid] as? VectorTileLayer
                if (vl?.paint is LineLayerPaint) 1 else 0
            }
        } else {
            emptyList()
        }

        val prevFbo = fbo.bind()
        GLES31.glClearColor(0f, 0f, 0f, 0f)
        GLES31.glClear(GLES31.GL_COLOR_BUFFER_BIT or GLES31.GL_STENCIL_BUFFER_BIT)
        GLES31.glDisable(GLES31.GL_STENCIL_TEST)
        GLES31.glColorMask(true, true, true, true)

        val mapZoomNow = CameraSync.customLayerRenderZoom ?: CameraSync.mapZoom
        val useMapboxNativeMv = projection.size >= 16 && modelViewBase.size >= 16

        renderer.beginMaskFboDrawPass()

        fun ensureGeoJsonMaskMeshForLayer(maskLayerId: String, meshStencilKey: String) {
            val meshCoord = TileCoord.fromHashShort(meshStencilKey) ?: return
            val vl = mc.layers[maskLayerId] as? VectorTileLayer ?: return
            val geoSrc = vl.source as? GeoJSONSource ?: return
            val seq = geoSrc.geoJsonStencilSequence
            val cached = cache.getExactCustomMaskMesh(maskLayerId, meshStencilKey)
            if (cached != null &&
                cached.geoJsonStencilSequence >= 0 &&
                cached.geoJsonStencilSequence == seq
            ) {
                return
            }
            val feats = cache.getOrComputeGeoJsonStencilFilteredFeatures(
                maskLayerId,
                seq,
                vl.filter,
            ) { geoSrc.data?.features().orEmpty() }
            val tri = if (vl.paint is LineLayerPaint) {
                val linePaint = vl.paint as LineLayerPaint
                val halfW = when (val th = linePaint.stroke.thickness) {
                    is StyleValue.Constant -> (th.value / 400.0).toFloat().coerceIn(0.001f, 0.05f)
                    else -> 0.003f
                }
                GlStencilMaskMeshBuilder.buildLineRibbonTileUvTriangles(
                    meshCoord,
                    feats,
                    halfW,
                    GlStencilMaskMeshBuilder.lineRibbonStyleFromLineLayerPaint(linePaint),
                )
            } else {
                GlStencilMaskMeshBuilder.buildTileUvTriangles(meshCoord, feats)
            }
            if (tri != null) {
                cache.putCustomMaskMesh(
                    maskLayerId,
                    meshStencilKey,
                    GlStencilMaskTileCache.CpuMesh(
                        tri,
                        tri.limit() / 2,
                        geoJsonStencilSequence = seq,
                    ),
                )
            } else {
                cache.removeCustomMaskTile(maskLayerId, meshStencilKey)
            }
        }

        var drewAny = false
        try {
            for (meshInfo in meshInfos) {
                Matrix.setIdentityM(matrixArray, 0)
                val overscale = if (useMapboxNativeMv) {
                    CameraSync.tileRasterOverscale(mapZoomNow, meshInfo.z.toInt())
                } else {
                    1f
                }
                Matrix.scaleM(matrixArray, 0, 512f * overscale, 512f * overscale, 1f)
                Matrix.translateM(matrixArray, 0, meshInfo.x, meshInfo.y, 0f)
                Matrix.multiplyMM(modelViewMatrixArray, 0, modelViewBase, 0, matrixArray, 0)

                val meshStencilKey = stencilCacheKeyForMeshInfo(meshInfo)

                if (useSequentialAll) {
                    var passIdx = 0
                    spec.clipBounds?.let { b ->
                        val ck = "${b.westExtent}_${b.southExtent}_${b.eastExtent}_${b.northExtent}"
                        val tri = GlStencilMaskMeshBuilder.buildLatLonBoundsClipTileUv(meshInfo, b)
                        if (tri != null) {
                            val mesh = GlStencilMaskTileCache.CpuMesh(tri, tri.limit() / 2)
                            val vboKey = renderer.clipStencilVboKey(meshInfo, ck)
                            if (renderer.drawSequentialAllMaskPassToMaskFbo(
                                    mesh,
                                    vboKey,
                                    passIdx++,
                                    projection,
                                    modelViewMatrixArray,
                                    rasterProgram,
                                )
                            ) {
                                drewAny = true
                            }
                        }
                    }
                    for (maskLayerId in sequentialAllLayerOrder) {
                        ensureGeoJsonMaskMeshForLayer(maskLayerId, meshStencilKey)
                        val resolved = renderer.tryResolveCustomMaskVboForDraw(
                            cache,
                            maskLayerId,
                            meshStencilKey,
                        ) ?: continue
                        if (resolved.first.vertexCount < 3) continue
                        val (mesh, vboK, _) = resolved
                        if (renderer.drawSequentialAllMaskPassToMaskFbo(
                                mesh,
                                vboK,
                                passIdx++,
                                projection,
                                modelViewMatrixArray,
                                rasterProgram,
                            )
                        ) {
                            drewAny = true
                        }
                    }
                } else {
                    for (maskLayerId in slotIds) {
                        val vl = mc.layers[maskLayerId] as? VectorTileLayer ?: continue
                        if (vl.paint is FillLayerPaint) {
                            // When clipBounds is set, use that axis-aligned area once per tile
                            // instead of per-tile GeoJSON fill (which becomes white tile rects).
                            if (spec.clipBounds != null) continue
                            ensureGeoJsonMaskMeshForLayer(maskLayerId, meshStencilKey)
                        }
                        val resolved = renderer.tryResolveCustomMaskVboForDraw(
                            cache,
                            maskLayerId,
                            meshStencilKey,
                        ) ?: continue
                        if (resolved.first.vertexCount < 3) continue
                        val (mesh, vboK, _) = resolved
                        if (renderer.drawMeshWhiteToMaskFbo(
                                mesh,
                                vboK,
                                projection,
                                modelViewMatrixArray,
                                rasterProgram,
                            )
                        ) {
                            drewAny = true
                        }
                    }
                    spec.clipBounds?.let { b ->
                        val ck = "${b.westExtent}_${b.southExtent}_${b.eastExtent}_${b.northExtent}"
                        val tri = GlStencilMaskMeshBuilder.buildLatLonBoundsClipTileUv(meshInfo, b)
                        if (tri != null) {
                            val mesh = GlStencilMaskTileCache.CpuMesh(tri, tri.limit() / 2)
                            val vboKey = renderer.clipStencilVboKey(meshInfo, ck)
                            if (renderer.drawMeshWhiteToMaskFbo(
                                    mesh,
                                    vboKey,
                                    projection,
                                    modelViewMatrixArray,
                                    rasterProgram,
                                )
                            ) {
                                drewAny = true
                            }
                        }
                    }
                }
            }
        } finally {
            renderer.endMaskFboDrawPass(rasterProgram)
        }

        GLES31.glDisable(GLES31.GL_STENCIL_TEST)
        GLES31.glColorMask(true, true, true, true)
        fbo.unbind(prevFbo)

        val readinessKey = maskMeshReadinessKey(spec, meshInfos, cache, renderer)
        val meshesComplete = maskMeshesComplete(spec, meshInfos, cache, renderer)
        lastMaskMeshReadinessKey = readinessKey
        lastInvert = spec.invert

        // Stay dirty until every visible tile has mask geometry (CONUS GeoJSON + highway MVT).
        dirty = !meshesComplete || !drewAny

        if (!dirty) {
            lastBuiltWidth = viewportWidth
            lastBuiltHeight = viewportHeight
            lastSpecKey = specKey(spec)
            lastMeshSignature = meshSignature(meshInfos)
            System.arraycopy(projection, 0, lastProjection, 0, 16)
            System.arraycopy(modelViewBase, 0, lastModelViewBase, 0, 16)
            hasLastMatrices = true
        }

        return fbo.colorTextureId() != 0
    }

    fun release() {
        fbo.release()
        dirty = true
        hasLastMatrices = false
        lastMaskMeshReadinessKey = null
    }

    private fun specKey(spec: StencilLayerMaskSpec): String {
        val clipKey = spec.clipBounds?.let { b ->
            "${b.westExtent}_${b.southExtent}_${b.eastExtent}_${b.northExtent}"
        } ?: ""
        return "${spec.mode}_${spec.invert}_${clipKey}_${spec.layers.joinToString(",") { it.layerId }}"
    }

    private fun meshSignature(meshInfos: List<MeshInfo>): String =
        meshInfos.joinToString(";") { stencilCacheKeyForMeshInfo(it) }

    /**
     * Tracks which mask slots have drawable geometry for the current visible weather tiles.
     * Changes when async MVT builds finish even if the camera is still.
     */
    private fun maskMeshReadinessKey(
        spec: StencilLayerMaskSpec,
        meshInfos: List<MeshInfo>,
        cache: GlStencilMaskTileCache,
        renderer: GlStencilMaskRenderer,
    ): String {
        val sb = StringBuilder()
        for (meshInfo in meshInfos) {
            val tileKey = stencilCacheKeyForMeshInfo(meshInfo)
            for (ref in spec.layers) {
                val resolved = renderer.tryResolveCustomMaskVboForDraw(cache, ref.layerId, tileKey)
                val ready = resolved != null && resolved.first.vertexCount >= 3
                sb.append(ref.layerId).append(':').append(tileKey).append(':')
                    .append(if (ready) '1' else '0').append(';')
            }
        }
        return sb.toString()
    }

    private fun maskMeshesComplete(
        spec: StencilLayerMaskSpec,
        meshInfos: List<MeshInfo>,
        cache: GlStencilMaskTileCache,
        renderer: GlStencilMaskRenderer,
    ): Boolean {
        if (meshInfos.isEmpty()) return false
        for (meshInfo in meshInfos) {
            val tileKey = stencilCacheKeyForMeshInfo(meshInfo)
            for (ref in spec.layers) {
                val resolved = renderer.tryResolveCustomMaskVboForDraw(cache, ref.layerId, tileKey)
                    ?: return false
                if (resolved.first.vertexCount < 3) return false
            }
        }
        return true
    }

    private fun matricesEqual(a: FloatArray, b: FloatArray): Boolean {
        for (i in 0 until 16) {
            if (a[i] != b[i]) return false
        }
        return true
    }
}
