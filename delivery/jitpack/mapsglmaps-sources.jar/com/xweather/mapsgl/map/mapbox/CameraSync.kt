package com.xweather.mapsgl.map.mapbox

import com.xweather.mapsgl.gl.math.Matrix4
import kotlin.jvm.JvmField
import kotlin.jvm.Volatile
import com.xweather.mapsgl.gl.math.ProjectionMatrix
import com.xweather.mapsgl.gl.math.RotateAxis
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera

class CameraSync {
    companion object {
        var mapZoom: Double = 0.0
        lateinit var camera: Camera
        const val WORLD_SIZE = 1024000 // TILE_SIZE * 2000
        const val cameraToCenterDistance = 0f
        const val EARTH_RADIUS = 6371008.8
        const val FOV_ORTHO = 0.1 / 180 * Math.PI; // Mapbox doesn't accept 0 as FOV

        // from Mapbox https://github.com/mapbox/mapbox-gl-js/blob/0063cbd10a97218fb6a0f64c99bf18609b918f4c/src/geo/lng_lat.js#L117
        const val EARTH_CIRCUMFERENCE_EQUATOR = 40075017;

        // const WORLD_SIZE = WORLD_SIZE
        const val PROJECTION_WORLD_SIZE = WORLD_SIZE / (EARTH_RADIUS * Math.PI * 2);
        const val MERCATOR_A = EARTH_RADIUS
        const val DEG2RAD = Math.PI / 180
        const val RAD2DEG = 180 / Math.PI;

        // const EARTH_RADIUS = EARTH_RADIUS;
        const val EARTH_CIRCUMFERENCE = 2 * Math.PI * EARTH_RADIUS; // 40075000, // In meters
                var scaleMatrix: Matrix4 = Matrix4.identity()
        var translationMatrix: Matrix4 = Matrix4.identity()
        var worldMatrix: ProjectionMatrix = ProjectionMatrix()
        var rotScalePitchMatrix: Matrix4

        /**
         * Filled by [CustomLayerMatrixBridge] each [com.mapbox.maps.CustomLayerHost.render] frame.
         * Encoded raster [com.xweather.mapsgl.gl.RenderPass] uses these (paired) so tiles share the
         * same clip-space transform as the Mapbox basemap under pitch/bearing; do not mix with
         * [camera] projection/view for that path.
         */
        @JvmField
        var mapboxProjectionMatrix: FloatArray? = null

        @JvmField
        var mapboxModelViewMatrix: FloatArray? = null

        /**
         * [CustomLayerRenderParameters.zoom] for the frame currently being rendered in
         * [com.mapbox.maps.CustomLayerHost.render]. Cleared after render.
         *
         * [camera.zoom] is updated on the main thread after each frame finishes; using it for tile Z
         * during custom-layer draw can lag by one frame and disagree with [mapboxModelViewMatrix]
         * near integer zooms.
         */
        @Volatile
        @JvmField
        var customLayerRenderZoom: Double? = null

        /**
         * Last [CustomLayerRenderParameters.zoom] from [CustomLayerMatrixBridge.pushToCameraSync].
         * Not cleared with [customLayerRenderZoom] so async CPU work (instanced wind gather) uses the same
         * Mercator scale as the custom-layer projection matrices instead of [MapboxMap.cameraState.zoom],
         * which can diverge during pinch-zoom and causes rapid sub-pixel jitter.
         */
        @Volatile
        @JvmField
        var lastCustomLayerRenderZoom: Double? = null

        /**
         * Zoom aligned with Mapbox custom-layer [CustomLayerRenderParameters] for this frame / last render.
         */
        fun zoomForCustomLayerInstancing(): Double =
            customLayerRenderZoom ?: lastCustomLayerRenderZoom ?: mapZoom

        /**
         * CPU instance Mercator XY uses world pixels at [zBuild] (512×2^zBuild). Custom-layer P/MV are for
         * [zoomForCustomLayerInstancing]. Apply this factor to stored positions in the vertex shader so they
         * match the current matrices between async instance rebuilds (removes zoom jitter).
         */
        fun mercatorWorldPixelZoomFix(zBuild: Double): Float {
            val zRender = zoomForCustomLayerInstancing()
            val f = Math.pow(2.0, zRender - zBuild)
            return if (!f.isNaN() && f.isFinite() && f > 0.0) f.toFloat() else 1f
        }

        init {
            rotScalePitchMatrix = Matrix4.identity()
        }


        private fun lon2tile(lon: Double, zoom: Double): Double {
            return (lon + 180.0) / 360.0 * (1 shl zoom.toInt())
        }

        private fun lat2tile(lat: Double, zoom: Double): Double {
            val latRad = Math.toRadians(lat)
            return (1 - Math.log(Math.tan(latRad) + 1 / Math.cos(latRad)) / Math.PI) / 2 * (1 shl zoom.toInt())
        }

        /**
         * Extra scale for 512×512 raster tile quads in Mapbox custom-layer space relative to
         * integer tile Z. Uses fractional [mapZoom] so encoded rasters track zoom between integers
         * instead of stepping when [mapZoom] crosses whole numbers.
         */
        fun tileRasterOverscale(mapZoom: Double, tileZ: Int): Float =
            Math.pow(2.0, mapZoom - tileZ.toDouble()).toFloat()

        /**
         * Scale (tile zoom) then bearing (Z) then pitch (X), using **post-multiplication** so each
         * rotation applies in map/tangent space: M = T_scale × R_z(-bearing) × R_x(pitch).
         * The previous left-multiplication chain (R_x × R_z × T) put the map plane in the wrong
         * orientation relative to the perspective camera except at specific bearing/pitch combos.
         */
        fun calculateCameraMatrixDeg(
            pitch: Float, bearing: Float, translateZ: Matrix4
        ): Matrix4 {
            val m = Matrix4()
            m.multiply(translateZ, m)
            val rz = Matrix4().rotateInDegrees(RotateAxis.RotateZ, -bearing)
            m.multiply(m, rz)
            val rx = Matrix4().rotateInDegrees(RotateAxis.RotateX, pitch)
            m.multiply(m, rx)
            return m
        }

    }//end companion object

}