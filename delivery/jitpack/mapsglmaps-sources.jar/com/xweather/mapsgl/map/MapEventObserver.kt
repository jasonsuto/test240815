package com.xweather.mapsgl.map

import com.xweather.mapsgl.layers.tile.RenderContext
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.map.mapbox.MapboxMapController

/**
 * Lifecycle and interaction callbacks for objects attached to the map pipeline (layers, controls, etc.).
 *
 * [com.xweather.mapsgl.layers.tile.MapLayer] implements this interface so hosts can react to visibility,
 * camera moves, and teardown consistently with the Mapbox-backed controller.
 */
interface MapEventObserver {
    /** Called when the observer is attached with no tile-layer context (simple registration). */
    @Throws(Exception::class)
    fun onAdd()

    /** Called when the observer is attached with render context and owning tile layer / controller. */
    @Throws(Exception::class)
    fun onAdd(context: RenderContext<Any>, tileLayer: TileLayer, controller: MapboxMapController)

    /** Called when the observer is removed from the map; release GL or listeners here. */
    @Throws(Exception::class)
    fun onRemove()

    /** Invoked while the map camera is moving (per frame or throttled). */
    @Throws(Exception::class)
    suspend fun onMove()

    /** Periodic or explicit update tick (animation, data refresh hooks). */
    @Throws(Exception::class)
    suspend fun update()

    /** First callback when a gesture or programmatic camera change begins. */
    @Throws(Exception::class)
    fun onMoveStart()

    /** Invoked once when a camera movement settles. */
    @Throws(Exception::class)
    suspend fun onMoveEnd()

    /** Host view size or map drawable size changed. */
    @Throws(Exception::class)
    fun onResize()

    /** Map tap / click routed from the gestures plugin. */
    @Throws(Exception::class)
    fun onClick()

    /** Observer or host layer became visible. */
    @Throws(Exception::class)
    fun onVisible()

    /** Observer or host layer became hidden. */
    @Throws(Exception::class)
    fun onHidden()
}