/**
 * MapController.kt
 *
 * Adapted from IOS version
 * Need to reincorporate EncodedSourceDescriptor
 *
 * @author Jason Suto 12/12/23
 *
 **/

package com.xweather.mapsgl.map

import LayerEvents
import android.content.ComponentCallbacks2
import android.content.Context
import android.graphics.RectF
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Choreographer
import androidx.core.view.isVisible
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModel
import androidx.lifecycle.findViewTreeLifecycleOwner
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import com.mapbox.geojson.Point
import com.mapbox.maps.CustomLayerHost
import com.mapbox.maps.MapView
import com.mapbox.maps.extension.style.expressions.dsl.generated.config
import com.mapbox.maps.plugin.gestures.OnMapClickListener
import com.xweather.mapsgl.anim.AnimationEvent
import com.xweather.mapsgl.anim.AnimationOptions
import com.xweather.mapsgl.anim.AnimationState
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.anim.Timeline.Companion.timeStrings
import com.xweather.mapsgl.config.weather.account.XweatherAccount
import com.xweather.mapsgl.controls.DataInspectorControl
import com.xweather.mapsgl.controls.legend.LegendControl
import com.xweather.mapsgl.controls.legend.Point.PointLegend
import com.xweather.mapsgl.controls.legend.bar.BarLegend
import com.xweather.mapsgl.data.DataInspectorResult
import com.xweather.mapsgl.data.LayerTileList
import com.xweather.mapsgl.data.Queue
import com.xweather.mapsgl.data.TileList
import com.xweather.mapsgl.data.series.AnimatorSync
import com.xweather.mapsgl.events.Cancellable
import com.xweather.mapsgl.events.EventDispatcher
import com.xweather.mapsgl.events.MapControllerEvents
import com.xweather.mapsgl.extensions.Dimension
import com.xweather.mapsgl.geo.Viewport
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera
import com.xweather.mapsgl.gl.worldObjects.cameras.CameraType
import com.xweather.mapsgl.layers.FeatureQueryResult
import com.xweather.mapsgl.layers.QueriedFeature
import com.xweather.mapsgl.layers.spec.ContourLayerDescriptor
import com.xweather.mapsgl.layers.spec.GridLayerDescriptor
import com.xweather.mapsgl.layers.spec.LayerDescriptor
import com.xweather.mapsgl.layers.spec.MaskLayerKind
import com.xweather.mapsgl.layers.spec.ParticleLayerDescriptor
import com.xweather.mapsgl.layers.spec.RasterLayerDescriptor
import com.xweather.mapsgl.layers.spec.SampleLayerDescriptor
import com.xweather.mapsgl.layers.spec.VectorLayerDescriptor
import com.xweather.mapsgl.layers.tile.EncodedTileLayer
import com.xweather.mapsgl.layers.tile.MapLayer
import com.xweather.mapsgl.layers.tile.RenderContext
import com.xweather.mapsgl.layers.tile.TileConversions
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.layers.tile.VectorTileLayer
import com.xweather.mapsgl.map.mapbox.CameraSync
import com.xweather.mapsgl.map.mapbox.CameraSync.Companion.camera
import com.xweather.mapsgl.map.mapbox.CameraSync.Companion.mapZoom
import com.xweather.mapsgl.map.mapbox.MapboxLayerHost
import com.xweather.mapsgl.map.mapbox.MapboxMapController
import com.xweather.mapsgl.map.mapbox.MapboxMapController.Companion.PERSPECTIVECAMERA
import com.xweather.mapsgl.map.mapbox.MapboxMapController.Companion.TAG
import com.xweather.mapsgl.renderers.ContourRenderer
import com.xweather.mapsgl.renderers.EmptyRenderer
import com.xweather.mapsgl.renderers.EncodedDataRenderer
import com.xweather.mapsgl.renderers.GridLayerRenderer
import com.xweather.mapsgl.renderers.ParticleRenderer
import com.xweather.mapsgl.renderers.RasterLayerRenderer
import com.xweather.mapsgl.renderers.WindArrowInstancedRenderer
import com.xweather.mapsgl.renderers.WindBarbInstancedRenderer
import com.xweather.mapsgl.sources.DataSource
import com.xweather.mapsgl.sources.EncodedGridVectorTileSource
import com.xweather.mapsgl.sources.EncodedTileSource
import com.xweather.mapsgl.sources.GeoJSONSource
import com.xweather.mapsgl.sources.ImageTileSource
import com.xweather.mapsgl.sources.RasterTileApiEvent
import com.xweather.mapsgl.sources.TileSource
import com.xweather.mapsgl.sources.VectorTileSource
import com.xweather.mapsgl.sources.XweatherEncodedTileSource
import com.xweather.mapsgl.sources.data.EncodedData
import com.xweather.mapsgl.sources.source.spec.EncodedSourceDescriptor
import com.xweather.mapsgl.sources.source.spec.GeoJSONSourceDescriptor
import com.xweather.mapsgl.sources.source.spec.ImageSourceDescriptor
import com.xweather.mapsgl.sources.source.spec.SourceDescriptor
import com.xweather.mapsgl.sources.source.spec.VectorSourceDescriptor
import com.xweather.mapsgl.style.ColorScaleOptions
import com.xweather.mapsgl.style.ContourLayerPaint
import com.xweather.mapsgl.style.GridLayerPaint
import com.xweather.mapsgl.style.LayerPaint
import com.xweather.mapsgl.style.ParticleLayerPaint
import com.xweather.mapsgl.style.RasterLayerPaint
import com.xweather.mapsgl.style.SampleLayerPaint
import com.xweather.mapsgl.style.VectorLayerPaint
import com.xweather.mapsgl.style.colorStopBandsFromOptionsStops
import com.xweather.mapsgl.tiles.LatLonBounds
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.types.Coordinate
import com.xweather.mapsgl.types.DataSourceConsumer
import com.xweather.mapsgl.types.MapProvider
import com.xweather.mapsgl.types.SampleExpression
import com.xweather.mapsgl.types.Size
import com.xweather.mapsgl.types.TileSize
import com.xweather.mapsgl.utils.Signal
import com.xweather.mapsgl.utils.parseDateArrayFromString
import com.xweather.mapsgl.weather.CompositeWeatherLayerConfiguration
import com.xweather.mapsgl.weather.LayerCode
import com.xweather.mapsgl.weather.WeatherConfiguration
import com.xweather.mapsgl.weather.WeatherLayerConfiguration
import com.xweather.mapsgl.weather.WeatherService
import com.xweather.mapsgl.weather.XweatherAuthenticator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.sql.DriverManager
import kotlin.collections.set
import kotlin.math.atan
import kotlin.math.floor
import kotlin.math.roundToInt

internal sealed class MapControllerError : Throwable() {
    data class ALREADY_EXISTS(val desc: String = "already exists") : Error()
    data class INVALID_SOURCE(val desc: String = "invalid source") : Error()
}

/**
 * Bridge between the host map view (Mapbox [MapView]) and MapsGL: sources, tile layers, timeline,
 * data inspector, legends, and weather APIs.
 *
 * Use [com.xweather.mapsgl.map.mapbox.MapboxMapController] as the concrete implementation for Mapbox.
 *
 * @param mapView Host [MapView]; used for context, lifecycle, and dimensions.
 * @param account Xweather credentials used by [service] and tile requests.
 */
abstract class MapController(val mapView: MapView, val account: XweatherAccount) : MapProvider, ViewModel(),
    DefaultLifecycleObserver, TileLayer.TileLayerEventListener, ComponentCallbacks2, OnMapClickListener {

    internal companion object {
        var packageName: String? = null

        /** Logcat filter tag for [MapController] init diagnostics (e.g. device density at creation). */
        const val MAP_CONTROLLER_LOG_TAG = "MapsGL.MapController"
    }

    init {
        val dm = mapView.context.resources.displayMetrics
        Log.i(
            MAP_CONTROLLER_LOG_TAG,
            "MapController created: density=${dm.density} densityDpi=${dm.densityDpi} " +
                    "scaledDensity=${dm.scaledDensity} xdpi=${dm.xdpi} ydpi=${dm.ydpi} " +
                    "widthPx=${dm.widthPixels} heightPx=${dm.heightPixels}",
        )
    }

    private val listeners: MutableMap<String, MutableList<(Any) -> Unit>> = mutableMapOf()

    /** Geographic center of the map in latitude/longitude degrees, kept in sync with the camera. */
    lateinit var centerLatLng: Coordinate// = Coordinate(viewport.getCenter().y, viewport.getCenterOffset().x)
    private var sources: MutableMap<String, DataSource> = mutableMapOf()
    /** All MapsGL map layers currently registered on this controller, keyed by layer id. */
    var layers: MutableMap<String, MapLayer<*, *>> = mutableMapOf()
    private var layerIdsByWeatherCode: MutableMap<LayerCode, MutableList<String>> = mutableMapOf()
    private var particleLayers: MutableMap<String, MapLayer<*, *>> = mutableMapOf()

    /** Pick/inspect weather values at a tap location; enable with [addDataInspectorControl]. */
    val dataInspector = DataInspectorControl(this)
    private var _legendControl: LegendControl? = null
    /** Optional UI control for layer legends; install with [add]. */
    var legendControl: LegendControl? = null


    private val downloadTrackingHandler = Handler(Looper.getMainLooper())
    private var downloadStartTime = 0L
    val thisMap = this

    private val downloadTrackingRunnable = object : Runnable {
        override fun run() {
            val elapsedSeconds = (System.currentTimeMillis() - downloadStartTime) / 1000
            //println(">>> MapController: Still waiting for encoded downloads... ($elapsedSeconds seconds elapsed)")

            // --- TIMEOUT LOGIC ---
            if (elapsedSeconds > 125) {
                println(">>> MapController: Download timed out after 125 seconds. Clearing pending downloads.")
                if (thisMap is MapboxMapController) {
                    thisMap.clearPending()
                }
                // Clear the pending downloads
                // The LiveData observer will then see the empty map and stop the handler.
                return // Stop the runnable immediately
            }

            // Schedule next check in 1 second
            downloadTrackingHandler.postDelayed(this, 1000)
        }
    }

    internal val layerHosts: MutableMap<String, MapboxLayerHost> = mutableMapOf()
    private var lastUpdated = 0L
    private var currentTime = 0L
    private val minimumDIUpdateInterval = 60

    // If the inspector is active over an area with no loaded tiles yet, we want it to
    // refresh as soon as *any* encoded tile download completes (so new tile data can
    // immediately appear in the callout).
    private var lastPendingEncodedTotal: Int = 0
    private var lastDIUpdateOnEncodedTileLoadAt: Long = 0L
    private val minimumDIUpdateIntervalOnEncodedTileLoadMs = 250L

    /** -1 is fast, 1 is sharper. This is also sent to TileLayer. **/
    internal var zoomOffset = -1 //-1 is quicker to load, less detail, 0 looks sharper.
    internal var animatingTimeline = false
    internal var readyToPlay = true
    private val _onLoadStart = MutableLiveData<Unit>() // Unit signifies no specific data
    /** Internal debounce job for camera move-end handling; managed by [MapboxMapController]. */
    var debounceMoveEndJob: Job? = null // Add this property

    /** Single main-thread scope for map work — avoids allocating a new [CoroutineScope] on every launch. */
    private val controllerMainJob = SupervisorJob()
    private val controllerMainScope = CoroutineScope(controllerMainJob + Dispatchers.Main)

    /** Posted when loading begins for any tracked data source (e.g. tile wave started). */
    val onLoadStart: LiveData<Unit> = _onLoadStart
    private var loadProgressSessionActive: Boolean = false
    private var loadProgressLastCompletedPct: Int = 0
    private var pendingLoadCompleteJob: Job? = null
    private val loadCompleteDebounceMs: Long = 700L

    private fun emitOnLoadProgressPercent(percent: Int, force: Boolean = false) {
        val clamped = percent.coerceIn(0, 100)
        if (force) {
            loadProgressLastCompletedPct = clamped
            dispatchOnLoadProgress(Queue.Progress(total = 100, completed = clamped))
            return
        }
        if (!loadProgressSessionActive) {
            loadProgressSessionActive = true
            loadProgressLastCompletedPct = 0
        }
        // Keep progress monotonic within one load session so staggered multi-layer waves
        // do not visually jump backward (e.g. 50 -> 0 -> 100).
        val monotonic = maxOf(loadProgressLastCompletedPct, clamped)
        if (monotonic != loadProgressLastCompletedPct) {
            loadProgressLastCompletedPct = monotonic
            dispatchOnLoadProgress(Queue.Progress(total = 100, completed = monotonic))
        }
    }

    internal fun triggerLoadStart() {
        pendingLoadCompleteJob?.cancel()
        pendingLoadCompleteJob = null
        _onLoadStart.postValue(Unit)
        if (!loadProgressSessionActive) {
            loadProgressSessionActive = true
            loadProgressLastCompletedPct = 0
            dispatchOnLoadProgress(Queue.Progress(total = 100, completed = 0))
        }
        //this.trigger(MapControllerEvents.LOAD_PROGRESS, true)
        //if (pr.ON) pr.p(TAG, pr.loadTracking, "Loading Started")
    }

    internal fun triggerLoadComplete() {
        pendingLoadCompleteJob?.cancel()
        pendingLoadCompleteJob = controllerMainScope.launch {
            // Two-layer loads can briefly drain then refill pending queues; debounce completion so
            // onLoadProgress does not reset (0 -> 50 -> 0 -> 100) between near-adjacent waves.
            delay(loadCompleteDebounceMs)

            Timeline.currentDLCount = 0
            Timeline.resetEncodedDownloadProgressCounters()
            Timeline.pendingPercent = 0f
            _dlProgress.postValue(Timeline.pendingPercent)
            emitOnLoadProgressPercent(100, force = true)
            loadProgressSessionActive = false
            _onLoadComplete.postValue(Unit)
            //trigger(MapControllerEvents.LOAD_COMPLETE, true)
            if (pr.ON) pr.p(TAG, pr.loadTracking, "Loading Done")

            // do a final datainspector here
            //if (pr.ON) pr.p("MapController", pr.queryTrack, "onLoadComplete() triggered, doing a query...")
            dataInspector.targetCoordinate?.let { coords ->
                val allLayerIds = layers.values.map { it.id }
                viewModelScope.launch {
                    if (pr.ON) pr.p(
                        "MapController",
                        pr.queryTrack,
                        "onLoadComplete()  calling query with $coords, $allLayerIds..."
                    )
                    query(coords, allLayerIds, true)
                }
            }
            pendingLoadCompleteJob = null
        }
    }

    private val _onLoadComplete = MutableLiveData<Unit>() // Unit signifies no specific data
    private val _dlProgress = MutableLiveData<Float>() // Unit signifies no specific data
    private val _onLoadProgressLiveData = MutableLiveData<MapLoadProgress>()


    /** Posted when the current load session completes (encoded downloads and bind pipeline idle). */
    val onLoadComplete: LiveData<Unit> = _onLoadComplete
    /** Approximate download progress fraction (0f–1f) while tiles are in flight. */
    val dlProgress: LiveData<Float> = _dlProgress
    /** Same progress as [onLoadProgress], exposed as a [Signal] for coroutine collectors. */
    val onLoadProgressValue = Signal.eventOnly<MapLoadProgress>(scope = viewModelScope)

    /**
     * Emits [MapLoadProgress] while map data loads. Use
     * `onLoadProgress.observe(this) { progress -> ... }` like other [LiveData] on this controller.
     * For coroutine / flow access, see [onLoadProgressValue].
     */
    val onLoadProgress: LiveData<MapLoadProgress> = _onLoadProgressLiveData

    private fun dispatchOnLoadProgress(progress: Queue.Progress) {
        val payload = MapLoadProgress.fromQueue(progress)
        onLoadProgressValue.send(payload)
        _onLoadProgressLiveData.postValue(payload)
    }

    /** Fires with a source id after [addSource] registers it and the source is ready for layers. */
    val onSourceAdded = Signal.eventOnly<String>(scope = viewModelScope)

    private val onSourceRemoved = Signal.eventOnly<String>(scope = viewModelScope)
    private val onLayerAdded = Signal.eventOnly<String>(scope = viewModelScope)
    private val onLayerRemoved = Signal.eventOnly<String>(scope = viewModelScope)


    private var customLayerUpdatesHaveStarted = false
    internal val type = PERSPECTIVECAMERA
    private var frameCallback: Choreographer.FrameCallback? = null
    private val choreographer = Choreographer.getInstance()
    //private val griddedOverlaySourceByParent = mutableMapOf<String, String>()

    //** This may not be needed. onMove was being used in instances other than when the camera moved **/
    internal suspend fun onMoveNoMove(pauseParticles: Boolean = true, tag: String = "empty") {

        //if(pr.ON) pr.p(TAG, pr.onMove, "onMoveNoMove()")
        if (pauseParticles) camera.moveState = Camera.MOVING
        for (layer in getMapsGLRenderedLayers()) {
            if (layer.visible) {
                layer.onMove() // calls:  bounds = mapController?.getBounds()?: return AND requestVisibleTiles(bounds!!)
            }
        }
    }

    internal val eventDispatcher = EventDispatcher()

    /**
     * Configuration options that control the behavior of timeline animations and data preloading.
     *
     * Use this object to modify settings such as playback speed, loop behavior, and
     * whether the system should aggressively pre-fetch tiles ([AnimationOptions.shouldPreloadData])
     * to ensure seamless, buffer-free playback across the active time range.
     */
    val animationOptions: AnimationOptions = AnimationOptions()

    /** instance used for managing animation and time-based data. **/
    val timeline: Timeline = Timeline(animationOptions, this)

    private val animatorSync: AnimatorSync = AnimatorSync(timeline)
    internal val viewport: Viewport = Viewport(this)
    internal val tileSize = 512f
    internal var worldSize = 0f
    internal var cameraTriggered = false

    /** Discrete zoom from [MapboxMapController.updateCamera] (`mapZoom.toInt() + zoomOffset`). Encoded data-inspector tile Z follows [TileLayer.getTileBounds] instead. Matrix scale uses fractional `mapZoom + zoomOffset` there. */
    internal var zoomInt = 0
    internal var densityMult = 1.0f
    internal var scaleCalc = 0f
    internal var translationCalc = 0.0

    /** Keep track of screen size to detect orientation change. **/
    internal var lastWidth = 0

    /**Usually 60, 90, 120 fps **/
    internal var refreshRate: Float

    /**
     * The primary interface for communicating with the Xweather backend.
     *
     * This service handles the construction of API requests, authentication
     * using the provided [account] credentials, and the retrieval of
     * weather data for the various layers and data sources managed by this controller.
     */
    val service: WeatherService = WeatherService(account)

    init {

        // added 260311 for individual layer anim

        // Example: Tracking the pending list
        TileList.pendingList.listener = object : LayerTileList.TileListListener {
            override fun onListStarted() {
                if (pr.ON) pr.p(
                    "MapboxMapController",
                    pr.download26,
                    "Downloads started: Showing progress bar..."
                )
                // UI code: progressBar.visibility = View.VISIBLE
                // Layer animation gating is handled at draw-time in RenderPass.

                triggerLoadStart()
            }

            override fun onListEmpty() {
                if (pr.ON) {
                    pr.p(
                        "MapboxMapController",
                        pr.download26,
                        "TileList pending queue empty (HTTP + decode done for tracked intervals). " +
                                "Progress UI still waits for GPU bind (Timeline pending map).",
                    )
                }
                // Do not post load complete here: pendingList clears when bytes are received and processed,
                // while textures may not be bound yet. Hiding the bar is driven by
                // [Timeline.pendingEncodedDownloadsLiveData] emptying after bindTextures().
                // When the map is otherwise idle, Mapbox may not render again; nudge a repaint so
                // [MapboxLayerHost.bindTextures] can drain the bind queue (max binds/frame) and clear Timeline pending.
                controllerMainScope.launch {
                    redraw()
                }
            }

            override fun onSubListEmpty(layerId: String) {
                if (pr.ON) pr.p("MapboxMapController", pr.download26, "All downloads finished: Hiding progress bar.")
                // Layer animation gating is handled at draw-time in RenderPass.
            }

            override fun onTick() {
                // This prints every 0.5 seconds while items exist in pendingList

                val pendingCount = TileList.pendingList.countAllEntries()
                Timeline.calcDLPercent(pendingCount)
                _dlProgress.postValue(Timeline.pendingPercent)
                emitOnLoadProgressPercent(Timeline.pendingPercent.roundToInt())

                if (pr.ON) {
                    if (Timeline.currentDLCount != 0)
                        pr.p(
                            "MapboxMapController",
                            pr.download26,
                            "Still downloading ${pendingCount}/${Timeline.currentDLCount}  " +
                                    "----- ${Timeline.pendingPercent}% ----- "
                        )
                    else {
                        pr.p(
                            "MapboxMapController",
                            pr.download26,
                            "Still downloading ${pendingCount}) "
                        )
                    }

                }
            }
        }

        // end added 260311 for individual layer anim

        // Setup the listener for option changes
        timeline.opts.onPreloadChanged = { isEnabled ->
            if (isEnabled) {
                viewModelScope.launch {
                    preloadVisibleTiles()
                }
            }
        }

        val timelineAdvanceListener: (Any) -> Unit = {
            // This runs on the thread the timeline uses
            //binding.timelineView.timelineControls.setPosition(controller.timeline.position)

            if (dataInspector.isActive == true) {
                currentTime = System.currentTimeMillis()
                if (currentTime - lastUpdated > minimumDIUpdateInterval) {
                    lastUpdated = currentTime
                    val lifecycleOwner = mapView.findViewTreeLifecycleOwner()
                    lifecycleOwner?.lifecycleScope?.launch(Dispatchers.Main) { //260226 was .Main
                        //println(">> CALLING update()")
                        dataInspector.update()
                    }
                }
            }
        }
        timeline.on(AnimationEvent.advance, timelineAdvanceListener)

        packageName = mapView.context.packageName
        setZoom(1.0)
        refreshRate = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
            getScreenRefreshRate(mapView.context)
        else 60f

        Timeline.frameRate = refreshRate

        // Update the `timeRange` property on data sources when the timeline range changes
        timeline.on(AnimationEvent.range_change) {
            sources.values.forEach {
                if (it is TileSource<*>) {
                    if (pr.ON) pr.p(TAG, pr.timeLineListener, "range change:")
                    it.timeRange = timeline.start..timeline.end
                }
            }
        }

        timeline.on(AnimationEvent.INTERVAL_CHANGE) {
            val vt = parseDateArrayFromString(timeStrings[Timeline.currentPhaseA]).first()
            layers.forEach {
                val source = it.value.source
                if (source is VectorTileSource && source !is EncodedGridVectorTileSource) {
                    source.validTime = vt
                    if (!animatingTimeline) {
                        source.invalidate()
                    }
                }
            }
            forEachEncodedGridVectorTileSource { grid ->
                grid.validTime = vt
                if (!animatingTimeline) {
                    grid.invalidate()
                }
            }
        }

        Timeline.pendingVectorDownloadsLiveData.observe(
            this.mapView.context as LifecycleOwner
        ) { count ->
            if (count == 0) {
                //println(">> MapController Vector DONE LOADING!!!!!!")
                if (layers.values.any {
                        val source = it.source as? VectorTileSource
                        source?.dlCount == 1
                    }) {
                    if (dataInspector.on) {
                        dataInspector.updateVector()
                    }

                }
                //timeline.setIsDownloading(false)
            }
        }

        Timeline.pendingEncodedDownloadsLiveData.observe(
            mapView.findViewTreeLifecycleOwner() ?: (mapView.context as LifecycleOwner)
        ) { hashMap ->
            if (hashMap.isNotEmpty()) {
                val pendingTotal = hashMap.values.sumOf { it.size }
                val completedAny = pendingTotal < lastPendingEncodedTotal
                lastPendingEncodedTotal = pendingTotal

                val target = dataInspector.targetCoordinate
                val diActive = dataInspector.on && dataInspector.isActive && target != null
                val now = System.currentTimeMillis()
                if (completedAny && diActive && now - lastDIUpdateOnEncodedTileLoadAt > minimumDIUpdateIntervalOnEncodedTileLoadMs) {
                    lastDIUpdateOnEncodedTileLoadAt = now
                    dataInspector.update()
                }

                Timeline.calcDLPercent(TileList.pendingList.countAllEntries())
                _dlProgress.postValue(Timeline.pendingPercent)
                emitOnLoadProgressPercent(Timeline.pendingPercent.roundToInt())

                // Start tracking if not already started
                if (downloadStartTime == 0L) {
                    downloadStartTime = System.currentTimeMillis()
                    downloadTrackingHandler.post(downloadTrackingRunnable)
                    if (pr.ON) pr.p(TAG, pr.loadTracking, "Downloads started. Timer initiated.")
                }
                //timeline.setIsDownloading(true)
                //triggerLoadStart()
            } else {
                lastPendingEncodedTotal = 0
                // CLEANUP: Stop the timer and reset start time
                downloadTrackingHandler.removeCallbacks(downloadTrackingRunnable)
                val totalSeconds = (System.currentTimeMillis() - downloadStartTime) / 1000
                downloadStartTime = 0L
                //println(">>> MapController: All downloads finished! Total time: $totalSeconds seconds.")
                //timeline.setIsDownloading(false)
                triggerLoadComplete()
            }
        }

    } // end init{}

    /**
     * Triggers a manual pre-fetch of tile animation data.
     *
     * This function caches tiles for the visible viewport across the timeline's active
     * time range.
     * This is typically used to ensure smooth playback and minimize loading time
     */
    fun preloadAnimationData() {
        viewModelScope.launch {
            animationOptions.forcePreloadOneTime = true
            preloadVisibleTiles()
            animationOptions.forcePreloadOneTime = false
        }
    }


    /**
     * Activates and initializes the Data Inspector control for the map.
     *
     * This function enables the "pick" or "inspect" mode which allows users to retrieve
     * underlying weather data values from specific coordinates on the map. It ensures
     * that listeners are only initialized once and sets up the synchronization
     * for vector data updates.
     *
     * @param mapView The [MapView] instance where the data inspector UI should be hosted.
     * @return The initialized [DataInspectorControl] instance.
     */
    fun addDataInspectorControl(mapView: MapView): DataInspectorControl {
        if (!dataInspector.on) {
            dataInspector.initializeListeners(this)

            this.on(DataInspectorEvent.VECTOR_UPDATE) {
                //if (pr.ON) pr.p(TAG, pr.flickerFix, "queryFeatures() on(DataInspectorEvent.VECTOR_UPDATE)")
                dataInspector.updateVector()
            }
        }

        dataInspector.on = true
        return dataInspector
    }

    /**
     * Deactivates the Data Inspector control and cleans up its associated resources.
     *
     * This function performs the following cleanup steps:
     * 1. Sets the [DataInspectorControl.on] state to `false`.
     * 2. Triggers the UI to hide its overlay/view components.
     * 3. Unregisters all event listeners (such as `VECTOR_UPDATE`) previously attached
     *    to this [MapController] to prevent memory leaks and unnecessary background processing.
     *
     * Call this when the user exits "inspection" or "picker" mode.
     */
    fun removeDataInspectorControl() {
        dataInspector.on = false
        dataInspector.hide()
        dataInspector.removeEvents(this)
        //dataInspector = null
    }

    /**
     * Returns whether the map currently contains a weather layer with the specified identifier.
     * @param code Weather product to check.
     * @return `true` if that product (or every sub-layer of a composite) is present.
     */
    fun hasWeatherLayer(code: LayerCode): Boolean {
        // If code corresponds to a composite layer, then iterate through the composite's layers and check if all layers exist.
        val config = LayerCode.getConfigurationForLayerCode(code, service)
        if (config is CompositeWeatherLayerConfiguration) {
            val results = config.layers.map { hasWeatherLayer(it.code) }
            return results.all { it }
        }
        return layerIdsByWeatherCode[code] != null
    }

    /**
     *
     * Returns A layer given its LayerCode.
     *
     * example: LayerCode.Temperatures
     *
     * @param code Weather product to resolve.
     * @return The single [MapLayer] for that code, or `null` if missing or if multiple layers share the same code.
     */
    fun getWeatherLayer(code: LayerCode): MapLayer<*, *>? {
        layerIdsByWeatherCode[code]?.let {
            if (it.size > 1) {
                println(
                    "[MapsGL] There are multiple layers associated with the weather code ${code.value}: ${
                        it.joinToString(
                            ", "
                        )
                    }"
                )
                return null
            }
            return getLayer(it.first())
        }
        return null
    }

    /**
     * Adds a weather layer from a [LayerCode] preset (source + descriptor + paint from [service]).
     *
     * @param layerCode Built-in or configured weather product.
     * @param id Optional stable id prefix; composite children get derived ids.
     * @param beforeId Optional existing layer id to insert below in the stack.
     * @return The primary new [TileLayer], or `null` if configuration is invalid.
     */
    fun addWeatherLayer(layerCode: LayerCode, id: String? = null, beforeId: String? = null): TileLayer? {
        // LayerCode.getConfigurationForLayerCode might return the base WeatherConfiguration.
        // The specific generic type is often known when calling WeatherService.SpecificLayer() directly.
        val configuration = LayerCode.getConfigurationForLayerCode(layerCode, service)
        return addWeatherLayer(configuration, id, beforeId)
    }

    /**
     * Adds a weather layer from an explicit [WeatherConfiguration] (use when you built the config
     * from [WeatherService] factories instead of [LayerCode]).
     *
     * @param config Source + layer descriptor + optional legend; composites recurse into sub-configs.
     * @param id Optional id prefix for the new layer(s).
     * @param beforeId Optional insertion anchor in the layer stack.
     * @param isCompoundLayer Internal flag when recursing for composite layers.
     * @return The primary new [TileLayer], or `null` if the configuration cannot be applied.
     */
    fun addWeatherLayer(
        config: WeatherConfiguration,
        id: String? = null,
        beforeId: String? = null,
        isCompoundLayer: Boolean = false
    ): TileLayer? {
        if (config is CompositeWeatherLayerConfiguration) {
            var addedLayer: TileLayer? = null
            for (subConfig in config.layers) { // subConfig is AnyWeatherLayerConfiguration
                //val subId = if (id != null) "${id}__${subConfig.code.value}" else null // old code, always null
                val subId =
                    if (id != null) "${id}__${subConfig.code.value}" else "${config.code.name}__${subConfig.code.value}"
                // Recursive call, subConfig is still AnyWeatherLayerConfiguration
                val result = addWeatherLayer(subConfig, subId, beforeId, true)
                result?.code = config.code.value // Use the composite's code
                if (addedLayer == null && result != null) {
                    addedLayer = result
                }
            }

            setPresentation(config, addedLayer)
            trigger(MapControllerEvents.LAYER_ADDED, (addedLayer is VectorTileLayer))
            return addedLayer
        }

        // We expect a WeatherLayerConfiguration<S, LD, P> here for individual layers.
        // If LayerCode.getConfigurationForLayerCode returns a non-generic WeatherConfiguration,
        // you might need to reconsider its return type or handle it.
        // For now, let's assume if it's not Composite, it's our generic WeatherLayerConfiguration.
        if (config !is WeatherLayerConfiguration<*, *>) { // Check against the generic form
            println("[MapsGL] Warning: addWeatherLayer received a WeatherConfiguration that is not a WeatherLayerConfiguration for ${config.code.value}. Layer not added.")
            return null
        }
        // Now 'config' is known to be WeatherLayerConfiguration<S, LD, P>
        // S, LD, P are star-projected here but will be specific if the `config` instance was created that way.

        getWeatherLayer(config.code)?.let {
            moveLayer(it.id, beforeId)
            setLayerVisible(it.id, true)
            trigger(MapControllerEvents.VISIBILITY_CHANGED, it.id)
            if (this is MapboxMapController) {
                val maskKind = when (val ld = config.layer) {
                    is SampleLayerDescriptor -> ld.mask
                    is ContourLayerDescriptor -> ld.mask
                    is ParticleLayerDescriptor -> ld.mask
                    is GridLayerDescriptor -> ld.mask
                    else -> MaskLayerKind.NONE
                }
                if (maskKind != MaskLayerKind.NONE) {
                    println(">>> MapController: addWeatherLayer() scheduling syncLandMaskStackAfterWeatherLayerAdded()")
                    this.syncLandMaskStackAfterWeatherLayerAdded(it.id, beforeId, maskKind)
                }
            }

            // Do not call add() again when the layer already exists: add() increments legendRefCounts
            // but only attaches one LegendView, so a second add leaves refcount > 1 and removeWeatherLayer
            // removes the map layer once while the legend stays (ref never reaches 0).
            if (config.legend != null) {
                val legend = config.legend!!
                if (legendControl?.getLegend(legend.id) == null) {
                    legendControl?.add(legend)
                }
            }

            return it as TileLayer // Assuming all weather layers are TileLayers
        }

        val insertBeforeId: String? = beforeId

        // Add the source from the configuration
        addSource(config.source) // config.source is SourceDescriptor (S)
        val layerDescriptor = config.layer

        // Special handling for EncodedSourceDescriptor and paint properties
        // This section becomes much cleaner as 'layerDescriptor.paint' is now specifically typed.
        if (config.source is EncodedSourceDescriptor) {
            val source = config.source as EncodedSourceDescriptor // Cast for dataset access
            val paint = layerDescriptor.paint

            val channels = when (paint) {
                is SampleLayerPaint -> paint.sample.channel
                is ParticleLayerPaint -> paint.sample.channel
                is ContourLayerPaint -> paint.sample.channel
                is GridLayerPaint -> paint.sample?.channel ?: emptyList()
                else -> emptyList()
            }

            if (channels.isNotEmpty()) {
                // Keep dataset signed range for VECTOR: sample.frag maps u/v with mix(dataRangeMin,dataRangeMax).
                // Legend-only non-negative range is applied in [colorScaleForBarLegend], not here.
                val tempRange = source.datasets?.get(channels[0].rawValue)?.dataRange
                when (paint) {
                    is ContourLayerPaint -> {
                        if (pr.ON) pr.p(TAG, pr.contour, "addWeatherLayer() detected contourLayerPaint 300 ")
                        if (paint.sample.colorScale.range == null) {
                            paint.sample.colorScale.range = tempRange
                        }
                        if (paint.sample.expression != SampleExpression.DIFFERENCE) {
                            paint.sample.colorScale.range = tempRange
                        }
                        val tempQuality = paint.sample.quality
                        zoomOffset = 0
                    }

                    is SampleLayerPaint -> {
                        if (paint.sample.colorScale.range == null) {
                            paint.sample.colorScale.range = tempRange
                        }
                        if (paint.sample.expression != SampleExpression.DIFFERENCE) {
                            paint.sample.colorScale.range = tempRange
                        }
                        val tempQuality = paint.sample.quality
                        zoomOffset = 0
                    }

                    is ParticleLayerPaint -> {
                        paint.sample.colorScale.range = tempRange
                        val tempQuality = paint.sample.quality
                        zoomOffset = 0
                    }

                    is GridLayerPaint -> {
                        paint.sample?.let { sp ->
                            if (sp.colorScale.range == null) {
                                sp.colorScale.range = tempRange
                            }
                            if (sp.expression != SampleExpression.DIFFERENCE) {
                                sp.colorScale.range = tempRange
                            }
                            zoomOffset = 0
                        }
                    }

                    else -> {}
                }
            }
        }

        val layer = addLayer(layerDescriptor, insertBeforeId) ?: return null // Pass the correctly typed layerDescriptor

        if (!isCompoundLayer) {
            if (pr.ON) pr.p(TAG, pr.vectorRefactor, "triggering LAYER_ADDED from addweatherLayer() NORMALLY")
            trigger(MapControllerEvents.LAYER_ADDED, (layer is VectorTileLayer))
        }


        if (layerIdsByWeatherCode[config.code] == null) {
            layerIdsByWeatherCode[config.code] = mutableListOf()
        }
        layerIdsByWeatherCode[config.code]?.add(layer.id)
        layer.code = config.code.value

        if (this is MapboxMapController) {
            val maskKindFromDescriptor: MaskLayerKind? = when (layerDescriptor) {
                is SampleLayerDescriptor -> layerDescriptor.mask
                is ContourLayerDescriptor -> layerDescriptor.mask
                is ParticleLayerDescriptor -> layerDescriptor.mask
                is GridLayerDescriptor -> layerDescriptor.mask
                else -> null // Or MaskLayerKind.NONE if that makes more sense to avoid a null check later
            }
            if (maskKindFromDescriptor != null && maskKindFromDescriptor != MaskLayerKind.NONE) {
                val currentMapboxMap = this.mapboxMap!!

                println(">>> MapController: addWeatherLayer() calling addMaskLayer()")

                val maskLayer = addMaskLayer(maskKindFromDescriptor, service, this, currentMapboxMap, insertBeforeId)


                if (maskKindFromDescriptor == MaskLayerKind.LAND && layer is EncodedTileLayer) {
                    layer.hasLandMask = true
                    println(">>> MapController: addWeatherLayer()    layer.hasLandMask = true")
                }

                // Custom layer is added asynchronously in MapboxMapController.addToMap; mask order must be
                // applied after the style contains the weather layer (see syncLandMaskStackAfterWeatherLayerAdded).
                println(">>> MapController: addWeatherLayer() scheduling syncLandMaskStackAfterWeatherLayerAdded()")
                this.syncLandMaskStackAfterWeatherLayerAdded(layer.id, insertBeforeId, maskKindFromDescriptor)
            }
        }

        addLegend(config)
        if (layer.id == "severe.alerts.fill") {
            controllerMainScope.launch {
                delay(1500) // Wait for 2 seconds (non-blocking)
                updateLegendsForMap()
                delay(2500) // Wait for 2 seconds (non-blocking)
                updateLegendsForMap()
                //println(">>> MaoController MapsGL: 2 seconds have passed for severe alerts, called updateLegendsForMap")
            }
        }

        setPresentation(config, layer)
        return layer
    }

    /**
     * Resolves the [WeatherConfiguration] that would be used for [addWeatherLayer] with this [layerCode].
     */
    fun getConfigForCode(layerCode: LayerCode): WeatherConfiguration {
        return LayerCode.getConfigurationForLayerCode(layerCode, service)
    }

    /**
     * Shows or hides every map layer (and optional legend) belonging to [code], including composite children.
     *
     * @param code Weather product to affect.
     * @param visible `true` to show and request tiles; `false` to hide and detach legend if configured.
     */
    fun setWeatherLayerVisibility(code: LayerCode, visible: Boolean) {
        // Check if the code corresponds to a composite layer. If so, then iterate through each of its layers and set the visibility.
        val config = LayerCode.getConfigurationForLayerCode(code, service)
        if (config is CompositeWeatherLayerConfiguration) {
            config.layers.forEach { setWeatherLayerVisibility(it.code, visible) }
            trigger(MapControllerEvents.VISIBILITY_CHANGED, config.code)
            return

        }

        getWeatherLayer(code)?.let {
            if (visible) {
                it.show()
            } else {
                it.hide()
                if ((config is WeatherLayerConfiguration<*, *>)) {
                    config.legend?.let { it1 ->
                        legendControl?.removeLegend(it1.id)
                    }
                }
            }

            setLayerVisible(it.id, visible)

            if (this is MapboxMapController) {
                println(">>> MapController: setWeatherLayerVisibility() calling showOrHideLandMask()")
                this.showOrHideLandMask(it.id)
            }
            trigger(MapControllerEvents.VISIBILITY_CHANGED, it.id)
        }
    }

    /**
     * Removes the weather layer(s) for [code] from the map, sources, legends, and mask sidecars as needed.
     */
    fun removeWeatherLayer(code: LayerCode) {
        val config = LayerCode.getConfigurationForLayerCode(code, service)

        if (config is CompositeWeatherLayerConfiguration) {
            for (subConfig in config.layers) {
                removeLayer(subConfig.layer.id, true)
                layerIdsByWeatherCode[subConfig.code]?.let {
                    layerIdsByWeatherCode.remove(subConfig.code)
                }

                subConfig.legend?.let { it1 -> legendControl?.removeLegend(it1.id) }
            }
            trigger(MapControllerEvents.LAYER_REMOVED, config.layers.first().layer.id)
            return
        }

        layerIdsByWeatherCode[code]?.let {
            if (it.size == 0) return
            if (it.size > 1) {
                // TODO: print warning to console that multiple layers exist for the same layer code
                println("Warning: Multiple layers exist for the same layer code: $code")
                return
            }

            val layerId = it.first()
            removeLayer(layerId)
            layerIdsByWeatherCode.remove(code)

            //added to try to fix issue 17 crash
            layerHosts.remove(layerId)
            if (pr.ON) pr.p(TAG, pr.lHost, "removeWeatherlayer() $layerId removed")

            if ((config is WeatherLayerConfiguration<*, *>)) {
                val layerDescriptor = config.layer

                if (this is MapboxMapController) {
                    val maskKindToRelease = when (layerDescriptor) {
                        is SampleLayerDescriptor -> layerDescriptor.mask
                        is ContourLayerDescriptor -> layerDescriptor.mask
                        is ParticleLayerDescriptor -> layerDescriptor.mask
                        is GridLayerDescriptor -> layerDescriptor.mask
                        else -> MaskLayerKind.NONE
                    }
                    if (maskKindToRelease != MaskLayerKind.NONE) {
                        println(">>> MapController: removeWeatherLayer() showOrHideLandMask + removeMaskLayer($maskKindToRelease)")
                        this.showOrHideLandMask()
                        // Refcount was only ever incremented in addMaskLayer; without decrement the persistent
                        // mask style layer stayed in a bad state after hide — re-add did not show land mask until zoom.
                        MaskUtils.removeMaskLayer(maskKindToRelease, this)
                    }
                }

                config.legend?.let { it1 -> legendControl?.removeLegend(it1.id) }

            }
        }
    }

    private fun setPresentation(config: WeatherConfiguration, layer: TileLayer?) {
        if (layer != null && config is WeatherLayerConfiguration<*, *>) {
            if (config.presentation != null) {
                dataInspector.setPresentation(layer.id, config.presentation!!)
            }
        }
    }

    /**
     * Returns the map's container size.
     */
    override fun getSize(): Size {
        throw Error("Subclasses must override `getSize`")
    }

    /**
     * Returns the map's geographical center coordinate.
     */
    override fun getCenter(): Coordinate {
        throw Error("Subclasses must override `getCenter`")
    }

    /**
     * Sets the map's geographical center coordinate.
     *
     * @param center Latitude/longitude in degrees.
     */
    open fun setCenter(center: Coordinate) {
        throw Error("Subclasses must override `setCenter`")
    }

    /**
     * Visible geographic bounds in latitude/longitude (implementation wraps Mapbox camera).
     *
     * @return South/west/north/east extents used for tile selection and the data inspector.
     */
    override fun getBounds(): LatLonBounds {
        throw Error("Subclasses must override `getBounds`")
    }

    /**
     * Returns the map's current zoom level.
     */
    override fun getZoom(): Double {
        throw Error("Subclasses must override `getZoom`")
        return mapZoom
    }

    /**
     * Sets the map's zoom level.
     *
     * @param zoom Map zoom level understood by the host map SDK.
     */
    open fun setZoom(zoom: Double) {
        throw Error("Subclasses must override `setZoom`")
    }

    /**
     * Returns the map's current rotational bearing in degrees, if supported. A bearing of `0` orients the map so that
     * north is up.
     */
    override fun getBearing(): Double {
        throw Error("Subclasses must override `getBearing`")
    }

    /**
     * Returns the map's current pitch/tilt in degrees, if supported.
     */
    override fun getPitch(): Double {
        throw Error("Subclasses must override `getPitch`")
    }

    /**
     * Returns the map camera's current field-of-view in degrees.
     */
    override fun getFov(): Double {
        throw Error("Subclasses must override `getFov`")
    }

    //==============================================================================================================

    override fun onCreate(owner: LifecycleOwner) {
        // Start observing when the owner is created
        ImageTileSource.apiEvent.observe(owner, ::onRasterTileEvent)
    }

    private fun getScreenRefreshRate(context: Context): Float {
        if (Build.VERSION.SDK_INT >= 30)
            return context.display.refreshRate ?: 60f
        else return 60f
    }

    /**
     * Observes encoded-tile metadata keys; when a layer id is emitted, that [TileLayer] refreshes visible tiles.
     * Attach only if you extend encoded sources; normally the controller wires this internally.
     */
    val metadataObserver = Observer<String> { newValue ->
        controllerMainScope.launch {
            val layer = layers[newValue]
            if (layer != null) {
                (layer as TileLayer).requestVisibleTiles(getBounds(), true)
            }
        }
    }
    /** Library-internal: previous frame had pending tile downloads. */
    var wasWaitingOnDL = false
    /** Library-internal: at least one visible layer is waiting on tile data. */
    var waitingOnDL = false
    /** Library-internal: edge detection for post-download refresh. */
    var wasWaitCheck = false

    /** Requests a redraw of custom / GL layers on the next frame. */
    internal open fun redraw() {
        throw Error("Subclasses must override `redraw`")
    }

    /**
     * Sets a paint-related property on a layer (reserved for future Mapbox style parity; not fully implemented).
     *
     * @param layerId Target layer id.
     * @param property Key path of the paint field.
     * @param value New value to apply.
     */
    fun setPaintProperty(layerId: String, property: String, value: Any) {
        //TODO: implement
    }

    internal open fun updateCenterLatLngFromMap() {
        throw Error("Subclasses must override `updateCenterLatLngFromMap`")
    }

    /**
     * Hook for map SDK–specific registration of a custom layer host after MapsGL created the layer.
     *
     * @param layerID Layer id.
     * @param layerHost Mapbox [CustomLayerHost] implementation for that layer.
     */
    open fun add(layerID: String, layerHost: CustomLayerHost) {}

    /**
     * Toggles visibility of a MapsGL layer by id and triggers a redraw.
     *
     * @param id Layer id previously returned by [addLayer] / [addWeatherLayer].
     * @param visible `true` to draw and participate in tile requests; `false` to hide.
     */
    open fun setLayerVisible(id: String, visible: Boolean = true) {
        println(">>> MapController: setLayerVisible($id, $visible) entered")
        //if(pr.ON) pr.p(TAG, pr.ordering, "setLayerVisible() id:$id visible:$visible")

        mapZoom = getZoom()

        println(">>> MapController: setLayerVisible() before: visible:(${layers[id]?.visible}) ")


        if (layers[id]?.visible != visible) {
            layers[id]?.visible = visible
            redraw()
        }
        println(">>> MapController: setLayerVisible() after: visible:(${layers[id]?.visible}) ")

    }

    internal open fun addToMap(source: DataSource, onSourceAdded: () -> Unit) {}

    internal open fun addToMap(layer: MapLayer<*, *>, beforeId: String?) {
        if (pr.ON) pr.p(
            "MapController",
            pr.waaveRenderpath,
            ">> addToMap(source: DataSource, onSourceAdded: () -> Unit) {}  ENTERED"
        )
        layers[layer.id] = layer
        if (layer.paint is ParticleLayerPaint) {
            particleLayers[layer.id] = layer
        }
        layer.visible = true
        if (pr.ON) pr.p("MapController", pr.waaveRenderpath, ">> layer.onAdd(context, this controller)")
        layer.onAdd(mapView.context, this)
        controllerMainScope.launch {
            timeline.updateDataMeld(timeline.state == AnimationState.playing /*&& readyToPlay*/)
            refreshVisibleLayers()
            redraw()
        }
    }

    internal open fun removeFromMap(source: DataSource) {
    }

    internal open fun removeFromMap(layer: MapLayer<*, *>) {
        layer.visible = false
        particleLayers.remove(layer.id)
        layer.onRemove()
    }

    // ========================================================================================================

    /**
     * Returns whether the map currently contains a data source with the specified identifier.
     *
     * @param id Identifier of the data source to check for.
     * @return True if the map contains the data source, false otherwise.
     */
    fun hasSource(id: String): Boolean {
        return sources[id] != null
    }

    /**
     * @param id Layer id.
     * @return `true` if a layer with that id is registered.
     */
    fun hasLayer(id: String): Boolean {
        return layers[id] != null
    }

    /**
     * @param id Source id passed to [addSource].
     * @return The [DataSource] instance, or `null` if not registered.
     */
    fun getSource(id: String): DataSource? {
//        if (sources[id] == null) {
//            return sources.get("source")
//        }
        return sources[id]
    }

    /**
     * Every [EncodedGridVectorTileSource] in [sources], including GL-only gridded symbol sidecars that have no
     * [VectorTileLayer] consuming the Mapbox vector source.
     */
    protected fun forEachEncodedGridVectorTileSource(action: (EncodedGridVectorTileSource) -> Unit) {
        sources.values.filterIsInstance<EncodedGridVectorTileSource>().forEach(action)
    }

    private fun encodedGridVectorSidecarSourceId(parentLayerId: String): String =
        "${parentLayerId}__encodedGridVectors_argb_v2"

    /**
     * Instanced wind barbs/arrows register a sidecar [EncodedGridVectorTileSource] whose id is
     * [encodedGridVectorSidecarSourceId]. It must be removed when the parent tile layer goes away or the next add
     * would reuse a stale palette from [sources.getOrPut].
     */
    private fun removeEncodedGridSidecarForLayer(weatherLayerId: String) {
        val sidecarId = encodedGridVectorSidecarSourceId(weatherLayerId)
        getSource(sidecarId)?.let { sidecar ->
            sidecar.removeConsumer(weatherLayerId)
            sources.remove(sidecar.id)
            removeFromMap(sidecar)
            onSourceRemoved.send(sidecar.id)
        }
    }

    /**
     * True if any encoded-grid sidecar still drives Mapbox custom geometry during timeline meld
     * (vs. GPU-only instanced wind, which sets [EncodedGridVectorTileSource.timelineMeldInvalidatesMapboxTiles] false).
     */
    protected fun anyEncodedGridVectorUsesMapboxTimelineMeld(): Boolean =
        sources.values.filterIsInstance<EncodedGridVectorTileSource>().any { it.timelineMeldInvalidatesMapboxTiles }

    /**
     * @param id Layer id.
     * @return The [MapLayer] for that id, or `null`.
     */
    fun getLayer(id: String): MapLayer<*, *>? {
        return layers[id]
    }

    /**
     * Resolves [XweatherAuthenticator] for a new source: uses the descriptor value when set, otherwise
     * [service.authenticator] so URL templates (`{accessKey}`, etc.) and bearer auth work without app code wiring.
     */
    private fun authenticatorForSource(descriptorAuth: XweatherAuthenticator?): XweatherAuthenticator =
        descriptorAuth ?: service.authenticator

    /**
     * Registers a data source. When the descriptor leaves [ImageSourceDescriptor.authenticator] /
     * [EncodedSourceDescriptor.authenticator] / [VectorSourceDescriptor.authenticator] / [GeoJSONSourceDescriptor.authenticator]
     * unset, this controller supplies [service.authenticator] automatically.
     */
    fun addSource(descriptor: SourceDescriptor): DataSource {
        val id = descriptor.id
        sources[id]?.let { return it }

        val source: DataSource = when (descriptor) {
            is ImageSourceDescriptor -> {
                ImageTileSource(id, id, authenticatorForSource(descriptor.authenticator)).apply {
                    tileURL = descriptor.url
                    metadataURL = descriptor.metadataUrl
                    minZoom = descriptor.minZoom ?: 0f
                    maxZoom = descriptor.maxZoom ?: 21f
                    bounds = descriptor.bounds
                    tileSize = descriptor.tileSize ?: TileSize(256)
                }
            }

            is EncodedSourceDescriptor -> {
                val tileSource = sources.getOrPut(id) {
                    XweatherEncodedTileSource(id, authenticatorForSource(descriptor.authenticator)).apply {
                        tileURL = descriptor.url
                        metadataURL = descriptor.metadataUrl
                        minZoom = descriptor.minZoom ?: 0f
                        maxZoom = descriptor.maxZoom ?: 21f
                        bounds = descriptor.bounds
                        tileSize = descriptor.tileSize ?: TileSize(512, 512)
                        datasets = descriptor.datasets ?: emptyList()
                    }
                }
                tileSource
            }

            is VectorSourceDescriptor -> {
                if (pr.ON) pr.p("MapController", pr.adminLayers, "addSource() descriptor.id: ${descriptor.id}}")
                val tileSource = sources.getOrPut(id) {
                    VectorTileSource(id, authenticatorForSource(descriptor.authenticator)).apply {
                        tileURL = descriptor.url
                        metadataURL = descriptor.metadataUrl
                        minZoom = descriptor.minZoom ?: 0f
                        maxZoom = descriptor.maxZoom ?: 21f
                        bounds = descriptor.bounds
                        tileSize = descriptor.tileSize ?: TileSize(512, 512)
                    }
                }
                tileSource
            }

            is GeoJSONSourceDescriptor -> {
                val dataSource = sources.getOrPut(id) {
                    GeoJSONSource(id).apply {
                        url = descriptor.url
                        attribution = descriptor.attribution
                        authenticator = authenticatorForSource(descriptor.authenticator)
                    }
                }
                dataSource
            }

            else -> throw IllegalArgumentException("Unsupported source descriptor type: ${descriptor::class}")
        }

        source.timeRange = timeline.start..timeline.end
        sources[id] = source

        if (source is VectorTileSource || source is GeoJSONSource) {
            addToMap(source) {
                onSourceAdded.send(source.id)
            }
        } else {
            onSourceAdded.send(source.id)
        }

        return source
    }

    /**
     * Adds a new layer to the map.
     * @param descriptor Layer definition referencing an existing source id and paint.
     * @param beforeID Optional existing layer id to insert **below** in the stack; `null` appends on top.
     * @return The new [TileLayer], or `null` if the source is missing or the descriptor is unsupported.
     */
    fun <P : LayerPaint> addLayer(
        descriptor: LayerDescriptor<P>,
        beforeID: String?,
    ): TileLayer? {
        val source = getSource(descriptor.source) ?: return null
        //println(">>> MapController addLayer() about to create DataRenderer for ${descriptor.id}")

        val layer: TileLayer? = when {
            source is EncodedTileSource -> {
                when (descriptor) {
                    is SampleLayerDescriptor -> {
                        EncodedTileLayer(
                            descriptor.id,
                            source as TileSource<TileData>,
                            descriptor.paint,
                            EncodedDataRenderer<EncodedData, RenderContext<Any>>(descriptor.id),
                            zoomOffset,
                            viewModelScope,
                            descriptor.quality
                        )
                    }

                    is ContourLayerDescriptor -> {
                        EncodedTileLayer(
                            descriptor.id,
                            source as TileSource<TileData>,
                            descriptor.paint,
                            ContourRenderer(descriptor.id),
                            zoomOffset,
                            viewModelScope,
                            descriptor.quality
                        )
                    }

                    is ParticleLayerDescriptor -> {
                        EncodedTileLayer(
                            descriptor.id,
                            source as TileSource<TileData>,
                            descriptor.paint,
                            ParticleRenderer(descriptor.id),
                            zoomOffset,
                            viewModelScope,
                            descriptor.quality
                        )
                    }

                    is GridLayerDescriptor -> {
                        val renderer =
                            when {
                                isGlInstancedWindBarbs(descriptor) -> WindBarbInstancedRenderer(descriptor.id)
                                isGlInstancedWindArrows(descriptor) -> WindArrowInstancedRenderer(descriptor.id)
                                else -> EmptyRenderer(descriptor.id)
                            }
                        EncodedTileLayer(
                            descriptor.id,
                            source as TileSource<TileData>,
                            descriptor.paint,
                            renderer,
                            zoomOffset,
                            viewModelScope,
                            descriptor.quality
                        )
                    }

                    else -> null
                }?.also {
                    (source as XweatherEncodedTileSource).setObserver(metadataObserver, it.id)
                }
            }

            descriptor is RasterLayerDescriptor -> {
                ImageTileSource.setKey(account.id, account.secret)
                TileLayer(
                    descriptor.id,
                    source as TileSource<TileData>,
                    descriptor.paint as RasterLayerPaint,
                    RasterLayerRenderer(),
                    zoomOffset,
                    viewModelScope,
                    descriptor.quality
                )
            }

            descriptor is VectorLayerDescriptor<*> -> {
                VectorTileLayer(
                    descriptor.id,
                    source as TileSource<TileData>,
                    descriptor.paint as VectorLayerPaint,
                    RasterLayerRenderer(),
                    zoomOffset,
                    viewModelScope
                ).apply {
                    sourceLayer = descriptor.sourceLayer
                    filter = descriptor.filter
                }
            }

            descriptor is GridLayerDescriptor -> {
                EncodedTileLayer(
                    descriptor.id,
                    source as TileSource<TileData>,
                    descriptor.paint,
                    EmptyRenderer(descriptor.id), //ParticleRenderer(descriptor.id),
                    zoomOffset,
                    viewModelScope,
                    descriptor.quality
                )
            }

            else -> null
        }

        if (layer == null) return null

        layer.type = descriptor.type
        layer.animator?.let {
            animatorSync.add(layer)
            timeline.add(it.animation)
            layer.enabled = it.canShowForDate()
        }

        layers[layer.id] = layer
        layer.mapController = this
        if (pr.ON) pr.p("MapController", pr.waaveRenderpath, ">> addLayer() calling: addToMap(layer, beforeId)")
        addToMap(layer, beforeID)

        val sourceConsumer = DataSourceConsumer(layerId = layer.id)
        when (layer) {
            is VectorTileLayer -> {
                sourceConsumer.sourceLayerId = layer.sourceLayer
            }
        }
        layer.source.addConsumer(sourceConsumer)

        if (descriptor is GridLayerDescriptor && source is XweatherEncodedTileSource && layer is EncodedTileLayer) {
            if (isGlInstancedWindBarbs(descriptor) || isGlInstancedWindArrows(descriptor)) {
                addGriddedGridSourceForGlWindBarbs(
                    parentLayer = layer,
                    descriptor = descriptor,
                    encodedSource = source,
                )
            }
        }




        onLayerAdded.send(layer.id)
        return layer
    }

    private fun isGlInstancedWindBarbs(descriptor: GridLayerDescriptor): Boolean =
        descriptor.id == "conditions.wind_speed.symbol"

    private fun isGlInstancedWindArrows(descriptor: GridLayerDescriptor): Boolean =
        descriptor.id == "conditions.wind_speed.arrow" ||
                (descriptor.id.startsWith("maritime.") && descriptor.id.endsWith("_dir.fill"))

    /**
     * Wind barbs drawn as instanced GL quads in the custom layer pass (pitch-correct); no Mapbox vector symbol layer.
     * Still registers the [EncodedGridVectorTileSource] in [sources] for geometry/sampling and lifecycle cleanup.
     */
    private fun addGriddedGridSourceForGlWindBarbs(
        parentLayer: EncodedTileLayer,
        descriptor: GridLayerDescriptor,
        encodedSource: XweatherEncodedTileSource,
    ) {
        val vectorSourceId = encodedGridVectorSidecarSourceId(parentLayer.id)
        val maritimeDirWhite =
            descriptor.id.startsWith("maritime.") && descriptor.id.endsWith("_dir.fill")
        val displayDensity = mapView.resources.displayMetrics.density.let { if (it > 0f) it else 1f }
        val vectorSource = sources.getOrPut(vectorSourceId) {
            EncodedGridVectorTileSource(
                id = vectorSourceId,
                encodedSource = encodedSource,
                gridSpacing = descriptor.paint.grid.spacing,
                iconEncodedColorScale = descriptor.paint.sample?.colorScale,
                iconEncodedScalarMax = descriptor.paint.sample?.encodedScalarNormMax,
                timelineMeldInvalidatesMapboxTiles = false,
                instancedQuadMonochromeWhite = maritimeDirWhite,
            )
        } as EncodedGridVectorTileSource

        vectorSource.syncGridSpacingFromPaint(descriptor.paint.grid.spacing, displayDensity)

        // Sidecar source may be reused from a prior add (see [removeEncodedGridSidecarForLayer]); always sync palette.
        vectorSource.applyIconColorOptions(
            descriptor.paint.sample?.colorScale,
            descriptor.paint.sample?.encodedScalarNormMax,
        )

        vectorSource.timeRange = timeline.start..timeline.end
        vectorSource.validTime = parseDateArrayFromString(timeStrings[Timeline.currentPhaseA]).first()
        //griddedOverlaySourceByParent[parentLayer.id] = vectorSourceId
        vectorSource.addConsumer(DataSourceConsumer(layerId = parentLayer.id))
        when (val r = parentLayer.tileLayerRenderer) {
            is GridLayerRenderer -> r.attachGridSource(vectorSource)
            else -> return
        }
    }

    /**
     * Reorders an existing layer in the host map style.
     *
     * @param id Layer to move.
     * @param beforeId Layer id to insert before, or `null` to move to the top.
     */
    open fun moveLayer(id: String, beforeId: String?) {}

    /**
     * Unregisters a data source from this controller (does not remove layers that still reference it).
     *
     * @param id Source id.
     */
    fun removeSource(id: String) {
        getSource(id)?.let {
            sources.remove(it.id)
            onSourceRemoved.send(it.id)
        }
    }

    /**
     * Removes a layer by id, detaches consumers, and cleans encoded-grid sidecars when present.
     *
     * @param id Layer id.
     * @param isCompounLayer When removing a composite child, skips duplicate [MapControllerEvents.LAYER_REMOVED] emits.
     */
    fun removeLayer(id: String, isCompounLayer: Boolean = false) {
        removeEncodedGridSidecarForLayer(id)
        /*
        val hadGriddedVectorOverlay = griddedOverlayLayerByParent.containsKey(id)
        griddedOverlayLayerByParent.remove(id)?.let { overlayId ->
            getLayer(overlayId)?.let { overlay ->
                removeFromMap(overlay)
                layers.remove(overlay.id)
                overlay.source.removeConsumer(layerId = overlay.id)
                onLayerRemoved.send(overlay.id)
                overlay.mapController = null
            }
        }
        griddedOverlaySourceByParent.remove(id)?.let { sourceId ->
            val source = sources[sourceId]
            if (source is EncodedGridVectorTileSource) {
                if (!hadGriddedVectorOverlay) {
                    source.removeConsumer(id)
                }
                removeFromMap(source)
                sources.remove(source.id)
            }
        }
        */
        getLayer(id)?.let {
            removeFromMap(it)
            layers.remove(it.id)
            it.source.removeConsumer(layerId = it.id)
            onLayerRemoved.send(it.id)
            it.mapController = null

            if (!isCompounLayer) {
                trigger(MapControllerEvents.LAYER_REMOVED, it.id)
            }
        }
    }

    /**
     * Returns the list of layers that are rendered by MapsGL (not layers rendered by Mapbox).
     */
    internal fun getMapsGLRenderedLayers(): List<MapLayer<*, *>> {
        return layers.values.filter { it !is VectorTileLayer }
    }

    /**
     * After the camera stops, encoded tile layers need current [getBounds] on each [TileLayer] before we preflight,
     * otherwise [TileLayer.preflightEncodedDownloadPairCount] uses a stale viewport and [refreshVisibleLayers]
     * skips preflight once [addPendingEncodedDownload] runs — causing 100% then ~50% when the second request wave adds work.
     */
    private suspend fun establishEncodedDownloadSessionAfterCameraIdleIfNothingPending() {
        val playingOrPreload =
            timeline.state == AnimationState.playing ||
                    timeline.opts.shouldPreloadData ||
                    timeline.opts.forcePreloadOneTime
        if (!playingOrPreload) return
        if (Timeline.countPendingEncodedAll() != 0) return

        Timeline.resetEncodedDownloadProgressCounters()

        val mapBounds = getBounds()
        var sessionTotal = 0
        for (layer in getMapsGLRenderedLayers()) {
            if (layer.visible && layer is TileLayer) {
                val tl = layer as TileLayer
                tl.bounds = mapBounds
                if (tl.source.isEncoded) {
                    sessionTotal += tl.preflightEncodedDownloadPairCount()
                }
            }
        }
        Timeline.setEncodedSessionDownloadTarget(sessionTotal)
    }

    internal suspend fun onMoveEnd() {
        camera.moveState = Camera.STOPPED

        establishEncodedDownloadSessionAfterCameraIdleIfNothingPending()

        for (layer in getMapsGLRenderedLayers()) {
            if (layer.visible) {
                layer.onMoveEnd()
            }
        }

    }

    internal fun updateTiles(updateCamera: Boolean = false) {
        controllerMainScope.launch {
            if (updateCamera) {
            } else { //particles use this
                timeline.updateDataMeld(timeline.state == AnimationState.playing /*&& readyToPlay*/)
                // If we are already in the middle of tile downloads, avoid kicking off another wave
                // of visible-tile requests from repeated "paused" timeline updates.
                // This prevents the download queue from growing while waiting.
                refreshVisibleLayers(requestDL = !Timeline.isDownloading) //should this be moved outside of else?
            }
            redraw() //This causes render to happen
        }
    }

    internal suspend fun onMove(pauseParticles: Boolean = true, tag: String = "empty") {
        if (pauseParticles) camera.moveState = Camera.MOVING

        for (layer in getMapsGLRenderedLayers()) {
            if (layer.visible) {
                if (timeline.state != AnimationState.playing || !pauseParticles || Timeline.pausedForDownload) {
                    layer.onMove() // calls:  bounds = mapController?.getBounds()?: return AND requestVisibleTiles(bounds!!)
                }
            }
        }
    }

    /**
     * Recomputes visible tiles for every visible MapsGL layer and marks custom layer hosts dirty.
     *
     * @param requestDL When `true`, layers may enqueue HTTP/decodes for missing tiles; when `false`,
     * only binding / draw state is refreshed (e.g. after downloads complete).
     */
    suspend fun refreshVisibleLayers(requestDL: Boolean = true) { //called from updateTiles
        if (requestDL) {
            val playingOrPreload =
                timeline.state == AnimationState.playing ||
                        timeline.opts.shouldPreloadData ||
                        timeline.opts.forcePreloadOneTime
            if (playingOrPreload && Timeline.isEncodedDownloadSessionTargetUnset()) {
                var sessionTotal = 0
                for (layer in getMapsGLRenderedLayers()) {
                    if (layer.visible && layer is TileLayer) {
                        val tl = layer as TileLayer
                        if (tl.source.isEncoded) {
                            sessionTotal += tl.preflightEncodedDownloadPairCount()
                        }
                    }
                }
                Timeline.setEncodedSessionDownloadTarget(sessionTotal)
            }
        }
        for (layer in getMapsGLRenderedLayers()) {
            if (layer.visible) {
                if (requestDL) {
                    layer.update() // request download of visible tiles without updating camera
                }
                setLayerHostToUpdate(layer.id)
            }
        }
    }

    /**
     * Marks the custom layer host for [layerId] so textures/uniforms are uploaded on the next draw pass.
     */
    open fun setLayerHostToUpdate(layerId: String) {}

    /** This functionality needs to be moved to the timeline classes **/
    internal fun startAnimatingTimeline(playPressed: Boolean) {
        if (playPressed) {
            animatingTimeline = true
        } else {
            timeline.seekBarMoved = true
            // animatingTimeline = !animatingTimeline
        }

        if (animatingTimeline) {
            startCustomLayerUpdates()
        }
    }

    private suspend fun preloadVisibleTiles() {
        for (layer in getMapsGLRenderedLayers()) {
            if (layer.visible) {
                if (true) {

                    if (pr.ON) pr.p(TAG, pr.preload, "calling layer.onMove for ${layer.id}")
                    layer.onMove() // calls:  bounds = mapController?.getBounds()?: return AND requestVisibleTiles(bounds!!)
                }
            }
        }
    }

    internal fun startCustomLayerUpdates(isParticleLayer: Boolean = false) {
        if (!customLayerUpdatesHaveStarted || isParticleLayer) {
            customLayerUpdatesHaveStarted = true

            // This prevents doubling up on animations and also prevents timeline animation states from stopping particles.
            if (isParticleLayer) {
                if (frameCallback != null) {
                    choreographer.removeFrameCallback(frameCallback!!)
                }
                frameCallback = null // Clear the reference
            }

            frameCallback = object : Choreographer.FrameCallback {
                override fun doFrame(frameTimeNanos: Long) {
                    //if(pr.ON) pr.p(TAG, pr.animPart,"startCustomLayerUpdates() isParticleLayer? $isParticleLayer")
                    if (timeline.state == AnimationState.playing || timeline.seekBarMoved || isParticleLayer) {
                        //if(pr.ON) pr.p(TAG, pr.animPart,"startCustomLayerUpdates()  isParticleLayer? $isParticleLayer")
                        updateCustomLayer()
                    }
                    if (timeline.state == AnimationState.paused || timeline.state == AnimationState.loading) {
                    }
                    choreographer.postFrameCallback(this)
                }
            }
            choreographer.postFrameCallback(frameCallback!!)
        }
    }

    private fun updateCustomLayer() {
        // Choreographer.FrameCallback runs on the main looper; avoid coroutine allocation every frame during playback.
        if (timeline.state == AnimationState.playing || timeline.seekBarMoved) {
            timeline.seekBarMoved = false
            timeline.updateDataMeld(timeline.state == AnimationState.playing /*&& readyToPlay*/)
            redraw()
        } else if (particleLayers.values.any { it.visible }) {
            timeline.updateDataMeld(timeline.state == AnimationState.playing /*&& readyToPlay*/)
            redraw()
        }
    }

    private fun changeZoomOffset(change: Int) {
        zoomOffset += change
        for (layer in layers) {
            (layer.value as TileLayer).zoomOffset += change
        }
    }

    internal fun setupCamera(initial: Boolean = true) {
        if (pr.ON) pr.p(TAG, pr.rotS, " setupCamera($initial")
        val width = mapView.width.toFloat()
        val height = mapView.height.toFloat()
        densityMult = ((mapView.resources.displayMetrics.density / height) * 800)

        val nz = height * .02f;
        /** from Mapbox https://github.com/mapbox/mapbox-gl-js/blob/main/src/geo/transform.js#L93 **/
        val fov = atan(3f * .25f)
        val pitchAngle = Math.cos((Math.PI * .5) - getPitch())
        val nearZ = Math.max((nz * pitchAngle).toFloat(), nz)
        // Large far plane for map-scale world coordinates; cap avoids the worst float32 precision loss
        // from 1e21 while staying generous enough not to clip tile geometry after pitch/translation.
        val farZ = (nearZ * 1e6f).coerceIn(nearZ * 500f, 1e15f)
        val right = width * .5f
        val left = -right
        val top = height * .5f
        val bottom = -top

        if (type == PERSPECTIVECAMERA) {
            if (initial) {
                camera = Camera(
                    CameraType.Perspective,
                    fov = fov,
                    near = nearZ,
                    far = farZ,
                    bounds = RectF(left, top, right, bottom)
                )
            } else {
                camera.setup(
                    CameraType.Perspective,
                    fov = fov,
                    near = nearZ,
                    far = farZ,
                    bounds = RectF(left, top, right, bottom)
                )
            }

            camera.projectionMatrix = camera.projectionMatrix.perspective(
                Math.toDegrees(fov.toDouble()).toFloat(),
                width / height,
                nearZ,
                farZ
            )
        } else { //ORTHOCAMERA
            if (initial) {
                camera = Camera(
                    CameraType.Orthographic,
                    near = nearZ,
                    far = farZ,
                    fov = fov,
                    bounds = RectF(left, top, right, bottom)
                )
            } else {
                camera.setup(
                    CameraType.Orthographic,
                    near = nearZ,
                    far = farZ,
                    fov = fov,
                    bounds = RectF(left, top, right, bottom)
                )
            }
            camera.projectionMatrix = camera.projectionMatrix.orthographic(left, right, top, bottom, nearZ, farZ)
        }
        camera.resX = width.toInt()
        camera.resY = height.toInt()
        camera.aspect = width / height
    }

    private fun onRasterTileEvent(event: RasterTileApiEvent) {
        if (pr.ON) pr.p(TAG, pr.onMove, "onMoveNoMove() onRasterTileEvent ${event}")
        if (pr.ON) pr.p("MapboxMapController", pr.lag, "onRasterTileEvent")
        when (event) {
            is RasterTileApiEvent.Success -> {}
            is RasterTileApiEvent.Error -> DriverManager.println("$TAG event Error")
            is RasterTileApiEvent.Reload -> {
                //updateTiles(false)
                controllerMainScope.launch {
                    if (pr.ON) pr.p(TAG, pr.onMove, "calling onMoveNoMove() from event")
                    onMoveNoMove(false, tag = "from onRasterTileEvent")
                }
            }
        }
    }

    internal open fun setupEvents() {}

    /**
     * Adds a new weather layer to the map.
     * @param layerCode - An enum of type LayerCode that indicates the desired layer.
     * @returns The newly added map layer
     */
    internal fun checkDownloadStatus(layerID: String, pendingTileNum: Int) {
        val currentLayer = layers[layerID]

        if (currentLayer != null) {
            if (pendingTileNum != 0) {
                if (pr.ON) pr.p(TAG, pr.threadDL, "checkDLStatus() pendingTile: $pendingTileNum")
            }

            val tAnimation = currentLayer.animator!!.animation
            tAnimation.pendingCount = pendingTileNum
            if (pendingTileNum != tAnimation.lastPendingCount) { //change in status
                if (pendingTileNum == 0) {
                    //if(pr.ON) pr.p(TAG, pr.requestTracker,"checkDownloadStatus()  ${currentLayer.id} is done with downloads!")
                } else if (tAnimation.lastPendingCount == 0) {
                    if (pr.ON) pr.p(TAG, pr.threadDL, "checkDLStatus() detected DL start: $pendingTileNum")
                    //if(pr.ON) pr.p(TAG, pr.requestTracker,"checkDownloadStatus()  ${currentLayer.id} is starting to download!")
                    //timeline.setIsDownloading(true)
                    //triggerLoadStart()
                }
            }
            tAnimation.lastPendingCount = tAnimation.pendingCount
        }

        waitingOnDL = false
        var waitCheck = false

        for (layer in layers.values) {
            if (layer.visible && layer.animator!!.animation.pendingCount != 0) {
                //println("GL1 found PendingDL: ${layer.value.id} has ${layer.value.animator!!.animation.pendingCount}")
                layer.waitingOnDL = true
                waitCheck = true
                //waitingOnDL = true
            }
        }

        if (waitCheck/*waitingOnDL*/) { // if you are waiting on DL and the timeline doesn't know it yet, trigger
            if (!Timeline.isDownloading) {
                Timeline.isDownloading = true
                downloadsStarted()
            }
        } else { // If not waiting on DL, and timeline still thinks it is dl, dl is done.
            if (Timeline.isDownloading) {
                Timeline.isDownloading = false
                downloadsDone()
            }
        }

        if (waitCheck != wasWaitCheck) { // If you are newly not waiting, make sure to updateTiles() (bind)
            if (pr.ON) pr.p(TAG, pr.blankNonAnim, "checkDownloadStatus()  waitingOnDL: $waitingOnDL")
            if (!waitCheck) {
                //updateTiles(false)
                controllerMainScope.launch {
                    timeline.updateDataMeld(timeline.state == AnimationState.playing /*&& readyToPlay*/)
                    // Downloads just finished; don't kick off another wave of tile requests.
                    // Only set layer hosts so already-downloaded textures can be bound/rendered.
                    refreshVisibleLayers(requestDL = false)
                    // Defer the redraw to the next frame to avoid stalling the current one
                    // right when downloads complete and layers start binding textures.
                    choreographer.postFrameCallback {
                        redraw()
                    }
                }
            }
        }

        if (true /*!waitingOnDL*/) {
            //timeline.setIsDownloading(false)
            //triggerLoadComplete()
            readyToPlay = true
        }

        wasWaitingOnDL = waitingOnDL

        wasWaitCheck = waitCheck
    }

    private fun downloadsStarted() {
        if (pr.ON) pr.p(
            TAG,
            pr.threadDL,
            "downloadsStarted() isPlaying: ${timeline.state == AnimationState.playing} --------------------------------"
        )
        // Do not pause the global timeline.
        // RenderPass draw-time gating handles incomplete layer intervals without freezing playback.
    }

    private fun downloadsDone() {
        if (pr.ON) pr.p(TAG, pr.autoPlay, "downloadsDone() Timeline.pausedForDownload: $${Timeline.pausedForDownload}")
        if (Timeline.pausedForDownload) {
            Timeline.pausedForDownload = false
            if (pr.ON) pr.p(TAG, pr.autoPlay, "downloadsDone() NOW GOING TO TIMELINE.PLAY() ")
            timeline.play(startImmediately = true)
        }
    }

    /** Get information from Encoded Tile Layers**/
    internal fun query(point: Point, layerList: List<TileLayer>, onTouch: Boolean = true): DataInspectorResult {
        var i = 0

        if (pr.ON) pr.p(TAG, pr.dIAnimation, "<< MapController query(): onTouch: $onTouch")

        val result: DataInspectorResult = if (onTouch) {
            dataInspector.dIResult
        } else {
            dataInspector.queryResult
        }

        result.clearEncoded()
        var fnVal: String
        for (layer in layerList) {
            // Match [TileLayer.getTileBounds]: tile Z = floor(renderZoom + layer.zoomOffset). Render path
            // prefers [CustomLayerRenderParameters.zoom] when the custom layer is drawing.
            val zoomBase = CameraSync.customLayerRenderZoom ?: camera.zoom
            val zoomVar = floor(zoomBase + layer.zoomOffset).toInt().coerceAtLeast(0)
            val latTile = TileConversions.latToTile(point.latitude(), zoomVar)
            val lonTile = TileConversions.lonToTileNormalized(point.longitude(), zoomVar)
            val latPix = TileConversions.getLatPixelInTile(point.latitude(), zoomVar, 512).toInt()
            val lonPix = TileConversions.getLonPixelInTile(point.longitude(), zoomVar, 512).toInt()
            val returnVal =
                layer.queryFeatures(
                    zoomVar,
                    latTile,
                    lonTile,
                    latPix,
                    lonPix,
                    point.longitude(),
                    point.latitude(),
                )

            if (pr.ON) pr.p(
                TAG,
                pr.dIAnimation,
                "<< MapController query(): z:$zoomVar, lat: $latTile, lonT: $lonTile, lapPix:$latPix, lonPix: $lonPix   "
            )
            if (pr.ON) pr.p(TAG, pr.dIAnimation, "<< MapController query():returnVal: $returnVal")

            if (returnVal != null) {

                val props = encodedQueriedFeatureProperties(returnVal, layer)

                result.queriedFeatures.add(
                    QueriedFeature(
                        null, layer.source.id, null,
                        props,
                        layer.id,
                    )
                )

                val presentation = dataInspector.presentationsByLayerId[layer.id]

                if (presentation != null) {
                    // Pass merged props (value, optional unit, timestamp) so formatters match MapsGL JS / iOS.
                    fnVal = presentation.fn(props)
                } else {
                    fnVal = ""
                }
                if (presentation != null) {
                    result.encodedTitles.add(presentation.title.toString())
                    result.encodedLayerIds.add(layer.id)
                }
                result.encodedValues.add(fnVal)
                result.encodedRawValues.add(returnVal)
                i++
            }
        }

        return result
    }


    /**
     * Queries encoded tile layers and Mapbox vector layers at [point] for the given layer ids.
     *
     * @param point Map click / inspect location in WGS84.
     * @param layerList Layer ids to include (encoded + vector as applicable).
     * @param onTouch When `true`, merges with the active data-inspector touch buffer.
     * @return Per-layer [FeatureQueryResult] entries suitable for UI callouts.
     */
    suspend fun query(
        point: Point,
        layerList: List<String>,
        onTouch: Boolean = false
    ): HashMap<String, FeatureQueryResult> {
        var returnVector: HashMap<String, FeatureQueryResult>? = null

        if (pr.ON) pr.p(TAG, pr.queryNoInsp, "query() entered")

        if (this is MapboxMapController) {
            val vectorLayerList = getVectorLayersById(layerList)
            // Await the result directly, no need for an arbitrary delay
            returnVector = queryFeatures(point, vectorLayerList)
        }

        val result = query(point, getEncodedLayersById(layerList), onTouch)

        if (pr.ON) {
            pr.p("MapController", pr.query11, "<<  query(): encodedLayerIds: ${result?.encodedLayerIds}")
            pr.p("MapController", pr.query11, "<<  query(): encodedRawValues: ${result?.encodedTitles}")
            pr.p("MapController", pr.query11, "<<  query(): encodedRawValues: ${result?.encodedRawValues}")
            pr.p("MapController", pr.query11, "<<  query(): vectorTitles: ${result?.vectorLayerIds}")
            pr.p("MapController", pr.query11, "<<  query(): vectorTitles: ${result?.vectorTitles}")
            pr.p("MapController", pr.query11, "<<  query(): vectorValues: ${result?.vectorValues}|")
        }

        val returnHashMap = hashMapOf<String, FeatureQueryResult>()
        if (result != null) {
            for (item in result.encodedLayerIds) {
                val forLayer =
                    result.queriedFeatures.filter { it.mapLayerId == item }
                returnHashMap[item] = FeatureQueryResult(item, forLayer)
            }

        }

        if (returnVector != null) {
            returnHashMap.putAll(returnVector)
        }
        return returnHashMap

        /*
        return if (result != null) {
            result.toHashMap()
        } else hashMapOf()
        */
    }

    private fun getEncodedLayersById(layerIds: List<String>): List<EncodedTileLayer> {
        return layerIds.mapNotNull { id ->
            layers[id] as? EncodedTileLayer
        }
    }

    private fun getVectorLayersById(layerIds: List<String>): List<VectorTileLayer> {
        return layerIds.mapNotNull { id ->
            layers[id] as? VectorTileLayer
        }
    }

    /**
     * Mapbox map click: forwards to the data inspector when it is enabled.
     *
     * @return Always `false` so Mapbox may continue propagating the click.
     */
    override fun onMapClick(point: Point): Boolean {
        if (dataInspector.on) {
            dataInspector.showInternal(point)
        }

        return false
    }

    /**
     * Dispatches a named event to listeners registered with [on] for [type].
     *
     * @param type Event name (see [MapControllerEvents] for built-ins).
     * @param data Optional payload passed to each listener.
     */
    fun trigger(type: String, data: Any? = null) {
        listeners[type]?.let { eventListeners ->
            val listenersToTrigger = ArrayList(eventListeners)
            listenersToTrigger.forEach { listener ->
                try {
                    if (data != null) {
                        listener(data)
                    }

                } catch (e: Exception) {
                    println("Error in event listener for type '$type': ${e.message}")
                }
            }
        }
    }

    /**
     * Registers [callback] for controller-issued events named [name] (see [MapControllerEvents]).
     */
    override fun on(name: String, callback: (Any) -> Unit) {
        if (!listeners.containsKey(name)) {
            listeners[name] = mutableListOf()
        }
        listeners[name]?.add(callback)
    }

    /**
     * Removes a previously registered [callback] for [name].
     */
    override fun off(name: String, callback: (Any) -> Unit) {
        listeners[name]?.remove(callback)

    }

    internal class DataInspectorEvent {
        companion object {
            const val VECTOR_UPDATE = "VectorUpdate"
        }
    }

    private val legendControlCancellables = mutableListOf<Cancellable>()

    /**
     * Installs the provided legend control, wiring it to map events and populating initial legends.
     */
    fun add(legendControl: LegendControl?) {
        if (this.legendControl === legendControl) {
            legendControl?.getView()?.isVisible = true
            return
        }

        if (legendControl == null) {
            return
        }

        if (this.legendControl != null) {
            removeLegendControl()
        }

        this.legendControl = legendControl
        legendControl.setup(this.mapView)
        legendControl.getView().isVisible = true
        addLegends(forWeatherLayerCodes = layerIdsByWeatherCode.keys.toList())
        updateLegendsForMap()
    }

    /**
     * Removes the currently installed legend control and clears any associated observers.
     */

    fun removeLegendControl() {
        legendControlCancellables.forEach { it.cancel() }
        legendControlCancellables.clear()

        // 1. Get the view reference before nulling the control
        val viewToRemove = legendControl?.getView()

        // 2. Hide it
        viewToRemove?.isVisible = false

        // 3. CRITICAL: Detach it from whatever parent it currently has (MapView or outerConstraint)
        // (viewToRemove?.parent as? ViewGroup)?.removeView(viewToRemove)

        // 4. Null the reference
        this.legendControl = null
    }

    private fun addLegends(forWeatherLayerCodes: List<LayerCode>) {
        if (pr.ON) pr.p("MapController", pr.legend, "addLegends()")
        val control = legendControl ?: return
        for (layerCode in forWeatherLayerCodes) {
            val config = LayerCode.getConfigurationForLayerCode(layerCode, service) ?: continue

            if (config is CompositeWeatherLayerConfiguration) {
                val compositeLayerCodes = config.layers.map { it.code }
                addLegends(forWeatherLayerCodes = compositeLayerCodes)
                continue
            }

            if (config is WeatherLayerConfiguration<*, *>) {
                if (pr.ON) pr.p("MapController", pr.legend, "addLegends() calling addLegend for ${config.code}")
                addLegend(forConfig = config)
            }
        }
    }

    internal fun updateLegendsForMap() {
        controllerMainScope.launch {
            updateFeatureDrivenPointLegends()
        }
    }

    /**
     * Adds or refreshes the legend defined on [forConfig] into the current [legendControl].
     */
    fun addLegend(forConfig: WeatherLayerConfiguration<*, *>) {
        val legend = forConfig.legend ?: return
        val control = legendControl ?: return

        // For bar legends, update the color scale options to align with the layer's paint configuration
        control.add(legend)
        setupLegendEvents(forConfig)
        syncLegend(forConfig)
    }

    private suspend fun updateFeatureDrivenPointLegends() {
        val control = legendControl ?: return
        val legends = control.legends.values
        val pointLegends = legends
            .filterIsInstance<PointLegend>()
            .filter { it.layerId != null && it.itemResolver != null }

        for (pointLegend in pointLegends) {
            val layerIdRegex = pointLegend.layerIdRegex ?: continue
            val itemResolver = pointLegend.itemResolver ?: continue

            for (layerCode in layerIdsByWeatherCode.keys) {
                if (layerIdRegex.matches(layerCode.value)) {
                    val vectorLayer = getWeatherLayer(layerCode) as? VectorTileLayer ?: continue
                    val features = vectorLayer.getVisibleFeatures()

                    if (features != null) {
                        val flattenedFeatures: List<QueriedFeature> = features.values.flatMap { it.features }
                        val items = itemResolver.resolveGL(flattenedFeatures)
                        //control.update(pointLegend.items(items))
                        control.update(pointLegend.copy(items = items))
                    }
                }
            }
        }
    }

    /**
     * Sets up event listeners for a weather layer to ensure its legend stays in sync
     * with paint changes and data updates. Only works AFTER the layer has been added to the map.
     */
    private fun setupLegendEvents(config: WeatherLayerConfiguration<*, *>) {
        val layer = config.layer
        layer.on("PAINT_CHANGE") { data ->
            // Cast to our nested class
            val event = data as? LayerEvents.SamplePaintChangeEvent ?: return@on

            if (config.legend is BarLegend<*>) {
                // Check the property name we sent in the trigger
                if (event.property == "sample.colorscale") {
                    syncLegend(config)
                }
            }

            /*
            else if (legend is PointLegend && legend.layerId != null) {
                val sourceId = config.source.id
                // Find the source and listen for data changes to refresh visible features
                getSource(sourceId)?.on("DATA_CHANGE") {
                    updateLegendsForMap()
                }
            }
            */
        }
    }

    /**
     * Color ramp used by bar legends: [SampleLayerPaint], [GridLayerPaint.sample] (e.g. wind barbs), or contour sample paint.
     */
    private fun barLegendColorScaleFromPaint(paint: LayerPaint): ColorScaleOptions? {
        return when (paint) {
            is SampleLayerPaint -> paint.sample.colorScale
            is GridLayerPaint -> paint.sample?.colorScale
            is ContourLayerPaint -> paint.sample.colorScale
            else -> null
        }
    }

    /**
     * Bar legend tick span for encoded VECTOR wind: speed is non-negative, but [ColorScaleOptions.range]
     * must stay symmetric (dataset u/v range) for GPU decoding — see EXPRESSION_VECTOR in sample.frag.
     */
    private fun colorScaleForBarLegend(paint: LayerPaint, colorScale: ColorScaleOptions): ColorScaleOptions {
        val range = colorScale.range ?: return colorScale
        val isVector = when (paint) {
            is SampleLayerPaint -> paint.sample.expression == SampleExpression.VECTOR
            is ContourLayerPaint -> paint.sample.expression == SampleExpression.VECTOR
            is GridLayerPaint -> paint.sample?.expression == SampleExpression.VECTOR
            else -> false
        }
        return if (isVector && range.start < 0.0) {
            colorScale.copy(range = 0.0..range.endInclusive)
        } else {
            colorScale
        }
    }

    /**
     * Intersection of two numeric ranges for bar-legend color span.
     *
     * [syncLegend] replaces template [ColorScaleOptions.range] with paint. When paint uses a default
     * span (e.g. first stop..last stop over the whole `precip_accum` palette), the bar would sample
     * the entire ramp (purple/cyan) while ticks still show 1-hour rates. Intersecting with the
     * template range keeps presentation (hour precip) aligned with [LegendCode] until paint is
     * explicitly narrower.
     */
    private fun intersectClosedRanges(
        paintRange: ClosedRange<Double>?,
        templateRange: ClosedRange<Double>?,
    ): ClosedRange<Double>? {
        if (paintRange == null) return templateRange
        if (templateRange == null) return paintRange
        val start = maxOf(paintRange.start, templateRange.start)
        val end = minOf(paintRange.endInclusive, templateRange.endInclusive)
        return if (start <= end) start..end else null
    }

    /**
     * Helper to trigger a legend sync specifically for a configuration.
     */
    private fun syncLegend(config: WeatherLayerConfiguration<*, *>) {

        val control = legendControl ?: return
        val currentLegend = config.legend ?: return
        val currentScale = barLegendColorScaleFromPaint(config.layer.paint) ?: return
        val legendScale = colorScaleForBarLegend(config.layer.paint, currentScale)

        if (currentLegend !is BarLegend<*>) return

        @Suppress("UNCHECKED_CAST")
        val barLegend = currentLegend as BarLegend<Dimension>
        val multibandStops = colorStopBandsFromOptionsStops(legendScale.stops)
        val updatedLegend = barLegend.copy(
            items = barLegend.items.mapIndexed { index, item ->
                // Multiband radar paint uses one nested stops list; each legend bar is one band (rain / mix / snow).
                val paintAlignedScale =
                    if (multibandStops != null && multibandStops.isNotEmpty()) {
                        val bandIndex = index.coerceIn(0, multibandStops.lastIndex)
                        legendScale.copy(stops = multibandStops[bandIndex])
                    } else {
                        legendScale
                    }
                // Paint carries raster/sample ramp settings (stops, range, interval). Legend templates
                // may set presentation-only flags such as interpolate=false for a stepped bar; do not let
                // paint defaults (interpolate=true) wipe those.
                val mergedRange =
                    intersectClosedRanges(paintAlignedScale.range, item.colorScaleOptions.range)
                        ?: paintAlignedScale.range
                        ?: item.colorScaleOptions.range
                item.copy(
                    colorScaleOptions = paintAlignedScale.copy(
                        interpolate = item.colorScaleOptions.interpolate,
                        range = mergedRange,
                    ),
                )
            },
        )

        control.update(updatedLegend)
    }

    override fun onDestroy(owner: LifecycleOwner) {
        downloadTrackingHandler.removeCallbacks(downloadTrackingRunnable)
        controllerMainJob.cancel()
        super.onDestroy(owner)
    }

}
