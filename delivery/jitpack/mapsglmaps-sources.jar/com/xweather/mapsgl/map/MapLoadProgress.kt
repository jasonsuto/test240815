package com.xweather.mapsgl.map

import com.xweather.mapsgl.data.Queue

/**
 * Load progress for map data sources, exposed on [MapController.onLoadProgress].
 * Top-level type so host apps (including AAR consumers) resolve [total] / [completed]
 * reliably; internal queue state still uses [Queue.Progress].
 *
 * @property total Work units tracked (e.g. tile or request count) for the current operation.
 * @property completed Successfully finished units.
 * @property failed Units that ended in error.
 * @property cancelled Units aborted (e.g. superseded by a new request).
 */
data class MapLoadProgress(
    val total: Int,
    val completed: Int = 0,
    val failed: Int = 0,
    val cancelled: Int = 0,
) {
    companion object {
        val zero: MapLoadProgress = MapLoadProgress(total = 0)

        internal fun fromQueue(p: Queue.Progress): MapLoadProgress =
            MapLoadProgress(
                total = p.total,
                completed = p.completed,
                failed = p.failed,
                cancelled = p.cancelled,
            )
    }
}
