package com.xweather.mapsgl.map

import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.layers.tile.TileLayer
import java.util.Date

/**
 * Builds [QueriedFeature.properties] for encoded tile queries: flat keys (`value`, optional `angle`),
 * optional `unit` (e.g. `mm/s` for `conditions.precip.fill`), and `timestamp` (interpolated frame time),
 * aligned with MapsGL iOS / JS inspector inputs.
 */
internal fun encodedQueriedFeatureProperties(returnVal: Any, layer: TileLayer): Map<String, Any?> {
    val props = LinkedHashMap<String, Any?>()
    when (returnVal) {
        is Map<*, *> -> {
            for ((k, v) in returnVal) {
                val key = k as? String ?: continue
                props[key] = v
            }
        }
        else -> props["value"] = returnVal
    }
    encodedQueryUnitForLayerId(layer.id)?.let { props["unit"] = it }
    interpolatedSampleTimestampMillis(layer)?.let { props["timestamp"] = Date(it) }
    return props
}

/** Display units for common conditions layers (matches iOS inspector keys where applicable). */
private fun encodedQueryUnitForLayerId(layerId: String): String? =
    when {
        layerId.contains("pressure_msl") -> "mbar"
        layerId.contains("wind_gust") || layerId.contains("wind_speed") -> "m/s"
        layerId.contains("humidity") -> "%"
        layerId.contains("temperature") || layerId.contains("wind_chill") || layerId.contains("heat_index") ||
            layerId.contains("feels_like") || layerId.contains("dew") -> "°C"
        layerId.contains("visibility") || layerId.contains(".vis.") -> "m"
        // Matches iOS / JS data inspector: precip accumulation uses mm/s then ×3600 in the formatter.
        layerId.contains("precip") && !layerId.contains("precip_rate") -> "mm/s"
        else -> null
    }

private fun interpolatedSampleTimestampMillis(layer: TileLayer): Long? {
    val lt = Timeline.sourceTimeHash[layer.source.id] ?: return null
    val longA = lt.timeLongs.getOrNull(lt.currentA) ?: return null
    val longB = lt.timeLongs.getOrNull(lt.currentB) ?: return null
    val t = lt.meld.coerceIn(0f, 1f)
    // timeLongs are epoch seconds (see Timeline.generateHourlyIntervals / datesToStringsAndLongs).
    val seconds = (longA + (longB - longA) * t).toLong()
    return seconds * 1000L
}
