package com.xweather.mapsgl.map

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL
import kotlin.math.ceil
import kotlin.math.min

interface ImageRegisteringMap {
    fun addImage(id: String, image: Bitmap, sdf: Boolean)
}

data class SpriteImage(
    val x: Int,
    val y: Int,
    val width: Int,
    val height: Int,
    val pixelRatio: Double
)

class MapStyle {
    suspend fun loadSprite(id: String, jsonUrl: String, map: ImageRegisteringMap, dpr: Float = 1.0f) {
        val metadataUrl = jsonUrl.replace("{suffix}", "@${min(3.0, ceil(dpr.toDouble())).toInt()}x")
//        println("LOAD SPRITE: dpr=$dpr, url=$metadataUrl")
        val spriteUrl = metadataUrl.replace(".json", ".png")
        val imageData = withContext(Dispatchers.IO) {
            URL(spriteUrl).openStream().use { it.readBytes() }
        }
        val jsonData = withContext(Dispatchers.IO) {
            URL(metadataUrl).openStream().use { it.reader().readText() }
        }

        val image = BitmapFactory.decodeByteArray(imageData, 0, imageData.size)
            ?: throw Exception("Failed to decode sprite image")
        val meta = parseSpriteMeta(jsonData)

        for ((name, info) in meta) {
            val rect = Rect(info.x, info.y, info.x + info.width, info.y + info.height)
            val cropped = Bitmap.createBitmap(image, rect.left, rect.top, rect.width(), rect.height())
            var icon = cropped
            val isSDF = name.endsWith("-sdf")
            val imageKey = "$id:${name.removeSuffix("-sdf")}"

            if (isSDF) {
                icon = convertSDFToTransparent(icon)
            }

            map.addImage(imageKey, icon, isSDF)
        }
    }

    private fun parseSpriteMeta(json: String): Map<String, SpriteImage> {
        val jsonObject = JSONObject(json)
        val result = mutableMapOf<String, SpriteImage>()
        for (key in jsonObject.keys()) {
            val obj = jsonObject.getJSONObject(key)
            val image = SpriteImage(
                x = obj.getInt("x"),
                y = obj.getInt("y"),
                width = obj.getInt("width"),
                height = obj.getInt("height"),
                pixelRatio = obj.getDouble("pixelRatio")
            )
            result[key] = image
        }
        return result
    }

    private fun convertSDFToTransparent(bitmap: Bitmap): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint()

        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)

        for (i in pixels.indices) {
            val red = Color.red(pixels[i])
            val alpha = red
            pixels[i] = Color.argb(alpha, red, red, red)
        }

        output.setPixels(pixels, 0, width, 0, 0, width, height)
        return output
    }
}