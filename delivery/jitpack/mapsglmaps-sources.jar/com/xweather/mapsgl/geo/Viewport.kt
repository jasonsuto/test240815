package com.xweather.mapsgl.geo


import com.xweather.mapsgl.geo.Geo.TILE_SIZE
import com.xweather.mapsgl.geo.Geo.tileToUnit
import com.xweather.mapsgl.geo.Geo.unitToTile
import com.xweather.mapsgl.geo.Geo.zoomScale
import com.xweather.mapsgl.geo.projection.Mercator
import com.xweather.mapsgl.geometry.BoundsDouble
import com.xweather.mapsgl.gl.math.ProjectionMatrix
import com.xweather.mapsgl.tiles.GLCoordinate2D
import com.xweather.mapsgl.tiles.TileBounds
import com.xweather.mapsgl.types.MapProvider
import com.xweather.mapsgl.types.Point
import com.xweather.mapsgl.types.Size
import com.xweather.mapsgl.types.math_type.ValueRangeInt
import kotlin.math.pow
import com.xweather.mapsgl.geo.Geo.worldSize as calcWorldSize

fun isWithinRange(min: Double, max: Double, d: Double, value: Double): Boolean {
    // within range
    if (min <= value && value <= max) {
        return true
    }
    // if range is above value, calculate how many d's fit between value and min
    if (min > value) {
        val k = Math.ceil((min - value) / d)
        return value + k * d <= max
    }
    // if range is below value, calculate how many d's fit between max and value
    val k = Math.ceil((value - max) / d)
    return value - k * d >= min
}

/**
 * A Viewport is responsible for keeping track of the map center and size as well as providing projection information
 * and utilities. The viewport stores its center and size in normalized (GL unit) coordinates, where the full world is
 * represented by a size of (1, 1) and a center of (0.5, 0.5). The scale of the viewport is calculated based on the
 * map’s current zoom level.
 *
 * The viewport is also responsible for calculating the visible map bounds (either normalized or geographical
 * coordinates) and the visible tiles/tile bounds to be used for rendering layers.
 *
 * NOTE: Most of this is just a passthrough to the map provider which provides map state information. However, this
 * class will be solely responsible for map state was our first-party map and globe views are implemented in later
 * phases.
 */
class Viewport(private val map: MapProvider) {

    /**
     * The center of the viewport as a normalized plot coordinate in the range of `[0..1]` relative to the world size.
     */
    var centerCoordinate: GLCoordinate2D
    var zoomLevel = 0.0
    var viewportSize: Size
    var pitchRange: ValueRangeInt = ValueRangeInt(0, 60, "degree")
    val tileSize: Double = TILE_SIZE.toDouble()
    var projection: Projection = Mercator()
    lateinit var projectionMatrix: ProjectionMatrix

    init {
        this.centerCoordinate = GLCoordinate2D(0.5, 0.5)
        this.viewportSize = Size(1, 1);
        this.pitchRange = ValueRangeInt(0, 60, "degrees");
    }

    /**
     * Returns the normalized plot coordinate of the top-left corner of the viewport in the range of `[0..1]`.
     */
    val position: PlotCoordinate
        get() = PlotCoordinate(
            centerCoordinate.x - viewportSize.width / 2,
            centerCoordinate.y - viewportSize.height / 2,
            0.0
        )

    /**
     * Returns the zoom scale of the viewport based on the map's current zoom level.
     */
    val zoomScale: Double
        get() = zoomScale(map.getZoom().toFloat())

    /**
     * Returns the size of the world in pixels for the current zoom level.
     */
    val worldSize: Double
        get() = calcWorldSize((map.getZoom()).toFloat(), tileSize.toInt()).toDouble()

    /**
     * Returns the normalized plot coordinate of the viewport center in the range of `[0..1]`.
     */
    fun getCenter(): GLCoordinate2D {
        return this.centerCoordinate
    }

    /**
     * Returns the normalized plot coordinate of the viewport top-left offset in the range of `[0..1]`.
     */
    fun getCenterOffset(): PlotCoordinate {
        val center = getCenter()
        val size = getSize()
        return PlotCoordinate(
            center.x - size.width / 2,
            center.y - size.height / 2,
            0.0
        )
    }

    /**
     * Returns the normalized size of the viewport in the range of `[0..1]`.
     */
    fun getSize(): Size {
        return viewportSize
    }

    /** Returns the normalized visible bounds of the map in the range of `[0..1]`.   */
    private fun getBounds(): BoundsDouble {
        val center = getCenter()
        val size = getSize()

        return BoundsDouble(
            center.x - (size.width / 2.0),
            center.x + (size.width / 2.0),
            center.y - (size.height / 2.0),
            center.y + (size.height / 2.0)
        )
    }

    fun getBearing(): Double {
        return map.getBearing()
    }

    fun getPitch(): Double {
        return map.getPitch()
    }

    fun getFov(): Double {
        return map.getFov()
    }

    /**
     * Returns the visible tile bounds for a specific zoom level, handling world wrapping as needed. If no zoom level
     * is provided, the current map zoom level is used.
     */
    private fun getVisibleTileBounds(zoom: Double = map.getZoom(), wrap: Boolean = true, time: String): TileBounds {
        val adjustedZoom = Math.floor(zoom).toInt()
        val bounds = getBounds()
        val dim = zoomScale(adjustedZoom.toFloat()).toInt() //TODO: Figure out precision needed
        val min = 0
        val max = dim - 1
        val tl = unitToTile(Point(bounds.left, bounds.top), zoom.toInt(), time = time)
        val br = unitToTile(Point(bounds.right, bounds.bottom), zoom.toInt(), time = time)
        val tileBounds = TileBounds(adjustedZoom, tl.x, br.x, tl.y, br.y)
        val left = if (wrap) tileBounds.left else Math.max(min, tileBounds.left)
        val right = if (wrap) tileBounds.right else Math.min(max, tileBounds.right)
        val top = Math.max(min, tileBounds.top)
        val bottom = Math.min(max, tileBounds.bottom)

        return TileBounds(adjustedZoom, left, right, top, bottom)
    }
/*
    /**
     * Returns the top-left corner offset of the visible tile region as normalized units in the range of `0..1`. If
     * the horizontal bounds exceed the world size, the `x` offset may be greater than `1` or less than `0` to account
     * for world wrapping.
     */
    fun getVisibleTileOffset(): Point {
        val zoom = Math.floor(map.getZoom()).toInt()
        val bounds = getVisibleTileBounds()
        return tileToUnit(TileInfoItem(bounds.left, bounds.top, zoom))
    }
*/
    /**
     * Returns the size of the world in pixels for the current zoom level.
     */
    fun getPixelExtent(): Double {
        return worldSize
    }

    /**
     * Returns the center of the viewport in pixels relative to the world pixel extent with the top-left corner
     * being (0,0) and the +y axis pointing downwards.
     */
    fun getPixelCenter(): Point {
        val center = getCenter()
        val size = map.getSize()
        return Point(
            center.x * size.width,
            center.y * size.height
        )
    }

    /**
     * Return the center of the viewport in pixels relative to the world pixel extent.
     */
    fun getPixelCenterOffset(): Point {
        val center = getPixelCenter()
        val size = map.getSize()
        return Point(
            size.width / 2 - center.x,
            size.height / 2 - center.y
        )
    }
    /*
    /**
     * Returns the top-left position of the visible tile bounds in normalized plot coordinates.
     */
    fun getNormalizedOffset(): PlotCoordinate {
        val zoom = Math.floor(map.getZoom()).toInt()
        val bounds = getVisibleTileBounds()
        val (x, y) = tileToUnit(TileInfoItem(bounds.left, bounds.top, zoom))
        return PlotCoordinate(x, y, 0.0)
    }
*/
    private fun centerOn(pos: Point) {
        centerCoordinate.x = pos.x
        centerCoordinate.y = pos.y
    }

    private fun centerOnPlotCoordinate(pos: PlotCoordinate) {
        centerCoordinate.x = pos.x
        centerCoordinate.y = pos.y
    }

    fun zoomedTo(
        zoom: Double,
        targetZoom: Double,
        targetPos: PlotCoordinate,
        relative: Boolean = true
    ): Viewport {
        val scale = 2.0.pow(targetZoom - zoom)
        val viewport = Viewport(map)
        viewport.centerOn(
            Point(
                targetPos.x - ((targetPos.x - centerCoordinate.x) / scale),
                targetPos.y - ((targetPos.y - centerCoordinate.y) / scale)
            )
        )
        viewport.viewportSize = Size((viewportSize.width / scale).toInt(), (viewportSize.height / scale).toInt())
        if (!relative) {
            viewport.centerOnPlotCoordinate(targetPos)
        }
        return viewport
    }

    fun apply(source: Viewport) {
        centerCoordinate = source.centerCoordinate.copy()
        viewportSize = source.viewportSize.copy()
    }

    fun copy(): Viewport {
        val clone = Viewport(map)
        clone.centerCoordinate = centerCoordinate.copy()
        clone.viewportSize = viewportSize.copy()
        return clone
    }
}