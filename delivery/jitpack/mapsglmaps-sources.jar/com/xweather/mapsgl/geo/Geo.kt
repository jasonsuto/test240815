package com.xweather.mapsgl.geo

import android.graphics.PointF
import com.xweather.mapsgl.geo.projection.Mercator
import com.xweather.mapsgl.gl.math.PowerTable.Companion.powerTableD
import com.xweather.mapsgl.tiles.Tile

import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.types.Coordinate
import com.xweather.mapsgl.types.CoordinateBounds
import com.xweather.mapsgl.types.Point
import com.xweather.mapsgl.utils.BoundingCoords
import kotlin.math.floor
import kotlin.math.log2
import kotlin.math.pow

object Geo {

    const val EARTH_RADIUS = 6378000.0
    //const val EARTH_RADIUS = 6371008.8;
    const val EARTH_CIRCUMFERENCE = 2 * Math.PI * EARTH_RADIUS
    const val HALF_CIRCUMFERENCE = EARTH_CIRCUMFERENCE / 2
    const val MAX_MERCATOR_LATITUDE = 85.0511287798
    const val TILE_SIZE = 256
    const val A = 6378137
    const val MAX_EXTENT = 20037508.342789244;
    const val WORLD_SIZE = A * Math.PI * 2;
    const val PROJECTION_WORLD_SIZE = WORLD_SIZE / (A * Math.PI * 2);
    const val MIN_ZOOM_METERS_PER_PIXEL =
        EARTH_CIRCUMFERENCE / TILE_SIZE; // min zoom draws world as 2 tiles wide


    const val METERS_PER_LAT = 111320

    fun zoomScale(zoom: Int): Double = 2.0.pow(zoom.toDouble())

    fun zoomScale(zoom: Double): Double = 2.0.pow(zoom)
    fun scaleZoom(scale: Double): Double = log2(scale)
    fun worldSize(zoom: Int, tileSize: Int = TILE_SIZE): Int = tileSize * zoomScale(zoom).toInt()
    fun metersPerTile(zoom: Int): Double = EARTH_CIRCUMFERENCE / 2.0.pow(zoom.toDouble())
    fun tileScale(zoom: Int): Double = 1 / zoomScale(zoom)
    fun metersPerPixel(zoom: Int): Double = MIN_ZOOM_METERS_PER_PIXEL / zoomScale(zoom)
    fun metersPerPixel(zoom: Double): Double = MIN_ZOOM_METERS_PER_PIXEL / zoomScale(zoom)




    fun worldSize(zoom: Float, tileSize: Int = TILE_SIZE): Int {
        return (tileSize * zoomScale(zoom)).toInt()  //todo: Precision?
    }


    fun zoomScale(zoom: Float) = 2.0.pow(zoom.toDouble())

    // never used in webgl
//    fun scaleZoom(scale: Float) = ln(scale.toDouble()) / ln(2.0)

    fun clamp(number: Double, min: Double, max: Double) = when {
        number < min -> min
        number > max -> max
        else -> number
    }

    fun degToRad(value: Double) = value * Math.PI / 180.0

    /**
     * Converts a latitude/longitude coordinate to a mercator plot coordinate.
     *
     * @param coord
     * @returns
     */
    fun coordToUnit(coord: Coordinate) = PointF(
        Mercator.lonToMercatorX(coord.lon).toFloat(),
        Mercator.latToMercatorY(coord.lat).toFloat()
    )

    /**
     * Converts a mercator plot coordinate to a latitude/longitude coordinate.
     *
     * @param unit
     * @returns
     */
    fun unitToCoord(unit: Point) = Coordinate(
        Mercator.mercatorYToLat(unit.y.toDouble()),
        Mercator.mercatorXToLon(unit.x.toDouble())
    )

    /**
     * Convert tile location to Mercator meters - multiply by pixels per tile, then by meters per pixel,
     * adjust for map origin.
     *
     * @param x
     * @param y
     * @param z
     * @returns
     */
    fun tileToMeters(x: Int, y: Int, z: Int) = PointF(
        Math.pow(x * EARTH_CIRCUMFERENCE / 2, z - HALF_CIRCUMFERENCE).toFloat(),
        Math.pow(-y * EARTH_CIRCUMFERENCE / 2, z - HALF_CIRCUMFERENCE).toFloat()
    )

    /**
     * Converts a mercator plot coordinate and zoom to a tile coordinate.
     *
     * @param unit
     * @returns
     */
    fun unitToTile(unit: Point, zoom: Int, time: String): TileCoord {
        val coord = unitToCoord(unit);
        return coordToTile(coord, zoom, time = time)
    }
    /*
    /** @return a point with ranges from 0 to 1 */
    fun tileToUnit(tile: TileInfo): Point {
        val tileSpan = 1 / powerTableD[tile.z]
        val x = tileSpan * tile.x
        val y = tileSpan * tile.y
        return Point(x, y)
    }
    */
    /** @return a point with ranges from 0 to 1 */
    fun tileToUnit(tile: Tile<TileData>): Point {
        val tileSpan = 1 / powerTableD[tile.coord.z]
        val x = tileSpan * tile.coord.x
        val y = tileSpan * tile.coord.y
        return Point(x, y)
    }

    fun tileToUnit(tile: TileCoord): Point {
        val tileSpan = 1 / powerTableD[tile.z]
        val x = tileSpan * tile.x
        val y = tileSpan * tile.y
        return Point(x, y)
    }

    fun tileScale(zoom: Float) = 1 / zoomScale(zoom)

    fun tileToCoordBounds(x: Int, y: Int, z: Int): CoordinateBounds {
        val nw = tileToCoord(x, y, z)
        val se = tileToCoord(x + 1, y + 1, z)
        return CoordinateBounds(nw.lat, se.lat, nw.lon, se.lon)
    }

    /** @return a Coordinate with lat/long */
    fun tileToCoord(x: Int, y: Int, z: Int): Coordinate {
        val n = powerTableD[z]
        val lon_deg = x / n * 360.0 - 180.0
        val lat_rad = Math.atan(Math.sinh(Math.PI * (1 - 2 * y / n)))
        val lat_deg = lat_rad * 180.0 / Math.PI
        return Coordinate(lat_deg, lon_deg)
    }

    /**
     * Convert a latitude/longitude coordinate and zoom to a tile coordinate.
     *
     * @param coord
     * @param zoom
     * @returns
     */
    fun coordToTile(coord: Coordinate, zoom: Int, time: String): TileCoord {
        val latClamped = clamp(coord.lat, -MAX_MERCATOR_LATITUDE, MAX_MERCATOR_LATITUDE);
        val latRadians = degToRad(latClamped);

        // https://wiki.openstreetmap.org/wiki/Slippy_map_tilenames#Lon..2Flat._to_tile_numbers_2
        val n = powerTableD[zoom]
        val x = floor(((coord.lon + 180) / 360) * powerTableD[zoom])
        val y = ((1.0 - Math.log(Math.tan(latRadians) + (1 / Math.cos(latRadians))) / Math.PI) / 2.0 * n)

        //println("GEO, coord2Tile returning ${TileCoord(x.toInt(), y.toInt(), zoom)}")
        return TileCoord(x.toInt(), y.toInt(), zoom, time = time)
    }

    /**
     * Returns the bounds of the given tile
     * @return a Pair of Pair of Doubles, representing (minLon, minLat) , (maxLon, maxLat))
     */
    fun getTileBounds(zoom: Int, x: Int, y: Int): BoundingCoords {
        val n = powerTableD[zoom]
        val lonDegPerTile = 360.0 / n
        val latRad = Math.atan(Math.sinh(Math.PI * (1 - 2 * y / n)))
        val minLon = x * lonDegPerTile - 180.0
        val maxLon = (x + 1) * lonDegPerTile - 180.0
        val minLat = Math.toDegrees(Math.atan(Math.sinh(Math.PI * (1 - 2 * (y + 1) / n))))
        val maxLat = Math.toDegrees(latRad)

        return BoundingCoords(minLon, minLat, maxLon, maxLat)
    }

}


/*

//data class Point(val x: Double, val y: Double)
//data class Coordinate(val lat: Double, val lon: Double)
data class TileInfo(val x: Int, val y: Int, val z: Int)
data class CoordinateBounds(
    val north: Double,
    val south: Double,
    val west: Double,
    val east: Double
)

fun metersToCoord(meters: Point): Coordinate {
    val (x, y) = meters
    val lon = x * 180 / 20037508.34
    val lat = atan(exp(y * Math.PI / 20037508.34)) * 360 / Math.PI - 90
    return Coordinate(lat, lon)
}

fun metersToTile(x: Double, y: Double, z: Int): TileInfo {
    val tileX = ((x + HALF_CIRCUMFERENCE) / (EARTH_CIRCUMFERENCE / 2.0.pow(z.toDouble()))).toInt()
    val tileY = ((-y + HALF_CIRCUMFERENCE) / (EARTH_CIRCUMFERENCE / 2.0.pow(z.toDouble()))).toInt()
    return TileInfo(tileX, tileY, z)
}

fun tileToMeters(x: Int, y: Int, z: Int): Point {
    val metersX = x * EARTH_CIRCUMFERENCE / 2.0.pow(z.toDouble()) - HALF_CIRCUMFERENCE
    val metersY = -(y * EARTH_CIRCUMFERENCE / 2.0.pow(z.toDouble()) - HALF_CIRCUMFERENCE)
    return Point(metersX, metersY)
}

fun tileToCoord(tile: TileInfo): Coordinate {
    val (x, y, z) = tile
    val scale = 2.0.pow(z.toDouble())
    val lon = (x / scale) * 360 - 180
    val n = Math.PI - (2 * Math.PI * y) / scale
    val lat = (180 / Math.PI) * atan(0.5 * (exp(n) - exp(-n)))
    return Coordinate(lat, lon)
}

fun tileToCoordBounds(tile: TileInfo): CoordinateBounds {
    val nw = tileToCoord(TileInfo(tile.x, tile.y, tile.z))
    val se = tileToCoord(TileInfo(tile.x + 1, tile.y + 1, tile.z))
    return CoordinateBounds(nw.lat, se.lat, nw.lon, se.lon)
}

fun tileToUnit(tile: TileInfo): Point {
    val tileSpan = 1 / 2.0.pow(tile.z.toDouble())
    val x = tileSpan * tile.x
    val y = tileSpan * tile.y
    return Point(x, y)
}

fun coordToMeters(coord: Coordinate): Point {
    val (lat, lon) = coord
    val x = lon * 20037508.34 / 180
    var y = log(tan((90 + lat) * Math.PI / 360), 10.0) / (Math.PI / 180)
    y = y * 20037508.34 / 180
    return Point(x, y)
}

fun coordToLongitude(coord: Coordinate): Double {
    val x = coord.lon * 20037508.34 / 180
    //var y = log(tan((90 + lat) * Math.PI / 360),10.0) / (Math.PI / 180)
    //y = y * 20037508.34 / 180
    return x
}

fun coordToLat(coord: Coordinate): Double {
    //val (lat, lon) = coord
    //val x = lon * 20037508.34 / 180
    var y = log(tan((90 + coord.lat) * Math.PI / 360), 10.0) / (Math.PI / 180)
    y = y * 20037508.34 / 180
    return y
}


fun coordToTile(coord: Coordinate, zoom: Int): TileInfo {
    val (lat, lon) = coord
    val latClamped = clamp(lat, -MAX_MERCATOR_LATITUDE, MAX_MERCATOR_LATITUDE)
    val latRadians = Math.toRadians(latClamped)
    val x = ((lon + 180) / 360 * 2.0.pow(zoom.toDouble())).toInt()
    val y = ((1 - log(
        tan(latRadians) + 1 / cos(latRadians),
        10.0
    ) / Math.PI) / 2 * 2.0.pow(zoom.toDouble())).toInt()
    return TileInfo(x, y, zoom)
}

fun unitToTile(unit: Point, zoom: Int): TileInfo {
    val coord = unitToCoord(unit)
    return coordToTile(coord, zoom)
}

fun coordToUnit(coord: Coordinate): Point {
    val (lat, lon) = coord
    val x = lonToMercatorX(lon)
    val y = latToMercatorY(lat)
    return Point(x, y)
}

fun unitToCoord(unit: Point): Coordinate {
    val (x, y) = unit
    val lat = mercatorYToLat(y)
    val lon = mercatorXToLon(x)
    return Coordinate(lat, lon)
}

fun normalizeLon(lon: Double): Double = (lon % 360 + 360 + 180) % 360 - 180

fun inBounds(coord: Coordinate, bounds: CoordinateBounds, allowIntersect: Boolean = true): Boolean {
    if (allowIntersect) {
        return coord.lat <= bounds.north && coord.lat >= bounds.south && coord.lon >= bounds.west && coord.lon <= bounds.east
    }
    return coord.lat < bounds.north && coord.lat > bounds.south && coord.lon > bounds.west && coord.lon < bounds.east
}



* */
