package com.xweather.mapsgl.enums

class TileState {
    enum class Color(val value: Int) {
        Initial(0),
        Loading(1),
        Processing(2),
        Ready(3),
        Expired(4),
        Failed(5),
        UpsampledOnly(6);
    }
}
