package com.xweather.mapsgl.data

import java.util.Date
import kotlin.math.floor
import kotlin.math.roundToInt
import kotlin.math.max
import kotlin.math.min


enum class PixelInterpolation {
    NEAREST,
    BILINEAR
}

/**
 * Describes how to interpolate across two time intervals during a query.
 * Provide both the *current* and *next* interval tuple (index, date) and a
 * normalized `progress` in [0,1] indicating where to sample between them.
 */
data class GriddedQueryOptions(
    // var expression: SampleExpression = DefaultSampleExpression, // Assuming a default
    var interpolation: PixelInterpolation = PixelInterpolation.NEAREST,
    /** Interval `t0` to use for the query. */
    var current: Pair<Int, Date>? = null,
    /** Interval `t1` to use for the query. */
    var next: Pair<Int, Date>? = null,
    /** Blend factor between `t0` and `t1` intervals in [0,1]; 0 = current, 1 = next */
    var progress: Double = 0.0
)

/**
 * A 2D grid of decoded scalar values (e.g., from encoded raster tiles).
 *
 * Important: `points.count` **must equal** `width * height` (row‑major).
 * Note: If `noData` is set and a sampled value equals it *exactly*, the query treats that sample as missing.
 */
data class GriddedValueData(
    val width: Int,
    val height: Int,
    val points: List<GriddedPoint>,
    val noData: Double? = 9999.0 // Default value as in Swift
) {
    init {
        require(points.size == width * height) {
            "GriddedData points count (${points.size}) must equal width * height (${width * height})"
        }
    }

    data class GriddedPoint(
        val value: Double,
        val angle: Double? = null
    ) {
        fun interpolatedTo(other: GriddedPoint, t: Double): GriddedPoint {
            val interpolatedAngle: Double? = if (this.angle != null && other.angle != null) {
                this.angle + (other.angle - this.angle) * t
            } else {
                null // Or choose one if only one is present, or always null if one is missing
            }
            return GriddedPoint(
                value = this.value + (other.value - this.value) * t,
                angle = interpolatedAngle
            )
        }
    }

    /** Computes the row‑major linear index for integer pixel coordinates. */
    // Precondition: x ∈ [0,width) ∧ y ∈ [0,height)
    private fun idx(x: Int, y: Int): Int = y * width + x

    /**
     * Returns the scalar at integer pixel coordinates.
     * @return The value if in‑bounds and not equal to `noData`; otherwise `null`.
     */
    fun pointAt(x: Int, y: Int): GriddedPoint? {
        if (x < 0 || y < 0 || x >= width || y >= height) {
            return null
        }
        val p = points[idx(x, y)]
        if (noData != null && p.value == noData) {
            return null
        }
        return p
    }

    /**
     * Samples the grid at fractional pixel coordinates using the selected interpolation.
     *   - x: X in pixel space (0 … width‑1), fractional allowed.
     *   - y: Y in pixel space (0 … height‑1), fractional allowed.
     *   - interpolation: `.NEAREST` or `.BILINEAR`.
     * @return Interpolated value, or `null` when the targeted sample is outside the grid or resolves to `noData`.
     * Behavior:
     *   - `.NEAREST` rounds (x,y) to the closest integer pixel.
     *   - `.BILINEAR` blends the four neighbors; if any corner is OOB/NoData, falls back to `.NEAREST` at (x,y).
     */
    fun query(x: Double, y: Double, interpolation: PixelInterpolation): GriddedPoint? {
        return when (interpolation) {
            PixelInterpolation.NEAREST -> {
                val xi = x.roundToInt() // Kotlin's roundToInt
                val yi = y.roundToInt()
                pointAt(x = xi, y = yi)
            }
            PixelInterpolation.BILINEAR -> {
                val x0 = floor(x).toInt()
                val y0 = floor(y).toInt()
                val x1 = x0 + 1
                val y1 = y0 + 1

                // Clamp fractional components to [0,1]
                val tx = max(0.0, min(1.0, x - x0.toDouble()))
                val ty = max(0.0, min(1.0, y - y0.toDouble()))

                val v00 = pointAt(x = x0, y = y0)
                val v10 = pointAt(x = x1, y = y0)
                val v01 = pointAt(x = x0, y = y1)
                val v11 = pointAt(x = x1, y = y1)

                if (v00 == null || v10 == null || v01 == null || v11 == null) {
                    // If any corner is missing (NoData or OOB), fall back to nearest
                    val xi = x.roundToInt()
                    val yi = y.roundToInt()
                    return pointAt(x = xi, y = yi)
                }

                // Bilinear interpolation for 'value'
                // Angle interpolation is more complex and depends on requirements (e.g., shortest path for circular data)
                // The current Point.interpolatedTo only interpolates angle if both exist.
                // For simplicity in bilinear, the Swift version only returns the value, not the angle.
                // We will do the same for the value, and the angle could be handled by interpolating points.

                val a = v00.value * (1 - tx) + v10.value * tx
                val b = v01.value * (1 - tx) + v11.value * tx
                val interpolatedValue = a * (1 - ty) + b * ty

                // For angle, one approach could be to interpolate the points (which interpolates angles if both exist)
                // and then take the angle from the final interpolated point, or handle it based on specific needs.
                // The Swift code example does not seem to interpolate the angle during bilinear directly,
                // it just creates a new Point(value: r, angle: nil). We'll follow that.
                return GriddedPoint(value = interpolatedValue, angle = null)
            }
        }
    }
}