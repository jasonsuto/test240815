package com.xweather.mapsgl.data

import com.xweather.mapsgl.anim.EventDispatcher
import com.xweather.mapsgl.events.Event
import com.xweather.mapsgl.events.TimeSeriesEvent
import kotlinx.coroutines.*
import java.util.concurrent.ConcurrentLinkedQueue

typealias Task<T> = suspend () -> T

data class QueueEventData(
    val queue: Queue<*>,
    val index: Int,
    val task: Task<*>,
    val result: Any?,
    val error: Throwable?
)

class QueueEvent(name: String, data: QueueEventData? = null) : Event

//open class Event(val name: String, val data: Any? = null)
/*
open class EventDispatcher {
    val eventFlow = MutableSharedFlow<Event>()

    fun trigger(event: Event) {
        eventFlow.tryEmit(event)
    }
}*/

class Queue<T>(options: QueueOptions = QueueOptionsImpl()) : EventDispatcher() {
    data class Progress(
        val total: Int,
        val completed: Int = 0,
        val failed: Int = 0,
        val cancelled: Int = 0
    ) {
        companion object {
            val zero: Progress = Progress(total = 0)
        }
    }

    private val tasks = ConcurrentLinkedQueue<Task<T>>()
    private val concurrency = options.concurrency
    private val autostart = options.autostart
    private var running = false
    private var pending = 0
    private var index = -1

    val length: Int get() = tasks.size
    val isRunning: Boolean get() = running
    val currentIndex: Int get() = index
    val currentTask: Task<T>? get() = tasks.elementAtOrNull(index)
    val last: Task<T>? get() = tasks.last() // todo: maybe tasks.peek would be better?

    fun enqueue(vararg tasks: Task<T>): Queue<T> {
        this.tasks.addAll(tasks.toList())
        if (autostart) start()
        return this
    }
    /*
    fun dequeue(arg: Any?): Task<T>? = when (arg) {
        is Int -> dequeueByIndex(arg)
        is Task<*> -> dequeueByTask(arg as Task<T>)
        else -> dequeueByIndex(tasks.size -1) // Default: remove last if arg is not specified
    }
    */
    fun peek(): Task<T>? = tasks.peek()

    fun start() {
        if (running) return
        run()
    }

    fun pause() = stop()
    fun resume() = start()
    fun stop() { running = false }


    fun cancel() {
        val wasRunning = running
        clear()
        if (wasRunning) trigger(QueueEvent("cancel"))
    }

    fun clear() {
        stop()
        pending = 0
        index = -1
        tasks.clear()
    }


    /*
    private fun dequeueByIndex(index: Int): Task<T>? = tasks.removeAt(index)

    private fun dequeueByTask(task: Task<T>): Task<T>? {
        val index = tasks.indexOf(task)
        return if (index != -1) dequeueByIndex(index) else null
    }*/

    private fun run() = CoroutineScope(Dispatchers.Default).launch {
        val triggerStartEvent = !running
        running = true
        if (pending >= concurrency) return@launch

        if (tasks.isEmpty()) {
            if (pending == 0) done()
            return@launch
        }

        if (triggerStartEvent) trigger(QueueEvent("start"))

        val task = tasks.poll() ?: return@launch

        try {
            val result = withContext(Dispatchers.IO) { task() }
            trigger(QueueEvent("task:complete", QueueEventData(this@Queue, index, task, result, null)))
        } catch (e: Throwable) {
            trigger(QueueEvent("error", QueueEventData(this@Queue, index, task, null, e)))
        } finally {
            pending--
            if (pending == 0 && tasks.isEmpty()) done()
            //else if (running) run() //fixme: this can lead to an endless loop?
        }
    }

    private fun done() {
        if (!running) return
        running = false
        trigger(QueueEvent("complete"))
    }

    private val listeners = mutableMapOf<TimeSeriesEvent, MutableList<(Event) -> Unit>>()


}

//data class QueueOptionsImpl(override val concurrency: Int = Int.MAX_VALUE, override val autostart: Boolean = false) : QueueOptions