package com.xweather.mapsgl.data
import com.xweather.mapsgl.sources.data.EncodedTimeSeriesData
import com.xweather.mapsgl.sources.data.evaluate
import com.xweather.mapsgl.types.ColorBand
import com.xweather.mapsgl.types.SampleChannel
import com.xweather.mapsgl.types.SampleExpression
import kotlinx.coroutines.*
import java.nio.ByteBuffer
import java.util.Date // Or java.time.Instant

// Assume these interfaces/classes are defined elsewhere in your Kotlin project:
// interface EncodedTimeSeriesData {
//    val series: TimeSeries<BitmapContainer?> // BitmapContainer holds image info and pixel data
// }
// interface TimeSeries<T> {
//    suspend fun snapshot(): List<TimePoint<T>>
// }
// data class TimePoint<T>(val timestamp: Date, val value: T)
//
// data class BitmapContainer( // Example structure
//    val imageWidth: Int,
//    val imageHeight: Int,
//    val imageRowBytes: Int,
//    val pixelBuffer: ByteBuffer // Or ByteArray that will be wrapped
// )
//
// enum class SampleChannel {
//    RED, GREEN, BLUE, ALPHA;
//    val colorBands: List<Int> get() = when (this) {
//        RED -> listOf(0)
//        GREEN -> listOf(1)
//        BLUE -> listOf(2)
//        ALPHA -> listOf(3)
//        // Define others if needed, or if a channel can represent multiple (e.g. RGB)
//    }
// }
//
// interface SampleExpression {
//    fun evaluate(pixel: IntArray, channels: List<Int>, mappingRange: ClosedFloatingPointRange<Double>): Double?
// }
//
// data class GriddedTimeSeriesValueData(val grids: Map<Date, GriddedValueData>) {
//    fun query(x: Double, y: Double, options: GriddedQueryOptions): GriddedValueData.Point? { /* ... */ }
// }
//
// data class GriddedValueData(val width: Int, val height: Int, val points: List<Point>, val noData: Double? = null) {
//    data class Point(val value: Double, val angle: Double? = null)
// }
//
// data class GriddedQueryOptions(
//    // val expression: SampleExpression = SomeDefaultExpression,
//    val interpolation: PixelInterpolation = PixelInterpolation.NEAREST,
//    var current: Pair<Int, Date>? = null,
//    var next: Pair<Int, Date>? = null,
//    var progress: Double = 0.0
// )
// enum class PixelInterpolation { NEAREST, BILINEAR }


/**
 * Encapsulates creation and incremental updates of time-series gridded values
 * derived from encoded bitmap tiles (one grid per timestamp). Holds the
 * resulting `GriddedTimeSeriesValueData` and forwards query requests to it.
 */
class GriddedDataFeature private constructor(
    var data: GriddedTimeSeriesValueData
) {

    /**
     * A minimal decode unit: timestamped image metadata and its backing bytes.
     * `pixelData` should contain the raw pixel buffer (e.g., RGBA or ARGB).
     */
    data class Item(
        val timestamp: Date,
        val imageWidth: Int,
        val imageHeight: Int,
        val imageRowBytes: Int, // Bytes per row
        val pixelData: ByteBuffer // Raw pixel data
    )




    companion object {


        /**
         * Builds a feature by extracting timestamped bitmap data from an
         * `EncodedTimeSeriesData` payload and decoding them into grids.
         */
        suspend fun create(
            data: EncodedTimeSeriesData,
            channel: ColorBand,
            expression: SampleExpression,
            dataRange: ClosedFloatingPointRange<Double> // Kotlin's range type
        ): GriddedDataFeature {

           TODO("Incomplete function ")

            /*
            val points = data.series.snapshot()
            val items: List<Item> = points.mapNotNull { timePoint ->
                val container = timePoint.value ?: return@mapNotNull null

                // Assuming BitmapContainer has width, height, rowBytes, and pixelBuffer
                // You'll need to adapt this based on your actual BitmapContainer structure

                /*
                Item(
                    timestamp = timePoint.timestamp,
                    imageWidth = container.imageWidth,
                    imageHeight = container.imageHeight,
                    imageRowBytes = container.imageRowBytes,
                    pixelData = container.pixelBuffer.duplicate().rewind() // Use a duplicate to avoid issues if buffer is shared/reused
                )
                */
            }//.sortedBy { it.timestamp }

            return create(items, channel, expression, dataRange)
        }

        /**
         * Builds a feature from pre-assembled decode items. Useful for tests or
         * alternate pipelines that already produced `(timestamp, image info, bytes)`.
         */
        suspend fun create(
            items: List<Item>,
            channel: SampleChannel,
            expression: SampleExpression,
            dataRange: ClosedFloatingPointRange<Double>
        ): GriddedDataFeature {
            val pairs = decode(items, channel, expression, dataRange)
            val grids: MutableMap<Date, GriddedValueData> = HashMap(pairs.size) // Set initial capacity
            for ((timestamp, grid) in pairs) {
                grids[timestamp] = grid
            }
            return GriddedDataFeature(GriddedTimeSeriesValueData(grids))

             */
        }





        /**
         * Decodes each bitmap item into a `GriddedValueData` using coroutines for concurrency.
         * Respects row padding (`bytesPerRow`) and uses the provided expression
         * for mapping pixel values from the selected channel(s) to the `dataRange`.
         */
        private suspend fun decode(
            items: List<Item>,
            channel: SampleChannel,
            expression: SampleExpression,
            dataRange: ClosedFloatingPointRange<Double>
        ): List<Pair<Date, GriddedValueData>> = coroutineScope {
            val deferredGrids = items.map { item ->
                async(Dispatchers.Default) { // Perform decoding on a background thread
                    val width = item.imageWidth
                    val height = item.imageHeight
                    // Bytes per pixel - Assuming 4 (e.g., RGBA or ARGB)
                    // This should be consistent with how imageRowBytes is calculated and how pixelData is structured.
                    val bytesPerPixel = 4
                    val bytesPerRow = item.imageRowBytes

                    val gridPoints = ArrayList<GriddedValueData.GriddedPoint>(width * height)
                    val pixelBuffer = item.pixelData.asReadOnlyBuffer() // Work with a read-only view
                    pixelBuffer.rewind() // Ensure we start reading from the beginning

                    //val pixelComponents = IntArray(4) // Reusable array for [r,g,b,a] or [a,r,g,b]
                    val pixelComponents = ByteArray(4) // Reusable array for [r,g,b,a] or [a,r,g,b]

                    for (y in 0 until height) {
                        val rowOffset = y * bytesPerRow
                        for (x in 0 until width) {
                            val pixelOffset = rowOffset + x * bytesPerPixel

                            if (pixelOffset + (bytesPerPixel -1) < pixelBuffer.limit()) {
                                // IMPORTANT: The order of get() calls (and thus what r,g,b,a mean)
                                // depends on the format of your ByteBuffer (e.g., RGBA or ARGB).
                                // The Swift code implies RGBA: pixels[o+0]=r, pixels[o+1]=g, ...
                                // If your ByteBuffer is ARGB (common with Android Bitmaps):
                                // val a = pixelBuffer.get(pixelOffset + 0).toInt() and 0xFF
                                // val r = pixelBuffer.get(pixelOffset + 1).toInt() and 0xFF
                                // val g = pixelBuffer.get(pixelOffset + 2).toInt() and 0xFF
                                // val b = pixelBuffer.get(pixelOffset + 3).toInt() and 0xFF
                                // For this example, I'll match the Swift RGBA assumption:
                                pixelComponents[0] = pixelBuffer.get(pixelOffset + 0)//.toInt() and 0xFF // R
                                pixelComponents[1] = pixelBuffer.get(pixelOffset + 1)//.toInt() and 0xFF // G
                                pixelComponents[2] = pixelBuffer.get(pixelOffset + 2)//.toInt() and 0xFF // B
                                pixelComponents[3] = pixelBuffer.get(pixelOffset + 3)//.toInt() and 0xFF // A

                                val mappedValue = expression.evaluate(
                                    pixelComponents,
                                    channels = channel.colorBands,
                                    mappingRange = dataRange
                                )
                                // Default to 0.0 if mappedValue is null, as in Swift
                                val point = GriddedValueData.GriddedPoint(value = mappedValue ?: 0.0, angle = null)
                                gridPoints.add(point)
                            } else {
                                // Handle pixel out of bounds: add a NoData point or skip
                                // For consistency with a full grid, you might add a point with a NoData value
                                // if your GriddedValueData supports it, or a default like 0.0.
                                // Or, if the grid size must be exact, this indicates an error.
                                // Log.e("DecodeError", "Pixel offset out of bounds for item ${item.timestamp}")
                                gridPoints.add(GriddedValueData.GriddedPoint(value = 0.0, angle = null)) // Placeholder
                            }
                        }
                    }
                    val grid = GriddedValueData(width = width, height = height, points = gridPoints)
                    item.timestamp to grid // Creates a Pair
                }
            }
            deferredGrids.awaitAll() // Wait for all async tasks to complete
        }




    } // End of companion object

    /**
     * Incrementally decodes and merges any **missing** intervals present in the
     * provided `EncodedTimeSeriesData` (does not rebuild existing timestamps).
     */

    /*
    suspend fun update(
        withData: EncodedTimeSeriesData,
        channel: SampleChannel,
        expression: SampleExpression,
        dataRange: ClosedFloatingPointRange<Double>
    ) {
        val points = withData.series.snapshot()
        val missingItems: List<Item> = points.mapNotNull { timePoint ->
            if (this.data.grids.containsKey(timePoint.timestamp)) return@mapNotNull null

            val container = timePoint.value ?: return@mapNotNull null
            Item(
                timestamp = timePoint.timestamp,
                imageWidth = container.imageWidth,
                imageHeight = container.imageHeight,
                imageRowBytes = container.imageRowBytes,
                pixelData = container.pixelBuffer.duplicate().rewind()
            )
        }
        // Call the other update function that takes a list of Items
        kotlinx.coroutines.flow.update(withItems = missingItems, channel = channel, expression = expression, dataRange = dataRange)
    }
*/
    /**
     * Incrementally decodes and merges any **missing** intervals from the given
     * items. No-op when `items` is empty.
     */

    /*
    suspend fun update(
        withItems items: List<Item>, // Added label for clarity, matching Swift more closely
        channel: SampleChannel,
        expression: SampleExpression,
        dataRange: ClosedFloatingPointRange<Double>
    ) {
        if (items.isEmpty()) return

        // Decode only the new items
        val newPairs = decode(items, channel, expression, dataRange)
        if (newPairs.isEmpty()) return

        // Create a mutable copy of the current grids to update
        val mergedGrids = this.data.grids.toMutableMap()
        for ((timestamp, grid) in newPairs) {
            mergedGrids[timestamp] = grid
        }
        // Update the 'data' property with a new GriddedTimeSeriesValueData containing the merged grids
        this.data = GriddedTimeSeriesValueData(grids = mergedGrids)
    }

    /**
     * Forwards a per-pixel query to the underlying `data` and associated query options.
     */
    fun query(x: Double, y: Double, options: GriddedQueryOptions): GriddedValueData.Point? {
        return data.query(x = x, y = y, options = options)
    }
        */

}