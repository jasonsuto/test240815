package com.xweather.mapsgl.data

import com.xweather.mapsgl.types.math_type.ValueRange

internal class DataRange(
    val range: ValueRange
) {
    val min: Double
        get() = range.min

    val max: Double
        get() = range.max

    val delta: Double
        get() = range.max - range.min

    fun getRange(range: ValueRange, normalized: Boolean = false): ValueRange {
        val min = maxOf(this.range.min, range.min)
        val max = minOf(this.range.max, range.max)
        return if (normalized) {
            ValueRange(
                min = position(min),
                max = position(max),
                ""
            )
        } else {
            ValueRange(
                min = min,
                max = max,
                ""
            )
        }
    }

    fun position(value: Double): Double {
        return (value - range.min) / delta
    }
}
