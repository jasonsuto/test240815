package com.xweather.mapsgl.renderers

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.opengl.GLES31
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max

/**
 * Builds a **wind-barb-only** `GL_TEXTURE_2D_ARRAY` from [sprite-sdf@2x.png] + JSON rects for
 * `wind-barb-{0,5,...,100}-sdf`. Hurricane / tropical tiles elsewhere in the PNG are **never** uploaded,
 * so the instanced barb shader cannot sample them even if indexing misbehaves.
 */
internal object WindBarbSdfAtlas {

    const val BARB_COUNT = 21

    private const val ASSET_PNG = "sdf/sprite-sdf@2x.png"
    private const val ASSET_JSON = "sdf/sprite-sdf@2x.json"

    /**
     * First row of buffer = **bottom** row of the bitmap (matches GLES `glTexSubImage2D` / `texImage2D` convention).
     */
    private fun bitmapToRgbaBufferBottomFirst(b: Bitmap): ByteBuffer {
        val w = b.width
        val h = b.height
        val pixels = IntArray(w * h)
        b.getPixels(pixels, 0, w, 0, 0, w, h)
        val buf = ByteBuffer.allocateDirect(w * h * 4).order(ByteOrder.nativeOrder())
        for (row in h - 1 downTo 0) {
            for (col in 0 until w) {
                val p = pixels[row * w + col]
                buf.put(((p shr 16) and 0xFF).toByte())
                buf.put(((p shr 8) and 0xFF).toByte())
                buf.put((p and 0xFF).toByte())
                buf.put(((p shr 24) and 0xFF).toByte())
            }
        }
        buf.position(0)
        return buf
    }

    fun uploadWindBarbTexture2DArray(context: Context): Int {
        val jsonText = context.assets.open(ASSET_JSON).bufferedReader().use { it.readText() }
        val root = JSONObject(jsonText)
        val full =
            context.assets.open(ASSET_PNG).use { BitmapFactory.decodeStream(it) }
                ?: error("WindBarbSdfAtlas: failed to decode $ASSET_PNG")

        var sliceW = 0
        var sliceH = 0
        for (i in 0 until BARB_COUNT) {
            val key = "wind-barb-${i * 5}-sdf"
            val o = root.getJSONObject(key)
            sliceW = max(sliceW, o.getInt("width"))
            sliceH = max(sliceH, o.getInt("height"))
        }

        val texIds = IntArray(1)
        GLES31.glGenTextures(1, texIds, 0)
        val tid = texIds[0]
        GLES31.glBindTexture(GLES31.GL_TEXTURE_2D_ARRAY, tid)
        /** LINEAR: SDF must vary smoothly across pixels so `fwidth(dist)` AA matches the web barb shader. */
        GLES31.glTexParameteri(
            GLES31.GL_TEXTURE_2D_ARRAY,
            GLES31.GL_TEXTURE_MIN_FILTER,
            GLES31.GL_LINEAR,
        )
        GLES31.glTexParameteri(
            GLES31.GL_TEXTURE_2D_ARRAY,
            GLES31.GL_TEXTURE_MAG_FILTER,
            GLES31.GL_LINEAR,
        )
        GLES31.glTexParameteri(
            GLES31.GL_TEXTURE_2D_ARRAY,
            GLES31.GL_TEXTURE_WRAP_S,
            GLES31.GL_CLAMP_TO_EDGE,
        )
        GLES31.glTexParameteri(
            GLES31.GL_TEXTURE_2D_ARRAY,
            GLES31.GL_TEXTURE_WRAP_T,
            GLES31.GL_CLAMP_TO_EDGE,
        )

        GLES31.glTexStorage3D(
            GLES31.GL_TEXTURE_2D_ARRAY,
            1,
            GLES31.GL_RGBA8,
            sliceW,
            sliceH,
            BARB_COUNT,
        )

        try {
            for (i in 0 until BARB_COUNT) {
                val key = "wind-barb-${i * 5}-sdf"
                val o = root.getJSONObject(key)
                val x = o.getInt("x")
                val y = o.getInt("y")
                val w = o.getInt("width")
                val h = o.getInt("height")
                val sub = Bitmap.createBitmap(full, x, y, w, h)
                val slice =
                    if (w != sliceW || h != sliceH) {
                        Bitmap.createScaledBitmap(sub, sliceW, sliceH, true).also { sub.recycle() }
                    } else {
                        sub
                    }
                val buf = bitmapToRgbaBufferBottomFirst(slice)
                slice.recycle()
                GLES31.glTexSubImage3D(
                    GLES31.GL_TEXTURE_2D_ARRAY,
                    0,
                    0,
                    0,
                    i,
                    sliceW,
                    sliceH,
                    1,
                    GLES31.GL_RGBA,
                    GLES31.GL_UNSIGNED_BYTE,
                    buf,
                )
            }
        } finally {
            full.recycle()
        }

        GLES31.glBindTexture(GLES31.GL_TEXTURE_2D_ARRAY, 0)
        return tid
    }
}
