package com.xweather.mapsgl.renderers


import com.xweather.mapsgl.gl.ParticleRenderPass
import com.xweather.mapsgl.gl.RenderPass
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.gl.programs.RasterTileProgram
import com.xweather.mapsgl.gl.programs.TriangleProgram
import com.xweather.mapsgl.style.ColorLookupTable
import com.xweather.mapsgl.style.LayerPaint
import com.xweather.mapsgl.style.ParticleLayerPaint
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.types.math_type.ValueRange
import kotlin.math.pow

interface ParticleRendererOptions : EncodedDataRendererOptions {
    val totalParticles: Int
    val particleSize: Int
    val enableTrails: Boolean
    val speedFactor: Double
    val dropRate: Double
    val dropRateBump: Double
    val fade: Double
}

class ParticleRenderer(override var id: String) : EncodedDataRenderer<TileData, LayerRenderContext<Any>>(id) {

    private lateinit var paintStyle: ParticleLayerPaint
    private var _particleCount = 256.0.pow(2).toInt()
    private var _renderTrails = false

    init {
        // If a custom particle count is set, automatically set `density` to `count`.
        val count = _particleCount
        this._particleCount = 0;
        this._renderTrails = false
    }

    override fun draw(context: LayerRenderContext<Any>, texUnit: HashMap<String, Int>) {
        TODO("Not yet implemented")
    }

    //override fun draw(texUnit: HashMap<String, HashMap<String, Int>>) {
    //    TODO("Not yet implemented")
    //}

    override fun onAdd() {
        TODO("Not yet implemented")
    }

    //override fun onAdd(context: RenderContext<Any>, tileLayer: TileLayer) {
    //    super.onAdd(tileLayer)
    //}

    override fun setUpRenderPass(): RenderPass {
        if (pr.ON) pr.p("ParticleRenderer", pr.waaveRenderpath, ">> setupRenderpass")
        if (this.tileLayer?.source?.id != null) {
            return ParticleRenderPass(tileLayer!!.source.id, tileLayer!!.paint)
        } else {
            return ParticleRenderPass("particle", tileLayer!!.paint)
        }
    }

    override suspend fun update() {
        TODO("Not yet implemented")
    }

    /*
    private fun makeMeshForRenderable(renderable: TileRenderable<DataType>?): Mesh {
        return try {
            if (program == null) {
                createProgram()
                mesh = Mesh(0, quadGeometry, program!!, createFrameBufferProgram())
                mesh.textureProgram = createTextureProgram()
                //tileLayer!!.paint is ParticleLayerPaint
            } else if (resetPaint) {
                resetProgram()
                resetPaint = false
            }
            return mesh

        } catch (e: Exception) {
            throw e
        }
    } */

    override fun prerender(context: LayerRenderContext<Any>) {
        super.prerender(context)
    }

    override fun setup(paint: LayerPaint) {
        paintStyle = (paint as ParticleLayerPaint)
        val colorScale = paintStyle.sample.colorScale
        var drawRange = paintStyle.sample.drawRange
        _outputRange = ValueRange(0.0, 255.0, "")

        val md = (this.tileLayer?.source)?.metadata
        if (md != null) {
            if (md.noData != null) _outputRange.min = md.noData!!.toDouble()
        }

        val tProgram = (program as TriangleProgram)

        if (drawRange == null) {
            drawRange = colorScale.range
        }

        val colorDrawRange = drawRange ?: 0.0..1.0
        createColorLookupTables(options = colorScale, drawRange = colorDrawRange)

        if (paintStyle.sample.drawRange != null) {
            tProgram.updateDataRange(
                colorDrawRange.start.toFloat(),
                colorDrawRange.endInclusive.toFloat()
            ) //TODO: Data range only matters for vector?
        } else {
            tProgram.updateDataRange(colorDrawRange.start.toFloat(), colorDrawRange.endInclusive.toFloat())
        }

        //Fixme: colorRange is applied in createColorLookupBitmap(), it should be applied earlier in createColorLookupTables()
        colorBandBitmap = arrayOf(colorLookupTable.createColorLookupBitmap(256, 1))

        tProgram.uniforms["colorBitmap"] = colorBandBitmap
        colorBandTexHandles[0] =
            ColorLookupTable.bitmapToTextureHandle(colorBandBitmap[0], paintStyle.sample.colorScale.interpolate)
        tProgram.uniforms["colorBandTexHandle"] = colorBandTexHandles[0]

        val channel1 = paintStyle.sample.channel[0].rawValue
        var channel2 = -1
        if (paintStyle.sample.channel.size > 1) {
            channel2 = paintStyle.sample.channel[1].rawValue
        }
        tProgram.updateChannels(channel1, channel2) //normal

    }

    override fun setNeedsUpdate() {}

    fun setupFrameBufferProgram(paint: LayerPaint, rasterTileProgram: RasterTileProgram) {
        paintStyle = (paint as ParticleLayerPaint)
        val colorScale = paintStyle.sample.colorScale
        var drawRange = paintStyle.sample.drawRange
        _outputRange = ValueRange(0.0, 255.0, "")

        val md = (this.tileLayer?.source)?.metadata
        if (md != null) {
            if (md.noData != null) _outputRange.min = md.noData!!.toDouble()
        }

        val tProgram = (rasterTileProgram as TriangleProgram)

        if (drawRange == null) {
            drawRange = colorScale.range
        } else { //received draw range from WeatherService drawRange (outside of color stops)
        }
        val colorDrawRange = drawRange ?: 0.0..1.0
        createColorLookupTables(options = colorScale, drawRange = colorDrawRange)

        if (paintStyle.sample.drawRange != null) {
            tProgram.updateDataRange(
                colorDrawRange.start.toFloat(),
                colorDrawRange.endInclusive.toFloat()
            ) //TODO: Data range only matters for vector?
        } else {
            tProgram.updateDataRange(colorDrawRange.start.toFloat(), colorDrawRange.endInclusive.toFloat())
        }

        //Fixme: colorRange is applied in createColorLookupBitmap(), it should be applied earlier in createColorLookupTables()
        colorBandBitmap = arrayOf(colorLookupTable.createColorLookupBitmap(256, 1))

        tProgram.uniforms["colorBitmap"] = colorBandBitmap[0]
        colorBandTexHandles[0] =
            ColorLookupTable.bitmapToTextureHandle(colorBandBitmap[0], paintStyle.sample.colorScale.interpolate)
        tProgram.uniforms["colorBandTexHandle"] = colorBandTexHandles[0]
        val channel1 = paintStyle.sample.channel[0].rawValue
        var channel2 = -1
        if (paintStyle.sample.channel.size > 1) {
            channel2 = paintStyle.sample.channel[1].rawValue
        }
        tProgram.updateChannels(channel1, channel2) //normal

    }

    fun updateParticleDrawPasses(enableTrails: Boolean) {
        this._renderTrails = enableTrails
    }
}