/**
 *  RasterLayerRenderer.kt
 *
 *
 *  Created by Jason Suto 12/21/23.
 *  Adapted from IOS version.
 */
package com.xweather.mapsgl.renderers

import com.xweather.mapsgl.gl.RenderPass
import com.xweather.mapsgl.layers.tile.RenderContext
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.map.mapbox.MapboxMapController
import com.xweather.mapsgl.tiles.TileData

/**
 *  RasterLayerRenderer.kt
 *
 *  A lot of this is handled in TileLayerRenderer
 *
 *  @author Jason Suto on 12/22/23.
 */
/// TODO: If `RasterLayerRenderer` doesn't need to add/override any methods
// (everything can be done in `TileRenderer` or `extension TileLayer where Context == RasterTileLayer.RenderContext`), change this to a typealias.
open class RasterLayerRenderer : TileLayerRenderer<TileData, LayerRenderContext<Any>>() {


    override fun draw(context: LayerRenderContext<Any>, texUnit: HashMap<String, Int>) {
        TODO("Not yet implemented")
    }

    //override fun draw(texUnit: HashMap<String, HashMap<String, Int>>) {
    //    TODO("Not yet implemented") //Handled in TileLayerRenderer
    //}

    override fun onAdd() {
        TODO("Not yet implemented") //Handled in TileLayerRenderer
    }

    override fun onAdd(context: RenderContext<Any>, tileLayer: TileLayer, controller: MapboxMapController) {
        TODO("Not yet implemented")
    }

    //override fun onAdd(context: RenderContext<Any>, tileLayer: TileLayer) {
    //    TODO("Not yet implemented")
    //}

    /** Called from TileLayerRenderer.prerender*/
    @Throws(Exception::class)
    override fun setUpRenderPass(): RenderPass {
        renderPass = RenderPass(tileLayer?.source!!.id, tileLayer!!.paint)
        renderPass.id = id
        return renderPass
    }

    override var id: String
        get() = tileLayer!!.id
        set(value) {}

    override suspend fun update() {
        TODO("Not yet implemented")
    }
}

@Deprecated("Use `RasterLayerRenderer` instead.", ReplaceWith("RasterLayerRenderer"))
internal typealias RasterRenderer = RasterLayerRenderer
