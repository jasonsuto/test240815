package com.xweather.mapsgl.types

import com.xweather.mapsgl.tiles.LatLonBounds

/**
 * Read-only view of map camera and viewport state for layers and utilities that cannot depend on Mapbox types directly.
 *
 * Implemented by [com.xweather.mapsgl.map.MapController] (and thus [com.xweather.mapsgl.map.mapbox.MapboxMapController]).
 */
interface MapProvider : Observable {
    /** Drawable / logical map size in pixels (see [Size]). */
    fun getSize(): Size

    /** Geographic center of the map in degrees. */
    fun getCenter(): Coordinate

    /** Axis-aligned visible bounds in latitude/longitude. */
    fun getBounds(): LatLonBounds

    /** Map zoom level (Mapbox zoom). */
    fun getZoom(): Double

    /** Bearing in degrees (rotation about the vertical axis). */
    fun getBearing(): Double

    /** Pitch / tilt in degrees. */
    fun getPitch(): Double

    /** Field of view used by the custom GL camera (when applicable). */
    fun getFov(): Double

    /**
     * West/east longitude in degrees for **tile enumeration** (may lie outside [-180, 180] when the
     * camera shows several world copies). Defaults to [getBounds]; Mapbox uses raw unwrapped bounds
     * so encoded layers can render every visible copy.
     */
    fun getUnwrappedCameraLonBoundsForTiles(): Pair<Double, Double> {
        val b = getBounds()
        return b.westExtent.toDouble() to b.eastExtent.toDouble()
    }
}

/**
 * Minimal publish/subscribe hook used by [MapProvider] implementations for named events.
 */
interface Observable {
    /** Subscribe to [name]; [callback] receives event payloads. */
    fun on(name: String, callback: (event: Any) -> Unit)

    /** Unsubscribe a previously registered [callback] for [name]. */
    fun off(name: String, callback: (event: Any) -> Unit)
}


