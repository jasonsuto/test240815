package com.xweather.mapsgl.types

import com.xweather.mapsgl.tiles.LatLonBounds

/**
 * Provides a common interface when communicating between data layers and the associated map.
 *
 * @interface MapProvider
 */

interface MapProvider : Observable {
    fun getSize(): Size
    fun getCenter(): Coordinate
    fun getBounds(): LatLonBounds
    fun getZoom(): Double
    fun getBearing(): Double
    fun getPitch(): Double
    fun getFov(): Double

    /**
     * West/east longitude in degrees for **tile enumeration** (may lie outside [-180, 180] when the
     * camera shows several world copies). Defaults to [getBounds]; Mapbox uses raw unwrapped bounds
     * so encoded layers can render every visible copy.
     */
    fun getUnwrappedCameraLonBoundsForTiles(): Pair<Double, Double> {
        val b = getBounds()
        return b.westExtent.toDouble() to b.eastExtent.toDouble()
    }
}

interface Observable {
    fun on(name: String, callback: (event: Any) -> Unit)
    fun off(name: String, callback: (event: Any) -> Unit)
}


