package com.xweather.mapsgl.types

class DataSourceConsumer(
    override val layerId: String,
    override var sourceLayerId: String? = null,
//    override val sourceLayerType: String,
//    override val type: String,
//    override val style: Pair<String, *>,
//    override val options: Pair<String, *>
) : LayerMetadata(layerId, sourceLayerId)

open class LayerMetadata(
    override val layerId: String,
    override val sourceLayerId: String? = null,
//    override val sourceLayerType: String,
//    override val type: String,
//    override val style: Pair<String, *>,
//    override val options: Pair<String, *>
) : ILayerMetadata

interface ILayerMetadata {
    val layerId: String
    val sourceLayerId: String?
//    val sourceLayerType: String
//    val type: String
//    val style: Pair<String, *>
//    val options: Pair<String, *>
}
