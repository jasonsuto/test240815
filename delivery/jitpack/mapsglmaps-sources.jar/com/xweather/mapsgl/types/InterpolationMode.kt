package com.xweather.mapsgl.types

enum class InterpolationMode {
    NONE,
    BILINEAR,
    BICUBIC,
    BIQUADRATIC
}