package com.xweather.mapsgl.utils

class TimeIntervalSeconds(val seconds: Long) {
}