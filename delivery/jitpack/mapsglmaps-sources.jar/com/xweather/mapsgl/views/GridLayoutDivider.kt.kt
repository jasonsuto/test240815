package com.xweather.mapsgl.views

import android.content.Context
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.widget.GridLayout
import androidx.core.content.ContextCompat
import com.xweather.mapsglmaps.R


/**
 * A custom ItemDecoration that draws horizontal dividers between rows in a GridLayout.
 * It intelligently skips drawing a divider after the very last row.
 */
class GridLayoutDivider(context: Context) {

    private val divider: Drawable?

    init {
        divider = ContextCompat.getDrawable(context, R.drawable.di_divider)
    }

    fun draw(canvas: Canvas, parent: GridLayout) {
        divider ?: return // Do nothing if the divider isn't available

        val childCount = parent.childCount
        val columnCount = parent.columnCount
        if (childCount == 0 || columnCount == 0) return

        // We only want to draw dividers *between* rows.
        // The number of dividers will be one less than the number of rows.
        val rowCount = (childCount + columnCount - 1) / columnCount
        if (rowCount <= 1) return

        for (i in 0 until rowCount - 1) {
            // Get the first child of the *next* row to determine where its top is.
            val firstChildInNextRow = parent.getChildAt((i + 1) * columnCount) ?: continue

            // The divider should be drawn just above the next row.
            // The 'top' of a view includes its top margin.
            val top = firstChildInNextRow.top - (firstChildInNextRow.layoutParams as GridLayout.LayoutParams).topMargin

            val bottom = top + divider.intrinsicHeight

            val left = parent.paddingLeft
            val right = parent.width - parent.paddingRight

            // Ensure we don't draw a divider where it shouldn't be
            if (top > 0) {
                divider.setBounds(left, top, right, bottom)
                divider.draw(canvas)
            }
        }
    }
}