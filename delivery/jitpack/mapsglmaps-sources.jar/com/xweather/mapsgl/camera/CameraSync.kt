package com.xweather.mapsgl.camera

const val WORLD_SIZE = 1024000 // TILE_SIZE * 2000
const val FOV_ORTHO = 0.1 / 180 * Math.PI // Mapbox doesn't accept 0 as FOV
val FOV = Math.atan(3.0 / 4.0) // from Mapbox https://github.com/mapbox/mapbox-gl-js/blob/main/src/geo/transform.js#L93
const val EARTH_RADIUS =
    6371008.8 // from Mapbox  https://github.com/mapbox/mapbox-gl-js/blob/0063cbd10a97218fb6a0f64c99bf18609b918f4c/src/geo/lng_lat.js#L11
const val EARTH_CIRCUMFERENCE_EQUATOR =
    40075017 // from Mapbox https://github.com/mapbox/mapbox-gl-js/blob/0063cbd10a97218fb6a0f64c99bf18609b918f4c/src/geo/lng_lat.js#L117
const val PROJECTION_WORLD_SIZE = WORLD_SIZE / (EARTH_RADIUS * Math.PI * 2)
const val MERCATOR_A = EARTH_RADIUS
const val DEG2RAD = Math.PI / 18
const val RAD2DEG = 180 / Math.PI
const val EARTH_CIRCUMFERENCE = 2 * Math.PI * EARTH_RADIUS // 40075000, // In meters
val FOV_DEGREES = FOV * 180 / Math.PI // Math.atan(3/4) in degrees
const val TILE_SIZE = 512

data class Coordinate(val lat: Double, val lon: Double)
data class CoordinateBounds(val north: Double, val west: Double)

interface ProjectionMatrix

/**
 *  CameraSync.kt
 *
 *  @author Jason Suto 02/20/24.
 *
 *  Most of this code is currently in MapboxMapController
 *
 */
class CameraSync() {}


