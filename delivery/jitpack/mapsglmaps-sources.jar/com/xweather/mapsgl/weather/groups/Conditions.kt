//
//  Conditions.kt
//
//  NOTE: This file is auto-generated and should not be edited directly!
//  Last updated: 2026-03-12T20:12:16.308Z
//

package com.xweather.mapsgl.weather.groups

import com.xweather.mapsgl.controls.legend.Legend
import com.xweather.mapsgl.layers.spec.ContourLayerDescriptor
import com.xweather.mapsgl.layers.spec.GridLayerDescriptor
import com.xweather.mapsgl.layers.spec.ParticleLayerDescriptor
import com.xweather.mapsgl.layers.spec.SampleLayerDescriptor
import com.xweather.mapsgl.sources.source.spec.EncodedSourceDescriptor
import com.xweather.mapsgl.style.ColorScaleOptions
import com.xweather.mapsgl.style.ColorStop
import com.xweather.mapsgl.style.ContourLayerPaint
import com.xweather.mapsgl.style.ContourPaint
import com.xweather.mapsgl.style.GridLayerPaint
import com.xweather.mapsgl.style.GridPaint
import com.xweather.mapsgl.style.IconAtlas
import com.xweather.mapsgl.style.IconPaint
import com.xweather.mapsgl.style.IconSize
import com.xweather.mapsgl.style.ParticleDensity
import com.xweather.mapsgl.style.ParticleLayerPaint
import com.xweather.mapsgl.style.ParticlePaint
import com.xweather.mapsgl.style.SampleLayerPaint
import com.xweather.mapsgl.style.SamplePaint
import com.xweather.mapsgl.style.StrokePaint
import com.xweather.mapsgl.style.StyleValue
import com.xweather.mapsgl.types.ColorBand
import com.xweather.mapsgl.types.DataQuality
import com.xweather.mapsgl.types.InterpolationMode
import com.xweather.mapsgl.types.SampleExpression
import com.xweather.mapsgl.types.Size
import com.xweather.mapsgl.utils.inToMMRate
import com.xweather.mapsgl.weather.BaseEncodedConfiguration
import com.xweather.mapsgl.weather.ColorScales
import com.xweather.mapsgl.weather.LayerCode
import com.xweather.mapsgl.weather.LegendCode
import com.xweather.mapsgl.weather.WeatherService
import com.xweather.mapsgl.weather.WeatherSource
import com.xweather.mapsgl.weather.common.Presentation
import com.xweather.mapsgl.weather.common.PresentationType
import com.xweather.mapsgl.weather.common.presentations
import com.xweather.mapsgl.weather.toColor

object Conditions {
    class CloudCover(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.CLOUD_COVER
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_TCDC_PRECIP_UVI(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "conditions.cloud_cover.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        listOf(
                                            ColorStop(0.0, toColor("rgba(50, 50, 50, 0)")),
                                            ColorStop(50.0, toColor("rgba(100, 100, 100, 0.4)")),
                                            ColorStop(100.0, toColor("rgba(242, 242, 242, 1)")),
                                        ),
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.PERCENTAGE]?.setTitle("Cloud Cover")
        override var legend: Legend? = null

        init {
            legend = LegendCode.CLOUD_COVER.getLegend()
        }
    }

    class DewPoints(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.DEW_POINTS
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_APTMP2_DPT2_RH2(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "conditions.dew_point.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.green),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.dewPoint.stops,
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.TEMPERATURE]?.setTitle("Dew Point")
        override var legend: Legend? = null

        init {
            legend = LegendCode.DEW_POINT.getLegend()
        }
    }

    class FeelsLike(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.FEELS_LIKE
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_APTMP2_DPT2_RH2(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "conditions.feels_like.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.temperature.stops,
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.TEMPERATURE]?.setTitle("Feels Like")
        override var legend: Legend? = null

        init {
            legend = LegendCode.TEMPERATURE.getLegend()
        }
    }

    class HeatIndex(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.HEAT_INDEX
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_APTMP2_DPT2_RH2(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "conditions.heat_index.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red),
                                interpolation = InterpolationMode.BICUBIC,
                                drawRange = 26.66667..54.44,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.temperature.stops,
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.TEMPERATURE]?.setTitle("Heat Index")
        override var legend: Legend? = null

        init {
            legend = LegendCode.HEAT_INDEX.getLegend()
        }
    }

    class Humidity(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.HUMIDITY
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_APTMP2_DPT2_RH2(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "conditions.humidity.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.blue),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.humidity.stops,
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.PERCENTAGE]?.setTitle("Humidity")
        override var legend: Legend? = null

        init {
            legend = LegendCode.HUMIDITY.getLegend()
        }
    }

    class Precipitation(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.PRECIPITATION
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_PRECIP(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "conditions.precip.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red, ColorBand.green, ColorBand.blue),
                                interpolation = InterpolationMode.BICUBIC,
                                drawRange = inToMMRate(0.01)..inToMMRate(5.0),
                                colorScale =
                                    ColorScaleOptions(
                                        stops = ColorScales.precip_accum.stops,
                                        range = inToMMRate(0.01)..inToMMRate(5.0),
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.PRECIPITATION]
        override var legend: Legend? = null

        init {
            legend = LegendCode.PRECIP_RATE.getLegend()
        }
    }

    /*
    class PrecipitationRate(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.PRECIPITATION_RATE
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_TCDC_PRECIP_UVI(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "conditions.precip_rate.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.green),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        listOf(
                                            ColorStop(0.0, toColor("rgba(0,0,0,0)")),
                                            ColorStop(0.00002, toColor("rgba(113,255,194,0)")),
                                            ColorStop(0.00002, toColor("#71ffc2")),
                                            ColorStop(0.00004, toColor("#49eb3a")),
                                            ColorStop(0.00117, toColor("#114c00")),
                                            ColorStop(0.0032, toColor("#e4c700")),
                                            ColorStop(0.01351, toColor("#da0000")),
                                            ColorStop(0.05696, toColor("#7a0009")),
                                            ColorStop(0.11696, toColor("#9e0570")),
                                        ),
                                        range = 0.0..0.17639,
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }
    */
    class PressureMeanSeaLevel(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.PRESSURE_MEAN_SEA_LEVEL
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_PRMSL_VIS_GUST10(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "conditions.pressure_msl.fill",
                source.id,
                quality = DataQuality.low,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        listOf(
                                            ColorStop(950.0, toColor("#D08AFF")),
                                            ColorStop(960.0, toColor("#9A00FF")),
                                            ColorStop(970.0, toColor("#6401FF")),
                                            ColorStop(980.0, toColor("#0300B8")),
                                            ColorStop(990.0, toColor("#084ADA")),
                                            ColorStop(1000.0, toColor("#01CDFF")),
                                            ColorStop(1010.0, toColor("#23DC02")),
                                            ColorStop(1020.0, toColor("#FEF90B")),
                                            ColorStop(1030.0, toColor("#FE7B00")),
                                            ColorStop(1040.0, toColor("#FA0107")),
                                            ColorStop(1050.0, toColor("#970100")),
                                            ColorStop(1060.0, toColor("#DB5C5F")),
                                        ),
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.PRESSURE]?.setTitle("Surface Pressure")
        override var legend: Legend? = null

        init {
            legend = LegendCode.PRESSURE.getLegend()
        }
    }

    class PressureMeanSeaLevelContour(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<ContourLayerDescriptor>() {
        override val code: LayerCode = LayerCode.PRESSURE_MEAN_SEA_LEVEL_CONTOUR
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_PRMSL_VIS_GUST10(service)
        override val layer: ContourLayerDescriptor =
            ContourLayerDescriptor(
                "conditions.pressure_msl.contour",
                source.id,
                quality = DataQuality.low,
                paint =
                    ContourLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        listOf(
                                            ColorStop(950.0, toColor("#D08AFF")),
                                            ColorStop(960.0, toColor("#9A00FF")),
                                            ColorStop(970.0, toColor("#6401FF")),
                                            ColorStop(980.0, toColor("#0300B8")),
                                            ColorStop(990.0, toColor("#084ADA")),
                                            ColorStop(1000.0, toColor("#01CDFF")),
                                            ColorStop(1010.0, toColor("#23DC02")),
                                            ColorStop(1020.0, toColor("#FEF90B")),
                                            ColorStop(1030.0, toColor("#FE7B00")),
                                            ColorStop(1040.0, toColor("#FA0107")),
                                            ColorStop(1050.0, toColor("#970100")),
                                            ColorStop(1060.0, toColor("#DB5C5F")),
                                        ),
                                        interval = 1.0,
                                    ),
                                smoothing = 0.5f,
                            ),
                        contour =
                            ContourPaint(
                                interval = StyleValue.Constant(2.0),
                                majorInterval = StyleValue.Constant(10.0),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.PRESSURE]?.setTitle("Surface Pressure")
        override var legend: Legend? = null

        init {
            legend = LegendCode.PRESSURE.getLegend()
        }
    }

    class Radar(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.RADAR
        override val source: EncodedSourceDescriptor = WeatherSource.radar_REFC_PRATE_PTYPESMPL(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "conditions.radar.fill",
                source.id,
                quality = DataQuality.exact,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red),
                                interpolation = InterpolationMode.BICUBIC,
                                drawRange = 10.0..87.0,
                                colorScale =
                                    ColorScaleOptions(
                                        stops =
                                            listOf(
                                                listOf(
                                                    ColorStop(0.0, toColor("rgba(0,0,0,0)")),
                                                    ColorStop(5.99, toColor("rgba(0,0,0,0)")),
                                                    ColorStop(6.0, toColor("#8CF482")),
                                                    ColorStop(10.0, toColor("#49eb3a")),
                                                    ColorStop(33.0, toColor("#114c00")),
                                                    ColorStop(40.0, toColor("#e4c700")),
                                                    ColorStop(50.0, toColor("#da0000")),
                                                    ColorStop(60.0, toColor("#7a0009")),
                                                    ColorStop(65.0, toColor("#9e0570")),
                                                    ColorStop(70.0, toColor("#dc42b1")),
                                                    ColorStop(80.0, toColor("#dea8ff")),
                                                    ColorStop(87.0, toColor("#faf3ff")),
                                                ),
                                                listOf(
                                                    ColorStop(0.0, toColor("rgba(0,0,0,0)")),
                                                    ColorStop(5.9, toColor("rgba(255,163,249,0)")),
                                                    ColorStop(6.0, toColor("#ffa3f9")),
                                                    ColorStop(25.0, toColor("#d518be")),
                                                    ColorStop(58.0, toColor("#58003c")),
                                                    ColorStop(87.0, toColor("#58003c")),
                                                ),
                                                listOf(
                                                    ColorStop(0.0, toColor("rgba(0,0,0,0)")),
                                                    ColorStop(5.9, toColor("rgba(124,255,255,0)")),
                                                    ColorStop(6.0, toColor("#7cffff")),
                                                    ColorStop(7.0, toColor("#00e8ff")),
                                                    ColorStop(25.0, toColor("#0061ea")),
                                                    ColorStop(45.0, toColor("#0000af")),
                                                    ColorStop(58.0, toColor("#5c00f5")),
                                                    ColorStop(87.0, toColor("#5c00f5")),
                                                ),
                                            ),
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.RADAR]
        override var legend: Legend? = null

        init {
            legend = LegendCode.RADAR.getLegend()
        }
    }

    class Snow(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.SNOW
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_SNOW_PRECIP_TMP2(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "conditions.snow.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red, ColorBand.green, ColorBand.blue),
                                interpolation = InterpolationMode.BICUBIC,
                                drawRange = 0.00254..0.21167,
                                colorScale =
                                    ColorScaleOptions(
                                        listOf(
                                            ColorStop(0.0, toColor("rgba(96,96,96,0)")),
                                            ColorStop(0.00025, toColor("rgba(96,96,96,0)")),
                                            ColorStop(0.00254, toColor("rgba(96,96,96,0.5)")),
                                            ColorStop(0.0254, toColor("#576066")),
                                            ColorStop(0.0762, toColor("#85D3FF")),
                                            ColorStop(0.1524, toColor("#25B4FF")),
                                            ColorStop(0.3048, toColor("#012DFF")),
                                            ColorStop(0.4572, toColor("#7000D9")),
                                            ColorStop(0.6096, toColor("#FF49C4")),
                                            ColorStop(1.2192, toColor("#FFECF7")),
                                            ColorStop(1.8288, toColor("#36E2F4")),
                                            ColorStop(3.048, toColor("#007682")),
                                            ColorStop(4.2672, toColor("#C38EF2")),
                                            ColorStop(6.096, toColor("#A34AF2")),
                                            ColorStop(7.62, toColor("#7100FF")),
                                        ),
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.SNOWFALL]
        override var legend: Legend? = null
    }

    class SnowDepth(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.SNOW_DEPTH
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_SNOD(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "conditions.snow_depth.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red),
                                interpolation = InterpolationMode.BICUBIC,
                                drawRange = 0.0254..7.9248,
                                colorScale =
                                    ColorScaleOptions(
                                        listOf(
                                            ColorStop(0.0, toColor("rgba(96,96,96,0)")),
                                            ColorStop(0.00025, toColor("rgba(96,96,96,0)")),
                                            ColorStop(0.00254, toColor("rgba(96,96,96,0.5)")),
                                            ColorStop(0.0254, toColor("#576066")),
                                            ColorStop(0.0762, toColor("#85D3FF")),
                                            ColorStop(0.1524, toColor("#25B4FF")),
                                            ColorStop(0.3048, toColor("#012DFF")),
                                            ColorStop(0.4572, toColor("#7000D9")),
                                            ColorStop(0.6096, toColor("#FF49C4")),
                                            ColorStop(1.2192, toColor("#FFECF7")),
                                            ColorStop(1.8288, toColor("#36E2F4")),
                                            ColorStop(3.048, toColor("#007682")),
                                            ColorStop(4.2672, toColor("#C38EF2")),
                                            ColorStop(6.096, toColor("#A34AF2")),
                                            ColorStop(7.62, toColor("#7100FF")),
                                        ),
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null

        init {
            legend = LegendCode.SNOW_DEPTH.getLegend()
        }
    }

    class Temperatures(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.TEMPERATURES
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_TMP2_UGRD10_VGRD10(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "conditions.temperature.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.temperature.stops,
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.TEMPERATURE]

        init {
            legend = LegendCode.TEMPERATURE.getLegend()
        }
    }

    class Temperatures1HourChange(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.TEMPERATURES_1_HOUR_CHANGE
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_TMP2_DELTA(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "conditions.temperature_1hr_change.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                expression = SampleExpression.DIFFERENCE,
                                channel = listOf(ColorBand.red, ColorBand.blue),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        listOf(
                                            ColorStop(-22.2, toColor("#EF90FF")),
                                            ColorStop(-13.875, toColor("#D741DA")),
                                            ColorStop(-8.325, toColor("#8B21DA")),
                                            ColorStop(-5.55, toColor("#0070F1")),
                                            ColorStop(-2.775, toColor("#8ED4F9")),
                                            ColorStop(-0.555, toColor("rgba(142,212,249,0)")),
                                            ColorStop(0.0, toColor("rgba(0,0,0,0)")),
                                            ColorStop(0.555, toColor("rgba(255,217,42,0)")),
                                            ColorStop(2.775, toColor("#FFD92A")),
                                            ColorStop(5.55, toColor("#FF932A")),
                                            ColorStop(8.325, toColor("#E2330B")),
                                            ColorStop(19.425, toColor("#9D0000")),
                                            ColorStop(22.2, toColor("#D00071")),
                                        ),
                                        range = -22.2..22.2,
                                        interval = 0.0,
                                    ),
                                offset = 0.5f,
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.TEMPERATURE_CHANGE]
        override var legend: Legend? = null

        init {
            legend = LegendCode.TEMPERATURE_CHANGE_1_HOUR.getLegend()
        }
    }

    class Temperatures24HourChange(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.TEMPERATURES_24_HOUR_CHANGE
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_TMP2_DELTA(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "conditions.temperature_24hr_change.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                expression = SampleExpression.DIFFERENCE,
                                channel = listOf(ColorBand.red, ColorBand.green),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        listOf(
                                            ColorStop(-33.3, toColor("#EF90FF")),
                                            ColorStop(-27.75, toColor("#D741DA")),
                                            ColorStop(-22.2, toColor("#8B21DA")),
                                            ColorStop(-16.65, toColor("#0013CA")),
                                            ColorStop(-11.1, toColor("#0070F1")),
                                            ColorStop(-5.55, toColor("#8ED4F9")),
                                            ColorStop(-0.555, toColor("rgba(142,212,249,0)")),
                                            ColorStop(0.0, toColor("rgba(0,0,0,0)")),
                                            ColorStop(0.555, toColor("rgba(255,217,42,0)")),
                                            ColorStop(5.55, toColor("#FFD92A")),
                                            ColorStop(11.1, toColor("#FF932A")),
                                            ColorStop(16.65, toColor("#E2330B")),
                                            ColorStop(22.2, toColor("#9D0000")),
                                            ColorStop(27.75, toColor("#D00071")),
                                            ColorStop(33.3, toColor("#FF698C")),
                                        ),
                                        range = -27.75..27.75,
                                        interval = 0.0,
                                    ),
                                offset = 0.5f,
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.TEMPERATURE_CHANGE]
        override var legend: Legend? = null

        init {
            legend = LegendCode.TEMPERATURE_CHANGE_24_HOUR.getLegend()
        }
    }

    class TemperaturesContour(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<ContourLayerDescriptor>() {
        override val code: LayerCode = LayerCode.TEMPERATURES_CONTOUR
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_TMP2_UGRD10_VGRD10(service)
        override val layer: ContourLayerDescriptor =
            ContourLayerDescriptor(
                "conditions.temperature.contour",
                source.id,
                quality = DataQuality.high,
                paint =
                    ContourLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.temperature.stops,
                                        interval = 1.0,
                                    ),
                                smoothing = 1.0f,
                            ),
                        contour =
                            ContourPaint(
                                interval = StyleValue.Constant(1.11),
                                majorInterval = StyleValue.Constant(5.55),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.TEMPERATURE]
        override var legend: Legend? = null

        init {
            legend = LegendCode.TEMPERATURE.getLegend()
        }
    }

    class UltravioletIndex(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.ULTRAVIOLET_INDEX
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_TCDC_PRECIP_UVI(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "conditions.uvi.fill",
                source.id,
                quality = DataQuality.low,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.blue),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.uvi.stops,
                                        interval = 1.0,
                                    ),
                                smoothing = 1.0f,
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.INDEX]?.setTitle("UV Index")

        init {
            legend = LegendCode.ULTRAVIOLET_INDEX.getLegend()
        }
    }

    class Visibility(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.VISIBILITY
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_PRMSL_VIS_GUST10(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "conditions.visibility.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.green),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        listOf(
                                            ColorStop(0.0, toColor("#ffb400")),
                                            ColorStop(4023.35, toColor("#ffea00")),
                                            ColorStop(8046.7, toColor("rgba(255, 255, 173, 0.5)")),
                                            ColorStop(16093.4, toColor("rgba(162, 162, 162, 0)")),
                                        ),
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.DISTANCE]?.setTitle("Visibility")

        init {
            legend = LegendCode.VISIBILITY.getLegend()
        }
    }

    class WindChill(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.WIND_CHILL
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_APTMP2_DPT2_RH2(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "conditions.wind_chill.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red),
                                interpolation = InterpolationMode.BICUBIC,
                                drawRange = -62.22..4.44444,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.temperature.stops,
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.TEMPERATURE]?.setTitle("Wind Chill")
        override var legend: Legend? = null

        init {
            legend = LegendCode.WIND_CHILL.getLegend()
        }
    }

    class WindGusts(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.WIND_GUSTS
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_PRMSL_VIS_GUST10(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "conditions.wind_gust.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.blue),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.windSpeed.stops,
                                        range = 0.0..53.64,
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.WIND_GUST]
        override var legend: Legend? = null

        init {
            legend = LegendCode.WIND_SPEED.getLegend()
        }
    }

    class WindParticles(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<ParticleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.WIND_PARTICLES
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_TMP2_UGRD10_VGRD10(service)
        override val layer: ParticleLayerDescriptor =
            ParticleLayerDescriptor(
                "conditions.wind_speed.particle",
                source.id,
                quality = DataQuality.exact,
                paint =
                    ParticleLayerPaint(
                        sample =
                            SamplePaint(
                                expression = SampleExpression.VECTOR,
                                channel = listOf(ColorBand.green, ColorBand.blue),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.windSpeed.stops,
                                        range = 0.0..53.64,
                                        interval = 0.0,
                                    ),
                                smoothing = 1.0f,
                            ),
                        particle =
                            ParticlePaint(
                                density = ParticleDensity.NORMAL,
                                size = Size(2, 2),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.WIND_SPEED]
        override var legend: Legend? = null

        init {
            legend = LegendCode.WIND_SPEED.getLegend()
        }
    }

    class WindSpeeds(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.WIND_SPEEDS
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_TMP2_UGRD10_VGRD10(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "conditions.wind_speed.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                expression = SampleExpression.VECTOR,
                                channel = listOf(ColorBand.green, ColorBand.blue),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.windSpeed.stops,
                                        range = 0.0..53.64,
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.WIND_SPEED]
        override var legend: Legend? = null

        init {
            legend = LegendCode.WIND_SPEED.getLegend()
        }
    }

    class WindSpeedsContour(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<ContourLayerDescriptor>() {
        override val code: LayerCode = LayerCode.WIND_SPEEDS_CONTOUR
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_TMP2_UGRD10_VGRD10(service)
        override val layer: ContourLayerDescriptor =
            ContourLayerDescriptor(
                "conditions.wind_speed.contour",
                source.id,
                quality = DataQuality.high,
                paint =
                    ContourLayerPaint(
                        sample =
                            SamplePaint(
                                expression = SampleExpression.VECTOR,
                                channel = listOf(ColorBand.green, ColorBand.blue),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.windSpeed.stops,
                                        range = 0.0..53.64,
                                        interval = 2.25,
                                    ),
                                smoothing = 1.0f,
                            ),
                        contour =
                            ContourPaint(
                                interval = StyleValue.Constant(2.25),
                                majorInterval = StyleValue.Constant(11.25),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.WIND_SPEED]
        override var legend: Legend? = null

        init {
            legend = LegendCode.WIND_SPEED.getLegend()
        }
    }

    class WindBarbs(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<GridLayerDescriptor>() {
        override val code: LayerCode = LayerCode.WIND_BARBS
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_TMP2_UGRD10_VGRD10(service)
        override val layer: GridLayerDescriptor =
            GridLayerDescriptor(
                "conditions.wind_speed.symbol",
                source.id,
                quality = DataQuality.medium,
                paint =
                    GridLayerPaint(
                        sample =
                            SamplePaint(
                                expression = SampleExpression.VECTOR,
                                channel = listOf(ColorBand.green, ColorBand.blue),
                                interpolation = InterpolationMode.BICUBIC,
                                smoothing = 1f,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.windSpeed.stops,
                                        range = 0.0..53.64,
                                        interval = 0.0,
                                    ),
                                encodedScalarNormMax = 53.64,
                            ),
                        grid = GridPaint(spacing = 30.0),
                        icon =
                            IconPaint(
                                allowOverlap = StyleValue.Constant(true),
                                atlas =
                                    IconAtlas(
                                        ids =
                                            listOf(
                                                0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50,
                                                55, 60, 65, 70, 75, 80, 85, 90, 95, 100,
                                            ).map { kt -> "mapsgl:wind-barb-$kt" },
                                        intervalMs = 5.0 * IconAtlas.KNOTS_TO_MS_PER_KNOT,

                                        ),
                                iconSize = IconSize(width = 40f, height = 40f),
                                anchor = StyleValue.Constant(com.xweather.mapsgl.types.Anchor.BOTTOM),
                                offset =
                                    StyleValue.Constant(
                                        com.xweather.mapsgl.types.AnchorOffset(0.0, 5.0),
                                    ),
                                rotation = -90.0,
                                rotationUsesDataDirection = true,
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.WIND_SPEED]
        override var legend: Legend? = null

        init {
            legend = LegendCode.WIND_SPEED.getLegend()
        }
    }

    class WindDir(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<GridLayerDescriptor>() {
        override val code: LayerCode = LayerCode.WIND_DIR
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_TMP2_UGRD10_VGRD10(service)
        override val layer: GridLayerDescriptor =
            GridLayerDescriptor(
                "conditions.wind_speed.arrow",
                source.id,
                quality = DataQuality.medium,

                paint =
                    GridLayerPaint(
                        stroke = StrokePaint(thickness = StyleValue.Constant(0.0)),
                        icon =
                            IconPaint(
                                allowOverlap = StyleValue.Constant(true),
                                image = StyleValue.Constant("mapsgl:arrow"),
                                //iconSize = IconSize(width = 120.0f, height = 60.0f), //40, 20
                                iconSize = IconSize(width = 40.0f, height = 20.0f),
                                anchor = StyleValue.Constant(com.xweather.mapsgl.types.Anchor.LEFT),
                                offset = StyleValue.Constant(com.xweather.mapsgl.types.AnchorOffset(0.0, 0.0)),
                                rotation = -90.0,
                                rotationUsesDataDirection = true,
                            ),
                        grid = GridPaint(spacing = 30.0),
                        sample =
                            SamplePaint(
                                expression = SampleExpression.VECTOR,
                                channel = listOf(ColorBand.green, ColorBand.blue),
                                interpolation = InterpolationMode.BICUBIC,
                                smoothing = 1f,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.windSpeed.stops,
                                        range = 0.0..53.64,
                                        interval = 0.0,
                                    ),
                                encodedScalarNormMax = 53.64,
                            ),
                    ),
            )

        override var presentation = presentations[PresentationType.WIND_SPEED]
        override var legend: Legend? = null

        init {
            legend = LegendCode.WIND_SPEED.getLegend()
        }
    }
}
