//
//  ColorScales.kt
//
//  NOTE: This file is auto-generated and should not be edited directly!
//  Last updated: 2026-03-12T20:12:16.047Z
//

package com.xweather.mapsgl.weather

import androidx.compose.ui.graphics.Color
import com.xweather.mapsgl.style.ColorStop
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.StyleColor
import com.xweather.mapsgl.utils.inToMMRate

internal fun toColor(input: String): Color {
    return when {
        input.startsWith("#") -> {
            val cleanHex = input.removePrefix("#").trim()
            val expandedHex =
                when (cleanHex.length) {
                    3 -> cleanHex.map { "$it$it" }.joinToString("")
                    6, 8 -> cleanHex
                    else -> throw IllegalArgumentException("Invalid hex color: $input ($cleanHex)")
                }

            val colorLong = expandedHex.toLong(16)
            return when (expandedHex.length) {
                6 -> Color(colorLong or 0x00000000FF000000) // add alpha = 0xFF
                8 -> Color(colorLong)
                else -> throw IllegalArgumentException("Invalid expanded hex color: $input")
            }
        }

        input.startsWith("rgba") -> {
            // Remove "rgba(" and ")" and split by commas
            val values = input.removePrefix("rgba(").removeSuffix(")").split(",")

            // Parse the values to integers
            val r = values[0].trim().toInt()
            val g = values[1].trim().toInt()
            val b = values[2].trim().toInt()
            val a = (values[3].trim().toFloat() * 255).toInt() // Convert alpha from 0-1 to 0-255

            // Return the Color object
            return Color(r, g, b, a)
        }

        else -> throw IllegalArgumentException("Unsupported color format: $input")
    }
}

data class ColorValue<T>(
    val value: T,
    val color: Color,
    val label: String? = null,
)

sealed class DataColorScale {
    data class Stops(
        val stops: List<ColorStop>,
    ) : DataColorScale()

    data class Values(
        val values: List<ColorValue<Any>>,
    ) : DataColorScale()

    val stopsOrEmpty: List<ColorStop>
        get() =
            when (this) {
                is Stops -> stops
                is Values -> emptyList()
            }

    val valuesOrEmpty: List<ColorValue<Any>>
        get() =
            when (this) {
                is Stops -> emptyList()
                is Values -> values
            }

    fun toExpressionSteps(): List<Expression.Step<Any>> =
        when (this) {
            is DataColorScale.Stops ->
                this.stops.map {
                    Expression.Step(it.value, StyleColor.Color(it.color))
                }

            is DataColorScale.Values ->
                this.values.map {
                    Expression.Step(it.value, StyleColor.Color(it.color))
                }
        }
}

object ColorScales {
    val heatmap =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("rgba(0, 0, 0, 0)")),
                ColorStop(0.2, toColor("rgba(0, 0, 255, 0.2)")),
                ColorStop(0.45, toColor("rgba(0, 255, 0, 0.5)")),
                ColorStop(0.85, toColor("rgba(255, 255, 0, 1)")),
                ColorStop(1.0, toColor("rgba(255, 0, 0, 1)")),
            ),
        )
    /** Matches JS `groups/airquality/colors.ts` `points` (used by circle fill + point legend). */
    val airQuality =
        DataColorScale.Values(
            listOf(
                ColorValue("good", toColor("#29e11f"), "Good"),
                ColorValue("moderate", toColor("#f8f92a"), "Moderate"),
                ColorValue("unhealthy-for-sensitive-groups", toColor("#f9681b"), "Unhealthy for Sensitive Groups"),
                ColorValue("unhealthy for sensitive groups", toColor("#f9681b"), "Unhealthy for Sensitive Groups"),
                ColorValue("unhealthy", toColor("#f60115"), "Unhealthy"),
                ColorValue("very-unhealthy", toColor("#7a2c83"), "Very Unhealthy"),
                ColorValue("very unhealthy", toColor("#7a2c83"), "Very Unhealthy"),
                ColorValue("very_unhealthy", toColor("#7a2c83"), "Very Unhealthy"),
                ColorValue("hazardous", toColor("#65001b"), "Hazardous"),
            ),
        )
    val airQualityCo =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("rgba(7, 54, 161, 0)")),
                ColorStop(500.0, toColor("#0B8ACE")),
                ColorStop(650.0, toColor("#F2D538")),
                ColorStop(800.0, toColor("#F28012")),
                ColorStop(900.0, toColor("#DF0612")),
                ColorStop(1000.0, toColor("#980657")),
            ),
        )
    val airQualityHealthIndexCategories =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("#0000ff")),
                ColorStop(3.5, toColor("#00ff00")),
                ColorStop(6.5, toColor("#ffff00")),
                ColorStop(10.5, toColor("#ff0000")),
            ),
        )
    val airQualityIndex =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("#29e11f")),
                ColorStop(25.0, toColor("#29e11f")),
                ColorStop(75.0, toColor("#f8f92a")),
                ColorStop(125.0, toColor("#f9681b")),
                ColorStop(175.0, toColor("#f60115")),
                ColorStop(251.0, toColor("#7a2c83")),
                ColorStop(301.0, toColor("#65001b")),
                ColorStop(500.0, toColor("#65001b")),
            ),
        )
    val airQualityIndexCaiCategories =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("#0000ff")),
                ColorStop(51.0, toColor("#00ff00")),
                ColorStop(101.0, toColor("#ffff00")),
                ColorStop(251.0, toColor("#ff0000")),
            ),
        )
    val airQualityIndexCaqiCategories =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("#79bc6a")),
                ColorStop(26.0, toColor("#bbcf4c")),
                ColorStop(51.0, toColor("#eec20b")),
                ColorStop(76.0, toColor("#f29305")),
                ColorStop(101.0, toColor("#e8416f")),
            ),
        )
    val airQualityIndexCategories =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("#29e11f")),
                ColorStop(51.0, toColor("#f8f92a")),
                ColorStop(101.0, toColor("#f9681b")),
                ColorStop(151.0, toColor("#f60115")),
                ColorStop(200.0, toColor("#7a2c83")),
                ColorStop(301.0, toColor("#65001b")),
            ),
        )
    val airQualityIndexChinaCategories =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("#00ff00")),
                ColorStop(51.0, toColor("#ffff00")),
                ColorStop(101.0, toColor("#ff9900")),
                ColorStop(151.0, toColor("#ff0000")),
                ColorStop(201.0, toColor("#540099")),
                ColorStop(301.0, toColor("#800000")),
            ),
        )
    val airQualityIndexEaqiCategories =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("#50f0e6")),
                ColorStop(26.0, toColor("#50ccaa")),
                ColorStop(51.0, toColor("#f0e641")),
                ColorStop(76.0, toColor("#ff5050")),
                ColorStop(101.0, toColor("#960032")),
                ColorStop(126.0, toColor("#7d2181")),
            ),
        )
    val airQualityIndexIndiaCategories =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("#00cc00")),
                ColorStop(51.0, toColor("#66cc00")),
                ColorStop(101.0, toColor("#ffff00")),
                ColorStop(201.0, toColor("#ff9900")),
                ColorStop(301.0, toColor("#ff0000")),
                ColorStop(401.0, toColor("#a52a2a")),
            ),
        )
    val airQualityIndexUbaDaqiCategories =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("#50f0e6")),
                ColorStop(26.0, toColor("#50cdaa")),
                ColorStop(51.0, toColor("#f0e641")),
                ColorStop(76.0, toColor("#ff5050")),
                ColorStop(101.0, toColor("#960032")),
            ),
        )
    val airQualityIndexUkDaqiCategories =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("#009900")),
                ColorStop(1.5, toColor("#ff9900")),
                ColorStop(4.5, toColor("#ff0000")),
                ColorStop(7.5, toColor("#990099")),
            ),
        )
    val airQualityNo =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("rgba(7, 54, 161, 0)")),
                ColorStop(5.0, toColor("#0B8ACE")),
                ColorStop(25.0, toColor("#F2D538")),
                ColorStop(50.0, toColor("#F28012")),
                ColorStop(100.0, toColor("#DF0612")),
            ),
        )
    val airQualityNo2 =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("rgba(7, 54, 161, 0)")),
                ColorStop(10.0, toColor("#0B8ACE")),
                ColorStop(20.0, toColor("#F2D538")),
                ColorStop(30.0, toColor("#F28012")),
                ColorStop(50.0, toColor("#DF0612")),
                ColorStop(100.0, toColor("#980657")),
            ),
        )
    val airQualityO3 =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("rgba(7, 54, 161, 0)")),
                ColorStop(50.0, toColor("#0B8ACE")),
                ColorStop(100.0, toColor("#F2D538")),
                ColorStop(150.0, toColor("#F28012")),
                ColorStop(200.0, toColor("#DF0612")),
                ColorStop(300.0, toColor("#980657")),
            ),
        )
    val airQualityPm10 =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("rgba(7, 54, 161, 0)")),
                ColorStop(50.0, toColor("#0B8ACE")),
                ColorStop(100.0, toColor("#F2D538")),
                ColorStop(250.0, toColor("#F28012")),
                ColorStop(500.0, toColor("#DF0612")),
                ColorStop(1000.0, toColor("#980657")),
            ),
        )
    val airQualityPm2p5 =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("rgba(7, 54, 161, 0)")),
                ColorStop(25.0, toColor("#0B8ACE")),
                ColorStop(50.0, toColor("#F2D538")),
                ColorStop(100.0, toColor("#F28012")),
                ColorStop(200.0, toColor("#DF0612")),
                ColorStop(300.0, toColor("#980657")),
            ),
        )
    val airQualitySo2 =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("rgba(7, 54, 161, 0)")),
                ColorStop(5.0, toColor("#0B8ACE")),
                ColorStop(10.0, toColor("#F2D538")),
                ColorStop(25.0, toColor("#F28012")),
                ColorStop(50.0, toColor("#DF0612")),
                ColorStop(100.0, toColor("#980657")),
            ),
        )
    val convective =
        DataColorScale.Values(
            listOf(
                ColorValue("general", toColor("#b3e6b1"), "General"),
                ColorValue("marginal", toColor("#6cbd69"), "Marginal"),
                ColorValue("slight", toColor("#f4f964"), "Slight"),
                ColorValue("enhanced", toColor("#e0b767"), "Enhanced"),
                ColorValue("moderate", toColor("#e0686a"), "Moderate"),
                ColorValue("high", toColor("#fe59ff"), "High"),
            ),
        )
    val dewPoint =
        DataColorScale.Stops(
            listOf(
                ColorStop(-84.44, toColor("#fde3ff")),
                ColorStop(-78.89, toColor("#e0b6ec")),
                ColorStop(-73.33, toColor("#c38ad9")),
                ColorStop(-67.78, toColor("#a75ec6")),
                ColorStop(-62.22, toColor("#8f46b3")),
                ColorStop(-56.67, toColor("#782ea0")),
                ColorStop(-51.11, toColor("#61178e")),
                ColorStop(-45.56, toColor("#5d2d9d")),
                ColorStop(-40.0, toColor("#5943ac")),
                ColorStop(-34.44, toColor("#5559bc")),
                ColorStop(-30.28, toColor("#7f86dd")),
                ColorStop(-26.11, toColor("#aab4fe")),
                ColorStop(-21.94, toColor("#7f84a9")),
                ColorStop(-17.78, toColor("#555555")),
                ColorStop(-13.61, toColor("#62594f")),
                ColorStop(-9.44, toColor("#705e49")),
                ColorStop(-5.28, toColor("#816b57")),
                ColorStop(-1.11, toColor("#927865")),
                ColorStop(3.06, toColor("#a0938a")),
                ColorStop(7.22, toColor("#afafaf")),
                ColorStop(10.0, toColor("#5ee243")),
                ColorStop(15.56, toColor("#14b300")),
                ColorStop(21.11, toColor("#0e5e00")),
                ColorStop(26.67, toColor("#93a600")),
                ColorStop(32.22, toColor("#fff800")),
            ),
        )
    val droughtMonitor =
        DataColorScale.Values(
            listOf(
                ColorValue("D0", toColor("#ffff00"), "D0"),
                ColorValue("D1", toColor("#fccc66"), "D1"),
                ColorValue("D2", toColor("#ff9b00"), "D2"),
                ColorValue("D3", toColor("#e10000"), "D3"),
                ColorValue("D4", toColor("#600000"), "D4"),
            ),
        )
    val earthquake =
        DataColorScale.Values(
            listOf(
                ColorValue("mini", toColor("#6fb314"), "Minor"),
                ColorValue("minor", toColor("#dfcb01"), "Minor"),
                ColorValue("light", toColor("#ce8f00"), "Light"),
                ColorValue("moderate", toColor("#ff5d01"), "Moderate"),
                ColorValue("strong", toColor("#e90004"), "Strong"),
                ColorValue("major", toColor("#ce0052"), "Major"),
                ColorValue("great", toColor("#b90285"), "Great"),
                ColorValue("catastrophic", toColor("#f500ff"), "Catastrophic"),
            ),
        )
    val hailProbability =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("rgba(37,61,156,1)")),
                ColorStop(0.2, toColor("#253D9C")),
                ColorStop(0.4, toColor("#1D6AA2")),
                ColorStop(0.6, toColor("#09BB93")),
                ColorStop(0.8, toColor("#FEF112")),
                ColorStop(1.0, toColor("#FE5412")),
            ),
        )
    val hailThreat =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("#DE0ED3")),
                ColorStop(10.0, toColor("#C60ECC")),
                ColorStop(20.0, toColor("#B00EC6")),
                ColorStop(30.0, toColor("#980BC0")),
                ColorStop(40.0, toColor("#810CBA")),
                ColorStop(50.0, toColor("#690BB4")),
                ColorStop(60.0, toColor("#520BAE")),
            ),
        )
    val hailSize =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("rgba(132,0,170,0)")),
                ColorStop(1.0, toColor("#560073")),
                ColorStop(12.7, toColor("#68008B")),
                ColorStop(25.4, toColor("#7810FF")),
                ColorStop(38.1, toColor("#8695FF")),
                ColorStop(50.8, toColor("#8695FF")),
                ColorStop(63.5, toColor("#919CEA")),
                ColorStop(76.2, toColor("#DFE5ED")),
            ),
        )
    val humidity =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("#4b2b18")),
                ColorStop(10.0, toColor("#634a3b")),
                ColorStop(20.0, toColor("#7c695e")),
                ColorStop(30.0, toColor("#958881")),
                ColorStop(40.0, toColor("#aea7a4")),
                ColorStop(50.0, toColor("#c7c7c7")),
                ColorStop(60.0, toColor("#6aea55")),
                ColorStop(70.0, toColor("#18d200")),
                ColorStop(80.0, toColor("#14ab00")),
                ColorStop(90.0, toColor("#118400")),
                ColorStop(100.0, toColor("#0e5e00")),
            ),
        )
    val lightningDensity =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("rgba(255,235,122,0)")),
                ColorStop(1.0, toColor("#FFD800")),
                ColorStop(3.0, toColor("#FF7E00")),
                ColorStop(6.0, toColor("#ED0000")),
                ColorStop(8.0, toColor("#E400F0")),
                ColorStop(10.0, toColor("#EEC5F0")),
            ),
        )
    val lightningStrike =
        DataColorScale.Values(
            listOf(
                ColorValue(0.0, toColor("#eeeeee"), "< 1 minute"),
                ColorValue(60.0, toColor("#F8E203"), "1-5 minutes"),
                ColorValue(300.0, toColor("#F97000"), "5-10 minutes"),
                ColorValue(600.0, toColor("#C4150D"), "> 10 minutes"),
            ),
        )
    val lightningThreat =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("#F1DE01")),
                ColorStop(10.0, toColor("#EDBF02")),
                ColorStop(20.0, toColor("#EAA100")),
                ColorStop(30.0, toColor("#E68300")),
                ColorStop(40.0, toColor("#E46600")),
                ColorStop(50.0, toColor("#E14701")),
                ColorStop(60.0, toColor("#DE2900")),
            ),
        )
    val mslp =
        DataColorScale.Stops(
            listOf(
                ColorStop(950.0, toColor("#D08AFF")),
                ColorStop(960.0, toColor("#9A00FF")),
                ColorStop(970.0, toColor("#6401FF")),
                ColorStop(980.0, toColor("#0300B8")),
                ColorStop(990.0, toColor("#084ADA")),
                ColorStop(1000.0, toColor("#01CDFF")),
                ColorStop(1010.0, toColor("#23DC02")),
                ColorStop(1020.0, toColor("#FEF90B")),
                ColorStop(1030.0, toColor("#FE7B00")),
                ColorStop(1040.0, toColor("#FA0107")),
                ColorStop(1050.0, toColor("#970100")),
                ColorStop(1060.0, toColor("#DB5C5F")),
            ),
        )
    val oceanCurrent =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("rgba(16,145,253,0)")),
                ColorStop(0.5144, toColor("#1091FD")),
                ColorStop(0.7716, toColor("#37FF84")),
                ColorStop(1.0288, toColor("#B6FF06")),
                ColorStop(1.286, toColor("#FEE10A")),
                ColorStop(1.5432, toColor("#EFB80C")),
                ColorStop(1.8004, toColor("#FD8408")),
                ColorStop(2.0576, toColor("#F43305")),
                ColorStop(2.3148, toColor("#AB1406")),
                ColorStop(2.572, toColor("#931537")),
                ColorStop(3.0864, toColor("#A4168A")),
            ),
        )
    val prate =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("rgba(0,0,0,0)")),
                ColorStop(0.00002, toColor("rgba(113,255,194,0)")),
                ColorStop(0.00002, toColor("#71ffc2")),
                ColorStop(0.00004, toColor("#49eb3a")),
                ColorStop(0.00117, toColor("#114c00")),
                ColorStop(0.0032, toColor("#e4c700")),
                ColorStop(0.01351, toColor("#da0000")),
                ColorStop(0.05696, toColor("#7a0009")),
                ColorStop(0.11696, toColor("#9e0570")),
            ),
        )
    /** Matches MapsGL JS `weather/common/colors.ts` `precip_accum` (in/hr as mm/s via [inToMMRate]). */
    val precip_accum =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("#939593")),
                ColorStop(inToMMRate(0.0999999), toColor("#6D746B")),
                ColorStop(inToMMRate(0.1), toColor("#B8FF9C")),
                ColorStop(inToMMRate(0.5), toColor("#30D72F")),
                ColorStop(inToMMRate(1.0), toColor("#006C00")),
                ColorStop(inToMMRate(2.0), toColor("#FFFC0B")),
                ColorStop(inToMMRate(4.0), toColor("#DF1400")),
                ColorStop(inToMMRate(6.0), toColor("#860000")),
                ColorStop(inToMMRate(8.0), toColor("#4D014B")),
                ColorStop(inToMMRate(10.0), toColor("#E501E5")),
                ColorStop(inToMMRate(12.0), toColor("#FF91FF")),
                ColorStop(inToMMRate(14.0), toColor("#D6F1F4")),
                ColorStop(inToMMRate(16.0), toColor("#36E2F4")),
                ColorStop(inToMMRate(20.0), toColor("#00626C")),
                ColorStop(inToMMRate(25.0), toColor("#F1CCC2")),
                ColorStop(inToMMRate(30.0), toColor("#9F5F51")),
            ),
        )
    val radarRain =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("rgba(0,0,0,0)")),
                ColorStop(5.99, toColor("rgba(0,0,0,0)")),
                ColorStop(6.0, toColor("#8CF482")),
                ColorStop(10.0, toColor("#49eb3a")),
                ColorStop(33.0, toColor("#114c00")),
                ColorStop(40.0, toColor("#e4c700")),
                ColorStop(50.0, toColor("#da0000")),
                ColorStop(60.0, toColor("#7a0009")),
                ColorStop(65.0, toColor("#9e0570")),
                ColorStop(70.0, toColor("#dc42b1")),
                ColorStop(80.0, toColor("#dea8ff")),
                ColorStop(87.0, toColor("#faf3ff")),
            ),
        )
    val radarMix =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("rgba(0,0,0,0)")),
                ColorStop(5.9, toColor("rgba(255,163,249,0)")),
                ColorStop(6.0, toColor("#ffa3f9")),
                ColorStop(25.0, toColor("#d518be")),
                ColorStop(58.0, toColor("#58003c")),
                ColorStop(87.0, toColor("#58003c")),
            ),
        )
    val radarSnow =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("rgba(0,0,0,0)")),
                ColorStop(5.9, toColor("rgba(124,255,255,0)")),
                ColorStop(6.0, toColor("#7cffff")),
                ColorStop(7.0, toColor("#00e8ff")),
                ColorStop(25.0, toColor("#0061ea")),
                ColorStop(45.0, toColor("#0000af")),
                ColorStop(58.0, toColor("#5c00f5")),
                ColorStop(87.0, toColor("#5c00f5")),
            ),
        )
    val radarRateRain =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.00001, toColor("rgba(0,0,0,0)")),
                ColorStop(0.00002, toColor("rgba(0,0,0,0)")),
                ColorStop(0.00002, toColor("#8CF482")),
                ColorStop(0.00004, toColor("#49eb3a")),
                ColorStop(0.00117, toColor("#114c00")),
                ColorStop(0.0032, toColor("#e4c700")),
                ColorStop(0.01351, toColor("#da0000")),
                ColorStop(0.05696, toColor("#7a0009")),
                ColorStop(0.11696, toColor("#9e0570")),
                ColorStop(0.24019, toColor("#dc42b1")),
                ColorStop(1.01287, toColor("#dea8ff")),
                ColorStop(2.77366, toColor("#faf3ff")),
            ),
        )
    val radarRateMix =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.00001, toColor("rgba(0,0,0,0)")),
                ColorStop(0.00002, toColor("rgba(255,163,249,0)")),
                ColorStop(0.00002, toColor("#ffa3f9")),
                ColorStop(0.00037, toColor("#d518be")),
                ColorStop(0.04271, toColor("#58003c")),
                ColorStop(2.77366, toColor("#58003c")),
            ),
        )
    val radarRateSnow =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.00001, toColor("rgba(0,0,0,0)")),
                ColorStop(0.00002, toColor("rgba(124,255,255,0)")),
                ColorStop(0.00002, toColor("#7cffff")),
                ColorStop(0.00003, toColor("#00e8ff")),
                ColorStop(0.00037, toColor("#0061ea")),
                ColorStop(0.00658, toColor("#0000af")),
                ColorStop(0.04271, toColor("#5c00f5")),
                ColorStop(2.77366, toColor("#5c00f5")),
            ),
        )
    val sky =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("rgba(50, 50, 50, 0)")),
                ColorStop(50.0, toColor("rgba(100, 100, 100, 0.4)")),
                ColorStop(100.0, toColor("rgba(242, 242, 242, 1)")),
            ),
        )
    val snowdepth =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("rgba(96,96,96,0)")),
                ColorStop(0.00025, toColor("rgba(96,96,96,0)")),
                ColorStop(0.00254, toColor("rgba(96,96,96,0.5)")),
                ColorStop(0.0254, toColor("#576066")),
                ColorStop(0.0762, toColor("#85D3FF")),
                ColorStop(0.1524, toColor("#25B4FF")),
                ColorStop(0.3048, toColor("#012DFF")),
                ColorStop(0.4572, toColor("#7000D9")),
                ColorStop(0.6096, toColor("#FF49C4")),
                ColorStop(1.2192, toColor("#FFECF7")),
                ColorStop(1.8288, toColor("#36E2F4")),
                ColorStop(3.048, toColor("#007682")),
                ColorStop(4.2672, toColor("#C38EF2")),
                ColorStop(6.096, toColor("#A34AF2")),
                ColorStop(7.62, toColor("#7100FF")),
            ),
        )
    val stormcell =
        DataColorScale.Values(
            listOf(
                ColorValue("general", toColor("#2ED300"), "General"),
                ColorValue("hail", toColor("#EBE100"), "Hail"),
                ColorValue("rotating", toColor("#F17200"), "Rotating"),
                ColorValue("tornado", toColor("#FF2600"), "Tornado"),
            ),
        )
    val stormreport =
        DataColorScale.Values(
            listOf(
                ColorValue("avalanche", toColor("#629FEC"), "Avalanche"),
                ColorValue("blizzard", toColor("#4100E2"), "Blizzard"),
                ColorValue("fire", toColor("#E66300"), "Fire"),
                ColorValue("flood", toColor("#117D01"), "Flood"),
                ColorValue("fog", toColor("#767676"), "Fog"),
                ColorValue("ice", toColor("#B300E2"), "Ice"),
                ColorValue("hail", toColor("#61DEF7"), "Hail"),
                ColorValue("lightning", toColor("#8C8C8C"), "Lightning"),
                ColorValue("rain", toColor("#39E600"), "Rain"),
                ColorValue("snow", toColor("#165CEF"), "Snow"),
                ColorValue("tides", toColor("#40DB83"), "Tides"),
                ColorValue("tornado", toColor("#C50000"), "Tornado"),
                ColorValue("wind", toColor("#D8CC03"), "Wind"),
                ColorValue("tropical", toColor("#FF59B3"), "Tropical"),
            ),
        )
    val stormSurge =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("#091597")),
                ColorStop(0.6096, toColor("#04C9FC")),
                ColorStop(1.2192, toColor("#8CFB37")),
                ColorStop(1.8288, toColor("#FCFA3A")),
                ColorStop(2.4384, toColor("#FF6116")),
                ColorStop(3.048, toColor("#FF040B")),
                ColorStop(3.6576, toColor("#79003C")),
                ColorStop(4.2672, toColor("#FF2391")),
                ColorStop(4.8768, toColor("#FFE0FF")),
            ),
        )
    val tempChange1Hour =
        DataColorScale.Stops(
            listOf(
                ColorStop(-22.2, toColor("#EF90FF")),
                ColorStop(-13.875, toColor("#D741DA")),
                ColorStop(-8.325, toColor("#8B21DA")),
                ColorStop(-5.55, toColor("#0070F1")),
                ColorStop(-2.775, toColor("#8ED4F9")),
                ColorStop(-0.555, toColor("rgba(142,212,249,0)")),
                ColorStop(0.0, toColor("rgba(0,0,0,0)")),
                ColorStop(0.555, toColor("rgba(255,217,42,0)")),
                ColorStop(2.775, toColor("#FFD92A")),
                ColorStop(5.55, toColor("#FF932A")),
                ColorStop(8.325, toColor("#E2330B")),
                ColorStop(19.425, toColor("#9D0000")),
                ColorStop(22.2, toColor("#D00071")),
            ),
        )
    val tempChange24Hour =
        DataColorScale.Stops(
            listOf(
                ColorStop(-33.3, toColor("#EF90FF")),
                ColorStop(-27.75, toColor("#D741DA")),
                ColorStop(-22.2, toColor("#8B21DA")),
                ColorStop(-16.65, toColor("#0013CA")),
                ColorStop(-11.1, toColor("#0070F1")),
                ColorStop(-5.55, toColor("#8ED4F9")),
                ColorStop(-0.555, toColor("rgba(142,212,249,0)")),
                ColorStop(0.0, toColor("rgba(0,0,0,0)")),
                ColorStop(0.555, toColor("rgba(255,217,42,0)")),
                ColorStop(5.55, toColor("#FFD92A")),
                ColorStop(11.1, toColor("#FF932A")),
                ColorStop(16.65, toColor("#E2330B")),
                ColorStop(22.2, toColor("#9D0000")),
                ColorStop(27.75, toColor("#D00071")),
                ColorStop(33.3, toColor("#FF698C")),
            ),
        )
    val temperature =
        DataColorScale.Stops(
            listOf(
                ColorStop(-90.0, toColor("#bef7ff")),
                ColorStop(-84.44, toColor("#00c7fb")),
                ColorStop(-78.89, toColor("#0075b6")),
                ColorStop(-73.33, toColor("#1B0084")),
                ColorStop(-67.78, toColor("#6100FF")),
                ColorStop(-62.22, toColor("#D592FF")),
                ColorStop(-56.67, toColor("#D150FF")),
                ColorStop(-51.11111, toColor("#8f00ca")),
                ColorStop(-45.55556, toColor("#630078")),
                ColorStop(-40.0, toColor("#a50099")),
                ColorStop(-34.44444, toColor("#ed00dc")),
                ColorStop(-28.88889, toColor("#f671ff")),
                ColorStop(-23.33333, toColor("#dcc1ed")),
                ColorStop(-17.77778, toColor("#1b007b")),
                ColorStop(-12.22222, toColor("#6e51ff")),
                ColorStop(-6.66667, toColor("#9bb6ff")),
                ColorStop(-1.11111, toColor("#18a5fc")),
                ColorStop(4.44444, toColor("#0900e7")),
                ColorStop(10.0, toColor("#14b000")),
                ColorStop(15.55556, toColor("#f5d508")),
                ColorStop(21.11111, toColor("#e17200")),
                ColorStop(26.66667, toColor("#f33300")),
                ColorStop(32.22222, toColor("#d00000")),
                ColorStop(37.77778, toColor("#720000")),
                ColorStop(43.33333, toColor("#ce0046")),
                ColorStop(48.88889, toColor("#ff4b98")),
                ColorStop(54.44, toColor("#ffadad")),
                ColorStop(60.0, toColor("#9f0000")),
                ColorStop(65.56, toColor("#ca4931")),
                ColorStop(71.11, toColor("#e9a696")),
            ),
        )
    val tideHeight =
        DataColorScale.Stops(
            listOf(
                ColorStop(-12.192, toColor("#EF90FF")),
                ColorStop(-9.144, toColor("#D741DA")),
                ColorStop(-6.096, toColor("#8B21DA")),
                ColorStop(-4.572, toColor("#0013CA")),
                ColorStop(-3.048, toColor("#0070F1")),
                ColorStop(-1.524, toColor("#8ED4F9")),
                ColorStop(-0.6096, toColor("rgba(142,212,249,0)")),
                ColorStop(0.0, toColor("rgba(0,0,0,0)")),
                ColorStop(0.6096, toColor("rgba(255,217,42,0)")),
                ColorStop(1.524, toColor("#FFD92A")),
                ColorStop(3.048, toColor("#FF932A")),
                ColorStop(4.572, toColor("#E2330B")),
                ColorStop(6.096, toColor("#9D0000")),
                ColorStop(9.144, toColor("#D00071")),
                ColorStop(12.192, toColor("#FF698C")),
            ),
        )
    val tropicalCyclone =
        DataColorScale.Values(
            listOf(
                ColorValue("LO", toColor("#4875FB"), "LO"),
                ColorValue("I", toColor("#4875FB"), "I"),
                ColorValue("TD", toColor("#FFE700"), "TD"),
                ColorValue("TS", toColor("#FEA800"), "TS"),
                ColorValue("H1", toColor("#DD0002"), "H1"),
                ColorValue("H2", toColor("#FF0491"), "H2"),
                ColorValue("H3", toColor("#DD00FD"), "H3"),
                ColorValue("H4", toColor("#FEAFFF"), "H4"),
                ColorValue("H5", toColor("#EFEFEF"), "H5"),
                ColorValue("TY", toColor("#DD0002"), "TY"),
                ColorValue("STY", toColor("#EFEFEF"), "STY"),
            ),
        )
    val uvi =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("rgba(0,0,0,0)")),
                ColorStop(1.0, toColor("#409F3F")),
                ColorStop(3.0, toColor("#FBFF00")),
                ColorStop(6.0, toColor("#DF8000")),
                ColorStop(8.0, toColor("#DF4000")),
                ColorStop(12.0, toColor("#C05FC0")),
            ),
        )
    val visibility =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("#ffb400")),
                ColorStop(4023.35, toColor("#ffea00")),
                ColorStop(8046.7, toColor("rgba(255, 255, 173, 0.5)")),
                ColorStop(16093.4, toColor("rgba(162, 162, 162, 0)")),
            ),
        )
    val waveHeight =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("#091597")),
                ColorStop(2.43, toColor("#04C9FC")),
                ColorStop(4.88, toColor("#8CFB37")),
                ColorStop(6.09, toColor("#FCFA3A")),
                ColorStop(7.3, toColor("#FF6116")),
                ColorStop(8.53, toColor("#FF040B")),
                ColorStop(10.36, toColor("#79003C")),
                ColorStop(12.19, toColor("#FF2391")),
                ColorStop(14.26, toColor("#FFE0FF")),
            ),
        )
    val wavePeriod =
        DataColorScale.Stops(
            listOf(
                ColorStop(2.0, toColor("#091597")),
                ColorStop(6.0, toColor("#0030AE")),
                ColorStop(10.0, toColor("#04C9FC")),
                ColorStop(14.0, toColor("#8CFB37")),
                ColorStop(16.0, toColor("#FCFA3A")),
                ColorStop(18.0, toColor("#FF6116")),
                ColorStop(20.0, toColor("#FF040B")),
                ColorStop(22.0, toColor("#79003C")),
                ColorStop(24.0, toColor("#FF2391")),
            ),
        )
    val windSpeed =
        DataColorScale.Stops(
            listOf(
                ColorStop(0.0, toColor("rgba(0,0,0,0)")),
                ColorStop(1.1176, toColor("#0050ff")),
                ColorStop(3.3528, toColor("#1bd3ff")),
                ColorStop(4.4704, toColor("#34ff87")),
                ColorStop(5.588, toColor("#72ff09")),
                ColorStop(6.7056, toColor("#b4ff08")),
                ColorStop(7.8232, toColor("#efff0b")),
                ColorStop(8.9408, toColor("#fee20a")),
                ColorStop(11.176, toColor("#f0b90a")),
                ColorStop(13.4112, toColor("#ed9909")),
                ColorStop(15.6464, toColor("#fd8609")),
                ColorStop(17.8816, toColor("#fd5d08")),
                ColorStop(20.0, toColor("#fb3706")),
                ColorStop(22.352, toColor("#c71506")),
                ColorStop(26.8224, toColor("#731005")),
                ColorStop(33.081, toColor("#D01DC7")),
                ColorStop(42.91584, toColor("#FFB1FB")),
                ColorStop(49.62144, toColor("#C8F0F4")),
                ColorStop(53.64, toColor("#36E2F4")),
                ColorStop(57.65856, toColor("#00626C")),
            ),
        )
}
