//
//  Datasets.kt
//
//  NOTE: This file is auto-generated and should not be edited directly!
//  Last updated: 2026-03-12T20:12:16.101Z
//

package com.xweather.mapsgl.weather

import com.xweather.mapsgl.types.ColorBand
import com.xweather.mapsgl.utils.TimeIntervalSeconds

enum class VectorComponent(
    val value: String,
) {
    u("U"),
    v("V"),
}

enum class MaritimeSurgeLevel(
    val value: Int,
) {
    primary(1),
    secondary(2),
    tertiary(3),
}

interface EncodedDataset {
    val code: String
    var band: ColorBand?
    val dataRange: ClosedRange<Double>
    val noData: Double?
    var timeOffset: TimeIntervalSeconds?
}

data class EncodedDataGroup(
    var id: String,
    var datasets: List<EncodedDataset>,
)

data class TemperatureDataset(
    // typealias UnitType =
    override var code: String = "weather-surface_TMP_2-HTGL",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = -62.22..54.44,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class WindDataset(
    // typealias UnitType =
    override var code: String = "weather-surface_{component}GRD_10-HTGL",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = -53.64..53.64,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
    var component: VectorComponent,
) : EncodedDataset {
    init {
        code = code.replace("{component}", component.value)
    }
}

data class WindGustDataset(
    // typealias UnitType =
    override var code: String = "weather-surface_GUST_10-HTGL",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..53.64,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class DewPointDataset(
    // typealias UnitType =
    override var code: String = "weather-surface_DPT_2-HTGL",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = -84.44..32.22,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class HumidityDataset(
    // typealias UnitType =
    override var code: String = "weather-surface_RH_2-HTGL",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..100.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class FeelsLikeDataset(
    // typealias UnitType =
    override var code: String = "weather-surface_APTMP_2-HTGL",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = -62.22..54.44,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class MeanSeaLevelPressureDataset(
    // typealias UnitType =
    override var code: String = "weather-surface_PRMSL_0-MSL",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 950.0..1060.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class VisibilityDataset(
    // typealias UnitType =
    override var code: String = "weather-surface_VIS_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..16093.4,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class CloudCoverDataset(
    // typealias UnitType =
    override var code: String = "weather-surface_TCDC_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..100.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class PrecipitationTypeDataset(
    // typealias UnitType =
    override var code: String = "weather-surface_PTYPE_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..255.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class PrecipitationRateDataset(
    // typealias UnitType =
    override var code: String = "weather-surface_PRATE_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..0.21167,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class SnowDepthDataset(
    // typealias UnitType =
    override var code: String = "forecast_SNOD_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..7.9248,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class UVIndexDataset(
    // typealias UnitType =
    override var code: String = "conditions_UVI_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..12.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class RadarDbzArchiveDataset(
    // typealias UnitType =
    override var code: String = "radar-composite_REFC_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..87.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class RadarPrecipitationRateArchiveDataset(
    // typealias UnitType =
    override var code: String = "radar-composite_PRATE_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..0.11696,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class RadarPrecipitationTypeArchiveDataset(
    // typealias UnitType =
    override var code: String = "radar-composite_PTYPESMPL_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..255.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class RadarDbzNowcastDataset(
    // typealias UnitType =
    override var code: String = "nowcast-composite_REFC_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..87.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class RadarPrecipitationRateNowcastDataset(
    // typealias UnitType =
    override var code: String = "nowcast-composite_PRATE_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..0.11696,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class RadarPrecipitationTypeNowcastDataset(
    // typealias UnitType =
    override var code: String = "nowcast-composite_PTYPESMPL_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..255.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class RadarDbzDataset(
    // typealias UnitType =
    override var code: String = "precip_REFC_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..87.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class RadarPrecipitationRateDataset(
    // typealias UnitType =
    override var code: String = "precip_PRATE_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..0.11696,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class RadarPrecipitationTypeDataset(
    // typealias UnitType =
    override var code: String = "precip_PTYPESMPL_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..255.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class AirQualityIndexAirNowDataset(
    // typealias UnitType =
    override var code: String = "air-quality_AQI-AirNow_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..500.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class AirQualityHealthIndexDataset(
    // typealias UnitType =
    override var code: String = "air-quality_AQHI-Canada_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..20.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class AirQualityIndexChinaDataset(
    // typealias UnitType =
    override var code: String = "air-quality_AQI-China_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..500.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class AirQualityIndexIndiaDataset(
    // typealias UnitType =
    override var code: String = "air-quality_AQI-India_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..500.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class AirQualityIndexEAQIDataset(
    // typealias UnitType =
    override var code: String = "air-quality_AQI-EAQI_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..150.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class AirQualityIndexCAIDataset(
    // typealias UnitType =
    override var code: String = "air-quality_AQI-CAI_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..500.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class AirQualityIndexCAQIDataset(
    // typealias UnitType =
    override var code: String = "air-quality_AQI-CAQI_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..200.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class AirQualityIndexUBADAQIDataset(
    // typealias UnitType =
    override var code: String = "air-quality_AQI-UBA-DAQI_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..125.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class AirQualityIndexUKDAQIDataset(
    // typealias UnitType =
    override var code: String = "air-quality_AQI-UK-DAQI_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..10.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class CarbonMonoxideDataset(
    // typealias UnitType =
    override var code: String = "air-quality_CO_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..1000.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class NitrogenMonoxideDataset(
    // typealias UnitType =
    override var code: String = "air-quality_NO_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..100.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class NitrogenDioxideDataset(
    // typealias UnitType =
    override var code: String = "air-quality_NO2_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..100.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class OzoneDataset(
    // typealias UnitType =
    override var code: String = "air-quality_O3_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..300.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class ParticulateMatter25Dataset(
    // typealias UnitType =
    override var code: String = "air-quality_PM2P5_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..300.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class ParticulateMatter10Dataset(
    // typealias UnitType =
    override var code: String = "air-quality_PM10_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..1000.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class SulfurDioxideDataset(
    // typealias UnitType =
    override var code: String = "air-quality_SO2_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..100.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class WaveHeightDataset(
    // typealias UnitType =
    override var code: String = "marine_HTSGW_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..15.0,
    override var noData: Double? = 0.0,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class WaveDirectionDataset(
    // typealias UnitType =
    override var code: String = "marine_DIRPW_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..359.0,
    override var noData: Double? = 0.0,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class WavePeriodDataset(
    // typealias UnitType =
    override var code: String = "marine_PERPW_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..24.0,
    override var noData: Double? = 0.0,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class SwellHeightDataset(
    // typealias UnitType =
    override var code: String = "marine_SWELL_{level}-SEQ",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..15.0,
    override var noData: Double? = 0.0,
    override var timeOffset: TimeIntervalSeconds? = null,
    var level: MaritimeSurgeLevel,
) : EncodedDataset {
    init {
        code = code.replace("{level}", level.value.toString())
    }
}

data class SwellPeriodDataset(
    // typealias UnitType =
    override var code: String = "marine_SWPER_{level}-SEQ",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..24.0,
    override var noData: Double? = 0.0,
    override var timeOffset: TimeIntervalSeconds? = null,
    var level: MaritimeSurgeLevel,
) : EncodedDataset {
    init {
        code = code.replace("{level}", level.value.toString())
    }
}

data class SwellDirectionDataset(
    // typealias UnitType =
    override var code: String = "marine_SWDIR_{level}-SEQ",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..359.0,
    override var noData: Double? = 0.0,
    override var timeOffset: TimeIntervalSeconds? = null,
    var level: MaritimeSurgeLevel,
) : EncodedDataset {
    init {
        code = code.replace("{level}", level.value.toString())
    }
}

data class OceanCurrentDataset(
    // typealias UnitType =
    override var code: String = "marine_{component}OGRD_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = -3.0864..3.0864,
    override var noData: Double? = 0.0,
    override var timeOffset: TimeIntervalSeconds? = null,
    var component: VectorComponent,
) : EncodedDataset {
    init {
        code = code.replace("{component}", component.value)
    }
}

data class SeaSurfaceTemperatureDataset(
    // typealias UnitType =
    override var code: String = "marine_WTMP_0-SFC",
    override var band: ColorBand? = null,
    //override var dataRange: ClosedRange<Double> = -100.0..100.0,
    override var dataRange: ClosedRange<Double> = -90.0..70.0,
    override var noData: Double? = 0.0,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class SurgeDataset(
    // typealias UnitType =
    override var code: String = "marine_SURGE_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..5.0,
    override var noData: Double? = 0.0,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class TideDataset(
    // typealias UnitType =
    override var code: String = "marine_TIDE_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = -12.192..12.192,
    override var noData: Double? = 0.0,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class RoadSummaryDataset(
    // typealias UnitType =
    override var code: String = "roadSeverity_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..0.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class RoadSurfaceDataset(
    // typealias UnitType =
    override var code: String = "roadCondition_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..0.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class RoadTemperatureDataset(
    // typealias UnitType =
    override var code: String = "roadTemperature_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = -62.22..54.44,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class RoadTemperatureFreezeDataset(
    // typealias UnitType =
    override var code: String = "roadTemperature_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = -62.22..54.44,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class RoadRiskRolloverDataset(
    // typealias UnitType =
    override var code: String = "roadRiskRollover_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..0.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class RoadRiskHydroplaneDataset(
    // typealias UnitType =
    override var code: String = "hydroplaneRisk_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..0.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class RoadRiskLowVisibilitySnowDataset(
    // typealias UnitType =
    override var code: String = "roadRiskSnow_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..0.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class RoadRiskLowVisibilityFogDataset(
    // typealias UnitType =
    override var code: String = "roadRiskFog_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..0.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
) : EncodedDataset

data class LightningDensityCloudtoGroundDataset(
    // typealias UnitType =
    override var code: String = "lightning-density-archive-{region}_LIGHTNING-STRIKES-CG_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..10.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
    var region: String,
) : EncodedDataset {
    init {
        code = code.replace("{region}", region)
    }
}

data class LightningDensityIntraCloudDataset(
    // typealias UnitType =
    override var code: String = "lightning-density-archive-{region}_LIGHTNING-STRIKES-IC_0-EATM",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..10.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
    var region: String,
) : EncodedDataset {
    init {
        code = code.replace("{region}", region)
    }
}

data class HailSizeDataset(
    // typealias UnitType =
    override var code: String = "hail-threats-archive-{region}_MESH_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..101.6,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
    var region: String,
) : EncodedDataset {
    init {
        code = code.replace("{region}", region)
    }
}

data class HailSevereProbabilityDataset(
    // typealias UnitType =
    override var code: String = "hail-threats-archive-{region}_POSH_0-SFC",
    override var band: ColorBand? = null,
    override var dataRange: ClosedRange<Double> = 0.0..100.0,
    override var noData: Double? = null,
    override var timeOffset: TimeIntervalSeconds? = null,
    var region: String,
) : EncodedDataset {
    init {
        code = code.replace("{region}", region)
    }
}

// MARK: - Dataset Groups

object DatasetGroups {
    var conditions_TMP2_UGRD10_VGRD10 =
        EncodedDataGroup(
            id = WeatherSource.SourceCode.conditions_TMP2_UGRD10_VGRD10.toString(),
            datasets =
                listOf(
                    TemperatureDataset(),
                    WindDataset(component = VectorComponent.u),
                    WindDataset(component = VectorComponent.v),
                ),
        )

    var conditions_TMP2_DELTA =
        EncodedDataGroup(
            id = WeatherSource.SourceCode.conditions_TMP2_DELTA.toString(),
            datasets =
                listOf(
                    TemperatureDataset(),
                    TemperatureDataset(timeOffset = TimeIntervalSeconds(-86400)),
                    TemperatureDataset(timeOffset = TimeIntervalSeconds(-7200)),
                ),
        )

    var conditions_TMP2_DPT2_RH2 =
        EncodedDataGroup(
            id = WeatherSource.SourceCode.conditions_TMP2_DPT2_RH2.toString(),
            datasets =
                listOf(
                    TemperatureDataset(),
                    DewPointDataset(),
                    HumidityDataset(),
                ),
        )

    var conditions_APTMP2_DPT2_RH2 =
        EncodedDataGroup(
            id = WeatherSource.SourceCode.conditions_APTMP2_DPT2_RH2.toString(),
            datasets =
                listOf(
                    FeelsLikeDataset(),
                    DewPointDataset(),
                    HumidityDataset(),
                ),
        )

    var conditions_PRMSL_VIS_GUST10 =
        EncodedDataGroup(
            id = WeatherSource.SourceCode.conditions_PRMSL_VIS_GUST10.toString(),
            datasets =
                listOf(
                    MeanSeaLevelPressureDataset(),
                    VisibilityDataset(),
                    WindGustDataset(),
                ),
        )

    var conditions_SNOD =
        EncodedDataGroup(
            id = WeatherSource.SourceCode.conditions_SNOD.toString(),
            datasets =
                listOf(
                    SnowDepthDataset(),
                ),
        )

    var conditions_TCDC_PRECIP_UVI =
        EncodedDataGroup(
            id = WeatherSource.SourceCode.conditions_TCDC_PRECIP_UVI.toString(),
            datasets =
                listOf(
                    CloudCoverDataset(),
                    PrecipitationRateDataset(),
                    UVIndexDataset(),
                ),
        )

    var conditions_PTYPE_PRECIP_TMP2 =
        EncodedDataGroup(
            id = WeatherSource.SourceCode.conditions_PTYPE_PRECIP_TMP2.toString(),
            datasets =
                listOf(
                    PrecipitationTypeDataset(),
                    PrecipitationRateDataset(),
                    TemperatureDataset(),
                ),
        )

    var conditions_PRECIP =
        EncodedDataGroup(
            id = WeatherSource.SourceCode.conditions_PRECIP.toString(),
            datasets =
                listOf(
                    PrecipitationRateDataset(),
                    PrecipitationRateDataset(),
                    PrecipitationRateDataset(),
                ),
        )

    var conditions_SNOW_PRECIP_TMP2 =
        EncodedDataGroup(
            id = WeatherSource.SourceCode.conditions_SNOW_PRECIP_TMP2.toString(),
            datasets =
                listOf(
                    PrecipitationRateDataset(),
                    PrecipitationRateDataset(),
                    TemperatureDataset(),
                ),
        )

    var radar_REFC_PRATE_PTYPESMPL =
        EncodedDataGroup(
            id = WeatherSource.SourceCode.radar_REFC_PRATE_PTYPESMPL.toString(),
            datasets =
                listOf(
                    RadarDbzDataset(),
                    RadarPrecipitationTypeDataset(),
                    RadarDbzArchiveDataset(),
                ),
        )

    var airquality_AQI_AirNow_PM2P5_PM10 =
        EncodedDataGroup(
            id = WeatherSource.SourceCode.airquality_AQI_AirNow_PM2P5_PM10.toString(),
            datasets =
                listOf(
                    AirQualityIndexAirNowDataset(),
                    ParticulateMatter25Dataset(),
                    ParticulateMatter10Dataset(),
                ),
        )

    var airquality_AQI_AQHI_AQI_China_AQI_India =
        EncodedDataGroup(
            id = WeatherSource.SourceCode.airquality_AQI_AQHI_AQI_China_AQI_India.toString(),
            datasets =
                listOf(
                    AirQualityHealthIndexDataset(),
                    AirQualityIndexChinaDataset(),
                    AirQualityIndexIndiaDataset(),
                ),
        )

    var airquality_AQI_EAQI_AQI_UBA_DAQI_AQI_UK_DAQI =
        EncodedDataGroup(
            id = WeatherSource.SourceCode.airquality_AQI_EAQI_AQI_UBA_DAQI_AQI_UK_DAQI.toString(),
            datasets =
                listOf(
                    AirQualityIndexEAQIDataset(),
                    AirQualityIndexUBADAQIDataset(),
                    AirQualityIndexUKDAQIDataset(),
                ),
        )

    var airquality_AQI_CAI_AQI_CAQI =
        EncodedDataGroup(
            id = WeatherSource.SourceCode.airquality_AQI_CAI_AQI_CAQI.toString(),
            datasets =
                listOf(
                    AirQualityIndexCAIDataset(),
                    AirQualityIndexCAQIDataset(),
                ),
        )

    var airquality_CO_NO_NO2 =
        EncodedDataGroup(
            id = WeatherSource.SourceCode.airquality_CO_NO_NO2.toString(),
            datasets =
                listOf(
                    CarbonMonoxideDataset(),
                    NitrogenMonoxideDataset(),
                    NitrogenDioxideDataset(),
                ),
        )

    var airquality_O3_SO2 =
        EncodedDataGroup(
            id = WeatherSource.SourceCode.airquality_O3_SO2.toString(),
            datasets =
                listOf(
                    OzoneDataset(),
                    SulfurDioxideDataset(),
                ),
        )

    var maritime_HTSGW_DIRPW_PERPW =
        EncodedDataGroup(
            id = WeatherSource.SourceCode.maritime_HTSGW_DIRPW_PERPW.toString(),
            datasets =
                listOf(
                    WaveHeightDataset(),
                    WavePeriodDataset(),
                    WaveDirectionDataset(),
                ),
        )

    var maritime_SWELL1_SWPER1_SWDIR1 =
        EncodedDataGroup(
            id = WeatherSource.SourceCode.maritime_SWELL1_SWPER1_SWDIR1.toString(),
            datasets =
                listOf(
                    SwellHeightDataset(level = MaritimeSurgeLevel.primary),
                    SwellPeriodDataset(level = MaritimeSurgeLevel.primary),
                    SwellDirectionDataset(level = MaritimeSurgeLevel.primary),
                ),
        )

    var maritime_SWELL2_SWPER2_SWDIR2 =
        EncodedDataGroup(
            id = WeatherSource.SourceCode.maritime_SWELL2_SWPER2_SWDIR2.toString(),
            datasets =
                listOf(
                    SwellHeightDataset(level = MaritimeSurgeLevel.secondary),
                    SwellPeriodDataset(level = MaritimeSurgeLevel.secondary),
                    SwellDirectionDataset(level = MaritimeSurgeLevel.secondary),
                ),
        )

    var maritime_SWELL3_SWPER3_SWDIR3 =
        EncodedDataGroup(
            id = WeatherSource.SourceCode.maritime_SWELL3_SWPER3_SWDIR3.toString(),
            datasets =
                listOf(
                    SwellHeightDataset(level = MaritimeSurgeLevel.tertiary),
                    SwellPeriodDataset(level = MaritimeSurgeLevel.tertiary),
                    SwellDirectionDataset(level = MaritimeSurgeLevel.tertiary),
                ),
        )

    var maritime_WTMP_UOGRD_VOGRD =
        EncodedDataGroup(
            id = WeatherSource.SourceCode.maritime_WTMP_UOGRD_VOGRD.toString(),
            datasets =
                listOf(
                    SeaSurfaceTemperatureDataset(),
                    OceanCurrentDataset(component = VectorComponent.u),
                    OceanCurrentDataset(component = VectorComponent.v),
                ),
        )

    var maritime_SURGE_TIDE =
        EncodedDataGroup(
            id = WeatherSource.SourceCode.maritime_SURGE_TIDE.toString(),
            datasets =
                listOf(
                    SurgeDataset(),
                    TideDataset(),
                ),
        )

    var severe_hail_MESH_POSH_us =
        EncodedDataGroup(
            id = WeatherSource.SourceCode.severe_hail_MESH_POSH_us.toString(),
            datasets =
                listOf(
                    HailSizeDataset(region = "conus"),
                    HailSevereProbabilityDataset(region = "conus"),
                ),
        )

    var severe_hail_MESH_POSH_europe =
        EncodedDataGroup(
            id = WeatherSource.SourceCode.severe_hail_MESH_POSH_europe.toString(),
            datasets =
                listOf(
                    HailSizeDataset(region = "europe"),
                    HailSevereProbabilityDataset(region = "europe"),
                ),
        )

    var severe_hail_MESH_POSH_japan =
        EncodedDataGroup(
            id = WeatherSource.SourceCode.severe_hail_MESH_POSH_japan.toString(),
            datasets =
                listOf(
                    HailSizeDataset(region = "japan"),
                    HailSevereProbabilityDataset(region = "japan"),
                ),
        )

    var severe_hail_MESH_POSH_australia =
        EncodedDataGroup(
            id = WeatherSource.SourceCode.severe_hail_MESH_POSH_australia.toString(),
            datasets =
                listOf(
                    HailSizeDataset(region = "australia"),
                    HailSevereProbabilityDataset(region = "australia"),
                ),
        )

    var severe_lightning_LGT_IC_LGT_CG_us =
        EncodedDataGroup(
            id = WeatherSource.SourceCode.severe_lightning_LGT_IC_LGT_CG_us.toString(),
            datasets =
                listOf(
                    LightningDensityCloudtoGroundDataset(region = "conus"),
                    LightningDensityIntraCloudDataset(region = "conus"),
                    LightningDensityCloudtoGroundDataset(region = "conus"),
                ),
        )

    var severe_lightning_LGT_IC_LGT_CG_europe =
        EncodedDataGroup(
            id = WeatherSource.SourceCode.severe_lightning_LGT_IC_LGT_CG_europe.toString(),
            datasets =
                listOf(
                    LightningDensityCloudtoGroundDataset(region = "europe"),
                    LightningDensityIntraCloudDataset(region = "europe"),
                    LightningDensityCloudtoGroundDataset(region = "europe"),
                ),
        )

    var severe_lightning_LGT_IC_LGT_CG_japan =
        EncodedDataGroup(
            id = WeatherSource.SourceCode.severe_lightning_LGT_IC_LGT_CG_japan.toString(),
            datasets =
                listOf(
                    LightningDensityCloudtoGroundDataset(region = "japan"),
                    LightningDensityIntraCloudDataset(region = "japan"),
                    LightningDensityCloudtoGroundDataset(region = "japan"),
                ),
        )

    var severe_lightning_LGT_IC_LGT_CG_australia =
        EncodedDataGroup(
            id = WeatherSource.SourceCode.severe_lightning_LGT_IC_LGT_CG_australia.toString(),
            datasets =
                listOf(
                    LightningDensityCloudtoGroundDataset(region = "australia"),
                    LightningDensityIntraCloudDataset(region = "australia"),
                    LightningDensityCloudtoGroundDataset(region = "australia"),
                ),
        )
}
