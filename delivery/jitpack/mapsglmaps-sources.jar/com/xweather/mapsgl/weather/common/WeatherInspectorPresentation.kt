package com.xweather.mapsgl.weather.common

import android.annotation.SuppressLint
import android.icu.text.SimpleDateFormat
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.mapbox.maps.QueriedRenderedFeature
import java.util.Date
import java.util.Locale
import kotlin.math.abs


enum class PresentationType {
    ACCUM_PRECIP, ALERTS, ANGLE,
    /** Maritime wave/swell gridded layers only ([MaritimeGriddedArrows]): +180° before [Units.degToDir] (N↔S, E↔W). */
    ANGLE_REVERSED,
    BASIC, CONVECTIVE, DIRECTION, DISTANCE, DROUGHT, EARTHQUAKE,
    HEIGHT, HEIGHT_CHANGE, HUMIDITY, INDEX, LIGHTNING_DENSITY, PERIOD, PERCENTAGE, POINTS, POLLUTANT, PRECIPITATION,
    PRESSURE, RADAR, RIVER_OBSERVATION, SIZE, SNOW_DEPTH, SNOWFALL, STORM_CELL, STORM_REPORT, TEMPERATURE,
    TEMPERATURE_CHANGE, THREAT, WAVE_HEIGHT, WILDFIRE, WIND_GUST, WIND_SPEED,
    /**
     * Compass string for [com.xweather.mapsgl.types.SampleExpression.ENCODED_WIND_UV] / instanced gridded arrows.
     * [value] is vertex **rotDeg** (vector blend of phases on GPU), not raw atan2(u,-v). Do not use [DIRECTION].
     */
    GRIDDED_ENC_WIND_UV_DIRECTION,
}

object Units {
    fun CtoF(celsius: Double): Double = celsius * 9.0 / 5.0 + 32.0
    fun CtoF(celsius: Number): Double = celsius.toDouble() * 9.0 / 5.0 + 32.0
    fun CtoFUnit(celsius: Double): Double = celsius * 9.0 / 5.0 // Assuming this is for change, so no +32
    fun msToKph(ms: Number): Double = ms.toDouble() * 3.6
    fun msToKph(ms: Double): Double = ms * 3.6
    fun msToMph(ms: Double): Double = ms * 2.23694
    fun msToMph(ms: Number): Double = ms.toDouble() * 2.23694
    fun degToDir(degrees: Double): String {
        val directions = listOf(
            "↓ N",
            "↓ NNE",
            "↙ NE",
            "← ENE",
            " ← E",
            "← ESE",
            "↖ SE",
            "↑ SSE",
            "↑ S",
            "↑ SSW",
            "↗ SW",
            "→ WSW",
            "→ W",
            "→ WNW",
            "↘ NW",
            "↓ NNW"
        )
        val index = ((degrees % 360 + 360) % 360 / 22.5).toInt()
        return directions[index]
    }

    fun degToDir(degrees: Float): String {
        return degToDir(degrees.toDouble())
    }

    /**
     * [vertexRotDeg] is the instanced-vertex rotation (after per-phase atan2(u,-v) → unit vectors → mix → atan2),
     * same as [com.xweather.mapsgl.layers.tile.EncodedTileLayer] returns for [SampleExpression.ENCODED_WIND_UV].
     * Maps to compass-from-north for [degToDir] glyphs (north-up map).
     */
    fun degToDirForGriddedWindUv(vertexRotDeg: Double): String {
        val bearingFromNorth = (vertexRotDeg + 90.0 + 720.0) % 360.0
        return degToDir(bearingFromNorth)
    }

    fun mbToHg(mb: Double): Double = mb * 0.02953
    fun mToKm(meters: Double): Double = meters / 1000.0
    fun mToMi(meters: Double): Double = meters * 0.000621371
    fun mToFt(meters: Double): Double = meters * 3.28084
    fun mmToIn(mm: Double): Double = mm / 25.4
}


/**
 * Recursively retrieves a nested value from a JsonObject using a dot-notated key path.
 *
 * Example:
 *   val dir = json.getValueAtPath("details.movement.dir")?.asString
 */
fun JsonObject.getValueAtPath(keyPath: String): JsonElement? {
    val keys = keyPath.split(".")
    var currentElement: JsonElement? = this

    for (key in keys) {
        if (currentElement == null || !currentElement.isJsonObject) {
            return null
        }
        val obj = currentElement.asJsonObject
        currentElement = obj.get(key)
    }

    return currentElement
}

data class Presentation(
    val title: Any, // Can be String or (value: Any) -> String
    val alwaysShow: Boolean? = null,
    val fn: (value: Any) -> String // Consider more specific types if possible, e.g., (value: Number) or (value: Map<String, Double>)
) {
    fun setTitle(newTitle: Any): Presentation {
        return this.copy(title = newTitle)
    }
}


private fun capitalizeFirstLetterOfEachWord(input: String): String {
    val lowercasedInput = input.lowercase()
    // 2. Split the string into words. This regex handles multiple spaces between words.
    val words = lowercasedInput.split(Regex("\\s+")).filter { it.isNotEmpty() }

    // 3. Capitalize the first letter of each word and join them back.
    return words.joinToString(" ") { word ->
        if (word.isNotEmpty()) {
            word.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
        } else {
            ""
        }
    }
}

private fun to1d(number: Double, useLocale: Locale = Locale.US): String {
    if (number.isNaN()) {
        return "NaN"
    } else if (number.isInfinite()) {
        return if (number > 0) "Infinity" else "-Infinity"
    }
    return String.format(useLocale, "%.1f", number)
}

private fun to1d(number: Float, useLocale: Locale = Locale.US): String {
    if (number.isNaN()) {
        return "NaN"
    } else if (number.isInfinite()) {
        return if (number > 0) "Infinity" else "-Infinity"
    }
    return String.format(useLocale, "%.1f", number)
}

private fun to2d(number: Double, useLocale: Locale = Locale.US): String {
    if (number.isNaN()) {
        return "NaN"
    } else if (number.isInfinite()) {
        return if (number > 0) "Infinity" else "-Infinity"
    }

    return String.format(useLocale, "%.2f", number)
}

private fun to2d(number: Float, useLocale: Locale = Locale.US): String {
    if (number.isNaN()) {
        return "NaN"
    } else if (number.isInfinite()) {
        return if (number > 0) "Infinity" else "-Infinity"
    }

    return String.format(useLocale, "%.2f", number)
}

@SuppressLint("DefaultLocale")
@Suppress("UNCHECKED_CAST") // Suppress for direct porting, refine as needed
val presentations: Map<PresentationType, Presentation> = mapOf(
    PresentationType.TEMPERATURE to Presentation(
        title = "Temperature", fn = { features ->
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toDouble() ?: return@Presentation ""
            "${to2d(value)}°C, ${to2d(Units.CtoF(value))}°F"
        }),

    PresentationType.TEMPERATURE_CHANGE to Presentation(
        title = "Temp Change2", fn = { features ->
            val featureMap = features as? Map<*, *> ?: return@Presentation "e1"
            val value = (featureMap["value"] as? Number)?.toDouble() ?: return@Presentation "e2"
            val prefix = if (value > 0) "+" else ""
            "$prefix${to1d(value)}°C, $prefix${to2d(Units.CtoFUnit(value))}°F"
        }),

    PresentationType.WIND_SPEED to Presentation(
        title = "Winds", fn = { features ->
            val m = features as? Map<*, *> ?: return@Presentation ""
            val speedMs = (m["value"] as? Number)?.toDouble()
            val angleDeg = (m["angle"] as? Number)?.toDouble()
            if (speedMs == null || speedMs.isNaN()) return@Presentation ""
            if (speedMs < 1e-6) return@Presentation "Calm"
            if (angleDeg == null || angleDeg.isNaN()) return@Presentation ""
            val adjustedAngle = angleDeg - 180
            "${Units.degToDir(adjustedAngle)} ${to1d(Units.msToKph(speedMs))} kph, ${to1d(Units.msToMph(speedMs))} mph"
        }),

    PresentationType.WIND_GUST to Presentation(
        title = "Wind Gusts", fn = { features ->
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toDouble() ?: 0.0
            "${to1d(Units.msToKph(value))} kph, ${to1d(Units.msToMph(value))} mph"
        }),

    PresentationType.HUMIDITY to Presentation(
        title = "Humidity", fn = { features ->
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toDouble() ?: return@Presentation ""
            "${kotlin.math.round(value)}%"
        }),

    PresentationType.PRESSURE to Presentation(
        title = "Surface Pressure", fn = { features ->
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toDouble() ?: return@Presentation ""
            "${to1d(value)} mb, ${to2d(Units.mbToHg(value))} in"
        }),

    PresentationType.DISTANCE to Presentation(
        title = "Visibility", fn = { features ->
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toDouble() ?: return@Presentation ""

            "${to1d(Units.mToKm(value))} km, ${to1d(Units.mToMi(value))} mi"
        }),

    PresentationType.HEIGHT to Presentation(
        title = "Wave Height", fn = { features ->
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toDouble() ?: return@Presentation ""
            "${to1d(value)} m, ${to1d(Units.mToFt(value))} ft"
        }),

    PresentationType.DIRECTION to Presentation(
        title = "Direction", fn = { features ->
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toDouble() ?: return@Presentation ""
            val angle = value - 180
            Units.degToDir(angle)
        }),

    PresentationType.GRIDDED_ENC_WIND_UV_DIRECTION to Presentation(
        title = "Direction", fn = { features ->
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toDouble() ?: return@Presentation ""
            Units.degToDirForGriddedWindUv(value)
        }),

    PresentationType.ANGLE_REVERSED to Presentation(
        title = "Direction", fn = { features ->
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toDouble() ?: return@Presentation ""
            val deg = (value % 360.0 + 360.0) % 360.0
            val swapped = (deg + 180.0) % 360.0
            Units.degToDir(swapped)
        }),

    PresentationType.PERIOD to Presentation(
        title = "Period", fn = { features ->
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toDouble() ?: return@Presentation ""
            "${kotlin.math.round(value)} sec"
        }),

    PresentationType.HEIGHT_CHANGE to Presentation(
        title = "Height Change", fn = { features ->
            //val numValue = (value as? Number)?.toDouble() ?: 0.0
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toDouble() ?: return@Presentation ""
            val prefix = if (value > 0) "+" else ""
            "$prefix${to2d(value)} m, $prefix${to1d(Units.mToFt(value))} ft"
        }),

    PresentationType.RADAR to Presentation(
        title = "Radar", fn = { features ->
            //val numValue = (value as? Number)?.toDouble() ?: 0.0
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toDouble() ?: return@Presentation ""
            if (value < 5) return@Presentation ""

            val intensity = when {
                value >= 60 -> "Extreme/Hail"
                value >= 55 -> "Intense"
                value >= 45 -> "Heavy"
                value >= 35 -> "Moderate"
                value >= 25 -> "Light"
                else -> "Very Light"
            }
            "$intensity: ${to2d(value)} dbz"
        }),

    PresentationType.ACCUM_PRECIP to Presentation(
        title = "Accum Precip", fn = { features ->
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toDouble() ?: 0.0
            val mmValue = value * 3600 // Assuming input 'value' is mm/s if it needs *3600 to be mm
            "${to1d(mmValue)} mm, ${to2d(Units.mmToIn(mmValue))} in"
        }),

    /**
     * [Conditions.Precipitation] — parity with MapsGL JS / iOS [PresentationFormat.precipitation]:
     * if [unit] is `mm/sec` or `mm/s`, multiply [value] by 3600 then show mm and inches (2 dp);
     * otherwise show raw [value] (2 dp).
     */
    PresentationType.PRECIPITATION to Presentation(
        title = "Precip",
        fn = { features ->
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toDouble() ?: return@Presentation ""
            var unitSymbol = featureMap["unit"] as? String
            var mmValue = value
            if (unitSymbol == "mm/sec" || unitSymbol == "mm/s") {
                mmValue *= 3600.0
                unitSymbol = "mm"
            }
            if (unitSymbol == "mm") {
                val inches = Units.mmToIn(mmValue)
                return@Presentation "${to2d(mmValue)}mm, ${to2d(inches)}in"
            }
            return@Presentation to2d(value)
        },
    ),

    PresentationType.SNOWFALL to Presentation(
        title = "Accum Snow", fn = { features ->
            //val numValue = (value as? Number)?.toDouble() ?: 0.0
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toDouble() ?: 0.0
            "${(to1d(value * 100))} cm, ${to1d((value * 39.3701))} in"
        }),

    PresentationType.SNOW_DEPTH to Presentation(
        title = "Snow Depth", fn = { features ->
            //val numValue = (value as? Number)?.toDouble() ?: 0.0
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toDouble() ?: 0.0
            "${(to1d(value))} m, ${to1d((value * 39.3701))} in"
        }),

    PresentationType.INDEX to Presentation(
        title = "AQI", fn = { features ->
            //val numValue = (value as? Number)?.toInt() ?: 0
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toInt() ?: 0
            "${value}"
        }),

    PresentationType.POINTS to Presentation(
        title = "Air Quality", fn = { features ->
            //val numValue = (value as? Number)?.toInt() ?: 0
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toInt() ?: 0.0
            "$value ug/m^3"
        }),

    PresentationType.POLLUTANT to Presentation(
        title = "", fn = { features ->
            //val numValue = (value as? Number)?.toInt() ?: 0
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toInt() ?: 0
            "$value ug/m^3"
        }),

    PresentationType.ALERTS to Presentation(
        title = "Alerts",
        fn = { value ->
            val features = value as List<QueriedRenderedFeature>
            val names = features.mapNotNull {
                it.queriedFeature.feature.getStringProperty("ADVISORY")
            }.distinct().joinToString(separator = "\n") { advisory ->
                capitalizeFirstLetterOfEachWord(advisory)
            }
            names
        }),

    PresentationType.DROUGHT to Presentation(
        title = "Drought Monitor",
        fn = { value ->
            val features = value as? List<QueriedRenderedFeature> ?: return@Presentation ""

            val names = features.mapNotNull { feature ->
                feature.queriedFeature.feature.properties()
                    ?.get("details")?.asJsonObject
                    ?.get("risk")?.asJsonObject
                    ?.get("name")?.asString
            }.distinct() // Get only unique names if multiple features have the same one.
                .joinToString(separator = "\n") // Join them with a newline if there are multiple distinct names.
            names
        }),

    PresentationType.EARTHQUAKE to Presentation(
        title = "Earthquakes", fn = { value ->
            val features = value as? List<QueriedRenderedFeature> ?: return@Presentation ""

            val names = features.mapNotNull { feature ->
                val properties = feature.queriedFeature.feature.properties()

                val report = properties?.get("report")?.asJsonObject ?: return@mapNotNull null

                val magnitude = report.get("mag")?.asDouble
                val type = report.get("type")?.asString
                val region = report.get("region")?.asString

                // 5. Build a formatted string if the required data exists.
                if (magnitude != null && type != null && region != null) {
                    // Capitalize the first letter of the 'type' for better display.
                    val formattedType = capitalizeFirstLetterOfEachWord(type)
                    "$magnitude ($formattedType - $region)"
                } else {
                    null
                }

            }.distinct().joinToString(separator = "\n\n") // Use double newline to separate entries
            names
        }),

    PresentationType.LIGHTNING_DENSITY to Presentation(
        title = "Index", fn = { value ->
            val featureMap = value as? Map<*, *> ?: return@Presentation ""
            val strikeValue = (featureMap["value"] as? Number)?.toFloat() ?: 0f
            val strikes = maxOf(1f, kotlin.math.round(strikeValue))
            val strikeText = if (strikes == 1f) "strike" else "strikes"
            String.format("%.0f %s/hr", strikes, strikeText)
        }),

    PresentationType.PERCENTAGE to Presentation(
        title = "percentage", fn = { value ->
            val featureMap = value as? Map<*, *> ?: return@Presentation ""
            val numValue = (featureMap["value"] as? Number)?.toDouble() ?: 0.0
            val final = "${to1d(numValue)}%"
            final
        }),

    PresentationType.SIZE to Presentation(
        title = "Size", fn = { value ->
            val number = value as Float
            "${(to1d(number * 100))} cm, ${to1d((number * 39.3701))} in"
        }),

    PresentationType.CONVECTIVE to Presentation(
        title = "Convective Outlook", fn = { value ->
            val features = value as List<QueriedRenderedFeature>
            val names = features.mapNotNull { feature ->
                // Safely access the nested "type" property within "details" -> "risk"
                feature.queriedFeature.feature.properties()
                    ?.get("details")?.asJsonObject?.get("risk")?.asJsonObject?.get("type")?.asString
            }.distinct() // Equivalent to Swift's .unique()
                .joinToString(separator = "\n") { riskType ->
                    // Use the existing helper function to format the string
                    capitalizeFirstLetterOfEachWord(riskType)
                }
            names
        }),

    PresentationType.RIVER_OBSERVATION to Presentation(
        title = "River Obs", // Updated title for clarity
        fn = { value ->
            val features = value as? List<QueriedRenderedFeature> ?: return@Presentation ""

            val names = features.mapNotNull { feature ->
                val status = feature.queriedFeature.feature.properties()
                    ?.get("ob")?.asJsonObject
                    ?.get("status")?.asString

                status?.let {
                    capitalizeFirstLetterOfEachWord(it.replace('_', ' '))
                }
            }.distinct() // Get only unique statuses.
                .joinToString(separator = "\n") // Join them with a newline.
            names
        }),

    PresentationType.STORM_CELL to Presentation(
        title = "Storm Cells", fn = { value ->
            val features = value as? List<QueriedRenderedFeature> ?: return@Presentation ""

            val names = features.mapNotNull { feature ->
                val properties = feature.queriedFeature.feature.properties() ?: return@mapNotNull null

                // Navigate: data.ob
                val ob = properties.get("ob")?.asJsonObject ?: return@mapNotNull null

                // Navigate: data.ob.movement.dirTo
                val moving = ob.get("movement")?.asJsonObject?.get("dirTo")?.asString

                // Navigate: data.traits.type
                val type = properties.get("traits")?.asJsonObject?.get("type")?.asString ?: ""

                if (type.isNotEmpty()) {
                    val formattedType = capitalizeFirstLetterOfEachWord(type)
                    if (!moving.isNullOrEmpty()) {
                        "$formattedType, moving $moving"
                    } else {
                        formattedType
                    }
                } else {
                    null
                }
            }.distinct().joinToString(separator = "\n")

            names
        }),
    /*
    PresentationType.STORM_CanREPORT to Presentation(
        title = "Storm Report", fn = { features ->
            ""
        }),
    */
    PresentationType.STORM_REPORT to Presentation(
        title = "Storm Reports", fn = { value ->
            val features = value as? List<QueriedRenderedFeature> ?: return@Presentation ""

            val names = features.mapNotNull { feature ->
                val properties = feature.queriedFeature.feature.properties() ?: return@mapNotNull null
                // Navigate: report -> type
                val reportObj = properties.get("report")?.asJsonObject
                val type = reportObj?.get("type")?.asString
                if (!type.isNullOrEmpty()) {
                    capitalizeFirstLetterOfEachWord(type)
                } else {
                    // Fallback: If 'type' is missing but 'cat' exists, use that
                    val cat = reportObj?.get("cat")?.asString
                    if (!cat.isNullOrEmpty()) capitalizeFirstLetterOfEachWord(cat) else null
                }
            }.distinct().joinToString(separator = "\n")
            if (names == "Snow") {
                "   Snow"
            } else {
                names
            }


        }),
    PresentationType.THREAT to Presentation(
        title = "Severe Threat", // You can adjust the title
        fn = { value ->
            val features = value as List<QueriedRenderedFeature>

            val names = features.mapNotNull { feature ->
                val properties = feature.queriedFeature.feature.properties()

                // 1. Guard for required properties, like in Swift.
                val movingDir =
                    properties?.get("details")?.asJsonObject?.get("movement")?.asJsonObject?.get("dir")?.asString
                        ?: return@mapNotNull null

                val movingSpeedKPH =
                    properties.get("details")?.asJsonObject?.get("movement")?.asJsonObject?.get("speedKPH")?.asDouble
                        ?: return@mapNotNull null

                val timestamp =
                    properties.get("period")?.asJsonObject?.get("range")?.asJsonObject?.get("minTimestamp")?.asDouble
                        ?: return@mapNotNull null

                val details = mutableListOf<String>()

                // 3. Format the date.
                val date = Date(timestamp.toLong() * 1000) // Convert seconds to milliseconds
                val dateFormat = SimpleDateFormat("MMM d, yyyy h:mm a", Locale.ENGLISH)
                details.add(dateFormat.format(date))

                val issuedAt = properties.get("details")?.asJsonObject?.get("issuedTimestamp")?.asDouble
                val periodStart =
                    properties.get("period")?.asJsonObject?.get("range")?.asJsonObject?.get("minTimestamp")?.asDouble
                        ?: issuedAt

                if (issuedAt != null && periodStart != null) {
                    val leadTimeMinutes = abs(periodStart - issuedAt).toInt() / 60
                    if (leadTimeMinutes > 0) {
                        details.add("+$leadTimeMinutes minute lead time")
                    }

                }

                // 5. Format the movement speed string using your existing Units object.
                val movingSpeedMPH = Units.msToMph(movingSpeedKPH / 3.6) // Convert KPH to MPH via m/s
                val formattedSpeed = String.format(
                    "Moving %s at %.0fkph (%.0fmph)", movingDir, movingSpeedKPH, movingSpeedMPH
                )
                details.add(formattedSpeed)

                // 6. Join all details with a newline.
                details.joinToString("\n")
            }.distinct() // .unique() in Kotlin

            // 7. Return the first unique entry, or an empty string.
            names.firstOrNull() ?: ""
        }),

    PresentationType.WILDFIRE to Presentation(
        title = "Fires", fn = { value ->
            val features = value as? List<QueriedRenderedFeature> ?: return@Presentation ""

            val entries = features.mapNotNull { queriedFeature ->
                val properties = queriedFeature.queriedFeature.feature.properties()

                // 1. Get the 'report' object first, as it contains all the info we need.
                val report = properties?.get("report")?.asJsonObject ?: return@mapNotNull null

                // 2. Extract required values safely from the 'report' object.
                val name = report.get("name")?.asString ?: "Unknown Fire"
                val areaAC = report.get("areaAC")?.asDouble
                val perContained = report.get("perContained")?.asDouble

                val details = mutableListOf<String>()

                // 3. Process and format the 'areaAC' value if it exists.
                if (areaAC != null && areaAC.isFinite()) {
                    val area = maxOf(areaAC, 1.0)
                    // Format the number to have 0 decimal places.
                    val formattedArea = String.format(Locale.US, "%.0f", area)
                    val unit = if (area > 1) "acres" else "acre"
                    details.add("$formattedArea $unit")

                    // 4. Process and format the 'perContained' value if it exists.
                    if (perContained != null && perContained.isFinite()) {
                        details.add(String.format(Locale.US, "(%.0f%% contained)", perContained))
                    }
                }

                // 5. Build the final display string.
                val detailsString = if (details.isNotEmpty()) {
                    " - " + details.joinToString(" ")
                } else {
                    "" // No details if area is not found
                }

                "$name$detailsString"

            }.distinct()

            entries.firstOrNull() ?: ""
        })
)