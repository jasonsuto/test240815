package com.xweather.mapsgl.weather

import com.xweather.mapsgl.controls.legend.Legend
import com.xweather.mapsgl.layers.spec.GridLayerDescriptor
import com.xweather.mapsgl.sources.source.spec.EncodedSourceDescriptor
import com.xweather.mapsgl.style.ColorScaleOptions
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.FillPaint
import com.xweather.mapsgl.style.GridLayerPaint
import com.xweather.mapsgl.style.GridPaint
import com.xweather.mapsgl.style.IconPaint
import com.xweather.mapsgl.style.SamplePaint
import com.xweather.mapsgl.style.StyleValue
import com.xweather.mapsgl.types.Anchor
import com.xweather.mapsgl.types.DataQuality

/**
 * Custom gridded layers that mirror non-generated JS SDK specs.
 */
object CustomGriddedLayers {
    /**
     * Kotlin equivalent of JS `conditions.wind_speed.arrow` gridded vector arrows.
     *
     * Notes:
     * - JS icon `size: { width: 40, height: 20 }` maps to Mapbox scalar `icon-size` in this SDK.
     * - JS `symbol.rotateWithMap/pitchWithMap` are not currently exposed in [IconPaint]/[GridLayerPaint].
     * - `iconImageId` must exist in loaded sprite assets (default tries `mapsgl:arrow`).
     */
    fun WindDirectionArrows(
        service: WeatherService,
        iconImageId: String = "mapsgl:arrow",
    ): WeatherLayerConfiguration<EncodedSourceDescriptor, GridLayerDescriptor> =
        object : BaseEncodedConfiguration<GridLayerDescriptor>() {
            override val code: LayerCode = LayerCode.WIND_SPEEDS
            override val source: EncodedSourceDescriptor = WeatherSource.conditions_TMP2_UGRD10_VGRD10(service)

            override val layer: GridLayerDescriptor =
                GridLayerDescriptor(
                    id = "conditions.wind_speed.arrow",
                    source = source.id,
                    quality = DataQuality.medium,
                    paint =
                        GridLayerPaint(
                            fill =
                                FillPaint(
                                    color =
                                        StyleValue.Expression(
                                            Expression.rgb(
                                                Expression.toNumber(Expression.get("shaderR")),
                                                Expression.toNumber(Expression.get("shaderG")),
                                                Expression.toNumber(Expression.get("shaderB")),
                                            ),
                                        ),
                                ),
                            icon =
                                IconPaint(
                                    allowOverlap = StyleValue.Constant(true),
                                    image = StyleValue.Constant(iconImageId),
                                    // Approximation for JS width/height sizing in current Kotlin SDK API.
                                    size = StyleValue.Constant(0.4),
                                    anchor = StyleValue.Constant(Anchor.LEFT),
                                    rotation = -90.0,
                                    rotationUsesDataDirection = true,
                                ),
                            text = emptyList(),
                            grid = GridPaint(spacing = 30.0),
                            sample =
                                SamplePaint(
                                    colorScale =
                                        ColorScaleOptions(
                                            ColorScales.windSpeed.stops,
                                            range = 0.0..53.64,
                                            interval = 0.0,
                                        ),
                                    encodedScalarNormMax = 53.64,
                                ),
                        ),
                )

            // Keep wind-speed legend parity with existing wind layers.
            override var presentation =
                com.xweather.mapsgl.weather.common.presentations[com.xweather.mapsgl.weather.common.PresentationType.WIND_SPEED]
            override var legend: Legend? = LegendCode.WIND_SPEED.getLegend()
        }
}

