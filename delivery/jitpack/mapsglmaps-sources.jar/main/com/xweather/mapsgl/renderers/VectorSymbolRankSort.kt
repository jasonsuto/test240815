package com.xweather.mapsgl.renderers

import com.xweather.mapsgl.style.SymbolRank
import com.xweather.mapsgl.style.SymbolRankDirection
import com.mapbox.geojson.Feature
import no.ecc.vectortile.VectorTileDecoder
import kotlin.math.roundToInt

internal object VectorSymbolRankSort {

    private const val RANK_MISSING = -1.0

    fun sorted(features: List<Feature>, rank: SymbolRank?): List<Feature> {
        if (rank == null || features.size <= 1) return features
        return features
            .map { it to rankValue(it, rank.property) }
            .let { keyed ->
                when (rank.direction) {
                    SymbolRankDirection.ASC -> keyed.sortedBy { it.second }
                    SymbolRankDirection.DESC -> keyed.sortedByDescending { it.second }
                }
            }
            .map { it.first }
    }

    fun rankValue(feature: Feature, rank: SymbolRank?): Float {
        if (rank == null) return 0f
        return rankValue(feature, rank.property).toFloat()
    }

    fun rankValue(feature: Feature, property: String): Double {
        val props = feature.properties() ?: return RANK_MISSING
        val el = props.get(property) ?: return RANK_MISSING
        if (el.isJsonNull) return RANK_MISSING
        if (!el.isJsonPrimitive) return RANK_MISSING
        val p = el.asJsonPrimitive
        if (p.isNumber) return p.asDouble
        if (p.isString) return p.asString.toDoubleOrNull() ?: RANK_MISSING
        return RANK_MISSING
    }

    /**
     * Rule: raw-vector-fast-path (Symbol port). Raw-attrs counterpart to [sorted]/[rankValue] — reads
     * the same flat, dot-notation-keyed property directly off [VectorTileDecoder.Feature.attributes].
     */
    fun sortedRaw(
        features: List<VectorTileDecoder.Feature>,
        rank: SymbolRank?,
    ): List<VectorTileDecoder.Feature> {
        if (rank == null || features.size <= 1) return features
        return features
            .map { it to rankValueRaw(it.attributes, rank.property) }
            .let { keyed ->
                when (rank.direction) {
                    SymbolRankDirection.ASC -> keyed.sortedBy { it.second }
                    SymbolRankDirection.DESC -> keyed.sortedByDescending { it.second }
                }
            }
            .map { it.first }
    }

    fun rankValueRaw(attributes: Map<String, Any?>, property: String): Double =
        when (val v = attributes[property]) {
            is Number -> v.toDouble()
            is String -> v.toDoubleOrNull() ?: RANK_MISSING
            else -> RANK_MISSING
        }
}

internal fun symbolCrossTileId(
    coordZ: Int,
    coordX: Int,
    coordY: Int,
    anchorU: Float,
    anchorV: Float,
    imageId: String,
    worldOffset: Int = 0,
): String {
    val ax = (anchorU * 10_000f).roundToInt()
    val ay = (anchorV * 10_000f).roundToInt()
    val imageKey = imageId.replace(' ', '_')
    return if (worldOffset == 0) {
        "$coordZ-$coordX-$coordY-$ax-$ay-$imageKey"
    } else {
        "$coordZ-$coordX-$coordY-o$worldOffset-$ax-$ay-$imageKey"
    }
}
