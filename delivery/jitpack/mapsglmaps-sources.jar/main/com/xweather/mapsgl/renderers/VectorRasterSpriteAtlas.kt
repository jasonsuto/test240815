package com.xweather.mapsgl.renderers

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.opengl.GLES31
import com.xweather.mapsgl.util.MapsGLDebug
import org.json.JSONObject
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/**
 * MapsGL **raster** sprite sheet (`sprite@2x.png` + JSON) for icons such as `mapsgl:fire-1`.
 * SDF wind/hurricane glyphs live in [VectorSpriteSdfAtlas]; fire/lightning icons are raster-only on the CDN sheet.
 *
 * Populated from [com.xweather.mapsgl.map.MapStyle.loadSprite] (same download Mapbox uses) with a CDN fallback.
 */
internal object VectorRasterSpriteAtlas {

    private const val TAG = "VectorRasterSpriteAtlas"
    private const val CDN_JSON = "https://cdn.aerisapi.com/sdk/js/mapsgl/assets/sprite@2x.json"
    private const val CDN_PNG = "https://cdn.aerisapi.com/sdk/js/mapsgl/assets/sprite@2x.png"

    private val loadState = AtomicInteger(0) // 0 idle, 1 loading, 2 staged
    private val loadExecutor = Executors.newSingleThreadExecutor()
    private val pendingReadyCallbacks = CopyOnWriteArrayList<() -> Unit>()

    @Volatile
    private var textureId: Int = 0

    @Volatile
    private var atlasWidth: Int = 0

    @Volatile
    private var atlasHeight: Int = 0

    @Volatile
    private var pendingRgba: ByteBuffer? = null

    private val uvBySpriteId = java.util.concurrent.ConcurrentHashMap<String, FloatArray>()

    fun isUvMapReady(): Boolean = uvBySpriteId.isNotEmpty()

    fun isTextureReady(): Boolean = textureId != 0

    fun lookupUvRect(imageId: String?): FloatArray? {
        if (imageId.isNullOrBlank()) return null
        uvBySpriteId[imageId]?.let { return it }
        val normalized = imageId.removePrefix("mapsgl:")
        uvBySpriteId["mapsgl:$normalized"]?.let { return it }
        uvBySpriteId[normalized]?.let { return it }
        // Expression `to-string` on whole-number floor/max can yield `fire-2.0` before formatting fix.
        val wholeFire = Regex("""^fire-(\d+)\.0$""").matchEntire(normalized)
        if (wholeFire != null) {
            val fixed = "fire-${wholeFire.groupValues[1]}"
            return uvBySpriteId["mapsgl:$fixed"] ?: uvBySpriteId[fixed]
        }
        return null
    }

    /** Called from [com.xweather.mapsgl.map.MapStyle.loadSprite] after the raster sheet PNG is decoded. */
    fun stageFullSheet(bitmap: Bitmap, jsonText: String) {
        synchronized(this) {
            atlasWidth = bitmap.width
            atlasHeight = bitmap.height
            pendingRgba = bitmapToRgbaBufferBottomFirst(bitmap)
            parseUvMap(jsonText)
            loadState.set(2)
            MapsGLDebug.logI(
                TAG,
                "stageFullSheet ${bitmap.width}x${bitmap.height} sprites=${uvBySpriteId.size} " +
                    "sampleKeys=${uvBySpriteId.keys.filter { it.contains("fire") }.take(5)}",
            )
        }
        flushReadyCallbacks()
    }

    fun ensureLoading(onReady: (() -> Unit)? = null) {
        if (isUvMapReady()) {
            return
        }
        if (onReady != null) {
            pendingReadyCallbacks.add(onReady)
        }
        if (loadState.get() >= 1) return
        if (!loadState.compareAndSet(0, 1)) return
        loadExecutor.submit {
            try {
                val jsonText = URL(CDN_JSON).openStream().use { it.reader().readText() }
                val pngBytes = URL(CDN_PNG).openStream().use { it.readBytes() }
                val bitmap = BitmapFactory.decodeByteArray(pngBytes, 0, pngBytes.size)
                    ?: error("VectorRasterSpriteAtlas: failed to decode PNG")
                stageFullSheet(bitmap, jsonText)
                bitmap.recycle()
                MapsGLDebug.logI(TAG, "CDN sprite load OK")
            } catch (e: Exception) {
                MapsGLDebug.logE(TAG, "CDN sprite load failed", e)
                loadState.set(0)
                pendingReadyCallbacks.clear()
            }
        }
    }

    /** After EGL context loss, GL texture names are invalid; pixel buffer is kept for re-upload. */
    fun onGlContextLost() {
        textureId = 0
    }

    /** Upload pending RGBA to GL; call on the render thread. Returns texture id or 0 if not ready. */
    fun ensureLoadedOnGlThread(): Int {
        if (textureId != 0 && GLES31.glIsTexture(textureId)) return textureId
        if (textureId != 0) textureId = 0
        ensureLoading()
        val rgba = pendingRgba ?: return 0
        rgba.position(0)
        val w = atlasWidth
        val h = atlasHeight
        if (w <= 0 || h <= 0) return 0
        val texIds = IntArray(1)
        GLES31.glGenTextures(1, texIds, 0)
        val tid = texIds[0]
        GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, tid)
        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MIN_FILTER, GLES31.GL_LINEAR)
        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MAG_FILTER, GLES31.GL_LINEAR)
        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_WRAP_S, GLES31.GL_CLAMP_TO_EDGE)
        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_WRAP_T, GLES31.GL_CLAMP_TO_EDGE)
        GLES31.glTexImage2D(
            GLES31.GL_TEXTURE_2D,
            0,
            GLES31.GL_RGBA8,
            w,
            h,
            0,
            GLES31.GL_RGBA,
            GLES31.GL_UNSIGNED_BYTE,
            rgba,
        )
        GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, 0)
        textureId = tid
        return tid
    }

    private fun flushReadyCallbacks() {
        val callbacks = pendingReadyCallbacks.toList()
        pendingReadyCallbacks.clear()
        for (cb in callbacks) {
            runCatching { cb.invoke() }
        }
    }

    private fun parseUvMap(jsonText: String) {
        val root = JSONObject(jsonText)
        val aw = atlasWidth.toFloat().coerceAtLeast(1f)
        val ah = atlasHeight.toFloat().coerceAtLeast(1f)
        uvBySpriteId.clear()
        for (key in root.keys()) {
            val o = root.getJSONObject(key)
            val x = o.getInt("x").toFloat()
            val y = o.getInt("y").toFloat()
            val w = o.getInt("width").toFloat()
            val h = o.getInt("height").toFloat()
            val u0 = x / aw
            val v0 = 1f - (y + h) / ah
            val u1 = (x + w) / aw
            val v1 = 1f - y / ah
            // Swap V so raster quads sample upright (PNG is top-origin; tile quad Y increases south).
            val rect = floatArrayOf(u0, v1, u1, v0)
            uvBySpriteId["mapsgl:$key"] = rect
            uvBySpriteId[key] = rect
        }
    }

    private fun bitmapToRgbaBufferBottomFirst(b: Bitmap): ByteBuffer {
        val w = b.width
        val h = b.height
        val pixels = IntArray(w * h)
        b.getPixels(pixels, 0, w, 0, 0, w, h)
        val buf = ByteBuffer.allocateDirect(w * h * 4).order(ByteOrder.nativeOrder())
        for (row in h - 1 downTo 0) {
            for (col in 0 until w) {
                val p = pixels[row * w + col]
                buf.put(((p shr 16) and 0xFF).toByte())
                buf.put(((p shr 8) and 0xFF).toByte())
                buf.put((p and 0xFF).toByte())
                buf.put(((p shr 24) and 0xFF).toByte())
            }
        }
        buf.position(0)
        return buf
    }
}
