package com.xweather.mapsgl.renderers

import com.mapbox.geojson.Feature
import com.xweather.mapsgl.map.mapbox.VectorCircleRawStyleEval
import com.xweather.mapsgl.map.mapbox.VectorFillStyleExpressionEval
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.IconSize
import com.xweather.mapsgl.style.StyleValue
import com.xweather.mapsgl.style.SymbolLayerPaint
import com.xweather.mapsgl.types.Anchor
import com.xweather.mapsgl.types.AnchorOffset
import kotlin.math.max

/**
 * MapsGL JS `layoutIcon` placement: anchor fractions, pixel offset, rotation, and width/height.
 */
internal object VectorSymbolLayout {

    data class IconPlacement(
        val halfWidthPx: Float,
        val halfHeightPx: Float,
        /** Pixel offset from the geometry anchor to the icon quad center (JS `p + size * anchorFrac`). */
        val centerOffsetXPx: Float,
        val centerOffsetYPx: Float,
        val rotationDeg: Float,
    )

    fun placement(
        paint: SymbolLayerPaint,
        feature: Feature,
        zoom: Double,
        densityMult: Float,
        layerId: String?,
    ): IconPlacement {
        val icon = paint.icon
        val (widthPx, heightPx) = iconDimensionsPx(paint, feature, zoom, densityMult, layerId)
        val anchorName =
            if (VectorSymbolPlacementDefaults.fireObsUsesBottomAnchor(layerId)) {
                "bottom"
            } else {
                resolveAnchorName(icon.anchor, feature, zoom)
            }
        val anchorFrac = anchorFraction(anchorName)
        val (offX, offY) =
            if (VectorSymbolPlacementDefaults.fireObsUsesBottomAnchor(layerId)) {
                0f to 2f
            } else {
                resolveOffsetPx(icon.offset, feature, zoom)
            }
        return IconPlacement(
            halfWidthPx = widthPx * 0.5f,
            halfHeightPx = heightPx * 0.5f,
            centerOffsetXPx = offX + widthPx * anchorFrac.first,
            centerOffsetYPx = offY + heightPx * anchorFrac.second,
            rotationDeg = resolveRotationDeg(icon.rotationExpression, feature, zoom),
        )
    }

    /**
     * Rule: raw-vector-fast-path (Symbol port). Raw-attrs counterpart to [placement], used only when
     * [resolveRawSymbolPathEligible] proved `anchor`/`offset` are [StyleValue.Constant] for this
     * layer's paint (so `resolveAnchorName`/`resolveOffsetPx`'s [StyleValue.Expression] branches are
     * unreachable here — those still need [Feature]/[VectorFillStyleExpressionEval] and have no raw
     * equivalent). Only `size` and `rotation` are genuinely evaluated per-feature.
     */
    fun placementRaw(
        paint: SymbolLayerPaint,
        attrs: Map<String, Any?>,
        zoom: Double,
        densityMult: Float,
        layerId: String?,
    ): IconPlacement {
        val icon = paint.icon
        val (widthPx, heightPx) = iconDimensionsPxRaw(paint, attrs, zoom, densityMult, layerId)
        val anchorName =
            if (VectorSymbolPlacementDefaults.fireObsUsesBottomAnchor(layerId)) {
                "bottom"
            } else {
                icon.anchor.constantValue?.value ?: "center"
            }
        val anchorFrac = anchorFraction(anchorName)
        val (offX, offY) =
            if (VectorSymbolPlacementDefaults.fireObsUsesBottomAnchor(layerId)) {
                0f to 2f
            } else {
                val o = icon.offset.constantValue ?: AnchorOffset()
                o.x.toFloat() to o.y.toFloat()
            }
        return IconPlacement(
            halfWidthPx = widthPx * 0.5f,
            halfHeightPx = heightPx * 0.5f,
            centerOffsetXPx = offX + widthPx * anchorFrac.first,
            centerOffsetYPx = offY + heightPx * anchorFrac.second,
            rotationDeg = resolveRotationDegRaw(icon.rotationExpression, attrs),
        )
    }

    private fun iconDimensionsPxRaw(
        paint: SymbolLayerPaint,
        attrs: Map<String, Any?>,
        zoom: Double,
        densityMult: Float,
        layerId: String?,
    ): Pair<Float, Float> {
        val icon = paint.icon
        val sizeMult = VectorSymbolPlacementDefaults.iconSizeMultiplier(layerId)
        val density = densityMult.coerceAtLeast(1e-3f) * VECTOR_SYMBOL_GL_PIXEL_SCALE * sizeMult
        VectorSymbolPlacementDefaults.fireObsIconSidePxRaw(layerId, attrs)?.let { sidePx ->
            val side = (sidePx * density).coerceIn(4f, 256f * sizeMult)
            return side to side
        }
        val scale = resolveSizeScaleRaw(icon.size, attrs)
        val iconSize = icon.iconSize
        if (iconSize != null) {
            val w = (iconSize.width * scale * density).coerceIn(4f, 256f * sizeMult)
            val h = (iconSize.height * scale * density).coerceIn(4f, 256f * sizeMult)
            return w to h
        }
        val ref = IconSize.JS_REFERENCE_WIDTH_PX
        val side = (ref * scale * density).coerceIn(4f, 256f * sizeMult)
        return side to side
    }

    private fun resolveSizeScaleRaw(size: StyleValue<Double>?, attrs: Map<String, Any?>): Float =
        when (size) {
            null -> 1f
            is StyleValue.Constant -> (size.constantValue ?: 1.0).toFloat()
            is StyleValue.Expression -> VectorCircleRawStyleEval.evaluateNumber(size.expression, attrs)?.toFloat() ?: 1f
        }

    private fun resolveRotationDegRaw(rotation: StyleValue<Double>, attrs: Map<String, Any?>): Float =
        when (rotation) {
            is StyleValue.Constant -> (rotation.constantValue ?: 0.0).toFloat()
            is StyleValue.Expression ->
                VectorCircleRawStyleEval.evaluateNumber(rotation.expression, attrs)?.toFloat() ?: 0f
        }

    /** JS `Ka(anchor)` fractions multiplied by icon width/height. */
    fun anchorFraction(anchorName: String): Pair<Float, Float> {
        var x = 0f
        var y = 0f
        when (anchorName) {
            "right", "top-right", "bottom-right" -> x = -0.5f
            "left", "top-left", "bottom-left" -> x = 0.5f
        }
        when (anchorName) {
            "bottom", "bottom-right", "bottom-left" -> y = -0.5f
            "top", "top-right", "top-left" -> y = 0.5f
        }
        return x to y
    }

    fun collisionHalfPx(placement: IconPlacement): Float =
        max(placement.halfWidthPx, placement.halfHeightPx)

    private fun iconDimensionsPx(
        paint: SymbolLayerPaint,
        feature: Feature,
        zoom: Double,
        densityMult: Float,
        layerId: String?,
    ): Pair<Float, Float> {
        val icon = paint.icon
        val sizeMult = VectorSymbolPlacementDefaults.iconSizeMultiplier(layerId)
        val density = densityMult.coerceAtLeast(1e-3f) * VECTOR_SYMBOL_GL_PIXEL_SCALE * sizeMult
        VectorSymbolPlacementDefaults.fireObsIconSidePx(layerId, feature)?.let { sidePx ->
            val side = (sidePx * density).coerceIn(4f, 256f * sizeMult)
            return side to side
        }
        val scale = resolveSizeScale(icon.size, feature, zoom)
        val iconSize = icon.iconSize
        if (iconSize != null) {
            val w = (iconSize.width * scale * density).coerceIn(4f, 256f * sizeMult)
            val h = (iconSize.height * scale * density).coerceIn(4f, 256f * sizeMult)
            return w to h
        }
        val ref = IconSize.JS_REFERENCE_WIDTH_PX
        val side = (ref * scale * density).coerceIn(4f, 256f * sizeMult)
        return side to side
    }

    private fun resolveSizeScale(size: StyleValue<Double>?, feature: Feature, zoom: Double): Float =
        when (size) {
            null -> 1f
            is StyleValue.Constant -> (size.constantValue ?: 1.0).toFloat()
            is StyleValue.Expression ->
                VectorFillStyleExpressionEval.evaluateNumber(size.expression, feature, zoom)?.toFloat() ?: 1f
        }

    private fun resolveAnchorName(
        anchor: StyleValue<Anchor>,
        feature: Feature,
        zoom: Double,
    ): String =
        when (anchor) {
            is StyleValue.Constant -> anchor.constantValue?.value ?: "center"
            is StyleValue.Expression ->
                VectorFillStyleExpressionEval.evaluateString(anchor.expression, feature) ?: "center"
        }

    private fun resolveOffsetPx(
        offset: StyleValue<AnchorOffset>,
        feature: Feature,
        zoom: Double,
    ): Pair<Float, Float> =
        when (offset) {
            is StyleValue.Constant -> {
                val o = offset.constantValue ?: AnchorOffset()
                o.x.toFloat() to o.y.toFloat()
            }
            is StyleValue.Expression -> evaluateOffsetExpression(offset.expression, feature, zoom) ?: (0f to 0f)
        }

    private fun evaluateOffsetExpression(
        expr: Expression,
        feature: Feature,
        zoom: Double,
    ): Pair<Float, Float>? {
        val raw = expr.raw
        if (raw is List<*>) {
            return when (raw[0] as? String) {
                "literal" -> tokenToOffsetPair(raw.getOrNull(1))
                "step" -> evaluateStepOffsetPair(raw, feature, zoom)
                else -> null
            }
        }
        return null
    }

    private fun evaluateStepOffsetPair(
        list: List<*>,
        feature: Feature,
        zoom: Double,
    ): Pair<Float, Float>? {
        if (list.size < 4) return null
        val input =
            if (list[1] is List<*> && (list[1] as List<*>).firstOrNull() == "zoom") {
                zoom
            } else {
                val stepInput = list[1] ?: return null
                @Suppress("UNCHECKED_CAST")
                VectorFillStyleExpressionEval.evaluateNumber(
                    Expression(stepInput as List<Any>),
                    feature,
                    zoom,
                )
            } ?: return null
        var result = tokenToOffsetPair(list[2]) ?: return null
        var i = 3
        while (i + 1 < list.size) {
            val thr = (list[i] as? Number)?.toDouble() ?: return null
            if (input >= thr) {
                result = tokenToOffsetPair(list[i + 1]) ?: result
            }
            i += 2
        }
        return result
    }

    private fun tokenToOffsetPair(token: Any?): Pair<Float, Float>? {
        return when (token) {
            is List<*> -> {
                if (token.size < 2) return null
                val x = token[0].asNumber() ?: return null
                val y = token[1].asNumber() ?: return null
                x.toFloat() to y.toFloat()
            }
            is Number -> token.toDouble().toFloat() to 0f
            else -> null
        }
    }

    private fun Any?.asNumber(): Double? =
        when (this) {
            is Number -> toDouble()
            is String -> toDoubleOrNull()
            else -> null
        }

    private fun resolveRotationDeg(
        rotation: StyleValue<Double>,
        feature: Feature,
        zoom: Double,
    ): Float =
        when (rotation) {
            is StyleValue.Constant -> (rotation.constantValue ?: 0.0).toFloat()
            is StyleValue.Expression ->
                VectorFillStyleExpressionEval.evaluateNumber(rotation.expression, feature, zoom)?.toFloat() ?: 0f
        }
}
