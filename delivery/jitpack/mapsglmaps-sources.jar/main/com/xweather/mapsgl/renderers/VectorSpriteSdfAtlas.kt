package com.xweather.mapsgl.renderers

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.opengl.GLES31
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Full MapsGL sprite sheet ([sprite-sdf@2x.png] + JSON) as a single `GL_TEXTURE_2D` for GLES symbol layers.
 * Image ids follow Mapbox style (`mapsgl:hurricane` → JSON key `hurricane-sdf`).
 */
internal object VectorSpriteSdfAtlas {

    private const val ASSET_PNG = "sdf/sprite-sdf@2x.png"
    private const val ASSET_JSON = "sdf/sprite-sdf@2x.json"

    @Volatile
    private var textureId: Int = 0

    @Volatile
    private var atlasWidth: Int = 0

    @Volatile
    private var atlasHeight: Int = 0

    private val uvBySpriteId = java.util.concurrent.ConcurrentHashMap<String, FloatArray>()

    fun onGlContextLost() {
        textureId = 0
    }

    fun ensureLoaded(context: Context): Int {
        if (textureId != 0 && GLES31.glIsTexture(textureId)) return textureId
        if (textureId != 0) textureId = 0
        synchronized(this) {
            if (textureId != 0 && GLES31.glIsTexture(textureId)) return textureId
            if (textureId != 0) textureId = 0
            val jsonText = context.assets.open(ASSET_JSON).bufferedReader().use { it.readText() }
            val root = JSONObject(jsonText)
            val full =
                context.assets.open(ASSET_PNG).use { BitmapFactory.decodeStream(it) }
                    ?: error("VectorSpriteSdfAtlas: failed to decode $ASSET_PNG")
            atlasWidth = full.width
            atlasHeight = full.height
            val buf = bitmapToRgbaBufferBottomFirst(full)
            full.recycle()

            val texIds = IntArray(1)
            GLES31.glGenTextures(1, texIds, 0)
            val tid = texIds[0]
            GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, tid)
            GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MIN_FILTER, GLES31.GL_LINEAR)
            GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MAG_FILTER, GLES31.GL_LINEAR)
            GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_WRAP_S, GLES31.GL_CLAMP_TO_EDGE)
            GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_WRAP_T, GLES31.GL_CLAMP_TO_EDGE)
            GLES31.glTexImage2D(
                GLES31.GL_TEXTURE_2D,
                0,
                GLES31.GL_RGBA8,
                atlasWidth,
                atlasHeight,
                0,
                GLES31.GL_RGBA,
                GLES31.GL_UNSIGNED_BYTE,
                buf,
            )
            GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, 0)

            val aw = atlasWidth.toFloat()
            val ah = atlasHeight.toFloat()
            for (key in root.keys()) {
                val o = root.getJSONObject(key)
                val x = o.getInt("x").toFloat()
                val y = o.getInt("y").toFloat()
                val w = o.getInt("width").toFloat()
                val h = o.getInt("height").toFloat()
                val u0 = x / aw
                val v0 = 1f - (y + h) / ah
                val u1 = (x + w) / aw
                val v1 = 1f - y / ah
                // Match [VectorRasterSpriteAtlas]: swap V so tile quads sample upright (PNG top-origin;
                // tile Y increases south; quad corner t.y=0 is north).
                val rect = floatArrayOf(u0, v1, u1, v0)
                val spriteId = key.removeSuffix("-sdf")
                uvBySpriteId["mapsgl:$spriteId"] = rect
                uvBySpriteId[spriteId] = rect
            }
            textureId = tid
            return tid
        }
    }

    fun lookupUvRect(imageId: String?): FloatArray? {
        if (imageId.isNullOrBlank()) return null
        uvBySpriteId[imageId]?.let { return it }
        val normalized = imageId.removePrefix("mapsgl:")
        return uvBySpriteId["mapsgl:$normalized"] ?: uvBySpriteId[normalized]
    }

    private fun bitmapToRgbaBufferBottomFirst(b: Bitmap): ByteBuffer {
        val w = b.width
        val h = b.height
        val pixels = IntArray(w * h)
        b.getPixels(pixels, 0, w, 0, 0, w, h)
        val buf = ByteBuffer.allocateDirect(w * h * 4).order(ByteOrder.nativeOrder())
        for (row in h - 1 downTo 0) {
            for (col in 0 until w) {
                val p = pixels[row * w + col]
                buf.put(((p shr 16) and 0xFF).toByte())
                buf.put(((p shr 8) and 0xFF).toByte())
                buf.put((p and 0xFF).toByte())
                buf.put(((p shr 24) and 0xFF).toByte())
            }
        }
        buf.position(0)
        return buf
    }
}
