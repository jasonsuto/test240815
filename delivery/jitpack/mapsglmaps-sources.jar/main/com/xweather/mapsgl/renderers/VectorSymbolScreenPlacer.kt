package com.xweather.mapsgl.renderers

import com.xweather.mapsgl.style.SymbolRankDirection
import kotlin.math.floor

/**
 * Screen-space symbol collision + opacity fade (MapsGL JS `placeSymbols` / `updateLayerOpacities`).
 */
internal class VectorSymbolScreenPlacer {

    data class Candidate(
        val crossTileId: String,
        val rank: Float,
        val screenBox: FloatArray,
    )

    private data class FadeState(
        var placed: Boolean,
        var opacity: Float,
    )

    private val lock = Any()
    private val opacityById = LinkedHashMap<String, FadeState>(256)
    private var lastUpdateMs: Long = 0L
    private var lastCandidateCount: Int = 0

    fun clear() {
        synchronized(lock) {
            opacityById.clear()
            lastUpdateMs = 0L
            lastCandidateCount = 0
        }
    }

    /**
     * Rule: placer-cross-thread-safe. [placeAndFade]/[clear] run on the Mapbox GL/render thread
     * while [needsContinuation] is polled from the main-looper keep-redrawing tick. Iterating
     * [opacityById] without a lock raced a concurrent mutation and crashed on pan/scroll with
     * ConcurrentModificationException (LinkedHashMap iterator).
     */
    fun needsContinuation(): Boolean =
        synchronized(lock) {
            opacityById.values.any { state ->
                val target = if (state.placed) 1f else 0f
                kotlin.math.abs(state.opacity - target) > 0.02f
            }
        }

    /**
     * Runs cross-tile collision, updates fade targets, and returns per-[crossTileId] draw opacity.
     *
     * @param snap when true, skip fade animation (used while the camera is moving to avoid redraw storms).
     */
    fun placeAndFade(
        candidates: List<Candidate>,
        rankDirection: SymbolRankDirection?,
        nowMs: Long,
        fadeDurationMs: Long = SYMBOL_FADE_DURATION_MS,
        snap: Boolean = false,
    ): Map<String, Float> = synchronized(lock) {
        // Rule: placement-visibility-boost. A candidate whose screen box sits right at a collision
        // boundary against a similarly-ranked neighbor can otherwise flicker in and out frame to
        // frame as either side's box shifts by a sub-pixel amount. Give anything that was actually
        // placed last frame a large one-sided bias so it keeps winning ties/near-ties against a
        // same-rank newcomer — only another already-visible candidate (or a clearly higher-ranked
        // one, since the bias doesn't erase real rank differences beyond it) can bump it out.
        //
        // Rule: skip-boost-on-growth (MapsGL JS `skipVisibilityCompare`). Applied unconditionally,
        // that bias also lets a low-rank label placed early permanently block a higher-rank label
        // that only shows up once a new tile finishes loading — the boost swamps any real rank gap,
        // so the newcomer can never win. JS sidesteps this by falling back to plain rank order
        // whenever the candidate set just grew (new tiles streamed in) or on the very first
        // placement, since there's no "existing picture" worth protecting yet in either case.
        val isInitialPlacement = opacityById.isEmpty()
        val instanceCountGrew = candidates.size > lastCandidateCount
        val skipVisibilityBoost = isInitialPlacement || instanceCountGrew
        lastCandidateCount = candidates.size
        fun effectiveRank(candidate: Candidate): Float {
            if (skipVisibilityBoost) return candidate.rank
            val wasVisible = opacityById[candidate.crossTileId]?.placed == true
            if (!wasVisible) return candidate.rank
            return when (rankDirection) {
                SymbolRankDirection.DESC -> candidate.rank + PLACEMENT_VISIBILITY_BOOST
                else -> candidate.rank - PLACEMENT_VISIBILITY_BOOST
            }
        }
        val sorted =
            when (rankDirection) {
                SymbolRankDirection.DESC -> candidates.sortedWith(compareByDescending<Candidate> { effectiveRank(it) }.thenBy { it.crossTileId })
                else -> candidates.sortedWith(compareBy<Candidate> { effectiveRank(it) }.thenBy { it.crossTileId })
            }
        val collision = ScreenCollisionIndex()
        val seenIds = HashSet<String>(sorted.size)
        for (candidate in sorted) {
            seenIds.add(candidate.crossTileId)
            val state = opacityById.getOrPut(candidate.crossTileId) { FadeState(placed = false, opacity = 0f) }
            val fits = !collision.collides(candidate.screenBox)
            state.placed = fits
            if (fits) {
                collision.insert(candidate.screenBox)
            }
        }
        for (id in opacityById.keys.toList()) {
            if (id !in seenIds) {
                opacityById[id]?.placed = false
            }
        }
        if (snap) {
            for (id in seenIds) {
                val state = opacityById[id] ?: continue
                state.opacity = if (state.placed) 1f else 0f
            }
            for (id in opacityById.keys.toList()) {
                if (id !in seenIds) {
                    opacityById[id]?.opacity = 0f
                }
            }
        } else {
            val delta = fadeDelta(nowMs, fadeDurationMs)
            for (id in seenIds) {
                opacityById[id]?.let { stepOpacity(it, delta) }
            }
            for (id in opacityById.keys.toList()) {
                if (id !in seenIds) {
                    opacityById[id]?.let { stepOpacity(it, delta) }
                }
            }
        }
        pruneStaleOpacity(seenIds)
        return buildOpacityResult(seenIds)
    }

    private fun buildOpacityResult(seenIds: Set<String>): Map<String, Float> {
        val out = HashMap<String, Float>(seenIds.size + 8)
        for (id in seenIds) {
            out[id] = opacityById[id]?.opacity ?: 1f
        }
        for ((id, state) in opacityById) {
            if (id !in seenIds && state.opacity > 0.02f) {
                out[id] = state.opacity
            }
        }
        return out
    }

    private fun pruneStaleOpacity(seenIds: Set<String>) {
        val it = opacityById.entries.iterator()
        while (it.hasNext()) {
            val (id, state) = it.next()
            if (id in seenIds) continue
            if (!state.placed && state.opacity <= 0.02f) {
                it.remove()
            }
        }
        while (opacityById.size > MAX_OPACITY_ENTRIES) {
            val drop = opacityById.entries.firstOrNull { !it.value.placed && it.value.opacity <= 0.02f }?.key
                ?: opacityById.keys.firstOrNull()
                ?: break
            opacityById.remove(drop)
        }
    }

    private fun fadeDelta(nowMs: Long, fadeDurationMs: Long): Float {
        val prev = lastUpdateMs
        lastUpdateMs = nowMs
        if (prev == 0L || fadeDurationMs <= 0L) return 1f
        val elapsed = (nowMs - prev).coerceIn(0L, 64L)
        return elapsed.toFloat() / fadeDurationMs.toFloat()
    }

    private fun stepOpacity(state: FadeState, delta: Float) {
        val target = if (state.placed) 1f else 0f
        when {
            state.opacity < target -> state.opacity = minOf(target, state.opacity + delta)
            state.opacity > target -> state.opacity = maxOf(target, state.opacity - delta)
        }
    }

    private class ScreenCollisionIndex {
        private val cellSize = 128f
        private val grid = HashMap<Long, ArrayList<FloatArray>>(64)

        fun collides(box: FloatArray): Boolean {
            var hit = false
            forEachCellInBox(box) { key ->
                if (hit) return@forEachCellInBox
                val cell = grid[key] ?: return@forEachCellInBox
                for (other in cell) {
                    if (overlaps(box, other)) {
                        hit = true
                        return@forEachCellInBox
                    }
                }
            }
            return hit
        }

        fun insert(box: FloatArray) {
            forEachCellInBox(box) { key ->
                grid.getOrPut(key) { ArrayList(4) }.add(box)
            }
        }

        private inline fun forEachCellInBox(box: FloatArray, action: (Long) -> Unit) {
            val x0 = floor(box[0] / cellSize).toInt()
            val y0 = floor(box[1] / cellSize).toInt()
            val x1 = floor(box[2] / cellSize).toInt()
            val y1 = floor(box[3] / cellSize).toInt()
            for (cy in y0..y1) {
                for (cx in x0..x1) {
                    action(cellKey(cx, cy))
                }
            }
        }

        private fun cellKey(cx: Int, cy: Int): Long =
            (cx.toLong() shl 32) or (cy.toLong() and 0xffffffffL)

        private fun overlaps(a: FloatArray, b: FloatArray): Boolean =
            a[0] < b[2] && a[2] > b[0] && a[1] < b[3] && a[3] > b[1]
    }

    companion object {
        private const val SYMBOL_FADE_DURATION_MS = 200L
        private const val MAX_OPACITY_ENTRIES = 512
        /** See placement-visibility-boost rule above. Large enough to dominate any real paint rank
         * spread, small enough that two boosted candidates still break ties by their own rank. */
        private const val PLACEMENT_VISIBILITY_BOOST = 1_000_000f
    }
}
