package com.xweather.mapsgl.renderers

import com.mapbox.geojson.Feature
import com.xweather.mapsgl.weather.groups.DataQuery
import kotlin.math.max
import kotlin.math.min
import kotlin.math.round

/**
 * Built-in MapsGL symbol placement overrides keyed by style layer id (matches JS weather configs).
 * JS `fires-obs-icons` uses `symbol: { pitchWithMap: false, rotateWithMap: false }`.
 */
internal object VectorSymbolPlacementDefaults {

    private const val FIRE_OBS_ICONS_LAYER_ID = "climate.fire_obs.icons"
    private const val FIRE_OBS_NAMES_LAYER_ID = "climate.fire_obs.names"
    private const val TROPICAL_NAMES_ACTIVE_LAYER_ID = "tropical.names_active.text"
    private const val TROPICAL_NAMES_ARCHIVE_LAYER_ID = "tropical.names_archive.text"
    private const val TROPICAL_NAMES_INVESTS_LAYER_ID = "tropical.names_invests.text"
    private const val PLACE_CITY_LAYER_ID = "admin.place_city.text"
    private const val PLACE_COUNTRY_LAYER_ID = "admin.place_country.text"
    private const val PLACE_NEIGHBORHOOD_LAYER_ID = "admin.place_neighborhood.text"
    private const val PLACE_STATE_LAYER_ID = "admin.place_state.text"

    private val tropicalNameLayerIds = setOf(
        TROPICAL_NAMES_ACTIVE_LAYER_ID,
        TROPICAL_NAMES_ARCHIVE_LAYER_ID,
        TROPICAL_NAMES_INVESTS_LAYER_ID,
    )

    /** JS `fires-obs-names` only emits labels at zoom >= 7. */
    private const val FIRE_OBS_NAMES_MIN_ZOOM = 7.0

    /** Zoom levels below [textMinZoom] over which label opacity ramps from 0 → 1. */
    private const val TEXT_MIN_ZOOM_FADE_BELOW = 0.5

    /** Zoom levels above [textMinZoom] over which label opacity ramps from 1 → 0 on zoom-out. */
    private const val TEXT_MIN_ZOOM_FADE_ABOVE = 0.35

    /**
     * Built-in override for [com.xweather.mapsgl.style.SymbolLayerPaint.pitchWithMap], for layers
     * whose generated config can't set the paint field directly. Null means "no override, use the
     * paint value" — most layers. JS `fires-obs-icons`/`fires-obs-names` both set
     * `pitchWithMap: false` (`climate.ts:328-330,407-410` in the JS SDK). Place labels stay
     * screen-upright (no map-plane tilt) so city/country names remain readable when pitched.
     *
     * JS tropical name layers also set `symbol.pitchWithMap/rotateWithMap: false` (`tropical.ts`
     * name paint). Generated Tropical.kt leaves Android defaults (`true`), which draws the label in
     * map-plane space and makes "Cristobal"-style names disappear at Active All demo zooms.
     */
    fun pitchWithMapOverride(layerId: String?): Boolean? =
        when (layerId) {
            FIRE_OBS_ICONS_LAYER_ID, FIRE_OBS_NAMES_LAYER_ID,
            PLACE_CITY_LAYER_ID, PLACE_COUNTRY_LAYER_ID,
            PLACE_NEIGHBORHOOD_LAYER_ID, PLACE_STATE_LAYER_ID,
                -> false
            in tropicalNameLayerIds -> false
            else -> null
        }

    /** Built-in override for [com.xweather.mapsgl.style.SymbolLayerPaint.rotateWithMap]; see [pitchWithMapOverride]. */
    fun rotateWithMapOverride(layerId: String?): Boolean? =
        when (layerId) {
            FIRE_OBS_ICONS_LAYER_ID, FIRE_OBS_NAMES_LAYER_ID,
            PLACE_CITY_LAYER_ID, PLACE_COUNTRY_LAYER_ID,
            PLACE_NEIGHBORHOOD_LAYER_ID, PLACE_STATE_LAYER_ID,
                -> false
            in tropicalNameLayerIds -> false
            else -> null
        }

    /**
     * Cap for MVT data zoom used by admin place-label layers. Above this, `open-street-map` tiles
     * often thin or omit `place` city/town features for whole regions (observed: Ohio blank at
     * camera ~z5 while z2–4 still carry Cleveland/Columbus/Cincinnati). Billboard place labels
     * (`pitchWithMap: false`) overzoom cleanly, so we keep requesting at most this z and let the
     * camera zoom further. Null = no cap (use the camera/source zoom like other symbol layers).
     */
    fun placeLabelMaxDataZoom(layerId: String?): Double? =
        when (layerId) {
            PLACE_CITY_LAYER_ID, PLACE_COUNTRY_LAYER_ID,
            PLACE_NEIGHBORHOOD_LAYER_ID, PLACE_STATE_LAYER_ID,
            -> PLACE_LABEL_MAX_DATA_ZOOM
            else -> null
        }

    private const val PLACE_LABEL_MAX_DATA_ZOOM = 4.0

    /** Minimum map zoom before GLES draws symbol text (layer-specific JS parity). */
    fun textMinZoom(layerId: String?): Double? =
        when (layerId) {
            FIRE_OBS_NAMES_LAYER_ID -> FIRE_OBS_NAMES_MIN_ZOOM
            else -> null
        }

    /**
     * Layer-wide text opacity from map zoom (smooth fade around [textMinZoom], not a hard step).
     * Returns 1 when the layer has no min-zoom gate.
     */
    fun textLayerZoomOpacity(layerId: String?, mapZoom: Double): Float {
        val minZoom = textMinZoom(layerId) ?: return 1f
        val fadeStart = minZoom - TEXT_MIN_ZOOM_FADE_BELOW
        val fadeEnd = minZoom + TEXT_MIN_ZOOM_FADE_ABOVE
        if (mapZoom <= fadeStart) return 0f
        if (mapZoom >= fadeEnd) return 1f
        val t = ((mapZoom - fadeStart) / (fadeEnd - fadeStart)).toFloat().coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    /**
     * GLES draw scale for all vector symbol icons (fire, lightning, etc.).
     */
    fun iconSizeMultiplier(layerId: String?): Float = 1f

    /**
     * JS `fires-obs-icons` `ri` size: 18–40px square from `report.areaAC`, else 20px.
     * Android [Climate.FiresObsIcons] still carries legacy mapbox `icon-size` for style export;
     * GLES layout uses this pixel formula instead.
     */
    fun fireObsIconSidePx(layerId: String?, feature: Feature): Float? {
        if (layerId != FIRE_OBS_ICONS_LAYER_ID) return null
        val props = feature.properties() ?: return 20f
        if (!props.has("report")) return 20f
        val area =
            when (val raw = props.get("report.areaAC")) {
                is Number -> max(1.0, raw.toDouble())
                else -> 1.0
            }
        val factor = min(1.0, area / 20_000.0)
        return min(40.0, round(18.0 + 22.0 * factor)).toFloat()
    }

    fun fireObsUsesBottomAnchor(layerId: String?): Boolean =
        layerId == FIRE_OBS_ICONS_LAYER_ID

    /**
     * Rule: raw-vector-fast-path (Symbol port). Raw-attrs counterpart to [fireObsIconSidePx] — reads
     * the same flat, dot-notation-keyed `"report.areaAC"` attribute directly (MVT attribute maps are
     * already flat before [com.xweather.mapsgl.sources.nestedDictionary] conversion, same key shape
     * [com.mapbox.geojson.Feature.properties] flattens to), so no nested-map traversal is needed here.
     */
    fun fireObsIconSidePxRaw(layerId: String?, attributes: Map<String, Any?>): Float? {
        if (layerId != FIRE_OBS_ICONS_LAYER_ID) return null
        if (!attributes.containsKey("report")) return 20f
        val area = when (val raw = attributes["report.areaAC"]) {
            is Number -> max(1.0, raw.toDouble())
            else -> 1.0
        }
        val factor = min(1.0, area / 20_000.0)
        return min(40.0, round(18.0 + 22.0 * factor)).toFloat()
    }

    /** Extra screen-down px between the fire icon/circle and the name label on GLES. */
    fun fireObsNamesExtraTextOffsetYPx(layerId: String?): Float =
        if (layerId == FIRE_OBS_NAMES_LAYER_ID) FIRE_OBS_NAMES_EXTRA_OFFSET_Y_PX else 0f

    private const val FIRE_OBS_NAMES_EXTRA_OFFSET_Y_PX = 6f

    /**
     * Per-layer override for the vertical gap between stacked [com.xweather.mapsgl.style.TextPaint]
     * lines (default [VectorTextLayout]'s flat `TEXT_LINE_GAP_PX`). Null = use the default. The
     * temperature value and city name were reading as two disconnected labels rather than one
     * value+name block; a negative gap pulls their (already-padded) glyph boxes closer together.
     */
    fun stackedLineGapPxOverride(layerId: String?): Float? =
        if (DataQuery.isValueTextLayerId(layerId)) -14f else null

    /**
     * When true, every stacked [com.xweather.mapsgl.style.TextPaint] line is horizontally centered
     * on the block's own widest line instead of left-aligned (the default — matches JS's newline
     * rasterization). Requested layer-specific: the temperature value should sit centered above the
     * (usually wider) city name, not flush against its left edge.
     */
    fun centerStackedLinesHorizontally(layerId: String?): Boolean =
        DataQuery.isValueTextLayerId(layerId)

    /**
     * Rule: place-label-text-scale-tuning. JS's `admin.ts` `text.size` values (10-22) assume a web
     * canvas context with no devicePixelRatio multiply for text (confirmed: JS's symbol quad scale
     * never multiplies by dpr, only fragment-shader SDF edge AA does — matching Android's `u_dpr`
     * usage, which is likewise fragment-only). Android's GLES billboard path has no such implicit
     * canvas-to-device mapping and must explicitly convert a dp-equivalent size to physical pixels
     * ([VectorTextLayout.resolveFontSizePx]'s `dpiMult * VECTOR_SYMBOL_GL_PIXEL_SCALE`, which reduces
     * to exactly one `density` multiply — confirmed no double-scaling anywhere in the pipeline). The
     * result is arithmetically correct but visually oversized: JS's numbers were tuned for desktop/web
     * viewing, and the identical values scaled as Android dp on a small, high-density phone screen at
     * a zoomed-out view (showing hundreds of simultaneous city labels) occupy a much larger fraction
     * of the visible map. [PLACE_LABEL_SIZE_SCALE] compensates for that phone-vs-desktop viewing
     * mismatch — tuned by live, on-device comparison, not derived from a formula.
     */
    private const val PLACE_LABEL_SIZE_SCALE = 1.2f

    /**
     * JS parity: `admin.ts`'s `placeLayer(...)` `text.size` functions for the 4 admin place-label
     * layers are zoom/rank-stepped functions, not expressible as a single [StyleValue.Constant]/
     * [StyleValue.Expression] in the generated (do-not-edit) `Admin.kt` config — none of the 4 ever
     * had a `size` set there, so they all fell back to [VectorTextLayout]'s flat 12px default.
     * Applied here instead, mirroring [fireObsIconSidePx]'s layer-id + [Feature] pattern; see
     * [PLACE_LABEL_SIZE_SCALE] for why the JS-parity numbers are additionally scaled down.
     */
    fun textFontSizePxOverride(layerId: String?, feature: Feature, zoom: Double): Float? {
        val jsParityPx = when (layerId) {
            PLACE_CITY_LAYER_ID -> placeCityFontSizePx(feature, zoom)
            PLACE_NEIGHBORHOOD_LAYER_ID -> if (zoom < 13.0) 11f else 14f
            PLACE_STATE_LAYER_ID -> if (zoom < 4.0) 10f else 12f
            PLACE_COUNTRY_LAYER_ID -> when {
                zoom < 2.0 -> 13f
                zoom < 4.0 -> 16f
                else -> 20f
            }

            else -> null
        } ?: return null
        return jsParityPx * PLACE_LABEL_SIZE_SCALE
    }

    /**
     * Rule: pruning-to-referenced-keys. Property keys read directly off [Feature.properties]/raw
     * attrs by [fireObsIconSidePx]/[fireObsIconSidePxRaw]/[textFontSizePxOverride] — none of these go
     * through any [StyleValue]/[Expression] the caller's [com.xweather.mapsgl.map.mapbox.ExpressionReferencedKeys]
     * walk can see, so they'd be silently pruned away once a consumer declares any restriction at all.
     */
    fun additionalNeededPropertyKeys(layerId: String?): Set<String> =
        when (layerId) {
            FIRE_OBS_ICONS_LAYER_ID -> setOf("report", "report.areaAC")
            PLACE_CITY_LAYER_ID -> setOf("class", "rank")
            else -> emptySet()
        }

    /**
     * Rule: place-label-contrast-tuning. `Admin.kt`'s place-label text colors (`#333` for place-city,
     * do-not-edit generated config) assume a light/white basemap under the text — dark fill against a
     * *dark* basemap (this demo app's theme) is nearly invisible, leaving only the white outline
     * visible and making the whole glyph read as a blurry white blob. Darkens the fill for readable
     * contrast against this app's dark map; the outline is already `#fff` and doesn't need a color
     * change, just a thinner stroke (see [textOutlineWidthScale]).
     */
    fun textFillColorOverride(layerId: String?): Int? =
        when (layerId) {
            PLACE_CITY_LAYER_ID -> BLACK_ARGB
            else -> null
        }

    private const val BLACK_ARGB = -0x1000000 // 0xFF000000.toInt(): opaque black

    /**
     * Outline-thickness multiplier applied on top of [VectorTextAtlas]'s own font-size-relative
     * outline width. Was thinned to 0.3x when small place-city glyphs were rasterized 1:1 with
     * their on-screen size (the halo read as thick/blurry relative to the thin letterforms) — now
     * that glyphs are supersampled (see [VectorTextAtlas.TEXT_SUPERSAMPLE]) the fill renders crisp
     * regardless of halo width, so back to the full formula reads better (bolder, more legible
     * against the map) instead of a thin sliver.
     */
    fun textOutlineWidthScale(layerId: String?): Float = 0.85f

    /**
     * Rule: place-label-contrast-tuning. The native Mapbox basemap's own labels (e.g. "Gothenburg",
     * rendered by the base style, not this layer) stay legible at a similar on-screen size with a
     * much thinner halo — a big part of why is bold letterforms: a bold stroke gives the same
     * absolute halo width a smaller *proportional* share of the glyph, letting the fill dominate.
     * `Admin.kt`'s place-city `TextPaint` sets no `weight` (defaults to regular).
     */
    fun textBoldOverride(layerId: String?): Boolean? =
        when (layerId) {
            PLACE_CITY_LAYER_ID -> true
            else -> null
        }

    /** JS `admin.ts` `place-city` text.size: branches on feature `class` and `rank`. */
    private fun placeCityFontSizePx(feature: Feature, zoom: Double): Float {
        val props = feature.properties()
        val classValue = props?.get("class")?.let { if (it.isJsonPrimitive) it.asString else null }
        // JS `data.rank < 5` is false when rank is missing (undefined < 5 === false in JS).
        val rank = props?.get("rank")?.let {
            if (it.isJsonPrimitive && it.asJsonPrimitive.isNumber) it.asDouble else null
        } ?: Double.MAX_VALUE
        if (classValue == "city") {
            return when {
                zoom < 4.0 -> 10f
                zoom < 6.0 -> 12f
                zoom < 8.0 -> if (rank < 5.0) 16f else 12f
                zoom < 11.0 -> if (rank < 5.0) 20f else 16f
                else -> 22f
            }
        }
        return if (zoom > 10.0) 16f else 12f
    }
}
