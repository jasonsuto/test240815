package com.xweather.mapsgl.renderers

import kotlin.math.floor

/**
 * Lightweight tile-space symbol placement grid (MapsGL JS `placeSymbols` collision thinning).
 * One icon per cell sized to its diameter in tile UV space (512px nominal tile).
 */
internal class VectorSymbolPlacementCuller {

    private val occupied = HashSet<Long>(256)

    fun tryPlace(tileU: Float, tileV: Float, halfPx: Float): Boolean {
        val diameterUv = ((halfPx * 2f) / 512f).coerceAtLeast(1e-5f)
        val cx = floor(tileU / diameterUv).toInt()
        val cy = floor(tileV / diameterUv).toInt()
        val key = (cx.toLong() shl 32) or (cy.toLong() and 0xffffffffL)
        return occupied.add(key)
    }
}

internal fun symbolAllowOverlapForPaint(paint: com.xweather.mapsgl.style.SymbolLayerPaint): Boolean {
    // A custom icon.shader draws icon-like instances with no bound image (icon-less shader-only
    // instances, see VectorSymbolLayerRenderer.buildInstances's `paint.icon.shader != null` branch) —
    // icon.allowOverlap must still gate collision for those, not just when an image is bound.
    val hasIcon = paint.icon.image != null || paint.icon.shader != null
    if (hasIcon) {
        val iconOverlap = when (val value = paint.icon.allowOverlap) {
            is com.xweather.mapsgl.style.StyleValue.Constant -> value.constantValue == true
            else -> false
        }
        if (iconOverlap) return true
    }
    if (paint.text.isEmpty()) return false
    return paint.text.any { tp ->
        when (val value = tp.allowOverlap) {
            is com.xweather.mapsgl.style.StyleValue.Constant -> value.constantValue == true
            else -> false
        }
    }
}
