package com.xweather.mapsgl.renderers

import android.opengl.GLES31
import android.opengl.Matrix
import androidx.compose.ui.graphics.Color
import com.xweather.mapsgl.gl.EmptyRenderPass
import com.xweather.mapsgl.gl.RenderPass
import com.xweather.mapsgl.gl.math.PowerTable.Companion.powerTableI
import com.xweather.mapsgl.gl.programs.RasterTileProgram
import com.xweather.mapsgl.gl.worldObjects.MeshInfo
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera
import com.xweather.mapsgl.layers.tile.RenderContext
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.layers.tile.VectorTileLayer
import com.xweather.mapsgl.map.mapbox.CameraSync
import com.xweather.mapsgl.map.mapbox.GlStencilMaskRendererHolder
import com.xweather.mapsgl.map.mapbox.MapboxMapController
import com.xweather.mapsgl.map.mapbox.VectorGeometryColorBuckets
import com.xweather.mapsgl.map.mapbox.VectorGeometryCoordinator
import com.xweather.mapsgl.map.mapbox.VectorFeatureStyleResolver
import com.xweather.mapsgl.map.mapbox.stencilCacheKeyForMeshInfo
import com.xweather.mapsgl.style.FillLayerPaint
import com.xweather.mapsgl.style.LineLayerPaint
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.tiles.TileData
import kotlinx.coroutines.launch

/**
 * Draws MVT fill/line layers as GLES triangle meshes (tile UV space) in the Mapbox custom-layer pass.
 */
class VectorGeometryRenderer(
    override var id: String,
) : TileLayerRenderer<TileData, LayerRenderContext<Any>>() {

    private val projectionMatrixArray = FloatArray(16)
    private val cameraArray = FloatArray(16)
    private val matrixArray = FloatArray(16)
    private val modelViewMatrixArray = FloatArray(16)

    override fun draw(context: LayerRenderContext<Any>, texUnit: HashMap<String, Int>) {}

    override fun onAdd() {}

    override fun onAdd(context: RenderContext<Any>, tileLayer: TileLayer, controller: MapboxMapController) {}

    override suspend fun update() {}

    override fun setUpRenderPass(): RenderPass =
        EmptyRenderPass(tileLayer?.source?.id ?: id, tileLayer!!.paint)

    override fun draw(context: LayerRenderContext<Any>, texUnit: HashMap<String, Int>, camera: Camera) {
        if (!renderpassInitialized) return
        val layer = tileLayer as? VectorTileLayer ?: return
        if (!layer.glRenderingActive()) return
        val mc = layer.mapController as? MapboxMapController ?: return
        val cache = mc.glStencilMaskTileCache
        val renderer = GlStencilMaskRendererHolder.renderer
        val rasterProgram = program as? RasterTileProgram

        val bounds = layer.bounds ?: mc.getBounds()
        val zoom = layer.zoomForVisibleTiles()
        val tileBounds = layer.getVisibleTileBounds(bounds, zoom)
        val coords = layer.getVisibleTileCoords(bounds, tileBounds, zoom, fromGetRenderables = true)
        if (coords.isEmpty()) return

        val mapboxProj = CameraSync.mapboxProjectionMatrix
        val mapboxMv = CameraSync.mapboxModelViewMatrix
        val useMapboxNativeMv =
            mapboxProj != null && mapboxMv != null && mapboxProj.size >= 16 && mapboxMv.size >= 16
        if (useMapboxNativeMv) {
            System.arraycopy(mapboxProj!!, 0, projectionMatrixArray, 0, 16)
            System.arraycopy(mapboxMv!!, 0, cameraArray, 0, 16)
        } else {
            matrixToFloatArray(camera.projectionMatrix, projectionMatrixArray)
            matrixToFloatArray(camera.viewMatrix, cameraArray)
        }

        val colors = resolveColors(layer)

        val mapZoomNow = CameraSync.customLayerRenderZoom ?: CameraSync.mapZoom
        val depthWas = GLES31.glIsEnabled(GLES31.GL_DEPTH_TEST)
        GLES31.glDisable(GLES31.GL_DEPTH_TEST)
        try {
            for (coord in coords) {
                val meshInfo = meshInfoForCoord(coord)
                val cacheKey = stencilCacheKeyForMeshInfo(meshInfo)
                val overscale = CameraSync.tileRasterOverscale(mapZoomNow, meshInfo.z.toInt())
                Matrix.setIdentityM(matrixArray, 0)
                Matrix.scaleM(matrixArray, 0, 512f * overscale, 512f * overscale, 1f)
                Matrix.translateM(matrixArray, 0, meshInfo.x, meshInfo.y, 0f)
                Matrix.multiplyMM(modelViewMatrixArray, 0, cameraArray, 0, matrixArray, 0)

                VectorGeometryCoordinator.prepareLineMeshesForDraw(
                    mc,
                    layer,
                    coord,
                    cacheKey,
                    mapZoomNow,
                )

                when (layer.paint) {
                    is LineLayerPaint -> drawLineMeshes(
                        renderer,
                        cache,
                        cacheKey,
                        layer.id,
                        projectionMatrixArray,
                        modelViewMatrixArray,
                        rasterProgram,
                        colors,
                    )

                    is FillLayerPaint -> drawFillMeshes(
                        renderer,
                        cache,
                        cacheKey,
                        layer.id,
                        projectionMatrixArray,
                        modelViewMatrixArray,
                        rasterProgram,
                        colors,
                    )
                }
            }
        } finally {
            if (depthWas) GLES31.glEnable(GLES31.GL_DEPTH_TEST)
        }
    }

    private fun drawLineMeshes(
        renderer: com.xweather.mapsgl.map.mapbox.GlStencilMaskRenderer,
        cache: com.xweather.mapsgl.map.mapbox.GlStencilMaskTileCache,
        cacheKey: String,
        layerId: String,
        projection: FloatArray,
        modelView: FloatArray,
        rasterProgram: RasterTileProgram?,
        colors: ResolvedColors,
    ) {
        val buckets = VectorGeometryColorBuckets.bucketsFor(layerId)
        if (buckets.isEmpty()) {
            renderer.drawVectorGeometryColored(
                cache,
                cacheKey,
                layerId,
                projection,
                modelView,
                rasterProgram,
                colors.fill.red,
                colors.fill.green,
                colors.fill.blue,
                colors.fill.alpha * colors.fillOpacity,
            )
            return
        }
        for ((bucketId, color) in buckets) {
            renderer.drawVectorGeometryColored(
                cache,
                cacheKey,
                bucketId,
                projection,
                modelView,
                rasterProgram,
                color.red,
                color.green,
                color.blue,
                color.alpha * colors.fillOpacity,
            )
        }
    }

    private fun drawFillMeshes(
        renderer: com.xweather.mapsgl.map.mapbox.GlStencilMaskRenderer,
        cache: com.xweather.mapsgl.map.mapbox.GlStencilMaskTileCache,
        cacheKey: String,
        layerId: String,
        projection: FloatArray,
        modelView: FloatArray,
        rasterProgram: RasterTileProgram?,
        colors: ResolvedColors,
    ) {
        val buckets = VectorGeometryColorBuckets.bucketsFor(layerId)
        if (buckets.isEmpty()) {
            renderer.drawVectorGeometryColored(
                cache,
                cacheKey,
                layerId,
                projection,
                modelView,
                rasterProgram,
                colors.fill.red,
                colors.fill.green,
                colors.fill.blue,
                colors.fill.alpha * colors.fillOpacity,
            )
        } else {
            for ((bucketId, color) in buckets) {
                renderer.drawVectorGeometryColored(
                    cache,
                    cacheKey,
                    bucketId,
                    projection,
                    modelView,
                    rasterProgram,
                    color.red,
                    color.green,
                    color.blue,
                    color.alpha * colors.fillOpacity,
                )
            }
        }

        colors.stroke?.let { strokeColor ->
            val strokeLayerId = FillLayerPaint.strokeOutlineLayerId(layerId)
            renderer.drawVectorGeometryColored(
                cache,
                cacheKey,
                strokeLayerId,
                projection,
                modelView,
                rasterProgram,
                strokeColor.red,
                strokeColor.green,
                strokeColor.blue,
                strokeColor.alpha * colors.strokeOpacity,
            )
        }
    }

    override fun onAdd(tileLayer: TileLayer) {
        super.onAdd(tileLayer)
        val mc = tileLayer.mapController
        if (mc != null && tileLayer is VectorTileLayer && tileLayer.glRenderingActive()) {
            VectorGeometryCoordinator.register(mc, tileLayer)
            tileLayer.externalScope.launch {
                tileLayer.prefetchVectorTilesForGlRendering()
            }
        }
    }

    private fun meshInfoForCoord(coord: TileCoord): MeshInfo {
        val n = powerTableI.getOrElse(coord.z) { 1 shl coord.z }
        val worldX = coord.x.toFloat() + coord.offset * n
        return MeshInfo(worldX, coord.y.toFloat(), coord.z.toFloat(), coord.hashShort())
    }

    private data class ResolvedColors(
        val fill: Color,
        val fillOpacity: Float,
        val stroke: Color?,
        val strokeOpacity: Float,
    )

    private fun resolveColors(layer: VectorTileLayer): ResolvedColors {
        return when (val paint = layer.paint) {
            is FillLayerPaint -> {
                val fill = VectorFeatureStyleResolver.constantColor(paint.fill.color, Color.White)
                val fillOp = (paint.fill.opacity.constantValue ?: 1.0).toFloat() * paint.opacity
                val strokePaint = paint.stroke
                if (strokePaint == null) {
                    ResolvedColors(fill, fillOp, null, 0f)
                } else {
                    val strokeBase = VectorFeatureStyleResolver.constantColor(strokePaint.color, Color.Black)
                    val strokeOp =
                        (strokePaint.opacity.constantValue ?: 1.0).toFloat() * paint.opacity
                    val stroke =
                        if (strokeOp <= 0f) {
                            null
                        } else {
                            strokeBase.copy(alpha = strokeBase.alpha.coerceIn(0f, 1f))
                        }
                    ResolvedColors(fill, fillOp, stroke, strokeOp)
                }
            }

            is LineLayerPaint -> {
                val stroke = VectorFeatureStyleResolver.constantColor(paint.stroke.color, Color.White)
                val strokeOp = (paint.stroke.opacity.constantValue ?: 1.0).toFloat() * paint.opacity
                ResolvedColors(stroke, strokeOp, null, strokeOp)
            }

            else -> ResolvedColors(Color.White, 1f, null, 1f)
        }
    }

    private fun matrixToFloatArray(
        source: com.xweather.mapsgl.gl.math.Matrix4,
        dest: FloatArray,
    ) {
        val elements = source.elements
        for (i in 0 until 16) {
            dest[i] = elements[i]
        }
    }
}
