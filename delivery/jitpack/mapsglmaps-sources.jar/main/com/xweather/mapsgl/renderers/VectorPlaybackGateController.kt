package com.xweather.mapsgl.renderers

import android.os.SystemClock
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.layers.tile.VectorTileLayer
import com.xweather.mapsgl.map.mapbox.VectorGlPlaybackDiagnostics
import com.xweather.mapsgl.sources.VectorTileSource
import com.xweather.mapsgl.sources.timelinePhaseEpochMillis
import com.xweather.mapsgl.sources.timelinePlaybackPrefetchEpochMillis
import com.xweather.mapsgl.tiles.TileCoord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Rule: shared-playback-gate. Generic gate-hold/warmup-priming state machine extracted from
 * [VectorCircleLayerRenderer] (which arrived at this design across several sessions, including
 * fixing two indefinite hangs and one OOM crash). Tile-prefetch waves, phase scheduling, and the
 * gate lifecycle (anchor -> warmup -> fully-primed -> steady-state) don't know what kind of
 * geometry they're waiting on — only the caller does. So the four things that DO differ per layer
 * type (building one interval's geometry, checking whether it's already built, and the two
 * diagnostic-string helpers) are passed in as lambdas by the renderer at each call site, closing
 * over that renderer's own cache/paint/style state. Each renderer owns its own controller instance
 * (no state is shared across layer instances or layer types).
 *
 * Kept deliberately faithful to the circle renderer's original control flow, including at least one
 * path ([completePlaybackGateIfReady] being reachable from both [schedulePlaybackFramePreparation]'s
 * background loop and synchronously from the caller's draw loop) whose exact necessity wasn't fully
 * re-derived during extraction — changing it was out of scope for a behavior-preserving refactor.
 */
/**
 * Rule: pan-during-playback. See VectorFillLayerRenderer.PLAYBACK_PREP_COORDS_SETTLE_MS — settle
 * window before restarting [VectorPlaybackGateController.schedulePlaybackFramePreparation]'s job on
 * a detected viewport-coords change.
 */
private const val PLAYBACK_PREP_COORDS_SETTLE_MS = 400L

/**
 * Rule: burst-oom-phase-build-cap. [schedulePlaybackFramePreparation] fires every pending phase's
 * fetch+parse+triangulate work concurrently (see its own "Rule: pipelining" comment) — a deliberate
 * fix for slow sequential priming, but with no cap this fires ALL pending phases at once. For a wide
 * viewport (many tiles/phase) times a long timeline (many pending phases at playback start, e.g. a
 * multi-day range), that's dozens of full-viewport triangulation sweeps launched simultaneously,
 * which OOM-crashed within ~15-20s of pressing play (confirmed live: OOM inside
 * VectorPolygonFillTriangulator, native JNI abort on NewFloatArray under pending OOM). Capping
 * concurrent phase builds keeps most of the pipelining win (still much faster than fully sequential)
 * while bounding peak concurrent memory pressure to a fixed, small number of full-viewport sweeps.
 */
private const val MAX_CONCURRENT_PHASE_BUILDS = 3

internal class VectorPlaybackGateController(private val layerId: String) {

    // ---- Generic playback state (moved verbatim from VectorCircleLayerRenderer) ----

    val refsByIntervalMs = LinkedHashMap<Long, List<VectorPlaybackMeshRef>>()
    /**
     * Rule: playback-refs-thread-safety. [refsByIntervalMs] is written from this controller's
     * background prep job while renderer callers (Circle/Symbol/Heatmap) iterate it synchronously on
     * the Mapbox GL render thread to compute protected/drawable keys — the exact "unsynchronized
     * cross-thread map access" this class's own class-doc used to call out as a known gap. Confirmed
     * live via a fatal crash in VectorFillLayerRenderer's separate copy of this same pattern
     * (`ConcurrentModificationException` inside a `LinkedHashMap` value iterator, racing this
     * controller-style background write, aborting the whole app via JNI from inside Mapbox's native
     * render()). Public so callers outside this class synchronize on the *same* lock before iterating
     * or mutating [refsByIntervalMs] — see each renderer's own KDoc at its iteration site.
     */
    val refsLock = Any()
    /**
     * Rule: pan-during-playback. Tags which [playbackPrepGeneration] each committed interval entry
     * was built against — see [schedulePlaybackFramePreparation]'s coords-restart handling for why
     * this exists instead of clearing [refsByIntervalMs] outright on a viewport change. Read/written
     * directly against the mutable [playbackPrepGeneration] field (not a per-job frozen snapshot) to
     * avoid threading a generation parameter through every renderer's call sites into this shared,
     * per-renderer-instance controller; a stale-generation tag from a narrow restart race self-heals
     * within one prep-loop tick, same as this class's existing unsynchronized cross-thread map access.
     */
    val refsGeneration = HashMap<Long, Long>()
    /** Rule: burst-oom-phase-build-cap. Bounds how many pending phases' fetch+parse+triangulate work
     * runs concurrently in [schedulePlaybackFramePreparation] — see [MAX_CONCURRENT_PHASE_BUILDS]'s
     * KDoc. One instance per renderer (this controller is never shared across layers), so total
     * system-wide concurrency is this cap times the number of currently-active layers, not unbounded
     * across the whole pending-phase set of a single wide/long-duration layer. */
    private val phaseBuildSemaphore = Semaphore(MAX_CONCURRENT_PHASE_BUILDS)
    /** Rule: pan-during-playback. See VectorFillLayerRenderer's identical fields/KDoc — debounced
     * coords-restart tracking for [playbackFramePrepJob]. */
    var playbackFramePrepCoordsKey: Set<String> = emptySet()
    var pendingPlaybackPrepCoordsKey: Set<String> = emptySet()
    var pendingPlaybackPrepCoordsKeyStableSinceMs: Long = 0L
    var playbackPrepGeneration: Long = 0L
    /** Rule: pan-during-playback. See VectorFillLayerRenderer's identical field/KDoc — drives the
     * loading spinner for a pan-triggered reload the same way the initial-warmup booleans drive it
     * for play-press, without touching those booleans (structurally independent flags). */
    var panReprimeInProgress: Boolean = false
    var wasGloballyPlaying = false
    var playbackWarmupComplete = true
    var warmupTilePrefetchJob: Job? = null
    var playbackFramePrepJob: Job? = null
    var lastPlaybackFramePrepPhaseA: Int = -1
    var lastGloballyInactiveMs: Long = 0L
    var lastPlaybackViewportTileKeys: Set<String> = emptySet()
    var initialPlaybackWarmupSatisfied = false
    var playbackStableCoords: List<TileCoord> = emptyList()
    var playbackStableCoordsUntilMs: Long = 0L
    var playbackGateAnchorPhaseA: Int = -1
    var playbackGateAnchorPhaseB: Int = -1
    var playbackGateOpenedAtMs: Long = 0L
    /** Rule: gate-hold-circuit-breaker. Set when gate-hold begins ([beginPlaybackPrefetchGate]); used
     * to force the gate open after [gateHoldTimeoutMs] even if a layer never resolves — see that
     * constant's KDoc. */
    private var gateHoldStartedAtMs: Long = 0L
    var playbackTimelineFullyPrimed = false
    var fullTimelineMvtPrefetchJob: Job? = null

    private val fullTimelineTailPhasesPerPrepTick = 8
    private val fullTimelineMvtRequestsPerWave = 16

    // A single stuck request (e.g. a hung connection) has been observed to block a tile fetch for
    // minutes with no client-side timeout, stalling the whole playback gate behind it. Abandoning
    // it after this long lets the wave move on; the next wave/tick will simply retry.
    private val playbackTileRequestTimeoutMs = 8_000L

    /**
     * Rule: gate-hold-circuit-breaker. A layer whose gate never resolves (bad data classification,
     * a source that never produces the tiles it claims to have, a future bug of a similar shape) used
     * to retry the same anchor phase forever with no way out — and since every visible time-series
     * layer registers into one shared, process-global ready-map at Play time
     * (`Timeline.glVectorFillLayerPlaybackReady`) whose loading spinner stays active until *every*
     * entry resolves, one permanently-stuck layer blocked every OTHER layer's timeline/spinner forever
     * too (confirmed live: a misclassified static layer froze lightning + fires-obs playback even
     * though both had fully primed). Generous relative to the ~1-3s per-phase build times already
     * logged in normal operation, so this should never fire for genuinely-loading data — only for a
     * layer that's truly never going to resolve. Matches this codebase's "never a hard failure"
     * convention: degrade (that one layer may show stale/incomplete content) rather than freeze
     * everyone.
     */
    private val gateHoldTimeoutMs = 15_000L

    fun maxPlaybackIntervalRefCacheSize(): Int {
        val phaseCount = Timeline.timeStrings.size.coerceAtLeast(1)
        return maxOf(phaseCount + 8, timelinePlaybackPrefetchEpochMillis().size * 4)
    }

    fun refsForInterval(intervalMs: Long?): List<VectorPlaybackMeshRef> {
        if (intervalMs == null) return emptyList()
        return refsByIntervalMs[intervalMs].orEmpty()
    }

    /** Resets all playback state; call from the renderer's own timeline-invalidation/release path. */
    fun invalidate() {
        playbackStableCoords = emptyList()
        playbackStableCoordsUntilMs = 0L
        wasGloballyPlaying = false
        lastPlaybackViewportTileKeys = emptySet()
        lastGloballyInactiveMs = 0L
        initialPlaybackWarmupSatisfied = false
        playbackWarmupComplete = true
        warmupTilePrefetchJob?.cancel()
        warmupTilePrefetchJob = null
        playbackFramePrepJob?.cancel()
        playbackFramePrepJob = null
        lastPlaybackFramePrepPhaseA = -1
        playbackGateOpenedAtMs = 0L
        gateHoldStartedAtMs = 0L
        playbackGateAnchorPhaseA = -1
        playbackGateAnchorPhaseB = -1
        playbackTimelineFullyPrimed = false
        fullTimelineMvtPrefetchJob?.cancel()
        fullTimelineMvtPrefetchJob = null
        synchronized(refsLock) { refsByIntervalMs.clear() }
    }

    fun beginPlaybackPrefetchGate(layer: VectorTileLayer?) {
        val priorViewportTileKeys = lastPlaybackViewportTileKeys
        var refreshedViewportTileKeys = priorViewportTileKeys
        layer?.let { vectorLayer ->
            val tileLayerRef = vectorLayer as? TileLayer ?: return@let
            tileLayerRef.refreshVisibleTileCoordsForVectorGl()
            val coords = tileLayerRef.visibleTileCoordsForGlVectorPlayback()
            if (coords.isNotEmpty()) {
                refreshedViewportTileKeys = coords.map { "${it.z}/${it.x}/${it.y}" }.toSet()
            }
            (vectorLayer.source as? VectorTileSource)?.cancelAllInFlightTimeSeriesTiles()
        }
        val viewportChanged =
            priorViewportTileKeys.isEmpty() ||
                refreshedViewportTileKeys.isEmpty() ||
                refreshedViewportTileKeys != priorViewportTileKeys
        lastPlaybackViewportTileKeys = refreshedViewportTileKeys
        playbackGateAnchorPhaseA = Timeline.currentPhaseA
        playbackGateAnchorPhaseB = Timeline.currentPhaseB
        playbackGateOpenedAtMs = 0L
        gateHoldStartedAtMs = SystemClock.elapsedRealtime()
        playbackWarmupComplete = false
        initialPlaybackWarmupSatisfied = false
        playbackTimelineFullyPrimed = false
        fullTimelineMvtPrefetchJob?.cancel()
        fullTimelineMvtPrefetchJob = null
        warmupTilePrefetchJob?.cancel()
        warmupTilePrefetchJob = null
        playbackFramePrepJob?.cancel()
        playbackFramePrepJob = null
        lastPlaybackFramePrepPhaseA = -1
        if (viewportChanged) {
            synchronized(refsLock) { refsByIntervalMs.clear() }
            playbackTimelineFullyPrimed = false
        }
        layer?.let { vectorLayer ->
            val vts = vectorLayer.source as? VectorTileSource ?: return@let
            val tileLayerRef = vectorLayer as? TileLayer ?: return@let
            val coords = tileLayerRef.visibleTileCoordsForGlVectorPlayback()
            if (coords.isNotEmpty()) {
                VectorGlPlaybackDiagnostics.onGateBegin(
                    layerId = vectorLayer.id,
                    playbackZoom = tileLayerRef.glVectorPlaybackDataZoom(),
                    coords = coords,
                    phaseCount = allTimelinePhaseEpochMs(vts).size,
                )
            }
        }
    }

    fun allTimelinePhaseEpochMs(vts: VectorTileSource): List<Long> =
        Timeline.timeStrings.indices
            .mapNotNull { timelinePhaseEpochMillis(it) }
            .map { vts.snappedTimeSeriesIntervalMs(it) }
            .distinct()

    fun timelinePhaseIndexForSnappedMs(vts: VectorTileSource, snappedMs: Long): Int =
        Timeline.timeStrings.indices.firstOrNull { idx ->
            timelinePhaseEpochMillis(idx)?.let { vts.snappedTimeSeriesIntervalMs(it) } == snappedMs
        } ?: -1

    fun isPlaybackTimelineFullyPrimed(
        vts: VectorTileSource,
        coords: List<TileCoord>,
        isDrawable: (TileCoord, Long) -> Boolean,
    ): Boolean {
        val allPhases = allTimelinePhaseEpochMs(vts)
        if (allPhases.isEmpty() || coords.isEmpty()) return true
        // Rule: pan-during-playback. Also requires the entry's generation tag to match the current
        // playbackPrepGeneration — otherwise a coords-restart (new viewport) would report "fully
        // primed" even though every entry still only covers the OLD viewport's tiles.
        return allPhases.all { snappedMs ->
            refsByIntervalMs.containsKey(snappedMs) &&
                refsGeneration[snappedMs] == playbackPrepGeneration &&
                coords.all { coord -> isDrawable(coord, snappedMs) }
        }
    }

    fun phasesForPlaybackFramePrep(
        vts: VectorTileSource,
        gateHoldActive: Boolean,
        fullTimelinePrimeActive: Boolean,
    ): List<Long> {
        // Rule: pan-during-playback. "Missing" also includes entries whose generation tag is stale
        // (built for a since-superseded coords set) — see refsGeneration's KDoc.
        fun isMissing(snappedMs: Long) =
            !refsByIntervalMs.containsKey(snappedMs) || refsGeneration[snappedMs] != playbackPrepGeneration
        when {
            gateHoldActive ->
                return allTimelinePhaseEpochMs(vts).filter(::isMissing)
            fullTimelinePrimeActive -> {
                val rolling = playbackPrefetchPhaseEpochMs(vts)
                val missingTailFirst = allTimelinePhaseEpochMs(vts)
                    .filter(::isMissing)
                    .sortedByDescending { timelinePhaseIndexForSnappedMs(vts, it) }
                    .take(fullTimelineTailPhasesPerPrepTick)
                return (rolling + missingTailFirst).distinct()
            }
            else -> {
                val currentPhaseMs = timelinePhaseEpochMillis(Timeline.currentPhaseA)
                val rollingPhases = playbackPrefetchPhaseEpochMs(vts)
                return buildList {
                    currentPhaseMs?.let { add(it) }
                    for (phaseMs in rollingPhases) {
                        if (phaseMs != currentPhaseMs) add(phaseMs)
                    }
                }
            }
        }
    }

    fun playbackPrefetchPhaseEpochMs(vts: VectorTileSource): List<Long> =
        timelinePlaybackPrefetchEpochMillis(lookBehind = 2, lookAhead = 10)
            .map { vts.snappedTimeSeriesIntervalMs(it) }
            .distinct()

    fun scheduleFullTimelineMvtPrefetch(
        layer: VectorTileLayer,
        vts: VectorTileSource,
        coords: List<TileCoord>,
    ) {
        if (!Timeline.isGloballyPlaying || coords.isEmpty()) return
        // Gate-hold prep owns full-timeline MVT fetch until [completePlaybackGateIfReady].
        if (!playbackWarmupComplete) return
        if (playbackTimelineFullyPrimed && playbackWarmupComplete) return
        if (fullTimelineMvtPrefetchJob?.isActive == true) return
        val prepCoords = coords.toList()
        fullTimelineMvtPrefetchJob = layer.externalScope.launch(Dispatchers.Default) {
            val phasesTailFirst = allTimelinePhaseEpochMs(vts)
                .sortedByDescending { timelinePhaseIndexForSnappedMs(vts, it) }
            while (isActive && Timeline.isGloballyPlaying && !playbackTimelineFullyPrimed) {
                val waveStartMs = SystemClock.elapsedRealtime()
                val requested = prefetchPlaybackTilesWave(
                    layer = layer,
                    vts = vts,
                    coords = prepCoords,
                    phases = phasesTailFirst,
                    waveBudget = fullTimelineMvtRequestsPerWave,
                    awaitCompletion = false,
                )
                val parsed = prefetchPlaybackNativeParseWave(
                    vts,
                    prepCoords,
                    phasesTailFirst,
                    waveBudget = 64,
                )
                VectorGlPlaybackDiagnostics.logPrefetchWave(
                    "fullTimeline",
                    requested,
                    SystemClock.elapsedRealtime() - waveStartMs,
                    parsed,
                )
                if (requested == 0 && parsed == 0 &&
                    allViewportPhasesDataResolved(vts, prepCoords, phasesTailFirst)
                ) {
                    break
                }
                delay(40)
            }
        }
    }

    fun playbackPrepCoords(layer: VectorTileLayer, fallback: List<TileCoord>): List<TileCoord> {
        layer.refreshVisibleTileCoordsForVectorGl()
        val visible = layer.visibleTileCoordsForGlVectorPlayback()
        return when {
            visible.isNotEmpty() -> visible
            playbackStableCoords.isNotEmpty() -> playbackStableCoords
            fallback.isNotEmpty() -> fallback
            else -> emptyList()
        }
    }

    /** Single coord set for gate, warmup, MVT prefetch, and frame prep (avoids stable-hold vs visible mismatch). */
    fun playbackGateCoords(
        layer: VectorTileLayer,
        primaryCoords: List<TileCoord>,
        fallbackCoords: List<TileCoord>,
    ): List<TileCoord> {
        val prep = playbackPrepCoords(layer, primaryCoords.ifEmpty { fallbackCoords })
        if (prep.isNotEmpty()) return prep
        return primaryCoords.ifEmpty { fallbackCoords }
    }

    fun completePlaybackGateIfReady(
        layer: VectorTileLayer,
        vts: VectorTileSource,
        gateCoords: List<TileCoord>,
        isDrawable: (TileCoord, Long) -> Boolean,
        force: Boolean = false,
    ): Boolean {
        if (!force && !isPlaybackTimelineFullyPrimed(vts, gateCoords, isDrawable)) return false
        if (force) {
            VectorGlPlaybackDiagnostics.onGateForceOpened(layerId, gateHoldTimeoutMs)
        }
        playbackWarmupComplete = true
        initialPlaybackWarmupSatisfied = true
        playbackTimelineFullyPrimed = true
        playbackGateAnchorPhaseA = -1
        playbackGateAnchorPhaseB = -1
        playbackGateOpenedAtMs = SystemClock.elapsedRealtime()
        VectorGlPlaybackDiagnostics.onGateOpen(layer.id)
        warmupTilePrefetchJob?.cancel()
        warmupTilePrefetchJob = null
        fullTimelineMvtPrefetchJob?.cancel()
        fullTimelineMvtPrefetchJob = null
        Timeline.setGlVectorFillLayerPlaybackReady(layer.id, true)
        Timeline.markPlaybackFullTimelinePrimed(layer.id)
        if (!Timeline.isAnyGlVectorFillLayerAwaitingPlayback()) {
            Timeline.endGlVectorFillPrefetchLoadUi()
            layer.mapController?.scheduleVectorFillPrefetchLoadComplete()
        }
        return true
    }

    suspend fun prefetchPlaybackTilesWave(
        layer: VectorTileLayer,
        vts: VectorTileSource,
        coords: List<TileCoord>,
        phases: List<Long>,
        waveBudget: Int,
        awaitCompletion: Boolean = false,
    ): Int {
        if (waveBudget <= 0 || coords.isEmpty() || phases.isEmpty()) return 0
        if (vts.inFlightTimeSeriesTileCount() >= VectorTileSource.TIME_SERIES_MAX_IN_FLIGHT_BEFORE_PREFETCH) {
            return 0
        }
        var scheduled = 0
        // Requests picked by the selection loop below are gathered here (when awaitCompletion is
        // set) and fetched concurrently rather than one-at-a-time, so a wave's wall-clock cost is
        // bounded by its slowest tile instead of the sum of every tile's fetch+parse latency.
        val toAwait = if (awaitCompletion) ArrayList<Pair<TileCoord, Long>>(waveBudget) else null
        phaseLoop@ for (phaseMs in phases) {
            for (coord in coords) {
                if (vts.inFlightTimeSeriesTileCount() >= VectorTileSource.TIME_SERIES_MAX_IN_FLIGHT_BEFORE_PREFETCH) {
                    break@phaseLoop
                }
                if (vts.hasTimeSeriesIntervalAt(coord.z, coord.x, coord.y, phaseMs)) continue
                val phaseToRequest = phaseMs
                val coordToRequest = coord
                if (awaitCompletion) {
                    toAwait?.add(coordToRequest to phaseToRequest)
                } else {
                    layer.externalScope.launch(Dispatchers.IO) {
                        runCatching {
                            withTimeoutOrNull(playbackTileRequestTimeoutMs) {
                                vts.requestTile(
                                    coordToRequest.x,
                                    coordToRequest.y,
                                    coordToRequest.z,
                                    intervalTime = java.util.Date(phaseToRequest),
                                )
                            }
                        }
                    }
                }
                scheduled++
                if (scheduled >= waveBudget) break@phaseLoop
            }
        }
        if (!toAwait.isNullOrEmpty()) {
            coroutineScope {
                toAwait.map { (coordToRequest, phaseToRequest) ->
                    async(Dispatchers.IO) {
                        runCatching {
                            withTimeoutOrNull(playbackTileRequestTimeoutMs) {
                                vts.requestTile(
                                    coordToRequest.x,
                                    coordToRequest.y,
                                    coordToRequest.z,
                                    intervalTime = java.util.Date(phaseToRequest),
                                )
                            }
                        }
                    }
                }.awaitAll()
            }
        }
        return scheduled
    }

    suspend fun prefetchPlaybackNativeParseWave(
        vts: VectorTileSource,
        coords: List<TileCoord>,
        phases: List<Long>,
        waveBudget: Int,
    ): Int {
        var parsed = 0
        phaseLoop@ for (phaseMs in phases) {
            val snappedMs = vts.snappedTimeSeriesIntervalMs(phaseMs)
            for (coord in coords) {
                if (vts.hasTimeSeriesDataLoadedAt(coord.z, coord.x, coord.y, snappedMs)) continue
                if (vts.isTimeSeriesIntervalDownloading(coord.z, coord.x, coord.y, snappedMs)) continue
                if (!vts.hasTimeSeriesIntervalAt(coord.z, coord.x, coord.y, snappedMs) &&
                    !vts.hasUnparsedNativeMvtAt(coord.z, coord.x, coord.y, snappedMs)
                ) {
                    continue
                }
                ensurePhaseDataParsed(vts, coord, snappedMs)
                parsed++
                if (parsed >= waveBudget) break@phaseLoop
            }
        }
        return parsed
    }

    fun countUnparsedNativeMvt(
        vts: VectorTileSource,
        coords: List<TileCoord>,
        phases: List<Long>,
    ): Int {
        var count = 0
        for (phaseMs in phases) {
            val snappedMs = vts.snappedTimeSeriesIntervalMs(phaseMs)
            for (coord in coords) {
                if (vts.hasUnparsedNativeMvtAt(coord.z, coord.x, coord.y, snappedMs)) count++
            }
        }
        return count
    }

    suspend fun ensurePhaseDataParsed(vts: VectorTileSource, coord: TileCoord, snappedMs: Long) {
        if (vts.hasTimeSeriesDataLoadedAt(coord.z, coord.x, coord.y, snappedMs)) return
        if (vts.isTimeSeriesIntervalDownloading(coord.z, coord.x, coord.y, snappedMs)) return
        vts.ensureTimeSeriesParsedAt(coord.z, coord.x, coord.y, snappedMs)
    }

    suspend fun ensurePlaybackPhaseDataReady(
        vts: VectorTileSource,
        coords: List<TileCoord>,
        snappedMs: Long,
    ) {
        if (vts.inFlightTimeSeriesTileCount() >= VectorTileSource.TIME_SERIES_MAX_IN_FLIGHT_BEFORE_PREFETCH) {
            return
        }
        // Rule: pipelining. requestTile()/ensurePhaseDataParsed() are suspend calls (network + parse);
        // launching them concurrently instead of one coord at a time cuts this function's
        // contribution to a phase's build time by roughly the coord count (was found to be a major
        // component of a full 25-interval run's wall-clock time, worse than either the network fetch
        // or the parse/triangulate work it was gating).
        coroutineScope {
            coords.map { coord ->
                async(Dispatchers.Default) {
                    if (vts.inFlightTimeSeriesTileCount() >= VectorTileSource.TIME_SERIES_MAX_IN_FLIGHT_BEFORE_PREFETCH) {
                        return@async
                    }
                    if (!vts.hasTimeSeriesIntervalAt(coord.z, coord.x, coord.y, snappedMs)) {
                        runCatching {
                            vts.requestTile(coord.x, coord.y, coord.z, intervalTime = java.util.Date(snappedMs))
                        }
                    } else if (
                        !vts.hasTimeSeriesDataLoadedAt(coord.z, coord.x, coord.y, snappedMs) &&
                        !vts.isTimeSeriesIntervalDownloading(coord.z, coord.x, coord.y, snappedMs)
                    ) {
                        ensurePhaseDataParsed(vts, coord, snappedMs)
                    }
                }
            }.awaitAll()
        }
    }

    fun allViewportPhasesDataResolved(
        vts: VectorTileSource,
        coords: List<TileCoord>,
        phases: List<Long>,
    ): Boolean {
        if (coords.isEmpty() || phases.isEmpty()) return true
        return phases.all { phaseMs ->
            val snappedMs = vts.snappedTimeSeriesIntervalMs(phaseMs)
            coords.all { coord -> vts.hasTimeSeriesDataLoadedAt(coord.z, coord.x, coord.y, snappedMs) }
        }
    }

    fun isIntervalReadyForPlaybackDisplay(
        vts: VectorTileSource,
        coords: List<TileCoord>,
        intervalMs: Long,
        isDrawable: (TileCoord, Long) -> Boolean,
    ): Boolean {
        if (coords.isEmpty()) return true
        val snappedMs = vts.snappedTimeSeriesIntervalMs(intervalMs)
        if (!coords.all { coord -> isDrawable(coord, snappedMs) }) return false
        return refsByIntervalMs.containsKey(snappedMs)
    }

    /**
     * The big playback loop: gate-hold (serialize breadth, one phase at a time, awaited fetches) ->
     * full-timeline-prime (every remaining phase, concurrently, non-blocking fetches) -> steady-state
     * (rolling window around the playhead). [buildRefs] does the layer-specific fetch-if-needed +
     * build-and-cache-geometry + wrap-in-refs work for one interval across all [coords]; everything
     * else here is generic scheduling/bookkeeping.
     */
    fun schedulePlaybackFramePreparation(
        layer: VectorTileLayer,
        vts: VectorTileSource,
        coords: List<TileCoord>,
        buildRefs: suspend (coords: List<TileCoord>, intervalMs: Long) -> List<VectorPlaybackMeshRef>,
        isDrawable: (coord: TileCoord, snappedMs: Long) -> Boolean,
        phaseStoreBlockers: (coords: List<TileCoord>, snappedMs: Long) -> List<String>,
        gateBlockers: (coords: List<TileCoord>) -> List<String>,
        onRepaintNeeded: () -> Unit,
    ) {
        if (!Timeline.isGloballyPlaying || coords.isEmpty()) return
        // Rule: dateline-world-copy. See VectorFillLayerRenderer's identical fix — must include
        // offset, not just z/x/y, or gaining/losing a world copy at wide zoomed-out antimeridian
        // views is never detected as a coords change.
        val coordsKey = coords.mapTo(HashSet(coords.size)) { "${it.z}/${it.x}/${it.y}/${it.offset}" }
        if (playbackFramePrepJob?.isActive == true) {
            if (coordsKey == playbackFramePrepCoordsKey) {
                pendingPlaybackPrepCoordsKey = coordsKey
                return
            }
            val now = SystemClock.elapsedRealtime()
            if (coordsKey != pendingPlaybackPrepCoordsKey) {
                pendingPlaybackPrepCoordsKey = coordsKey
                pendingPlaybackPrepCoordsKeyStableSinceMs = now
                return
            }
            if (now - pendingPlaybackPrepCoordsKeyStableSinceMs < PLAYBACK_PREP_COORDS_SETTLE_MS) return
            // Rule: pan-during-playback. See VectorFillLayerRenderer's identical restart logic/KDoc —
            // deliberately does NOT clear refsByIntervalMs (would blank the whole timeline's content
            // until rebuilt) and does NOT touch playbackWarmupComplete/initialPlaybackWarmupSatisfied
            // (confirmed to freeze the timeline clock for 30+ seconds if reset mid-playback). Bumps
            // playbackPrepGeneration instead; see refsGeneration's KDoc. The load-indicator flags
            // below ARE safe to touch here — see panReprimeInProgress's KDoc.
            playbackFramePrepJob?.cancel()
            playbackFramePrepJob = null
            playbackPrepGeneration++
            playbackTimelineFullyPrimed = false
            panReprimeInProgress = true
            Timeline.setGlVectorFillLayerPlaybackReady(layer.id, false)
            Timeline.beginGlVectorFillPrefetchLoadUi()
        }
        playbackFramePrepCoordsKey = coordsKey
        pendingPlaybackPrepCoordsKey = coordsKey
        val prepCoords = coords.toList()
        playbackFramePrepJob = layer.externalScope.launch(Dispatchers.Default) {
            while (isActive && Timeline.isGloballyPlaying) {
                val gateHoldActive = !playbackWarmupComplete && playbackGateAnchorPhaseA >= 0
                val fullTimelinePrimeActive = playbackWarmupComplete && !playbackTimelineFullyPrimed
                val allPhases = allTimelinePhaseEpochMs(vts)
                val phasesRaw = phasesForPlaybackFramePrep(vts, gateHoldActive, fullTimelinePrimeActive)
                val phases = if (gateHoldActive) phasesRaw.take(1) else phasesRaw
                var builtAny = false
                var tilesRequested = 0
                var tilesParsed = 0
                if (gateHoldActive) {
                    val gatePhase = phasesRaw.firstOrNull()
                    if (gatePhase != null) {
                        val gatePhases = listOf(gatePhase)
                        val waveStartMs = SystemClock.elapsedRealtime()
                        tilesRequested = prefetchPlaybackTilesWave(
                            layer = layer,
                            vts = vts,
                            coords = prepCoords,
                            phases = gatePhases,
                            waveBudget = prepCoords.size,
                            awaitCompletion = true,
                        )
                        tilesParsed = prefetchPlaybackNativeParseWave(
                            vts,
                            prepCoords,
                            gatePhases,
                            waveBudget = prepCoords.size,
                        )
                        VectorGlPlaybackDiagnostics.logPrefetchWave(
                            "gate",
                            tilesRequested,
                            SystemClock.elapsedRealtime() - waveStartMs,
                            tilesParsed,
                        )
                    }
                } else if (fullTimelinePrimeActive) {
                    val waveStartMs = SystemClock.elapsedRealtime()
                    tilesRequested = prefetchPlaybackTilesWave(
                        layer = layer,
                        vts = vts,
                        coords = prepCoords,
                        phases = phases,
                        waveBudget = fullTimelineMvtRequestsPerWave,
                        awaitCompletion = false,
                    )
                    VectorGlPlaybackDiagnostics.logPrefetchWave(
                        "post-gate",
                        tilesRequested,
                        SystemClock.elapsedRealtime() - waveStartMs,
                    )
                    tilesParsed = prefetchPlaybackNativeParseWave(vts, prepCoords, phases, waveBudget = 48)
                }
                val buildStartMs = SystemClock.elapsedRealtime()
                // Rule: pipelining. Fetch+build each pending phase concurrently (was found to be the
                // dominant cost in a full 25-interval run's wall-clock time — individual phases build
                // in 1-3s once their data is ready, but processing 8 phases per tick sequentially
                // meant each phase waited for the previous one's full network+parse+triangulate cycle
                // even when its own tiles were already available). refsByIntervalMs is not
                // thread-safe, so results are collected first and committed sequentially below — only
                // the fetch/build work runs concurrently, not the map writes.
                // Rule: pan-during-playback. Also re-processes an entry whose generation tag doesn't
                // match the current playbackPrepGeneration (i.e. it was built for a since-superseded
                // coords set) — see refsGeneration's KDoc.
                val pendingPhases = phases.filter { phaseMs ->
                    val snappedMs = vts.snappedTimeSeriesIntervalMs(phaseMs)
                    !refsByIntervalMs.containsKey(snappedMs) ||
                        refsGeneration[snappedMs] != playbackPrepGeneration
                }
                val phaseResults = coroutineScope {
                    pendingPhases.map { phaseMs ->
                        async(Dispatchers.Default) {
                            if (!isActive) return@async null
                            // Rule: burst-oom-phase-build-cap. Caps concurrent full-viewport
                            // fetch+parse+triangulate sweeps — see MAX_CONCURRENT_PHASE_BUILDS's KDoc.
                            // Still dispatches every pending phase's async{} immediately (so they queue
                            // fairly and start the instant a permit frees up), just bounds how many run
                            // their actual build work at once.
                            phaseBuildSemaphore.withPermit {
                                if (!isActive) return@withPermit null
                                val snappedMs = vts.snappedTimeSeriesIntervalMs(phaseMs)
                                ensurePlaybackPhaseDataReady(vts, prepCoords, snappedMs)
                                val phaseBuildStartMs = SystemClock.elapsedRealtime()
                                val refs = buildRefs(prepCoords, phaseMs)
                                Triple(snappedMs, refs, SystemClock.elapsedRealtime() - phaseBuildStartMs)
                            }
                        }
                    }.awaitAll()
                }
                for (result in phaseResults) {
                    if (result == null) continue
                    val (snappedMs, refs, phaseBuildElapsedMs) = result
                    if (prepCoords.all { coord -> isDrawable(coord, snappedMs) }) {
                        synchronized(refsLock) {
                            refsByIntervalMs[snappedMs] = refs
                            refsGeneration[snappedMs] = playbackPrepGeneration
                            trimPlaybackMeshRefCache(refsByIntervalMs, maxPlaybackIntervalRefCacheSize())
                        }
                        builtAny = true
                        VectorGlPlaybackDiagnostics.logPhaseBuilt(layerId, snappedMs, refs.size, phaseBuildElapsedMs)
                    } else {
                        val blockers = phaseStoreBlockers(prepCoords, snappedMs)
                        VectorGlPlaybackDiagnostics.logPhaseStoreBlocked(layerId, snappedMs, blockers)
                    }
                }
                val phaseBuildMs = SystemClock.elapsedRealtime() - buildStartMs
                val unparsedNative = countUnparsedNativeMvt(vts, prepCoords, phasesRaw)
                VectorGlPlaybackDiagnostics.logPrepTick(
                    layerId = layerId,
                    gateHold = gateHoldActive,
                    phasesAttempted = phases.size,
                    refsPrimed = refsByIntervalMs.size,
                    totalPhases = allPhases.size,
                    tilesRequested = tilesRequested,
                    tilesParsed = tilesParsed,
                    phaseBuildMs = phaseBuildMs,
                    builtAny = builtAny,
                    inFlightTiles = vts.inFlightTimeSeriesTileCount(),
                    unparsedNative = unparsedNative,
                )
                if (gateHoldActive) {
                    VectorGlPlaybackDiagnostics.logGateStatusIfDue(
                        layerId = layerId,
                        refsPrimed = refsByIntervalMs.size,
                        totalPhases = allPhases.size,
                        coords = prepCoords,
                        blockers = gateBlockers(prepCoords),
                    )
                }
                if (builtAny) onRepaintNeeded()
                if (gateHoldActive && completePlaybackGateIfReady(layer, vts, prepCoords, isDrawable)) {
                    break
                }
                // Rule: gate-hold-circuit-breaker. A gate that never fully primes must not block
                // every other layer's shared readiness map forever — see gateHoldTimeoutMs's KDoc.
                if (gateHoldActive &&
                    SystemClock.elapsedRealtime() - gateHoldStartedAtMs > gateHoldTimeoutMs &&
                    completePlaybackGateIfReady(layer, vts, prepCoords, isDrawable, force = true)
                ) {
                    break
                }
                if (fullTimelinePrimeActive && isPlaybackTimelineFullyPrimed(vts, prepCoords, isDrawable)) {
                    playbackTimelineFullyPrimed = true
                    fullTimelineMvtPrefetchJob?.cancel()
                    fullTimelineMvtPrefetchJob = null
                    Timeline.markPlaybackFullTimelinePrimed(layer.id)
                    // Rule: pan-during-playback. See VectorFillLayerRenderer's identical block/KDoc.
                    if (panReprimeInProgress) {
                        panReprimeInProgress = false
                        Timeline.setGlVectorFillLayerPlaybackReady(layer.id, true)
                        if (!Timeline.isAnyGlVectorFillLayerAwaitingPlayback()) {
                            Timeline.endGlVectorFillPrefetchLoadUi()
                            layer.mapController?.scheduleVectorFillPrefetchLoadComplete()
                        }
                    }
                }
                delay(
                    when {
                        gateHoldActive -> if (builtAny) 16L else 50L
                        !playbackWarmupComplete -> if (builtAny) 1L else 4L
                        fullTimelinePrimeActive -> if (builtAny) 1L else 4L
                        builtAny -> 4L
                        else -> 8L
                    },
                )
            }
        }
    }
}
