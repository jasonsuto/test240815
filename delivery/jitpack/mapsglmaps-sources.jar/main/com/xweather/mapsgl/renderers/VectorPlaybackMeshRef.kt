package com.xweather.mapsgl.renderers

import com.xweather.mapsgl.tiles.TileCoord

/**
 * Lightweight playback frame entry: tile coord + mesh cache key only.
 * Interleaved vertex data is stored once in native mesh cache (and optionally a small Java hot cache).
 */
internal data class VectorPlaybackMeshRef(
    val coord: TileCoord,
    val triKey: String,
    val vertexOpacity: Float = 1f,
)

internal fun trimPlaybackMeshRefCache(cache: LinkedHashMap<Long, List<VectorPlaybackMeshRef>>, limit: Int) {
    while (cache.size > limit) {
        val eldest = cache.keys.firstOrNull() ?: break
        cache.remove(eldest)
    }
}
