package com.xweather.mapsgl.renderers

import android.opengl.GLES31
import android.opengl.Matrix
import android.os.SystemClock
import android.util.Log
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.gl.EmptyRenderPass
import com.xweather.mapsgl.gl.RenderPass
import com.xweather.mapsgl.gl.math.PowerTable.Companion.powerTableI
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera
import com.xweather.mapsgl.layers.tile.RenderContext
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.layers.tile.VectorTileLayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import com.xweather.mapsgl.map.mapbox.CameraSync
import com.xweather.mapsgl.map.mapbox.ExpressionFilterFlatten
import com.xweather.mapsgl.map.mapbox.ExpressionReferencedKeys
import com.xweather.mapsgl.map.mapbox.GeoJsonWorldCopies
import com.xweather.mapsgl.map.mapbox.MapboxMapController
import com.xweather.mapsgl.map.mapbox.VectorDrawTime
import com.xweather.mapsgl.map.mapbox.VectorFeatureDrawFilter
import com.xweather.mapsgl.map.mapbox.VectorLayerDrawFilterDefaults
import com.xweather.mapsgl.map.mapbox.VectorMapTime
import com.xweather.mapsgl.map.mapbox.VectorHeatmapColorEval
import com.xweather.mapsgl.map.mapbox.VectorHeatmapPointExtract
import com.xweather.mapsgl.map.mapbox.VectorPolygonFillTriangulator
import com.xweather.mapsgl.sources.GeoJSONSource
import com.xweather.mapsgl.sources.VectorData
import com.xweather.mapsgl.sources.VectorTileSource
import com.xweather.mapsgl.sources.resolveVectorTileData
import com.xweather.mapsgl.style.HeatmapLayerPaint
import com.xweather.mapsgl.style.StyleValue
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.tiles.TileData
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

private const val VECTOR_HEATMAP_TAG = "VectorHeatmapLayerRenderer"
/** Accumulate density at half map resolution, then blur + upscale when colorizing. */
private const val HEATMAP_DENSITY_RESOLUTION_SCALE = 0.5f
/** Compresses accumulated density before ramp lookup (GLES magnitudes run hotter than Mapbox). */
private const val HEATMAP_COLOR_DENSITY_SCALE = 0.32f
/** Blur tap spacing in density-texel units (wider = softer halos). */
private const val HEATMAP_BLUR_SPREAD = 1.5f
private const val HEATMAP_BLUR_PASSES = 1
private const val HEATMAP_RADIUS_ZOOM_REFERENCE = 9.0
private const val HEATMAP_RADIUS_MIN_PX = 2f
private const val COLOR_RAMP_WIDTH = 256
private const val HEATMAP_SHADER_VERSION = 10
/** Bump when the point-cache key format changes (invalidates [VectorHeatmapLayerRenderer.pointCache]). */
private const val HEATMAP_POINT_CACHE_VERSION = 2
/**
 * Cap point batches retained per renderer. Rule: shared-playback-gate. Mirrors
 * VectorSymbolLayerRenderer's instanceCache cap — sized well above a full timeline's worth of
 * phases x coords so gate-hold's committed refs are never forced out by ordinary on-demand churn.
 */
private const val MAX_HEATMAP_POINT_CACHE_ENTRIES = 512
/** Placeholder for [VectorHeatmapLayerRenderer.CachedPointBatch.points] when a batch is backed by
 * [VectorHeatmapLayerRenderer.CachedPointBatch.directBuffer] instead (rule: zero-copy-gpu-upload). */
private val EMPTY_FLOAT_ARRAY = FloatArray(0)

/**
 * Draws [HeatmapLayerPaint] via GLES: Gaussian splats into a half-res density FBO, separable blur,
 * then a fullscreen colorize pass with the `heatmap-color` ramp.
 */
class VectorHeatmapLayerRenderer(
    override var id: String,
) : TileLayerRenderer<TileData, LayerRenderContext<Any>>() {

    companion object {
        @Volatile
        private var glGeneration = 0

        /** Invalidates cached GL programs/FBOs after Mapbox context loss. */
        fun onGlContextLost() {
            glGeneration++
        }
    }

    /** Rule: zero-copy-gpu-upload (Phase 5). [points] is used when this batch came from the JVM hot
     * cache or a freshly-built extract; [directBuffer]/[directByteCount]/[directTriKey] are set
     * instead when it came from a native-cache hit with no JVM copy — the draw loop must call
     * [releaseHeatmapPointsNativeDirect] via [directTriKey] exactly once after uploading it. */
    private data class CachedPointBatch(
        val coord: TileCoord,
        val points: FloatArray,
        val directBuffer: ByteBuffer? = null,
        val directByteCount: Int = 0,
        val directTriKey: String? = null,
        /** Encoded map-time reveal times aligned with [points] (3 floats per point). */
        val featureTimes: FloatArray? = null,
    )

    init {
        cachesTextures = false
    }

    override fun onAdd() {}
    override fun onAdd(context: RenderContext<Any>, tileLayer: TileLayer, controller: MapboxMapController) {}
    override fun onAdd(tileLayer: TileLayer) {
        super.onAdd(tileLayer)
        if (tileLayer is VectorTileLayer && tileLayer.glRenderingActive()) {
            tileLayer.externalScope.launch {
                tileLayer.prefetchVectorTilesForGlRendering()
                tileLayer.mapController?.redraw()
            }
        }
    }

    private var splatProgram = 0
    private var blurProgram = 0
    private var colorizeProgram = 0
    private var splatProgramVersion = -1
    private var uSplatMvp = -1
    private var uSplatRadiusUv = -1
    private var uSplatIntensity = -1
    private var uBlurInput = -1
    private var uBlurTexel = -1
    private var uColorizeDensity = -1
    private var uColorizeDensityScale = -1
    private var uColorizeOpacity = -1
    private var locColorizeRamp = -1

    private var densityFbo = 0
    private var densityTex = 0
    private var blurFbo = 0
    private var blurTex = 0
    private var colorRampTex = 0
    private var quadVbo = 0
    private var instanceVbo = 0
    private var vaoSplat = 0
    private var vaoColorize = 0
    private var fboWidth = 0
    private var fboHeight = 0
    private var rampStyleKey = Int.MIN_VALUE
    private var syncedGlGeneration = -1

    private val pointCache = ConcurrentHashMap<String, FloatArray>()
    private val heatmapFeatureTimeCache = ConcurrentHashMap<String, FloatArray>()
    private val pointInProgress = ConcurrentHashMap.newKeySet<String>()
    private var lastSuccessfulBatches: List<CachedPointBatch> = emptyList()
    private val backgroundExecutor = Executors.newSingleThreadExecutor()

    /** Rule: shared-playback-gate. Generic gate-hold/warmup state machine; see [VectorPlaybackGateController]. */
    private val gate = VectorPlaybackGateController(id)
    private var playbackFrozenBatches: List<CachedPointBatch> = emptyList()
    private var playbackFrozenIntervalMs: Long? = null
    private var pausedBatchCount = 0

    // Grace period before a just-resumed playback session freezes lastSuccessfulBatches as a
    // fallback — avoids re-freezing on a debounced blip (e.g. a quick pause/resume). Mirrors circle's.
    private val playbackPlayEdgeDebounceMs = 400L

    internal fun invalidateTimelineMeshCache() {
        pointCache.clear()
        heatmapFeatureTimeCache.clear()
        pointInProgress.clear()
        lastSuccessfulBatches = emptyList()
        playbackFrozenBatches = emptyList()
        playbackFrozenIntervalMs = null
        pausedBatchCount = 0
        gate.invalidate()
    }

    /** Rule: shared-playback-gate. Mirrors [VectorCircleLayerRenderer.beginPlaybackPrefetchGate]. */
    internal fun beginPlaybackPrefetchGate(layer: VectorTileLayer? = null) = gate.beginPlaybackPrefetchGate(layer)

    override fun setUpRenderPass(): RenderPass =
        EmptyRenderPass(tileLayer?.source?.id ?: id, tileLayer!!.paint)

    override fun prerender(context: LayerRenderContext<Any>) {}
    override fun draw(context: LayerRenderContext<Any>, texUnit: HashMap<String, Int>) {}

    override fun draw(context: LayerRenderContext<Any>, texUnit: HashMap<String, Int>, camera: Camera) {
        val layer = tileLayer as? VectorTileLayer ?: return
        val paint = layer.paint as? HeatmapLayerPaint ?: return
        val geo = layer.source as? GeoJSONSource
        val vts = layer.source as? VectorTileSource
        if (geo == null && vts == null) return

        // Rule: pruning-to-referenced-keys. Mirrors Circle/Symbol/Line's identical call - without
        // it this consumer counts as "needs every attribute", and because restrictedPropertyKeysFor
        // unions across all consumers of an MVT layer, one undeclared heatmap consumer disables
        // pruning for every other layer sharing the source.
        //
        // Collected off the effective filter, not layer.filter: VectorMapTime.mapTimeRevealKey
        // derives the reveal attribute from the effective filter's first `get` key (defaulting to
        // "timestamp"), so a set built from the declared filter alone could prune the attribute the
        // GPU reveal bakes from. timestamp/featureType/visible are pinned by
        // VectorTileSource.ALWAYS_NEEDED_PROPERTY_KEYS.
        vts?.declareNeededPropertyKeys(
            layer.id,
            ExpressionReferencedKeys.collect(
                VectorLayerDrawFilterDefaults.effectiveFilter(
                    layer.id,
                    ExpressionFilterFlatten.flatten(layer.filter),
                ),
                paint.heatmap.weight?.expressionValue,
            ),
        )

        val mapboxProj = CameraSync.mapboxProjectionMatrix
        val mapboxMv = CameraSync.mapboxModelViewMatrix
        val useMapboxNativeMv =
            mapboxProj != null && mapboxMv != null && mapboxProj.size >= 16 && mapboxMv.size >= 16
        if (!useMapboxNativeMv) return

        val proj = mapboxProj!!
        val mvCam = mapboxMv!!
        val mapZoomNow = CameraSync.zoomForCustomLayerInstancing()
        val densityMult = camera.dpiMult.coerceAtLeast(1e-3f)
        val opacity = paint.opacity.coerceIn(0f, 1f)
        val intensity = (paint.heatmap.intensity.constantValue ?: 1.0).toFloat().coerceAtLeast(0f)
        val styleRadiusPx =
            ((paint.heatmap.radius.constantValue ?: 10.0).toFloat() * densityMult)
                .coerceAtLeast(1f)
        val radiusPx = heatmapRadiusPxForMapZoom(styleRadiusPx, mapZoomNow)

        val viewportW = max(1, camera.resX)
        val viewportH = max(1, camera.resY)
        val densityW = max(1, (viewportW * HEATMAP_DENSITY_RESOLUTION_SCALE).toInt())
        val densityH = max(1, (viewportH * HEATMAP_DENSITY_RESOLUTION_SCALE).toInt())
        syncGlGeneration()
        ensureGlResources(densityW, densityH, paint)
        if (splatProgram == 0 || blurProgram == 0 || colorizeProgram == 0 || densityFbo == 0 || colorRampTex == 0) {
            return
        }

        // Rule: shared-playback-gate. Mirrors VectorCircleLayerRenderer/VectorSymbolLayerRenderer's
        // gate-hold/warmup-priming state machine (via the shared VectorPlaybackGateController) so
        // time-series heatmap layers get the same dedicated prefetch-ahead smoothing, instead of
        // resolving/building each interval on demand as playback reaches it. Unlike symbol/circle,
        // heatmap has only one downstream GL draw path, so the branches below just choose which
        // List<CachedPointBatch> to draw rather than returning early from separate draw helpers.
        val drawIntervalMs = vts?.let { vectorTileSourceDrawIntervalMs(tileLayer, it) }
        val nowMsEarly = SystemClock.elapsedRealtime()
        val playbackStable = Timeline.isGloballyPlaying
        if (!playbackStable) {
            gate.lastGloballyInactiveMs = nowMsEarly
        }
        if (gate.wasGloballyPlaying && !playbackStable) {
            gate.playbackWarmupComplete = true
            gate.initialPlaybackWarmupSatisfied = false
            playbackFrozenBatches = emptyList()
            playbackFrozenIntervalMs = null
            gate.warmupTilePrefetchJob?.cancel()
            gate.warmupTilePrefetchJob = null
        }
        val steadyStatePlaybackDraw =
            playbackStable && vts != null && vts.isTimeSeriesSource &&
                gate.playbackWarmupComplete && gate.initialPlaybackWarmupSatisfied
        if (playbackStable && !gate.wasGloballyPlaying && vts?.isTimeSeriesSource == true &&
            !gate.initialPlaybackWarmupSatisfied
        ) {
            val playResumeGapMs = nowMsEarly - gate.lastGloballyInactiveMs
            if (playResumeGapMs >= playbackPlayEdgeDebounceMs) {
                pausedBatchCount = lastSuccessfulBatches.size
                playbackFrozenIntervalMs = drawIntervalMs
                playbackFrozenBatches = lastSuccessfulBatches
                gate.playbackWarmupComplete = false
                gate.warmupTilePrefetchJob?.cancel()
                gate.warmupTilePrefetchJob = null
            }
        }
        gate.wasGloballyPlaying = playbackStable

        var batches: List<CachedPointBatch>? = null

        if (vts != null && vts.isTimeSeriesSource) {
            val visibleCoords = (tileLayer as TileLayer).visibleTileCoordsForMapboxVectorCache()
            val fallbackCoords = if (visibleCoords.isEmpty()) {
                (tileLayer as TileLayer).viewportCenterTileCoordsForPrefetch()
            } else {
                emptyList()
            }
            val styleKey = heatmapStyleKey(paint)
            val gateCoords = gate.playbackGateCoords(layer, visibleCoords, fallbackCoords)
            if (playbackStable && gateCoords.isNotEmpty()) {
                gate.scheduleFullTimelineMvtPrefetch(layer, vts, gateCoords)
                gate.schedulePlaybackFramePreparation(
                    layer = layer,
                    vts = vts,
                    coords = gateCoords,
                    buildRefs = { coords, intervalMs ->
                        buildPlaybackHeatmapRefsForInterval(vts, layer, paint, coords, intervalMs)
                    },
                    isDrawable = { coord, snappedMs ->
                        isHeatmapPhaseDrawable(vts, layer, paint, styleKey, coord, snappedMs)
                    },
                    phaseStoreBlockers = { coords, snappedMs -> heatmapPhaseStoreBlockers(vts, coords, snappedMs) },
                    gateBlockers = { coords -> summarizeHeatmapGateBlockers(vts, coords) },
                    onRepaintNeeded = { tileLayer?.mapController?.redraw() },
                )
            }

            if (playbackStable && !gate.playbackWarmupComplete && !gate.initialPlaybackWarmupSatisfied) {
                Timeline.setGlVectorFillLayerPlaybackReady(layer.id, false)
                if (gateCoords.isEmpty()) {
                    gate.playbackWarmupComplete = true
                    gate.initialPlaybackWarmupSatisfied = true
                    Timeline.setGlVectorFillLayerPlaybackReady(layer.id, true)
                    Timeline.endGlVectorFillPrefetchLoadUi()
                    layer.mapController?.scheduleVectorFillPrefetchLoadComplete()
                } else {
                    val isDrawable = { coord: TileCoord, snappedMs: Long ->
                        isHeatmapPhaseDrawable(vts, layer, paint, styleKey, coord, snappedMs)
                    }
                    val gateOpened = gate.playbackGateAnchorPhaseA < 0 &&
                        gate.completePlaybackGateIfReady(layer, vts, gateCoords, isDrawable)
                    if (!gateOpened) {
                        batches = playbackFrozenBatches.ifEmpty { lastSuccessfulBatches }
                    }
                }
            }

            if (batches == null && steadyStatePlaybackDraw && drawIntervalMs != null) {
                val snappedDraw = vts.snappedTimeSeriesIntervalMs(drawIntervalMs)
                val prebuilt = resolveHeatmapPlaybackBatches(vts, gate.refsForInterval(snappedDraw))
                if (prebuilt.isNotEmpty()) batches = prebuilt
            }
            if (batches == null && !playbackStable) {
                val resolveIntervalMs = drawIntervalMs?.let { vts.snappedTimeSeriesIntervalMs(it) }
                batches = buildTileBatches(
                    vts, layer, paint, mapZoomNow, gateCoords.ifEmpty { visibleCoords }, resolveIntervalMs,
                    exactInterval = true,
                )
            }
        } else if (geo != null) {
            batches = buildGeoJsonBatches(geo, layer, paint)
        } else if (vts != null) {
            val coords = (tileLayer as TileLayer).visibleTileCoordsForMapboxVectorCache()
                .ifEmpty { (tileLayer as TileLayer).viewportCenterTileCoordsForPrefetch() }
            batches = buildTileBatches(vts, layer, paint, mapZoomNow, coords, null, exactInterval = false)
        }

        var resolvedBatches = batches ?: emptyList()
        if (resolvedBatches.isEmpty() && lastSuccessfulBatches.isNotEmpty()) {
            resolvedBatches = lastSuccessfulBatches
        } else if (resolvedBatches.isNotEmpty()) {
            lastSuccessfulBatches = resolvedBatches
        }
        if (resolvedBatches.isEmpty()) return
        val batchesToDraw = filterHeatmapBatchesByMapTime(resolvedBatches, layer.id, layer.filter)
        if (batchesToDraw.isEmpty()) return

        val depthWas = GLES31.glIsEnabled(GLES31.GL_DEPTH_TEST)
        val stencilWas = GLES31.glIsEnabled(GLES31.GL_STENCIL_TEST)
        val scissorWas = GLES31.glIsEnabled(GLES31.GL_SCISSOR_TEST)
        GLES31.glDisable(GLES31.GL_DEPTH_TEST)
        if (stencilWas) GLES31.glDisable(GLES31.GL_STENCIL_TEST)
        if (scissorWas) GLES31.glDisable(GLES31.GL_SCISSOR_TEST)

        val prevFbo = IntArray(1)
        GLES31.glGetIntegerv(GLES31.GL_FRAMEBUFFER_BINDING, prevFbo, 0)
        val prevViewport = IntArray(4)
        GLES31.glGetIntegerv(GLES31.GL_VIEWPORT, prevViewport, 0)

        try {
            // Pass 1 — accumulate density
            GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, densityFbo)
            GLES31.glViewport(0, 0, fboWidth, fboHeight)
            GLES31.glClearColor(0f, 0f, 0f, 0f)
            GLES31.glClear(GLES31.GL_COLOR_BUFFER_BIT)
            GLES31.glEnable(GLES31.GL_BLEND)
            GLES31.glBlendFunc(GLES31.GL_ONE, GLES31.GL_ONE)
            GLES31.glColorMask(true, false, false, false)

            GLES31.glUseProgram(splatProgram)
            GLES31.glUniform1f(uSplatIntensity, intensity.coerceAtLeast(1e-6f))
            GLES31.glBindVertexArray(vaoSplat)

            var totalInstances = 0
            for (batch in batchesToDraw) {
                val isDirect = batch.directBuffer != null
                if (!isDirect && batch.points.isEmpty()) continue
                val instanceCount = if (isDirect) batch.directByteCount / 12 else batch.points.size / 3
                if (instanceCount <= 0) {
                    if (isDirect) batch.directTriKey?.let { vts?.releaseHeatmapPointsNativeDirect(it) }
                    continue
                }
                val overscale =
                    CameraSync.tileRasterOverscale(mapZoomNow, batch.coord.z).coerceAtLeast(1f)
                val radiusUv = radiusPx / 512f / overscale
                GLES31.glUniform1f(uSplatRadiusUv, radiusUv)

                val tileLocal = FloatArray(16)
                val modelView = FloatArray(16)
                val mvp = FloatArray(16)
                Matrix.setIdentityM(tileLocal, 0)
                Matrix.scaleM(tileLocal, 0, 512f * overscale, 512f * overscale, 1f)
                // Rule: dateline-world-copy. See VectorFillLayerRenderer.drawInterleavedForCoord's
                // identical fix — must include coord.offset or every world copy of a tile draws at
                // the same screen position, breaking rendering across the antimeridian at wide zoom.
                val worldCopyN = powerTableI.getOrElse(batch.coord.z) { 1 shl batch.coord.z }
                Matrix.translateM(
                    tileLocal, 0,
                    batch.coord.x.toFloat() + batch.coord.offset * worldCopyN,
                    batch.coord.y.toFloat(),
                    0f,
                )
                Matrix.multiplyMM(modelView, 0, mvCam, 0, tileLocal, 0)
                Matrix.multiplyMM(mvp, 0, proj, 0, modelView, 0)
                GLES31.glUniformMatrix4fv(uSplatMvp, 1, false, mvp, 0)

                totalInstances += instanceCount
                // Rule: zero-copy-gpu-upload (Phase 5). A direct-buffer batch's native checkout must be
                // released exactly once after this upload, whether or not the draw call itself succeeds.
                if (isDirect) {
                    try {
                        uploadInstanceBufferDirect(batch.directBuffer!!, batch.directByteCount)
                        GLES31.glDrawArraysInstanced(GLES31.GL_TRIANGLES, 0, 6, instanceCount)
                    } finally {
                        batch.directTriKey?.let { vts?.releaseHeatmapPointsNativeDirect(it) }
                    }
                } else {
                    uploadInstanceBuffer(batch.points)
                    GLES31.glDrawArraysInstanced(GLES31.GL_TRIANGLES, 0, 6, instanceCount)
                }
            }

            GLES31.glDisable(GLES31.GL_BLEND)
            GLES31.glColorMask(true, false, false, false)

            if (totalInstances == 0) return

            repeat(HEATMAP_BLUR_PASSES) {
                val blurSpread = HEATMAP_BLUR_SPREAD *
                    (paint.heatmap.blur.constantValue ?: 1.0).toFloat().coerceAtLeast(0f)
                drawBlurPass(blurFbo, densityTex, blurSpread / fboWidth, 0f)
                drawBlurPass(densityFbo, blurTex, 0f, blurSpread / fboHeight)
            }

            // Pass 4 — colorize
            GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, prevFbo[0])
            GLES31.glViewport(prevViewport[0], prevViewport[1], prevViewport[2], prevViewport[3])
            GLES31.glColorMask(true, true, true, true)
            GLES31.glEnable(GLES31.GL_BLEND)
            GLES31.glBlendFunc(GLES31.GL_SRC_ALPHA, GLES31.GL_ONE_MINUS_SRC_ALPHA)

            GLES31.glUseProgram(colorizeProgram)
            GLES31.glActiveTexture(GLES31.GL_TEXTURE0)
            GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, densityTex)
            GLES31.glUniform1i(uColorizeDensity, 0)
            GLES31.glUniform1f(uColorizeDensityScale, HEATMAP_COLOR_DENSITY_SCALE)
            GLES31.glActiveTexture(GLES31.GL_TEXTURE1)
            GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, colorRampTex)
            GLES31.glUniform1i(locColorizeRamp, 1)
            GLES31.glUniform1f(uColorizeOpacity, opacity)

            GLES31.glBindVertexArray(vaoColorize)
            GLES31.glDrawArrays(GLES31.GL_TRIANGLES, 0, 6)
        } finally {
            GLES31.glBindVertexArray(0)
            GLES31.glUseProgram(0)
            GLES31.glColorMask(true, true, true, true)
            GLES31.glDisable(GLES31.GL_BLEND)
            if (depthWas) GLES31.glEnable(GLES31.GL_DEPTH_TEST)
            if (stencilWas) GLES31.glEnable(GLES31.GL_STENCIL_TEST)
            if (scissorWas) GLES31.glEnable(GLES31.GL_SCISSOR_TEST)
        }
    }

    private fun buildGeoJsonBatches(
        geo: GeoJSONSource,
        layer: VectorTileLayer,
        paint: HeatmapLayerPaint,
    ): List<CachedPointBatch> {
        val features = geo.data?.features() ?: run {
            (tileLayer?.mapController as? MapboxMapController)?.ensureGeoJsonSourceDataLoaded(geo)
            return emptyList()
        }
        if (features.isEmpty()) return emptyList()
        val coord = TileCoord(0, 0, 0)
        val styleKey = heatmapStyleKey(paint)
        val cacheKey =
            "geojson|${geo.id}|$styleKey|${geo.geoJsonStencilSequence}|heatmap|v$HEATMAP_POINT_CACHE_VERSION"
        ensurePointsBuilt(
            cacheKey,
            features,
            coord,
            layer.sourceLayer,
            layer.filter,
            paint.heatmap.weight,
            layer.id,
            VectorDrawTime.currentMapTimeMillis(),
        )
        val points = pointCache[cacheKey]
        if (points != null && points.isNotEmpty()) {
            val times = heatmapFeatureTimeCache[cacheKey]
            // Rule: dateline-world-copy. Same points, one batch per visible world copy.
            return GeoJsonWorldCopies.visibleWorldCoords(tileLayer?.mapController).map { drawCoord ->
                CachedPointBatch(drawCoord, points, featureTimes = times)
            }
        }
        val inProgress = pointInProgress.contains(cacheKey)
        if (inProgress && lastSuccessfulBatches.isNotEmpty()) {
            return lastSuccessfulBatches.filter { it.coord == coord }
        }
        return emptyList()
    }

    private fun buildTileBatches(
        vts: VectorTileSource,
        layer: VectorTileLayer,
        paint: HeatmapLayerPaint,
        mapZoomNow: Double,
        coords: List<TileCoord>,
        resolveIntervalMs: Long?,
        exactInterval: Boolean,
    ): List<CachedPointBatch> {
        if (coords.isEmpty()) return emptyList()
        val styleKey = heatmapStyleKey(paint)
        val out = ArrayList<CachedPointBatch>(coords.size)
        for (coord in coords) {
            val resolved = vts.findCachedVectorTileForNominalZxy(coord.z, coord.x, coord.y, true) ?: continue
            // Rule: symbol-timeline-animation. resolved.data holds a VectorTimeSeriesData container
            // for time-series sources rather than a plain VectorData — unwrap it to the interval
            // currently being drawn, same as the other renderers' drawCoords().
            val data = resolveVectorTileData(resolved.data, resolveIntervalMs, exactInterval) as? VectorData
                ?: continue
            val meshFp = VectorPolygonFillTriangulator.meshCacheFingerprint(
                data.features,
                data.validTime.time,
                layer.sourceLayer,
            )
            val cacheKey = heatmapPlaybackTriKey(coord, layer.sourceLayer, styleKey, meshFp, data.validTime.time)
            ensurePointsBuilt(
                cacheKey,
                data.features,
                coord,
                layer.sourceLayer,
                layer.filter,
                paint.heatmap.weight,
                layer.id,
                resolveIntervalMs ?: VectorDrawTime.currentMapTimeMillis(),
                vts,
            )
            val dynamicMapTime = VectorFeatureDrawFilter.referencesMapTime(layer.id, layer.filter)
            val points = resolveHeatmapMesh(vts, cacheKey, requireFeatureTimes = dynamicMapTime) ?: continue
            if (points.isNotEmpty()) {
                out.add(
                    CachedPointBatch(
                        coord,
                        points,
                        featureTimes = heatmapFeatureTimeCache[cacheKey],
                    ),
                )
            }
        }
        return out
    }

    /** Rule: shared-playback-gate. Single triKey format shared by on-demand and gate-hold builds. */
    private fun heatmapPlaybackTriKey(
        coord: TileCoord,
        sourceLayer: String?,
        styleKey: Int,
        meshFp: Int,
        validTimeMs: Long,
    ): String =
        "${coord.z}/${coord.x}/${coord.y}|$sourceLayer|$styleKey|$meshFp|$validTimeMs|heatmap|v$HEATMAP_POINT_CACHE_VERSION"

    /** Rule: shared-playback-gate. Mirrors [VectorCircleLayerRenderer.protectedPlaybackTriKeys]. */
    private fun protectedHeatmapPointTriKeys(): Set<String> {
        val keys = HashSet<String>()
        // Rule: playback-refs-thread-safety. See VectorPlaybackGateController.refsLock's KDoc.
        // Rule: pan-during-playback. See VectorFillLayerRenderer.protectedFillTriKeys's KDoc — only
        // protects entries tagged with the current generation, so a coords-restart's stale entries
        // become evictable immediately instead of staying pinned for the whole reprime.
        synchronized(gate.refsLock) {
            for ((intervalMs, refs) in gate.refsByIntervalMs) {
                if (gate.refsGeneration[intervalMs] != gate.playbackPrepGeneration) continue
                for (ref in refs) keys.add(ref.triKey)
            }
        }
        return keys
    }

    /** Mirrors [VectorCircleLayerRenderer.resolveCircleMesh] — JVM hot cache first, then the native
     * heatmap-mesh cache (populated by a prior tile-based [putPointCache] call). Native caching only
     * applies to tile-based (time-series) sources; GeoJSON heatmap sources have no [VectorTileSource]. */
    private fun resolveHeatmapMesh(
        vts: VectorTileSource,
        triKey: String,
        requireFeatureTimes: Boolean = false,
    ): FloatArray? {
        pointCache[triKey]?.let { return it }
        if (requireFeatureTimes && !heatmapFeatureTimeCache.containsKey(triKey)) return null
        vts.getHeatmapPointsNative(triKey)?.let { native ->
            if (requireFeatureTimes && !heatmapFeatureTimeCache.containsKey(triKey)) return null
            pointCache[triKey] = native
            return native
        }
        return null
    }

    private fun putPointCache(
        key: String,
        points: FloatArray,
        vts: VectorTileSource? = null,
        featureTimes: FloatArray? = null,
    ) {
        if (points.isEmpty()) return
        vts?.putHeatmapPointsNative(key, points)
        if (featureTimes != null && featureTimes.isNotEmpty()) {
            heatmapFeatureTimeCache[key] = featureTimes
        } else {
            heatmapFeatureTimeCache.remove(key)
        }
        // Rule: shared-playback-gate. Mirrors VectorSymbolLayerRenderer.putInstanceCache — protects
        // gate-hold's committed refs from being evicted by ordinary on-demand churn during warmup.
        val protected = if (Timeline.isGloballyPlaying) protectedHeatmapPointTriKeys() else emptySet()
        val maxEntries = if (Timeline.isGloballyPlaying) {
            maxOf(MAX_HEATMAP_POINT_CACHE_ENTRIES, protected.size + 32)
        } else {
            MAX_HEATMAP_POINT_CACHE_ENTRIES
        }
        while (pointCache.size >= maxEntries) {
            val oldest = pointCache.keys.firstOrNull { it !in protected } ?: break
            pointCache.remove(oldest)
        }
        pointCache[key] = points
    }

    private fun ensurePointsBuilt(
        cacheKey: String,
        features: List<com.mapbox.geojson.Feature>,
        coord: TileCoord,
        sourceLayer: String?,
        filter: com.xweather.mapsgl.style.Expression?,
        weight: StyleValue<Double>?,
        layerId: String?,
        mapTimeMs: Long,
        vts: VectorTileSource? = null,
    ) {
        val dynamicMapTime = VectorFeatureDrawFilter.referencesMapTime(layerId, filter)
        val alreadyCached = if (vts != null) {
            resolveHeatmapMesh(vts, cacheKey, requireFeatureTimes = dynamicMapTime) != null
        } else {
            pointCache.containsKey(cacheKey) &&
                (!dynamicMapTime || heatmapFeatureTimeCache.containsKey(cacheKey))
        }
        if (alreadyCached) return
        if (!pointInProgress.add(cacheKey)) return
        val capturedLayer = tileLayer
        backgroundExecutor.submit {
            try {
                val built = VectorHeatmapPointExtract.extractDetailed(
                    features,
                    coord,
                    sourceLayer,
                    filter,
                    weight,
                    layerId,
                    mapTimeMs,
                    staticPrepForMapTime = VectorMapTime.usesMonotonicMapTimeReveal(layerId, filter),
                )
                if (built.points.isNotEmpty()) {
                    putPointCache(cacheKey, built.points, vts, built.featureTimes)
                    capturedLayer?.mapController?.redraw()
                }
            } finally {
                pointInProgress.remove(cacheKey)
            }
        }
    }

    private fun filterHeatmapBatchesByMapTime(
        batches: List<CachedPointBatch>,
        layerId: String?,
        filter: com.xweather.mapsgl.style.Expression?,
    ): List<CachedPointBatch> {
        if (!VectorMapTime.usesMonotonicMapTimeReveal(layerId, filter)) return batches
        return batches.mapNotNull { batch ->
            if (batch.directBuffer != null) {
                // No featureTime channel on native-direct uploads — skip rather than over-draw.
                return@mapNotNull null
            }
            val times = batch.featureTimes ?: return@mapNotNull null
            val compact = VectorHeatmapPointExtract.compactByMapTime(batch.points, times)
            if (compact.isEmpty()) null else batch.copy(points = compact, featureTimes = null)
        }
    }

    /**
     * Rule: shared-playback-gate. [VectorPlaybackGateController.schedulePlaybackFramePreparation]'s
     * `buildRefs` hook — the per-interval counterpart to [buildTileBatches]. Builds (or reuses a
     * cached) point batch per coord for [intervalMs] and wraps it as a [VectorPlaybackMeshRef]. Runs
     * on a background dispatcher already (called from the controller's coroutine), so
     * [VectorHeatmapPointExtract.extract] is called synchronously here rather than submitted to
     * [backgroundExecutor].
     */
    private suspend fun buildPlaybackHeatmapRefsForInterval(
        vts: VectorTileSource,
        layer: VectorTileLayer,
        paint: HeatmapLayerPaint,
        coords: List<TileCoord>,
        intervalMs: Long,
    ): List<VectorPlaybackMeshRef> {
        if (coords.isEmpty()) return emptyList()
        val snappedMs = vts.snappedTimeSeriesIntervalMs(intervalMs)
        val styleKey = heatmapStyleKey(paint)
        return coroutineScope {
            coords.map { coord ->
                async(Dispatchers.Default) {
                    if (!vts.hasTimeSeriesIntervalAt(coord.z, coord.x, coord.y, snappedMs)) return@async null
                    gate.ensurePhaseDataParsed(vts, coord, snappedMs)
                    val cached = vts.findCachedVectorTileForNominalZxy(coord.z, coord.x, coord.y, true)
                        ?: return@async null
                    val data = resolveVectorTileData(cached.data, snappedMs, exactInterval = true) as? VectorData
                        ?: return@async null
                    val meshFp = VectorPolygonFillTriangulator.meshCacheFingerprint(
                        data.features, data.validTime.time, layer.sourceLayer,
                    )
                    val triKey = heatmapPlaybackTriKey(coord, layer.sourceLayer, styleKey, meshFp, data.validTime.time)
                    val dynamicMapTime = VectorFeatureDrawFilter.referencesMapTime(layer.id, layer.filter)
                    val monotonicMapTime = VectorMapTime.usesMonotonicMapTimeReveal(layer.id, layer.filter)
                    val existing = resolveHeatmapMesh(vts, triKey, requireFeatureTimes = monotonicMapTime)
                    val points = existing ?: run {
                        val built = VectorHeatmapPointExtract.extractDetailed(
                            data.features, coord, layer.sourceLayer, layer.filter, paint.heatmap.weight,
                            layer.id, snappedMs, staticPrepForMapTime = monotonicMapTime,
                        )
                        putPointCache(triKey, built.points, vts, built.featureTimes)
                        built.points
                    }
                    if (points.isEmpty()) return@async null
                    VectorPlaybackMeshRef(coord, triKey, 1f)
                }
            }.awaitAll().filterNotNull()
        }
    }

    /**
     * Rule: shared-playback-gate. `isDrawable` hook — true when (coord, snappedMs) already has a
     * cached point batch, or is vacuously empty (no matching points to build). Mirrors
     * [VectorSymbolLayerRenderer.isSymbolPhaseDrawable]'s outer shape.
     */
    private fun isHeatmapPhaseDrawable(
        vts: VectorTileSource,
        layer: VectorTileLayer,
        paint: HeatmapLayerPaint,
        styleKey: Int,
        coord: TileCoord,
        snappedMs: Long,
    ): Boolean {
        if (vts.isTimeSeriesIntervalDownloading(coord.z, coord.x, coord.y, snappedMs)) return false
        if (!vts.hasTimeSeriesIntervalAt(coord.z, coord.x, coord.y, snappedMs)) return false
        val cached = vts.findCachedVectorTileForNominalZxy(coord.z, coord.x, coord.y, true) ?: return false
        val data = resolveVectorTileData(cached.data, snappedMs, exactInterval = true) as? VectorData ?: return false
        val meshFp = VectorPolygonFillTriangulator.meshCacheFingerprint(data.features, data.validTime.time, layer.sourceLayer)
        val triKey = heatmapPlaybackTriKey(coord, layer.sourceLayer, styleKey, meshFp, data.validTime.time)
        val monotonicMapTime = VectorMapTime.usesMonotonicMapTimeReveal(layer.id, layer.filter)
        if (resolveHeatmapMesh(vts, triKey, requireFeatureTimes = monotonicMapTime) != null) return true
        val points = VectorHeatmapPointExtract.extractDetailed(
            data.features, coord, layer.sourceLayer, layer.filter, paint.heatmap.weight, layer.id, snappedMs,
            staticPrepForMapTime = monotonicMapTime,
        ).points
        return points.isEmpty()
    }

    /** Rule: shared-playback-gate. Lightweight diagnostic-string hooks, mirrors symbol's. */
    private fun heatmapPhaseStoreBlockers(
        vts: VectorTileSource,
        coords: List<TileCoord>,
        snappedMs: Long,
    ): List<String> = coords.mapNotNull { coord ->
        when {
            vts.isTimeSeriesIntervalDownloading(coord.z, coord.x, coord.y, snappedMs) ->
                "${coord.z}/${coord.x}/${coord.y} downloading"
            !vts.hasTimeSeriesIntervalAt(coord.z, coord.x, coord.y, snappedMs) ->
                "${coord.z}/${coord.x}/${coord.y} no interval"
            !vts.hasTimeSeriesDataLoadedAt(coord.z, coord.x, coord.y, snappedMs) ->
                "${coord.z}/${coord.x}/${coord.y} no data"
            else -> "${coord.z}/${coord.x}/${coord.y} no points"
        }
    }

    private fun summarizeHeatmapGateBlockers(vts: VectorTileSource, coords: List<TileCoord>): List<String> {
        val allPhases = gate.allTimelinePhaseEpochMs(vts)
        val blockers = ArrayList<String>(8)
        for (snappedMs in allPhases) {
            if (!gate.refsByIntervalMs.containsKey(snappedMs)) {
                val coordBlockers = heatmapPhaseStoreBlockers(vts, coords, snappedMs)
                if (coordBlockers.isNotEmpty()) {
                    blockers.add("phase $snappedMs: ${coordBlockers.take(3).joinToString()}")
                } else {
                    blockers.add("phase $snappedMs missing refs")
                }
                if (blockers.size >= 8) break
            }
        }
        return blockers
    }

    /** Rule: shared-playback-gate. Resolves prebuilt [VectorPlaybackMeshRef]s to [CachedPointBatch]es.
     *
     * Rule: zero-copy-gpu-upload (Phase 5). Mirrors [VectorCircleLayerRenderer.drawPlaybackCircleRefs]'s
     * native-direct-first check: when the JVM hot cache ([pointCache]) doesn't already have this
     * triKey, try the native-cache direct [ByteBuffer] before falling back to [resolveHeatmapMesh]'s
     * FloatArray materialization. The direct-buffer batch's checkout is released by the draw loop
     * (`draw()`'s splat pass) right after it uploads that batch, via [directTriKey].
     */
    private fun resolveHeatmapPlaybackBatches(vts: VectorTileSource, refs: List<VectorPlaybackMeshRef>): List<CachedPointBatch> =
        refs.mapNotNull { ref ->
            val times = heatmapFeatureTimeCache[ref.triKey]
            // Prefer JVM materialization when map-time times are present so scrub can compact.
            if (times == null && !pointCache.containsKey(ref.triKey)) {
                val direct = vts.getHeatmapPointsNativeDirect(ref.triKey)
                if (direct != null) {
                    if (direct.capacity() <= 0) {
                        vts.releaseHeatmapPointsNativeDirect(ref.triKey)
                    } else {
                        return@mapNotNull CachedPointBatch(
                            coord = ref.coord,
                            points = EMPTY_FLOAT_ARRAY,
                            directBuffer = direct,
                            directByteCount = direct.capacity(),
                            directTriKey = ref.triKey,
                        )
                    }
                }
            }
            val points = resolveHeatmapMesh(vts, ref.triKey, requireFeatureTimes = times != null)
                ?: return@mapNotNull null
            if (points.isEmpty()) return@mapNotNull null
            CachedPointBatch(ref.coord, points, featureTimes = times)
        }

    private fun heatmapRadiusPxForMapZoom(styleRadiusPx: Float, zoom: Double): Float {
        val maxR = max(styleRadiusPx, HEATMAP_RADIUS_MIN_PX)
        val t = min(1.0, max(0.0, zoom / HEATMAP_RADIUS_ZOOM_REFERENCE))
        return HEATMAP_RADIUS_MIN_PX + (maxR - HEATMAP_RADIUS_MIN_PX) * t.toFloat()
    }

    private fun heatmapStyleKey(paint: HeatmapLayerPaint): Int {
        var h = paint.heatmap.color.hashCode()
        h = 31 * h + (paint.heatmap.radius.hashCode())
        h = 31 * h + (paint.heatmap.weight.hashCode())
        h = 31 * h + (paint.heatmap.intensity.hashCode())
        h = 31 * h + (paint.heatmap.blur.hashCode())
        return h
    }

    private fun syncGlGeneration() {
        if (syncedGlGeneration == glGeneration) return
        syncedGlGeneration = glGeneration
        releaseAllGl()
    }

    private fun releaseAllGl() {
        if (splatProgram != 0) {
            GLES31.glDeleteProgram(splatProgram)
            splatProgram = 0
        }
        if (blurProgram != 0) {
            GLES31.glDeleteProgram(blurProgram)
            blurProgram = 0
        }
        if (colorizeProgram != 0) {
            GLES31.glDeleteProgram(colorizeProgram)
            colorizeProgram = 0
        }
        splatProgramVersion = -1
        releaseDensityTargets()
        if (colorRampTex != 0) {
            GLES31.glDeleteTextures(1, intArrayOf(colorRampTex), 0)
            colorRampTex = 0
        }
        rampStyleKey = Int.MIN_VALUE
        if (vaoSplat != 0 || vaoColorize != 0) {
            val vaos = intArrayOf(vaoSplat, vaoColorize).filter { it != 0 }.toIntArray()
            GLES31.glDeleteVertexArrays(vaos.size, vaos, 0)
            vaoSplat = 0
            vaoColorize = 0
        }
        if (quadVbo != 0 || instanceVbo != 0) {
            val vbos = intArrayOf(quadVbo, instanceVbo).filter { it != 0 }.toIntArray()
            GLES31.glDeleteBuffers(vbos.size, vbos, 0)
            quadVbo = 0
            instanceVbo = 0
        }
    }

    private fun ensureGlResources(viewportW: Int, viewportH: Int, paint: HeatmapLayerPaint) {
        ensurePrograms()
        ensureDensityTarget(viewportW, viewportH)
        ensureColorRamp(paint)
        ensureQuadVbo()
    }

    private fun drawBlurPass(dstFbo: Int, srcTex: Int, texelX: Float, texelY: Float) {
        GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, dstFbo)
        GLES31.glUseProgram(blurProgram)
        GLES31.glActiveTexture(GLES31.GL_TEXTURE0)
        GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, srcTex)
        GLES31.glUniform1i(uBlurInput, 0)
        GLES31.glUniform2f(uBlurTexel, texelX, texelY)
        GLES31.glBindVertexArray(vaoColorize)
        GLES31.glDrawArrays(GLES31.GL_TRIANGLES, 0, 6)
    }

    private fun ensurePrograms() {
        if (splatProgram != 0 && blurProgram != 0 && colorizeProgram != 0 &&
            splatProgramVersion == HEATMAP_SHADER_VERSION
        ) {
            return
        }
        if (splatProgram != 0) {
            GLES31.glDeleteProgram(splatProgram)
            splatProgram = 0
        }
        if (blurProgram != 0) {
            GLES31.glDeleteProgram(blurProgram)
            blurProgram = 0
        }
        if (colorizeProgram != 0) {
            GLES31.glDeleteProgram(colorizeProgram)
            colorizeProgram = 0
        }
        val splatVs = """
            #version 310 es
            layout(location=0) in vec2 a_corner;
            layout(location=1) in vec2 a_center;
            layout(location=2) in float a_weight;
            uniform mat4 u_mvp;
            uniform float u_radius_uv;
            uniform float u_intensity;
            out vec2 v_extrude;
            flat out float v_pointWeight;
            void main() {
                const highp float ZERO = 1.0 / 255.0 / 16.0;
                const highp float GAUSS_COEF = 0.3989422804014327;
                v_pointWeight = a_weight;
                float denom = max(a_weight * u_intensity * GAUSS_COEF, 1e-20);
                float ratio = clamp(ZERO / denom, 1e-10, 1.0);
                float S = sqrt(-2.0 * log(ratio)) / 3.0;
                v_extrude = S * a_corner;
                vec2 pos = a_center + v_extrude * u_radius_uv;
                gl_Position = u_mvp * vec4(pos, 0.0, 1.0);
            }
        """.trimIndent()
        val splatFs = """
            #version 310 es
            precision highp float;
            uniform float u_intensity;
            in vec2 v_extrude;
            flat in float v_pointWeight;
            out vec4 fragColor;
            void main() {
                const highp float GAUSS_COEF = 0.3989422804014327;
                float d = -0.5 * 3.0 * 3.0 * dot(v_extrude, v_extrude);
                float val = v_pointWeight * u_intensity * GAUSS_COEF * exp(d);
                fragColor = vec4(val, 0.0, 0.0, 1.0);
            }
        """.trimIndent()
        val blurVs = """
            #version 310 es
            layout(location=0) in vec2 a_pos;
            out vec2 v_uv;
            void main() {
                v_uv = a_pos * 0.5 + 0.5;
                gl_Position = vec4(a_pos, 0.0, 1.0);
            }
        """.trimIndent()
        val blurFs = """
            #version 310 es
            precision highp float;
            uniform sampler2D u_density;
            uniform vec2 u_texel;
            in vec2 v_uv;
            out vec4 fragColor;
            void main() {
                float c = texture(u_density, v_uv).r * 0.2270270270;
                c += texture(u_density, v_uv + u_texel).r * 0.3162162162;
                c += texture(u_density, v_uv - u_texel).r * 0.3162162162;
                c += texture(u_density, v_uv + 2.0 * u_texel).r * 0.0702702703;
                c += texture(u_density, v_uv - 2.0 * u_texel).r * 0.0702702703;
                fragColor = vec4(c, 0.0, 0.0, 1.0);
            }
        """.trimIndent()
        val colorizeVs = """
            #version 310 es
            layout(location=0) in vec2 a_pos;
            out vec2 v_uv;
            void main() {
                v_uv = a_pos * 0.5 + 0.5;
                gl_Position = vec4(a_pos, 0.0, 1.0);
            }
        """.trimIndent()
        val colorizeFs = """
            #version 310 es
            precision highp float;
            uniform sampler2D u_density;
            uniform sampler2D u_colorRamp;
            uniform float u_density_scale;
            uniform float u_opacity;
            in vec2 v_uv;
            out vec4 fragColor;
            void main() {
                float density = texture(u_density, v_uv).r * u_density_scale;
                if (density <= 1e-6) discard;
                vec4 color = texture(u_colorRamp, vec2(clamp(density, 0.0, 1.0), 0.5));
                if (color.a <= 1e-4) discard;
                vec4 premul = vec4(color.rgb * color.a, color.a);
                fragColor = vec4(premul.rgb * u_opacity, premul.a * u_opacity);
            }
        """.trimIndent()
        splatProgram = linkSplatProgram(splatVs, splatFs) ?: return
        blurProgram = linkBlurProgram(blurVs, blurFs) ?: return
        colorizeProgram = linkColorizeProgram(colorizeVs, colorizeFs) ?: return
        splatProgramVersion = HEATMAP_SHADER_VERSION
        uSplatMvp = GLES31.glGetUniformLocation(splatProgram, "u_mvp")
        uSplatRadiusUv = GLES31.glGetUniformLocation(splatProgram, "u_radius_uv")
        uSplatIntensity = GLES31.glGetUniformLocation(splatProgram, "u_intensity")
        uBlurInput = GLES31.glGetUniformLocation(blurProgram, "u_density")
        uBlurTexel = GLES31.glGetUniformLocation(blurProgram, "u_texel")
        uColorizeDensity = GLES31.glGetUniformLocation(colorizeProgram, "u_density")
        uColorizeDensityScale = GLES31.glGetUniformLocation(colorizeProgram, "u_density_scale")
        uColorizeOpacity = GLES31.glGetUniformLocation(colorizeProgram, "u_opacity")
        locColorizeRamp = GLES31.glGetUniformLocation(colorizeProgram, "u_colorRamp")

        val vaos = IntArray(2)
        GLES31.glGenVertexArrays(2, vaos, 0)
        vaoSplat = vaos[0]
        vaoColorize = vaos[1]
        val vbos = IntArray(2)
        GLES31.glGenBuffers(2, vbos, 0)
        quadVbo = vbos[0]
        instanceVbo = vbos[1]

        val quad = floatArrayOf(
            -1f, -1f, 1f, -1f, -1f, 1f,
            1f, -1f, -1f, 1f, 1f, 1f,
        )
        GLES31.glBindVertexArray(vaoSplat)
        GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, quadVbo)
        GLES31.glBufferData(GLES31.GL_ARRAY_BUFFER, quad.size * 4, quad.toFloatBuffer(), GLES31.GL_STATIC_DRAW)
        GLES31.glEnableVertexAttribArray(0)
        GLES31.glVertexAttribPointer(0, 2, GLES31.GL_FLOAT, false, 8, 0)
        GLES31.glVertexAttribDivisor(0, 0)
        GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, instanceVbo)
        val stride = 12
        GLES31.glEnableVertexAttribArray(1)
        GLES31.glVertexAttribPointer(1, 2, GLES31.GL_FLOAT, false, stride, 0)
        GLES31.glVertexAttribDivisor(1, 1)
        GLES31.glEnableVertexAttribArray(2)
        GLES31.glVertexAttribPointer(2, 1, GLES31.GL_FLOAT, false, stride, 8)
        GLES31.glVertexAttribDivisor(2, 1)

        GLES31.glBindVertexArray(vaoColorize)
        GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, quadVbo)
        GLES31.glEnableVertexAttribArray(0)
        GLES31.glVertexAttribPointer(0, 2, GLES31.GL_FLOAT, false, 8, 0)
        GLES31.glBindVertexArray(0)
    }

    private fun ensureQuadVbo() {
        if (quadVbo != 0) return
    }

    private fun ensureDensityTarget(w: Int, h: Int) {
        if (w == fboWidth && h == fboHeight && densityFbo != 0 && blurFbo != 0) return
        releaseDensityTargets()
        fboWidth = w
        fboHeight = h
        densityTex = createDensityTexture(w, h)
        densityFbo = createDensityFramebuffer(densityTex, "density")
        if (densityFbo == 0) {
            releaseDensityTargets()
            return
        }
        blurTex = createDensityTexture(w, h)
        blurFbo = createDensityFramebuffer(blurTex, "blur")
        if (blurFbo == 0) {
            releaseDensityTargets()
            return
        }
        GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, 0)
    }

    private fun releaseDensityTargets() {
        if (densityTex != 0) {
            GLES31.glDeleteTextures(1, intArrayOf(densityTex), 0)
            densityTex = 0
        }
        if (blurTex != 0) {
            GLES31.glDeleteTextures(1, intArrayOf(blurTex), 0)
            blurTex = 0
        }
        if (densityFbo != 0) {
            GLES31.glDeleteFramebuffers(1, intArrayOf(densityFbo), 0)
            densityFbo = 0
        }
        if (blurFbo != 0) {
            GLES31.glDeleteFramebuffers(1, intArrayOf(blurFbo), 0)
            blurFbo = 0
        }
        fboWidth = 0
        fboHeight = 0
    }

    private fun createDensityTexture(w: Int, h: Int): Int {
        val tex = IntArray(1)
        GLES31.glGenTextures(1, tex, 0)
        GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, tex[0])
        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MIN_FILTER, GLES31.GL_LINEAR)
        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MAG_FILTER, GLES31.GL_LINEAR)
        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_WRAP_S, GLES31.GL_CLAMP_TO_EDGE)
        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_WRAP_T, GLES31.GL_CLAMP_TO_EDGE)
        GLES31.glTexImage2D(
            GLES31.GL_TEXTURE_2D, 0, GLES31.GL_R16F, w, h, 0,
            GLES31.GL_RED, GLES31.GL_HALF_FLOAT, null,
        )
        return tex[0]
    }

    private fun createDensityFramebuffer(tex: Int, label: String): Int {
        val fbo = IntArray(1)
        GLES31.glGenFramebuffers(1, fbo, 0)
        GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, fbo[0])
        GLES31.glFramebufferTexture2D(
            GLES31.GL_FRAMEBUFFER, GLES31.GL_COLOR_ATTACHMENT0,
            GLES31.GL_TEXTURE_2D, tex, 0,
        )
        val status = GLES31.glCheckFramebufferStatus(GLES31.GL_FRAMEBUFFER)
        if (status != GLES31.GL_FRAMEBUFFER_COMPLETE) {
            Log.e(VECTOR_HEATMAP_TAG, "$label FBO incomplete: 0x${status.toString(16)}")
            GLES31.glDeleteFramebuffers(1, intArrayOf(fbo[0]), 0)
            return 0
        }
        return fbo[0]
    }

    private fun ensureColorRamp(paint: HeatmapLayerPaint) {
        val styleKey = heatmapStyleKey(paint)
        if (colorRampTex != 0 && styleKey == rampStyleKey) return
        rampStyleKey = styleKey
        val stops = VectorHeatmapColorEval.buildRampStops(paint.heatmap.color)
        val pixels = VectorHeatmapColorEval.rampToTextureBytes(stops, COLOR_RAMP_WIDTH)
        if (colorRampTex == 0) {
            val tex = IntArray(1)
            GLES31.glGenTextures(1, tex, 0)
            colorRampTex = tex[0]
        }
        GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, colorRampTex)
        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MIN_FILTER, GLES31.GL_LINEAR)
        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MAG_FILTER, GLES31.GL_LINEAR)
        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_WRAP_S, GLES31.GL_CLAMP_TO_EDGE)
        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_WRAP_T, GLES31.GL_CLAMP_TO_EDGE)
        GLES31.glTexImage2D(
            GLES31.GL_TEXTURE_2D, 0, GLES31.GL_RGBA, COLOR_RAMP_WIDTH, 1, 0,
            GLES31.GL_RGBA, GLES31.GL_UNSIGNED_BYTE, pixels.toByteBuffer(),
        )
    }

    private fun uploadInstanceBuffer(points: FloatArray) {
        GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, instanceVbo)
        GLES31.glBufferData(GLES31.GL_ARRAY_BUFFER, points.size * 4, points.toFloatBuffer(), GLES31.GL_DYNAMIC_DRAW)
    }

    /** Rule: zero-copy-gpu-upload (Phase 5). [uploadInstanceBuffer]'s zero-copy counterpart — uploads
     * straight from the native cache's [ByteBuffer], no JVM FloatArray materialized in between. */
    private fun uploadInstanceBufferDirect(buffer: ByteBuffer, byteCount: Int) {
        buffer.order(ByteOrder.nativeOrder())
        buffer.position(0)
        buffer.limit(byteCount)
        GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, instanceVbo)
        GLES31.glBufferData(GLES31.GL_ARRAY_BUFFER, byteCount, buffer, GLES31.GL_DYNAMIC_DRAW)
    }

    private fun linkSplatProgram(vsSrc: String, fsSrc: String): Int? {
        val vs = compileShader(GLES31.GL_VERTEX_SHADER, vsSrc) ?: return null
        val fs = compileShader(GLES31.GL_FRAGMENT_SHADER, fsSrc) ?: return null
        val prog = GLES31.glCreateProgram()
        GLES31.glAttachShader(prog, vs)
        GLES31.glAttachShader(prog, fs)
        GLES31.glBindAttribLocation(prog, 0, "a_corner")
        GLES31.glBindAttribLocation(prog, 1, "a_center")
        GLES31.glBindAttribLocation(prog, 2, "a_weight")
        GLES31.glLinkProgram(prog)
        GLES31.glDeleteShader(vs)
        GLES31.glDeleteShader(fs)
        val ok = IntArray(1)
        GLES31.glGetProgramiv(prog, GLES31.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) {
            Log.e(VECTOR_HEATMAP_TAG, "splat link failed: ${GLES31.glGetProgramInfoLog(prog)}")
            GLES31.glDeleteProgram(prog)
            return null
        }
        return prog
    }

    private fun linkBlurProgram(vsSrc: String, fsSrc: String): Int? {
        val vs = compileShader(GLES31.GL_VERTEX_SHADER, vsSrc) ?: return null
        val fs = compileShader(GLES31.GL_FRAGMENT_SHADER, fsSrc) ?: return null
        val prog = GLES31.glCreateProgram()
        GLES31.glAttachShader(prog, vs)
        GLES31.glAttachShader(prog, fs)
        GLES31.glBindAttribLocation(prog, 0, "a_pos")
        GLES31.glLinkProgram(prog)
        GLES31.glDeleteShader(vs)
        GLES31.glDeleteShader(fs)
        val ok = IntArray(1)
        GLES31.glGetProgramiv(prog, GLES31.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) {
            Log.e(VECTOR_HEATMAP_TAG, "blur link failed: ${GLES31.glGetProgramInfoLog(prog)}")
            GLES31.glDeleteProgram(prog)
            return null
        }
        return prog
    }

    private fun linkColorizeProgram(vsSrc: String, fsSrc: String): Int? {
        val vs = compileShader(GLES31.GL_VERTEX_SHADER, vsSrc) ?: return null
        val fs = compileShader(GLES31.GL_FRAGMENT_SHADER, fsSrc) ?: return null
        val prog = GLES31.glCreateProgram()
        GLES31.glAttachShader(prog, vs)
        GLES31.glAttachShader(prog, fs)
        GLES31.glBindAttribLocation(prog, 0, "a_pos")
        GLES31.glLinkProgram(prog)
        GLES31.glDeleteShader(vs)
        GLES31.glDeleteShader(fs)
        val ok = IntArray(1)
        GLES31.glGetProgramiv(prog, GLES31.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) {
            Log.e(VECTOR_HEATMAP_TAG, "colorize link failed: ${GLES31.glGetProgramInfoLog(prog)}")
            GLES31.glDeleteProgram(prog)
            return null
        }
        return prog
    }

    private fun compileShader(type: Int, src: String): Int? {
        val s = GLES31.glCreateShader(type)
        GLES31.glShaderSource(s, src)
        GLES31.glCompileShader(s)
        val ok = IntArray(1)
        GLES31.glGetShaderiv(s, GLES31.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            Log.e(VECTOR_HEATMAP_TAG, "shader compile failed: ${GLES31.glGetShaderInfoLog(s)}")
            GLES31.glDeleteShader(s)
            return null
        }
        return s
    }

    override suspend fun update() {}

    private fun FloatArray.toFloatBuffer() =
        ByteBuffer.allocateDirect(size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(this).apply {
            position(0)
        }

    private fun ByteArray.toByteBuffer() =
        ByteBuffer.allocateDirect(size).order(ByteOrder.nativeOrder()).put(this).apply {
            position(0)
        }
}
