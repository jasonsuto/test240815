package com.xweather.mapsgl.renderers

import android.opengl.Matrix
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.gl.RenderPass
import com.xweather.mapsgl.gl.UnitQuad2DGeometry
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.gl.geometries.QuadGeometry
import com.xweather.mapsgl.gl.programs.Program
import com.xweather.mapsgl.gl.programs.RasterTileProgram
import com.xweather.mapsgl.gl.worldObjects.Mesh
import com.xweather.mapsgl.gl.worldObjects.MeshInfo
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera
import com.xweather.mapsgl.layers.spec.MaskLayerKind
import com.xweather.mapsgl.layers.spec.StencilLayerMaskSpec
import com.xweather.mapsgl.layers.spec.StencilMaskCombineMode
import com.xweather.mapsgl.layers.style.ParticleStyle
import com.xweather.mapsgl.layers.style.SampleStyle
import com.xweather.mapsgl.layers.tile.RenderContext
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.layers.tile.VectorTileLayer
import com.xweather.mapsgl.map.mapbox.GlStencilGeoJsonMaskMeshCoordinator
import com.xweather.mapsgl.map.mapbox.GlStencilMaskMeshBuilder
import com.xweather.mapsgl.map.mapbox.GlStencilMaskRenderer
import com.xweather.mapsgl.map.mapbox.CameraSync
import com.xweather.mapsgl.map.mapbox.GlStencilMaskRendererHolder
import com.xweather.mapsgl.map.mapbox.GlStencilMaskMarineLand
import com.xweather.mapsgl.map.mapbox.GlStencilMaskTileCache
import com.xweather.mapsgl.map.mapbox.MarineLandStencilPrediction
import com.xweather.mapsgl.map.mapbox.stencilCacheKeyForMeshInfo
import com.xweather.mapsgl.sources.GeoJSONSource
import com.xweather.mapsgl.style.ContourLayerPaint
import com.xweather.mapsgl.style.FillLayerPaint
import com.xweather.mapsgl.style.LineLayerPaint
import com.xweather.mapsgl.style.StyleValue
import com.xweather.mapsgl.style.ParticleLayerPaint
import com.xweather.mapsgl.style.SampleLayerPaint
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.tiles.TileRenderable
import com.xweather.mapsgl.types.SampleExpression

/**
 *   TileLayerRenderer.kt
 *
 *   Adapted from IOS version TileLayerRenderer.swift, TileRenderer in TS
 *   @author Jason Suto 12/20/23
 */

abstract class TileLayerRenderer<DataType : TileData, Context : LayerRenderContext<Any>> : LayerRenderer<Context> {

    private val TAG = "TileLayerRenderer"
    var tileLayer: TileLayer? = null
    internal lateinit var context: RenderContext<Any>
    private val helpers: MutableList<MeshInfo> = mutableListOf()
    private lateinit var _geometry: UnitQuad2DGeometry
    private lateinit var _renderPass: RenderPass //fixme: fix this, _renderpass should be initialized in onAdd()
    private var _renderablesAndMeshes: MutableMap<TileRenderable<DataType>, Mesh> = mutableMapOf()
    var cachesTextures = true;
    lateinit var mesh: Mesh
    private lateinit var FRAGMENT_SHADER_PATH: String
    private lateinit var VERTEX_SHADER_PATH: String
    private lateinit var RADAR_FRAGMENT_SHADER_PATH: String
    private lateinit var COMPUTE_SHADER_PATH: String
    private lateinit var TOUCH_SHADER_PATH: String
    lateinit var renderPass: RenderPass
    var renderpassInitialized = false
    val quadGeometry = QuadGeometry()
    var program: Program? = null
    var touchProgram: Program? = null
    var resetPaint = false

    /** Non-null while GLES stencil hooks are installed on [_renderPass]. */
    private var glStencilMaskHooksKey: String? = null

    /** Non-null while JS-style texture mask hooks are installed on [_renderPass]. */
    private var glTextureMaskHooksKey: String? = null

    init {
        quadGeometry.setVertices(UnitQuad2DGeometry.genQuad1x1())
    }

    override fun initialize(context: RenderContext<Any>) {
        this.context = context //This is also in makeMesh for renderable
    }

    /** empty so far */
    override fun setNeedsUpdate() {}

    /** empty so far */
    override fun setNeedsUpdate(force: Boolean) {}

    /** Called from TileLayer.render(), calls _renderPass.render() to do actual draw calls */
    override fun draw(context: Context, texUnit: HashMap<String, Int>, camera: Camera) {
        if (!renderpassInitialized) return
        configureGlStencilMaskHooksForDraw()
            _renderPass.render(texUnit, camera)
    }

    private fun clearGlStencilMaskHooks() {
        if (!renderpassInitialized) return
        _renderPass.stencilPassBegin = null
        _renderPass.stencilBeforeTile = null
        _renderPass.stencilAfterTile = null
        glStencilMaskHooksKey = null
        _renderPass.textureMaskBeforeTileLoop = null
        _renderPass.textureMaskBind = null
        glTextureMaskHooksKey = null
    }

    /** Drop cached hook keys so the next [draw] rebinds stencil/texture mask closures (e.g. mask layer toggle). */
    fun invalidateGlStencilMaskHooks() {
        glStencilMaskHooksKey = null
        glTextureMaskHooksKey = null
        // Do not clear stencil closures here: [configureGlStencilMaskHooksForDraw] runs at the
        // start of the same [draw] and would reinstall them. Clearing first caused a frame with
        // no WATER mask after Demo 2 → Demo 3 when finalize ran before the next full draw setup.
    }

    /**
     * When [EncodedTileLayer.glStencilMaskKind] is set, installs per-frame stencil hooks on [_renderPass]
     * (sample/contour encoded tiles only).
     */
    private fun configureGlStencilMaskHooksForDraw() {
        if (!renderpassInitialized) return
        val layer = tileLayer
        if (layer == null || program == null) {
            clearGlStencilMaskHooks()
            return
        }
        if (layer.paint is ParticleLayerPaint) {
            clearGlStencilMaskHooks()
            return
        }
        val mc = layer.mapController ?: run {
            clearGlStencilMaskHooks()
            return
        }
        val customSpec = layer.stencilLayerMask
        val useHybridLandHighwayStencil = shouldUseHybridLandHighwayStencil(layer, customSpec)
        if (useHybridLandHighwayStencil) {
            val hybridSpec = customSpec ?: run {
                clearGlStencilMaskHooks()
                return
            }
            if (hybridSpec.layers.isEmpty()) {
                clearGlStencilMaskHooks()
                return
            }
            val slotIds = hybridSpec.layers.map { it.layerId }
            val key = "hybrid_land_${layer.id}_${slotIds.joinToString(",")}"
            if (glStencilMaskHooksKey == key) return
            clearGlStencilMaskHooks()
            glStencilMaskHooksKey = key
            val cache = mc.glStencilMaskTileCache
            _renderPass.stencilPassBegin = null
            _renderPass.stencilBeforeTile = hybrid@{ meshInfo: MeshInfo, proj: FloatArray, mv: FloatArray ->
                val rp = program as? RasterTileProgram ?: return@hybrid
                val liveSpec = layer.stencilLayerMask ?: run {
                    GlStencilMaskRendererHolder.renderer.failClosedNoStencil()
                    return@hybrid
                }
                val renderer = GlStencilMaskRendererHolder.renderer
                val meshStencilKey = stencilCacheKeyForMeshInfo(meshInfo)
                val meshCoord = TileCoord.fromHashShort(meshStencilKey)
                if (applyMarineLandLandMaskPrepass(cache, meshStencilKey, renderer)) {
                    return@hybrid
                }
                val drewLand = renderer.drawMaskIntoStencil(
                    cache,
                    meshStencilKey,
                    MaskLayerKind.LAND,
                    proj,
                    mv,
                    rp,
                    layer.glStencilMaskCountryIso,
                )
                if (!drewLand) {
                    applyMarineLandLandMaskDrawMiss(cache, meshStencilKey, renderer)
                    return@hybrid
                }
                fun ensureGeoJsonMaskMeshForLayer(maskLayerId: String) {
                    val vl = mc.layers[maskLayerId] as? VectorTileLayer
                    val geoSrc = vl?.source as? GeoJSONSource
                    if (meshCoord != null && vl != null && geoSrc != null) {
                        val seq = geoSrc.geoJsonStencilSequence
                        val cached = cache.getExactCustomMaskMesh(maskLayerId, meshStencilKey)
                        if (cached != null &&
                            cached.geoJsonStencilSequence >= 0 &&
                            cached.geoJsonStencilSequence == seq
                        ) {
                            return
                        }
                        val feats = cache.getOrComputeGeoJsonStencilFilteredFeatures(
                            maskLayerId,
                            seq,
                            vl.filter,
                        ) { geoSrc.data?.features().orEmpty() }
                        val linePaint = vl.paint as? LineLayerPaint
                        val halfW = if (linePaint != null) {
                            when (val th = linePaint.stroke.thickness) {
                                is StyleValue.Constant -> (th.value / 400.0).toFloat().coerceIn(0.001f, 0.05f)
                                else -> 0.003f
                            }
                        } else {
                            0f
                        }
                        val lineStyle = linePaint?.let {
                            GlStencilMaskMeshBuilder.lineRibbonStyleFromLineLayerPaint(it)
                        }
                        GlStencilGeoJsonMaskMeshCoordinator.requestMeshIfNeeded(
                            mc,
                            cache,
                            maskLayerId,
                            meshStencilKey,
                            meshCoord,
                            feats,
                            seq,
                            halfW,
                            lineStyle,
                        )
                    }
                }
                var drewLineAny = false
                for (maskLayerId in liveSpec.layers.map { it.layerId }) {
                    ensureGeoJsonMaskMeshForLayer(maskLayerId)
                    if (renderer.drawCustomLineMaskOnLand(
                            cache,
                            meshStencilKey,
                            maskLayerId,
                            proj,
                            mv,
                            rp,
                        )
                    ) {
                        drewLineAny = true
                    }
                }
                if (!drewLineAny) {
                    renderer.failClosedNoStencil()
                    return@hybrid
                }
                renderer.configureStencilForHybridLandHighwayDraw()
            }
            _renderPass.stencilAfterTile = {
                GlStencilMaskRendererHolder.renderer.disableStencil()
            }
            return
        }
        if (customSpec != null &&
            (customSpec.layers.isNotEmpty() || customSpec.clipBounds != null) &&
            !useHybridLandHighwayStencil
        ) {
            val slotIds = customSpec.layers.map { it.layerId }
            val clipKey = customSpec.clipBounds?.let { b ->
                "${b.westExtent}_${b.southExtent}_${b.eastExtent}_${b.northExtent}"
            } ?: ""
            val key = "custom_${layer.id}_${customSpec.mode}_${customSpec.invert}_${clipKey}_" +
                slotIds.joinToString(",")
            // Texture mask FBO is built per visible weather tile. GeoJSON fill masks (e.g. CONUS)
            // triangulate most of each tile at low zoom, which paints white rectangles into the
            // mask and makes weather appear as a grid of tile quads. Use per-tile stencil for
            // specs that include fill mask layers; keep texture mask for line-only masks.
            val textureMaskOkForSpec = customSpec.layers.none { ref ->
                val vl = mc.layers[ref.layerId] as? VectorTileLayer
                vl?.paint is FillLayerPaint
            }
            if (mc.useGlTextureMaskFbo && textureMaskOkForSpec) {
                val texKey = "tex_$key"
                if (glTextureMaskHooksKey == texKey) return
                clearGlStencilMaskHooks()
                glTextureMaskHooksKey = texKey
                _renderPass.textureMaskBeforeTileLoop = textureMask@{ infos, proj, mvBase, w, h ->
                    val rp = program as? RasterTileProgram ?: return@textureMask
                    val liveSpec = layer.stencilLayerMask ?: return@textureMask
                    mc.glTextureMaskBuilder.rebuildIfNeeded(
                        mc,
                        liveSpec,
                        infos,
                        proj,
                        mvBase,
                        w,
                        h,
                        rp,
                    )
                }
                _renderPass.textureMaskBind = { prog, w, h ->
                    val texId = mc.glTextureMaskBuilder.colorTextureId()
                    prog.bindTextureMask(
                        texId,
                        w,
                        h,
                        texId != 0,
                        mc.glTextureMaskBuilder.lastInvert,
                    )
                }
                return
            }
            if (glStencilMaskHooksKey == key) return
            clearGlStencilMaskHooks()
            glStencilMaskHooksKey = key
            val cache = mc.glStencilMaskTileCache
            val useSequentialAll =
                customSpec.mode == StencilMaskCombineMode.ALL && !customSpec.invert
            val sequentialAllLayerOrder: List<String> = if (useSequentialAll) {
                slotIds.sortedBy { lid ->
                    val vl = mc.layers[lid] as? VectorTileLayer
                    if (vl?.paint is LineLayerPaint) 1 else 0
                }
            } else {
                emptyList()
            }
            _renderPass.stencilPassBegin = null
            _renderPass.stencilBeforeTile = stencil@{ meshInfo: MeshInfo, proj: FloatArray, mv: FloatArray ->
                val rp = program as? RasterTileProgram ?: return@stencil
                val liveSpec = layer.stencilLayerMask ?: run {
                    GlStencilMaskRendererHolder.renderer.failClosedNoStencil()
                    return@stencil
                }
                val liveSlotIds = liveSpec.layers.map { it.layerId }
                val useSequentialAllLive =
                    liveSpec.mode == StencilMaskCombineMode.ALL && !liveSpec.invert
                val sequentialAllLayerOrderLive: List<String> = if (useSequentialAllLive) {
                    liveSlotIds.sortedBy { lid ->
                        val vl = mc.layers[lid] as? VectorTileLayer
                        if (vl?.paint is LineLayerPaint) 1 else 0
                    }
                } else {
                    emptyList()
                }
                val meshStencilKey = stencilCacheKeyForMeshInfo(meshInfo)
                val meshCoord = TileCoord.fromHashShort(meshStencilKey)
                val renderer = GlStencilMaskRendererHolder.renderer

                fun ensureGeoJsonMaskMeshForLayer(maskLayerId: String) {
                    val vl = mc.layers[maskLayerId] as? VectorTileLayer
                    val geoSrc = vl?.source as? GeoJSONSource
                    if (meshCoord != null && vl != null && geoSrc != null) {
                        val seq = geoSrc.geoJsonStencilSequence
                        val cached = cache.getExactCustomMaskMesh(maskLayerId, meshStencilKey)
                        if (cached != null &&
                            cached.geoJsonStencilSequence >= 0 &&
                            cached.geoJsonStencilSequence == seq
                        ) {
                            return
                        }
                        val feats = cache.getOrComputeGeoJsonStencilFilteredFeatures(
                            maskLayerId,
                            seq,
                            vl.filter,
                        ) { geoSrc.data?.features().orEmpty() }
                        if (useSequentialAllLive) {
                            val tri = if (vl.paint is LineLayerPaint) {
                                val linePaint = vl.paint as LineLayerPaint
                                val halfW = when (val th = linePaint.stroke.thickness) {
                                    is StyleValue.Constant -> (th.value / 400.0).toFloat().coerceIn(0.001f, 0.05f)
                                    else -> 0.003f
                                }
                                GlStencilMaskMeshBuilder.buildLineRibbonTileUvTriangles(
                                    meshCoord,
                                    feats,
                                    halfW,
                                    GlStencilMaskMeshBuilder.lineRibbonStyleFromLineLayerPaint(linePaint),
                                )
                            } else {
                                GlStencilMaskMeshBuilder.buildTileUvTriangles(meshCoord, feats)
                            }
                            if (tri != null) {
                                cache.putCustomMaskMesh(
                                    maskLayerId,
                                    meshStencilKey,
                                    GlStencilMaskTileCache.CpuMesh(
                                        tri,
                                        tri.limit() / 2,
                                        geoJsonStencilSequence = seq,
                                    ),
                                )
                            } else {
                                cache.removeCustomMaskTile(maskLayerId, meshStencilKey)
                            }
                            return
                        }
                        val linePaint = vl.paint as? LineLayerPaint
                        val halfW = if (linePaint != null) {
                            when (val th = linePaint.stroke.thickness) {
                                is StyleValue.Constant -> (th.value / 400.0).toFloat().coerceIn(0.001f, 0.05f)
                                else -> 0.003f
                            }
                        } else {
                            0f
                        }
                        val lineStyle = linePaint?.let {
                            GlStencilMaskMeshBuilder.lineRibbonStyleFromLineLayerPaint(it)
                        }
                        GlStencilGeoJsonMaskMeshCoordinator.requestMeshIfNeeded(
                            mc,
                            cache,
                            maskLayerId,
                            meshStencilKey,
                            meshCoord,
                            feats,
                            seq,
                            halfW,
                            lineStyle,
                        )
                    }
                }

                // True per-pixel AND: area masks first, then line masks (Portugal ∩ roads, not either-or).
                if (useSequentialAllLive) {
                    var passIdx = 0
                    liveSpec.clipBounds?.let { b ->
                        val ck =
                            "${b.westExtent}_${b.southExtent}_${b.eastExtent}_${b.northExtent}"
                        val tri = GlStencilMaskMeshBuilder.buildLatLonBoundsClipTileUv(meshInfo, b)
                        if (tri == null) {
                            renderer.failClosedNoStencil()
                            return@stencil
                        }
                        val mesh = GlStencilMaskTileCache.CpuMesh(tri, tri.limit() / 2)
                        val vboKey = renderer.clipStencilVboKey(meshInfo, ck)
                        if (!renderer.drawSequentialAllMaskPass(mesh, vboKey, passIdx++, proj, mv, rp)) {
                            renderer.failClosedNoStencil()
                            return@stencil
                        }
                    }
                    for (maskLayerId in sequentialAllLayerOrderLive) {
                        ensureGeoJsonMaskMeshForLayer(maskLayerId)
                        val resolved = renderer.tryResolveCustomMaskVboForDraw(
                            cache,
                            maskLayerId,
                            meshStencilKey,
                        )
                        if (resolved == null || resolved.first.vertexCount < 3) {
                            renderer.failClosedNoStencil()
                            return@stencil
                        }
                        val (mesh, vboK, _) = resolved
                        if (!renderer.drawSequentialAllMaskPass(mesh, vboK, passIdx++, proj, mv, rp)) {
                            renderer.failClosedNoStencil()
                            return@stencil
                        }
                    }
                    if (passIdx == 0) {
                        renderer.failClosedNoStencil()
                        return@stencil
                    }
                    renderer.configureStencilForSequentialAll(passIdx, false)
                    return@stencil
                }

                var drewVectorAny = false
                liveSlotIds.forEachIndexed { index, maskLayerId ->
                    ensureGeoJsonMaskMeshForLayer(maskLayerId)
                    val bit = 1 shl index
                    if (renderer.drawCustomMaskSlotIntoStencil(
                            cache,
                            meshStencilKey,
                            maskLayerId,
                            bit,
                            proj,
                            mv,
                            rp,
                        )
                    ) {
                        drewVectorAny = true
                    }
                }
                val hasClip = liveSpec.clipBounds != null
                if (hasClip) {
                    val b = liveSpec.clipBounds!!
                    val ck =
                        "${b.westExtent}_${b.southExtent}_${b.eastExtent}_${b.northExtent}"
                    val tri = GlStencilMaskMeshBuilder.buildLatLonBoundsClipTileUv(meshInfo, b)
                    if (tri != null) {
                        val mesh = GlStencilMaskTileCache.CpuMesh(tri, tri.limit() / 2)
                        val bit = 1 shl liveSlotIds.size
                        renderer.drawClipBoundsMeshIntoStencil(
                            meshInfo,
                            ck,
                            mesh,
                            bit,
                            proj,
                            mv,
                            rp,
                        )
                    }
                    val totalSlots = liveSlotIds.size + 1
                    val combined = (1 shl totalSlots) - 1
                    renderer.configureStencilForLayerMaskCombine(
                        liveSpec.mode,
                        combined,
                        liveSpec.invert,
                    )
                } else if (drewVectorAny) {
                    val combined = (1 shl liveSlotIds.size) - 1
                    renderer.configureStencilForLayerMaskCombine(
                        liveSpec.mode,
                        combined,
                        liveSpec.invert,
                    )
                } else {
                    if (liveSpec.invert) {
                        renderer.failOpenNoStencil()
                    } else {
                        renderer.failClosedNoStencil()
                    }
                }
            }
            _renderPass.stencilAfterTile = {
                GlStencilMaskRendererHolder.renderer.disableStencil()
            }
            return
        }
        if (layer.glStencilMaskKind == MaskLayerKind.NONE) {
            clearGlStencilMaskHooks()
            return
        }
        val key = "${layer.id}_${layer.glStencilMaskKind.ordinal}_${layer.glStencilMaskCountryIso ?: ""}"
        if (glStencilMaskHooksKey == key) return
        clearGlStencilMaskHooks()
        glStencilMaskHooksKey = key
        val kind = layer.glStencilMaskKind
        val cache = mc.glStencilMaskTileCache
        _renderPass.stencilPassBegin = null
        _renderPass.stencilBeforeTile = stencil@{ meshInfo: MeshInfo, proj: FloatArray, mv: FloatArray ->
            val rp = program as? RasterTileProgram ?: return@stencil
            val renderer = GlStencilMaskRendererHolder.renderer
            val meshStencilKey = stencilCacheKeyForMeshInfo(meshInfo)
            if (kind == MaskLayerKind.LAND &&
                applyMarineLandLandMaskPrepass(cache, meshStencilKey, renderer)
            ) {
                return@stencil
            }
            if (kind == MaskLayerKind.WATER &&
                applyMarineWaterMaskPrepass(cache, meshStencilKey, renderer)
            ) {
                return@stencil
            }
            val drewMask = renderer.drawMaskIntoStencil(
                cache,
                meshStencilKey,
                kind,
                proj,
                mv,
                rp,
                layer.glStencilMaskCountryIso,
            )
            if (drewMask) {
                if (kind == MaskLayerKind.LAND) {
                    renderer.configureStencilForInvertedLandDraw()
                } else {
                    renderer.configureStencilForWeatherDraw(kind)
                }
            } else if (kind == MaskLayerKind.LAND) {
                applyMarineLandLandMaskDrawMiss(cache, meshStencilKey, renderer)
            } else {
                renderer.failClosedNoStencil()
            }
        }
        _renderPass.stencilAfterTile = {
            GlStencilMaskRendererHolder.renderer.disableStencil()
        }
    }

    /**
     * Early marine [MaskLayerKind.LAND] prepass before [GlStencilMaskRenderer.drawMaskIntoStencil].
     * @return `true` when stencil setup is complete and the caller should skip mask drawing.
     */
    private fun applyMarineLandLandMaskPrepass(
        cache: GlStencilMaskTileCache,
        meshStencilKey: String,
        renderer: GlStencilMaskRenderer,
    ): Boolean {
        return when (val p = cache.predictMarineLandStencilOutcome(meshStencilKey)) {
            is MarineLandStencilPrediction.AllLandNoWaterGeometry -> {
                renderer.failOpenNoStencil()
                true
            }
            is MarineLandStencilPrediction.FailClosed -> {
                renderer.failClosedNoStencil()
                true
            }
            is MarineLandStencilPrediction.WillStencil -> {
                if (p.waterUvArea > GlStencilMaskMarineLand.MAX_WATER_UV_AREA_FOR_LAND_MASK) {
                    renderer.failClosedNoStencil()
                    true
                } else {
                    false
                }
            }
        }
    }

    private fun applyMarineWaterMaskPrepass(
        cache: GlStencilMaskTileCache,
        meshStencilKey: String,
        renderer: GlStencilMaskRenderer,
    ): Boolean {
        return when (val p = cache.predictMarineLandStencilOutcome(meshStencilKey)) {
            is MarineLandStencilPrediction.AllLandNoWaterGeometry -> {
                renderer.failOpenNoStencil()
                true
            }
            is MarineLandStencilPrediction.FailClosed -> {
                renderer.failClosedNoStencil()
                true
            }
            is MarineLandStencilPrediction.WillStencil -> false
        }
    }

    /** Stencil write missed after [drawMaskIntoStencil]; align with [predictMarineLandStencilOutcome]. */
    private fun applyMarineLandLandMaskDrawMiss(
        cache: GlStencilMaskTileCache,
        meshStencilKey: String,
        renderer: GlStencilMaskRenderer,
    ) {
        when (cache.predictMarineLandStencilOutcome(meshStencilKey)) {
            is MarineLandStencilPrediction.AllLandNoWaterGeometry ->
                renderer.failOpenNoStencil()
            else ->
                renderer.failClosedNoStencil()
        }
    }

    private fun applyMarineWaterMaskDrawMiss(
        cache: GlStencilMaskTileCache,
        meshStencilKey: String,
        renderer: GlStencilMaskRenderer,
    ) {
        when (cache.predictMarineLandStencilOutcome(meshStencilKey)) {
            is MarineLandStencilPrediction.AllLandNoWaterGeometry ->
                renderer.failOpenNoStencil()
            else ->
                renderer.failClosedNoStencil()
        }
    }

    /**
     * Instanced gridded layers (wind/wave direction arrows) draw in one GL pass across the viewport,
     * so they cannot use per-tile [_renderPass.stencilBeforeTile] hooks. Writes land/water stencil
     * for every visible weather tile, then configures stencil test once before [drawInstanced].
     *
     * @return `true` when stencil test was configured and the caller must [GlStencilMaskRenderer.disableStencil]
     *         after the instanced draw.
     */
    protected fun prepareInstancedGridStencilMask(
        camera: Camera,
        tileCoords: List<TileCoord>,
    ): Boolean {
        val layer = tileLayer ?: return false
        if (layer.glStencilMaskKind == MaskLayerKind.NONE) return false
        if (layer.stencilLayerMask != null) return false
        val mc = layer.mapController ?: return false
        if (tileCoords.isEmpty()) return false

        val kind = layer.glStencilMaskKind
        val cache = mc.glStencilMaskTileCache
        val renderer = GlStencilMaskRendererHolder.renderer

        val projection = FloatArray(16)
        val cameraArray = FloatArray(16)
        val matrixArray = FloatArray(16)
        val modelView = FloatArray(16)

        val mapboxProj = CameraSync.mapboxProjectionMatrix
        val mapboxMv = CameraSync.mapboxModelViewMatrix
        val useMapboxNativeMv =
            mapboxProj != null && mapboxMv != null && mapboxProj.size >= 16 && mapboxMv.size >= 16
        if (useMapboxNativeMv) {
            System.arraycopy(mapboxProj!!, 0, projection, 0, 16)
            System.arraycopy(mapboxMv!!, 0, cameraArray, 0, 16)
        } else {
            camera.projectionMatrix.elements.forEachIndexed { i, v -> projection[i] = v.toFloat() }
            camera.viewMatrix.elements.forEachIndexed { i, v -> cameraArray[i] = v.toFloat() }
        }

        for (coord in tileCoords) {
            val meshInfo = MeshInfo(
                coord.x.toFloat(),
                coord.y.toFloat(),
                coord.z.toFloat(),
                coord.hashShort(),
            )
            meshInfo.inspectorHash = coord.hashShort()

            Matrix.setIdentityM(matrixArray, 0)
            val mapZoomNow = CameraSync.customLayerRenderZoom ?: CameraSync.mapZoom
            val overscale = if (useMapboxNativeMv) {
                CameraSync.tileRasterOverscale(mapZoomNow, coord.z)
            } else {
                1f
            }
            Matrix.scaleM(matrixArray, 0, 512f * overscale, 512f * overscale, 1f)
            Matrix.translateM(matrixArray, 0, meshInfo.x, meshInfo.y, 0f)
            Matrix.multiplyMM(modelView, 0, cameraArray, 0, matrixArray, 0)

            val meshStencilKey = stencilCacheKeyForMeshInfo(meshInfo)
            renderer.clearStencilForWeatherTileScreenBounds(
                projection,
                modelView,
                camera.resX,
                camera.resY,
            )
            writeInstancedGridTileStencil(
                cache,
                renderer,
                meshStencilKey,
                kind,
                projection,
                modelView,
                layer.glStencilMaskCountryIso,
            )
        }

        when (kind) {
            MaskLayerKind.LAND -> renderer.configureStencilForInvertedLandDraw()
            MaskLayerKind.WATER, MaskLayerKind.TRANSPORTATION, MaskLayerKind.COUNTRY ->
                renderer.configureStencilForWeatherDraw(kind)
            else -> return false
        }
        return true
    }

    /**
     * Stencil write for one weather tile during [prepareInstancedGridStencilMask]. Does not call
     * [GlStencilMaskRenderer.failOpenNoStencil] / [GlStencilMaskRenderer.failClosedNoStencil] so GL
     * state stays consistent across the multi-tile accumulation pass.
     */
    private fun writeInstancedGridTileStencil(
        cache: GlStencilMaskTileCache,
        renderer: GlStencilMaskRenderer,
        meshStencilKey: String,
        kind: MaskLayerKind,
        projection: FloatArray,
        modelView: FloatArray,
        countryIso: String?,
    ) {
        when (kind) {
            MaskLayerKind.WATER -> {
                when (val prediction = cache.predictMarineLandStencilOutcome(meshStencilKey)) {
                    is MarineLandStencilPrediction.AllLandNoWaterGeometry -> {
                        renderer.drawFullTileStencilRef(projection, modelView)
                        return
                    }
                    is MarineLandStencilPrediction.FailClosed -> return
                    is MarineLandStencilPrediction.WillStencil -> Unit
                }
                val drewMask = renderer.drawMaskIntoStencil(
                    cache,
                    meshStencilKey,
                    kind,
                    projection,
                    modelView,
                    rasterProgram = null,
                    countryIso3166Alpha2 = countryIso,
                )
                if (!drewMask &&
                    cache.predictMarineLandStencilOutcome(meshStencilKey)
                        is MarineLandStencilPrediction.AllLandNoWaterGeometry
                ) {
                    renderer.drawFullTileStencilRef(projection, modelView)
                }
            }
            MaskLayerKind.LAND -> {
                when (val prediction = cache.predictMarineLandStencilOutcome(meshStencilKey)) {
                    is MarineLandStencilPrediction.AllLandNoWaterGeometry -> return
                    is MarineLandStencilPrediction.FailClosed -> return
                    is MarineLandStencilPrediction.WillStencil -> {
                        if (prediction.waterUvArea > GlStencilMaskMarineLand.MAX_WATER_UV_AREA_FOR_LAND_MASK) {
                            return
                        }
                    }
                }
                renderer.drawMaskIntoStencil(
                    cache,
                    meshStencilKey,
                    kind,
                    projection,
                    modelView,
                    rasterProgram = null,
                    countryIso3166Alpha2 = countryIso,
                )
            }
            MaskLayerKind.COUNTRY, MaskLayerKind.TRANSPORTATION -> {
                renderer.drawMaskIntoStencil(
                    cache,
                    meshStencilKey,
                    kind,
                    projection,
                    modelView,
                    rasterProgram = null,
                    countryIso3166Alpha2 = countryIso,
                )
            }
            else -> Unit
        }
    }

    private fun shouldUseHybridLandHighwayStencil(
        layer: TileLayer,
        customSpec: StencilLayerMaskSpec?,
    ): Boolean {
        if (layer.hybridLandWithCustomLineMask) return true
        if (customSpec == null || customSpec.layers.isEmpty() || customSpec.clipBounds != null) {
            return false
        }
        return layer.glStencilMaskKind == MaskLayerKind.LAND
    }

    override fun onAdd(tileLayer: TileLayer) {
        this.tileLayer = tileLayer
        _renderPass = setUpRenderPass()
        renderPass = _renderPass
        renderpassInitialized = true
    }

    /**  Puts a list of meshes to be drawn into _renderPass.meshes   */
    override fun prerender(context: Context) {
        val renderables = context.renderables as? List<TileRenderable<DataType>> ?: return

        // 1. Synchronized cleanup of old meshes
        val currentKeys = _renderablesAndMeshes.keys.toSet()
        val toRemove = currentKeys.filter { it !in renderables }
        toRemove.forEach { _renderablesAndMeshes.remove(it) }
        helpers.clear()

        for (renderable in renderables) {
            // Get existing mesh or create a unique one for this tile
            val mesh = _renderablesAndMeshes.getOrPut(renderable) {
                makeMeshForRenderable(renderable)
            }

            // 3. ALWAYS update positions so tiles move when the map pans
            mesh.position.x = renderable.coord.x.toFloat()
            mesh.position.y = renderable.coord.y.toFloat()
            mesh.position.z = renderable.coord.z.toFloat()

            helpers.add(
                MeshInfo(
                    mesh.position.x, mesh.position.y, mesh.position.z,
                    renderable.tile.coordHash
                )
            )
        }
        _renderPass.meshInfoList = helpers.toList()
        _renderPass.meshes = _renderablesAndMeshes.values.toList()
    }

    private fun makeMeshForRenderable(renderable: TileRenderable<DataType>?): Mesh/*<TileMaterial>*/ {
        return try {
            if (program == null) {
                createProgram()
                if (tileLayer!!.paint is ParticleLayerPaint) {
                    mesh = Mesh(0, quadGeometry, program!!, createFrameBufferProgram())
                    mesh.textureProgram = createTextureProgram()

                } else {
                    //println("$TAG makeMeshForRenderable() paint is NOT ParticleStyle")
                    mesh = Mesh(0, quadGeometry, program!!, touchProgram = touchProgram)
                }
                //tileLayer!!.paint is ParticleLayerPaint
            } else if (resetPaint) {
                resetProgram()
                resetPaint = false
            }
            return mesh

        } catch (e: Exception) {
            throw e
        }
    }

    private fun createProgram(): RasterTileProgram {

        if (pr.ON) pr.p(TAG, pr.radarFix, "createProgram() Entered for ${tileLayer!!.id} ")

        if (tileLayer!!.paint is SampleLayerPaint) {

            val expression: String
            val encodedPaint = tileLayer!!.paint as SampleLayerPaint
            val expressionEnum = encodedPaint.sample.expression
            if (expressionEnum == SampleExpression.VECTOR) {
                expression = "EXPRESSION_VECTOR"
            } else if (expressionEnum == SampleExpression.DIFFERENCE) {
                expression = "EXPRESSION_DIFF"
            } else if (tileLayer!!.source.datasets.any { it.noData != null }) { // If any noData set, define in shader
                expression = "NO_DATA"
            } else {
                expression = "sample"
            }

            if (tileLayer!!.id != "conditions.radar.fill") {

                VERTEX_SHADER_PATH = "shaders/vertexShader.vert"
                FRAGMENT_SHADER_PATH = "shaders/sample.frag.combined.glsl" //correct shader

                //TOUCH_SHADER_PATH = "shaders/rawImage.glsl" //correct shader
                //FRAGMENT_SHADER_PATH="shaders/test/green.glsl" //single channel test
                //FRAGMENT_SHADER_PATH="shaders/fragmentShaderRawImage.glsl" // for testing raw image from server
                //FRAGMENT_SHADER_PATH="shaders/test/fragmentShaderColorBand.glsl" // for testing colorBand
                //FRAGMENT_SHADER_PATH="shaders/test/boarder.glsl" // for testing raw image with black boarder
                // FRAGMENT_SHADER_PATH="shaders/test/partTestShader.frag" // for testing particle generation
                program = RasterTileProgram(
                    tileLayer?.drawContext,
                    VERTEX_SHADER_PATH,
                    FRAGMENT_SHADER_PATH,
                    expression,
                    ProgramType.SAMPLE,
                )

                (this as EncodedDataRenderer<*, *>).setup(encodedPaint)

            } else { // Special shader for radar

                if (pr.ON) pr.p(TAG, pr.radarFix2, "createProgram() USING THE RADAR SHADER")
                tileLayer!!.isRadar = true
                VERTEX_SHADER_PATH = "shaders/vertexShader.vert"
                RADAR_FRAGMENT_SHADER_PATH = "shaders/sample-multiband.frag.glsl"

                program = RasterTileProgram(
                    tileLayer?.drawContext,
                    VERTEX_SHADER_PATH,
                    RADAR_FRAGMENT_SHADER_PATH,
                    expression,
                    ProgramType.SAMPLE,
                )
                (this as EncodedDataRenderer<*, *>).setup(encodedPaint)
                return program as RasterTileProgram
            }

        } else if (tileLayer!!.paint is ParticleLayerPaint) {
            COMPUTE_SHADER_PATH = "shaders/particles/tilePartComp31.glsl"
            FRAGMENT_SHADER_PATH = "shaders/particles/tilePartFrag31.glsl"
            VERTEX_SHADER_PATH = "shaders/particles/tilePartVert31.glsl"
            //VERTEX_SHADER_STRING=  "shaders/vertexShader.vert"
            //FRAGMENT_SHADER_PATH="shaders/fragmentShaderRawImage.glsl"

            val encodedPaint = tileLayer!!.paint as ParticleLayerPaint
            val expressionEnum = encodedPaint.sample.expression
            var expression: String
            if (expressionEnum == SampleExpression.VECTOR) {
                expression = "EXPRESSION_VECTOR"
            } else {
                expression = "EXPRESSION_ANGLE"
            }

            program = RasterTileProgram(
                tileLayer?.drawContext,
                VERTEX_SHADER_PATH,
                FRAGMENT_SHADER_PATH,
                expression,
                ProgramType.PARTICLE,
                COMPUTE_SHADER_PATH
            )
            (this as ParticleRenderer).setup(tileLayer!!.paint as ParticleLayerPaint)
        } else if (tileLayer!!.paint is ContourLayerPaint) {

            val expression: String
            val contourPaint = tileLayer!!.paint as ContourLayerPaint
            val expressionEnum = contourPaint.sample.expression
            if (expressionEnum == SampleExpression.VECTOR) {
                expression = "EXPRESSION_VECTOR"
            } else if (expressionEnum == SampleExpression.DIFFERENCE) {
                expression = "EXPRESSION_DIFF"
            } else if (tileLayer!!.source.datasets.any { it.noData != null }) { // If any noData set, define in shader
                expression = "NO_DATA"
            } else {
                expression = "NUMBER"
            }

            VERTEX_SHADER_PATH = "shaders/vertexContour.vert"
            FRAGMENT_SHADER_PATH = "shaders/fragmentContour.glsl"

            program = RasterTileProgram(
                tileLayer?.drawContext,
                VERTEX_SHADER_PATH,
                FRAGMENT_SHADER_PATH,
                expression,
                ProgramType.SAMPLE,
            )

            (this as EncodedDataRenderer<*, *>).setup(contourPaint)
            if (pr.ON) pr.p("TileLayerRenderer", pr.contour, "createProgram() Contour detected")


        } else { //Raster Image Tile
            if (pr.ON) pr.p(TAG, pr.autoGenerated, "createProgram() 800 ")
            VERTEX_SHADER_PATH = "shaders/vertexShader.vert"
            FRAGMENT_SHADER_PATH =
                "shaders/fragmentShaderRawImage.glsl" // Correct, for displaying raster image from server
            //FRAGMENT_SHADER_PATH= "shaders/test/fragmentShaderTexture.frag" // Just show the raw texture
            //if(pr.ON)pr.p(TAG,pr.particles,"createProgram(), raster detected")
            program = RasterTileProgram(
                tileLayer?.drawContext,
                VERTEX_SHADER_PATH,
                FRAGMENT_SHADER_PATH,
                "raster",
                ProgramType.RASTER
            )
        }

        return program as RasterTileProgram
    }

    /** Dynamically set colorstops **/
    private fun resetProgram(): RasterTileProgram {
        if (tileLayer!!.paint is SampleLayerPaint) {
            val expression = ((tileLayer!!.paint as SampleStyle).expression).toString()

            if (!tileLayer!!.isRadar) {
                program = RasterTileProgram(
                    tileLayer?.drawContext,
                    VERTEX_SHADER_PATH,
                    FRAGMENT_SHADER_PATH,
                    expression,
                    ProgramType.SAMPLE
                )
                (this as EncodedDataRenderer<*, *>).setup(tileLayer!!.paint as SampleLayerPaint)
            } else {
                program = RasterTileProgram(
                    tileLayer?.drawContext,
                    VERTEX_SHADER_PATH,
                    FRAGMENT_SHADER_PATH,
                    expression,
                    ProgramType.SAMPLE
                )
                (this as EncodedDataRenderer<*, *>).setup(tileLayer!!.paint as SampleLayerPaint)
                return program as RasterTileProgram
            }


        } else if (tileLayer!!.paint is ParticleLayerPaint) {

            if (pr.ON) pr.p(TAG, pr.customColor, "resetProgram(), particles detected")
            val expression = ((tileLayer!!.paint as ParticleStyle).expression).toString()
            program = RasterTileProgram(
                tileLayer?.drawContext,
                VERTEX_SHADER_PATH,
                FRAGMENT_SHADER_PATH,
                expression,
                ProgramType.PARTICLE
            )
            (this as ParticleRenderer).setup(tileLayer!!.paint as ParticleLayerPaint)
        } else { //Image Tile
            program = RasterTileProgram(
                tileLayer?.drawContext,
                VERTEX_SHADER_PATH,
                FRAGMENT_SHADER_PATH,
                "raster",
                ProgramType.RASTER
            )
        }
        if (pr.ON) pr.p(TAG, pr.customColor, "resetProgram(), returning")
        return program as RasterTileProgram
    }

    fun createFrameBufferProgram(): RasterTileProgram {
        val VERTEX_PATH = "shaders/particles/fb-trail-vert.glsl"
        val FRAGMENT_PATH = "shaders/particles/fb-trail-frag.glsl"
        //val FRAGMENT_PATH="shaders/fragmentShaderRawImage.glsl" // for testing raw image from server
        val rasterTileProgram =
            RasterTileProgram(tileLayer?.drawContext, VERTEX_PATH, FRAGMENT_PATH, "frameBuffer", ProgramType.PARTICLE)
        (this as ParticleRenderer).setupFrameBufferProgram(tileLayer!!.paint, rasterTileProgram)
        return rasterTileProgram
    }

    fun createTextureProgram(): RasterTileProgram {
        val VERTEX_PATH = "shaders/particles/mega-texture-vert.glsl"
        //val VERTEX_PATH =  "shaders/vertexShader.vert"
        val FRAGMENT_PATH = "shaders/particles/mega-texture-frag.glsl"
        //val FRAGMENT_PATH="shaders/fragmentShaderRawImage.glsl"
        return RasterTileProgram(
            tileLayer?.drawContext,
            VERTEX_PATH,
            FRAGMENT_PATH,
            "frameBuffer",
            ProgramType.PARTICLE
        )
    }

    @Throws(Exception::class)
    abstract fun setUpRenderPass(): RenderPass

    override fun onRemove() {
        if (pr.ON) pr.p(TAG, pr.i13, "TileLayerRenderer onRemove() Entered ")
        clearGlStencilMaskHooks()
    }

    override suspend fun onMove() {}

    override fun onMoveStart() {}

    override suspend fun onMoveEnd() {}

    override fun onResize() {}

    override fun onClick() {}

    override fun onVisible() {}

    override fun onHidden() {}
}

class ProgramType {
    companion object {
        const val RASTER = 1
        const val SAMPLE = 2
        const val PARTICLE = 3
    }
}