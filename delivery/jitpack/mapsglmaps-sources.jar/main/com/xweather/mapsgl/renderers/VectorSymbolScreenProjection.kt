package com.xweather.mapsgl.renderers

import android.opengl.Matrix
import com.xweather.mapsgl.gl.math.PowerTable.Companion.powerTableI
import com.xweather.mapsgl.tiles.TileCoord
import kotlin.math.cos
import kotlin.math.sin

/** Projects GLES symbol instances to screen-space bounds (MapsGL JS collision boxes). */
internal object VectorSymbolScreenProjection {

    /** Collision footprint vs drawn icon (inset from full quad bounds). */
    const val SYMBOL_COLLISION_BOX_SCALE = 0.72f

    fun buildTileMvp(
        coord: TileCoord,
        overscale: Float,
        proj: FloatArray,
        mvCam: FloatArray,
        tileLocal: FloatArray,
        modelView: FloatArray,
        mvp: FloatArray,
    ): FloatArray {
        Matrix.setIdentityM(tileLocal, 0)
        Matrix.scaleM(tileLocal, 0, 512f * overscale, 512f * overscale, 1f)
        // Rule: dateline-world-copy. See VectorFillLayerRenderer.drawInterleavedForCoord's identical
        // fix — must match VectorSymbolLayerRenderer.uploadInstanceBuffer's draw-matrix offset or
        // collision boxes are computed at the wrong screen position for a world-copied tile.
        val worldCopyN = powerTableI.getOrElse(coord.z) { 1 shl coord.z }
        Matrix.translateM(tileLocal, 0, coord.x.toFloat() + coord.offset * worldCopyN, coord.y.toFloat(), 0f)
        Matrix.multiplyMM(modelView, 0, mvCam, 0, tileLocal, 0)
        Matrix.multiplyMM(mvp, 0, proj, 0, modelView, 0)
        return mvp
    }

    fun screenBoundsForInstance(
        instances: FloatArray,
        instanceIndex: Int,
        mvp: FloatArray,
        overscale: Float,
        viewportW: Float,
        viewportH: Float,
        paddingPx: Float,
        billboard: Boolean,
        collisionScale: Float = SYMBOL_COLLISION_BOX_SCALE,
        halfWidthPxOverride: Float? = null,
        halfHeightPxOverride: Float? = null,
    ): FloatArray {
        val base = instanceIndex * SYMBOL_FLOATS_PER_INSTANCE
        val cu = instances[base]
        val cv = instances[base + 1]
        val hw = (halfWidthPxOverride ?: instances[base + 10]) * collisionScale
        val hh = (halfHeightPxOverride ?: instances[base + 11]) * collisionScale
        val offX = instances[base + 12]
        val offY = instances[base + 13]
        val rotRad = Math.toRadians(instances[base + 14].toDouble())
        val cosR = cos(rotRad).toFloat()
        val sinR = sin(rotRad).toFloat()
        val halfScale = 1f / (512f * overscale.coerceAtLeast(1e-6f))
        var minX = Float.POSITIVE_INFINITY
        var minY = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY
        var maxY = Float.NEGATIVE_INFINITY
        val corners = arrayOf(-1f to -1f, 1f to -1f, -1f to 1f, 1f to 1f)
        for ((qx, qy) in corners) {
            val rx = qx * hw
            val ry = qy * hh
            val cx = rx * cosR - ry * sinR + offX
            val cy = rx * sinR + ry * cosR + offY
            val (sx, sy) =
                if (billboard) {
                    projectBillboardCorner(cu, cv, cx, cy, mvp, viewportW, viewportH)
                } else {
                    val tu = cu + cx * halfScale
                    val tv = cv + cy * halfScale
                    projectTileUvToScreen(tu, tv, mvp, viewportW, viewportH)
                }
            minX = minOf(minX, sx)
            minY = minOf(minY, sy)
            maxX = maxOf(maxX, sx)
            maxY = maxOf(maxY, sy)
        }
        return floatArrayOf(
            minX - paddingPx,
            minY - paddingPx,
            maxX + paddingPx,
            maxY + paddingPx,
        )
    }

    private fun projectBillboardCorner(
        anchorU: Float,
        anchorV: Float,
        cornerPxX: Float,
        cornerPxY: Float,
        mvp: FloatArray,
        viewportW: Float,
        viewportH: Float,
    ): Pair<Float, Float> {
        val clipX = mvp[0] * anchorU + mvp[4] * anchorV + mvp[12]
        val clipY = mvp[1] * anchorU + mvp[5] * anchorV + mvp[13]
        val clipW = mvp[3] * anchorU + mvp[7] * anchorV + mvp[15]
        if (clipW == 0f) return 0f to 0f
        // Match SYMBOL_VERT billboard branch: offset in clip space, then perspective divide.
        val offClipX = cornerPxX * (2f / viewportW) * clipW
        val offClipY = -cornerPxY * (2f / viewportH) * clipW
        val ndcX = (clipX + offClipX) / clipW
        val ndcY = (clipY + offClipY) / clipW
        return (ndcX + 1f) * 0.5f * viewportW to (1f - ndcY) * 0.5f * viewportH
    }

    private fun projectTileUvToScreen(
        tileU: Float,
        tileV: Float,
        mvp: FloatArray,
        viewportW: Float,
        viewportH: Float,
    ): Pair<Float, Float> {
        val ndcX = mvp[0] * tileU + mvp[4] * tileV + mvp[12]
        val ndcY = mvp[1] * tileU + mvp[5] * tileV + mvp[13]
        val ndcW = mvp[3] * tileU + mvp[7] * tileV + mvp[15]
        if (ndcW == 0f) return 0f to 0f
        val x = ndcX / ndcW
        val y = ndcY / ndcW
        return (x + 1f) * 0.5f * viewportW to (1f - y) * 0.5f * viewportH
    }
}
