package com.xweather.mapsgl.renderers

import android.graphics.Bitmap
import android.graphics.Paint
import com.xweather.mapsgl.Partial
import com.xweather.mapsgl.anim.TimeSeriesState
import com.xweather.mapsgl.data.DataRange
import com.xweather.mapsgl.gl.RenderPass
import com.xweather.mapsgl.gl.programs.TriangleProgram
import com.xweather.mapsgl.layers.style.SampleStyle
import com.xweather.mapsgl.layers.tile.RenderContext
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.map.mapbox.MapboxMapController
import com.xweather.mapsgl.style.ColorLookupTable
import com.xweather.mapsgl.style.ColorMaskOptions
import com.xweather.mapsgl.style.ColorScaleOptions
import com.xweather.mapsgl.style.ColorStop
import com.xweather.mapsgl.style.colorScaleRangeForMagnitudeLookup
import com.xweather.mapsgl.style.colorStopsFromOptionsStops
import com.xweather.mapsgl.style.LayerPaint
import com.xweather.mapsgl.style.SampleLayerPaint
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.types.InterpolationMode
import com.xweather.mapsgl.types.RendererSpecification
import com.xweather.mapsgl.types.SampleChannel
import com.xweather.mapsgl.types.SampleExpression
import com.xweather.mapsgl.types.math_type.ValueRange


typealias TileRendererOptions = RendererSpecification

interface EncodedDataRendererOptions : TileRendererOptions {
    var palette: Partial<ColorScaleOptions>
    var channel: SampleChannel //| Array<SampleChannel>
    var interpolation: InterpolationMode
    var smoothing: Double
    var drawRange: Partial<ValueRange>
}

open class EncodedDataRenderer<DataType : TileData, Context : LayerRenderContext<Any>>(
    override var id: String
) : TileLayerRenderer<TileData, LayerRenderContext<Any>>() {

    var TAG = "EncodedDataRenderer"

    private var _timeState: TimeSeriesState = TimeSeriesState(
        position = 0,
        index = 0,
        nextIndex = 0
    )

    private val _colorLookupTables: MutableList<ColorLookupTable> = mutableListOf() //= []
    lateinit var _outputRange: ValueRange
    private lateinit var _dataRange: DataRange
    private lateinit var sampleDataRange: DataRange
    private lateinit var _channel: Array<String>
    private var _debugEnabled = false
    private lateinit var paintStyle: SampleLayerPaint // ColorSampling
    private val paint: Paint = Paint() //TODO: constructor?
    lateinit var colorBandBitmap: Array<Bitmap>//Array<Bitmap>
    var drawHigh = 0f
    var drawLow = 0f

    lateinit var colorLookupTable: ColorLookupTable
    var colorBandTexHandles = IntArray(3)
    var mode = 0

    val channel: Array<String>
        get() = _channel

    val interpolation: InterpolationMode
        get() {
            val mode = (context.paintStyle as SampleStyle).interpolation

            return if ((mode) != null) {
                mode
            } else {
                InterpolationMode.BILINEAR
            }
        }

    val smoothing: Double
        get() = /*context.paintStyle.sampleSmoothing() ?:*/ 0.0

    val progress: Double
        get() = /*layer.animator?.relativePosition ?:*/ 0.0

    val timeState: TimeSeriesState
        get() = _timeState

    val dataRange: ValueRange
        get() = _dataRange.range.copy()


    private val colorLookupTables: MutableList<ColorLookupTable>
        get() = _colorLookupTables

    override fun initialize(context: RenderContext<Any>) {
    }

    init {
        cachesTextures = false
    }

    override fun draw(context: LayerRenderContext<Any>, texUnit: HashMap<String, Int>) {
        TODO("Not yet implemented")
    }

    //override fun draw(texUnit: HashMap<String, HashMap<String, Int>>) {
    //   TODO("Not yet implemented")
    //}

    // override fun onAdd(context: RenderContext<Any>, tileLayer: TileLayer) {
    //     TODO("Not yet implemented")
    // }

    override fun onAdd() {
        TODO("Not yet implemented")
    }

    override fun onAdd(context: RenderContext<Any>, tileLayer: TileLayer, controller: MapboxMapController) {
        TODO("Not yet implemented")
    }

    override fun setNeedsUpdate() {}

    override fun setUpRenderPass(): RenderPass {
        // if(pr.ON)pr.p(TAG,pr.particles, "setupRenderPass() returning encoded or regular render pass")
        return RenderPass(tileLayer?.source!!.id, tileLayer!!.paint)
    }

    override suspend fun update() {
        TODO("Not yet implemented")
    }

    open fun setup(paint: LayerPaint) {
        paintStyle = paint as SampleLayerPaint
        val colorscale = paintStyle.sample.colorScale
        val expression = paintStyle.sample.expression
        val lutRange =
            (colorscale.range

                ?: run {
                    val stops = colorscale.stops.filterIsInstance<ColorStop>()
                    val first = stops.firstOrNull()?.value ?: 0.0
                    val last = stops.lastOrNull()?.value ?: (first + 1.0)
                    first..last
                }).let { colorScaleRangeForMagnitudeLookup(expression, it) }

        val sampleDrawRange = paintStyle.sample.drawRange
        _outputRange = ValueRange(0.0, 255.0, "")
        // sourceMetadata = dataSource.metadata  //.getMetadataForBand(band);

        val tProgram = (program as TriangleProgram)
        val md = (this.tileLayer?.source)?.metadata
        if (md != null) {
            if (md.noData != null) _outputRange.min = md.noData!!.toDouble()
        }

        // JS parity: build the color LUT from colorscale.range (e.g. 0..5 in/hr for precip), not sample drawRange.
        // drawRange only masks sub-threshold pixels in the shader; using it for the LUT drops gray low-rate stops.
        createColorLookupTables(options = colorscale, drawRange = lutRange)

        val channelIndex = paintStyle.sample.channel.firstOrNull()?.rawValue
        val datasetRange =
            channelIndex?.let { tileLayer?.source?.datasets?.get(it)?.dataRange }
                ?: tileLayer?.source?.datasets?.firstOrNull()?.dataRange
                ?: lutRange

        tProgram.updateDataRange(datasetRange.start.toFloat(), datasetRange.endInclusive.toFloat())
        tProgram.updateSampleDataRange(lutRange.start.toFloat(), lutRange.endInclusive.toFloat())

        val masks = colorscale.masks
        if (!masks.isNullOrEmpty()) {
            // JS/Apple masks: one LUT per mask. Android radar padding remaps ptype codes onto R/G/B
            // (value 1→G→slot0, 3→R→slot1, 2→B→slot2); place textures to match sample-multiband.frag.
            val slotBitmaps = arrayOfNulls<Bitmap>(3)
            val maskChannels = FloatArray(3) { -1f }
            val maskValues = FloatArray(3) { -1f }
            colorLookupTables.forEachIndexed { index, lut ->
                val stops = colorStopsFromOptionsStops(
                    masks.getOrNull(index)?.colorscale?.stops?.takeIf { it.isNotEmpty() }
                        ?: colorscale.stops
                )
                if (stops.isEmpty()) return@forEachIndexed
                val slot = colorScaleSlotForMaskValue(lut.maskValue ?: (index + 1))
                slotBitmaps[slot] = lut.createColorLookupBitmap(
                    ColorLookupTable.GPU_COLOR_LUT_WIDTH,
                    1,
                    stops,
                )
                maskChannels[slot] = (lut.maskBand?.rawValue ?: 1).toFloat()
                maskValues[slot] = (lut.maskValue ?: 0).toFloat() / 255f
            }
            val fallbackStops = colorStopsFromOptionsStops(
                masks.firstOrNull()?.colorscale?.stops?.takeIf { it.isNotEmpty() } ?: colorscale.stops
            )
            colorBandBitmap = Array(3) { i ->
                slotBitmaps[i] ?: colorLookupTable.createColorLookupBitmap(
                    ColorLookupTable.GPU_COLOR_LUT_WIDTH,
                    1,
                    fallbackStops.ifEmpty { colorLookupTable.initialStops },
                )
            }
            colorBandTexHandles[0] =
                ColorLookupTable.bitmapToTextureHandle(colorBandBitmap[0], paintStyle.sample.colorScale.interpolate)
            tProgram.uniforms["colorBandTexHandle"] = colorBandTexHandles[0]
            colorBandTexHandles[1] =
                ColorLookupTable.bitmapToTextureHandle(colorBandBitmap[1], paintStyle.sample.colorScale.interpolate)
            tProgram.uniforms["colorBandTexHandle1"] = colorBandTexHandles[1]
            colorBandTexHandles[2] =
                ColorLookupTable.bitmapToTextureHandle(colorBandBitmap[2], paintStyle.sample.colorScale.interpolate)
            tProgram.uniforms["colorBandTexHandle2"] = colorBandTexHandles[2]
            tProgram.setColorMaskUniforms(maskChannels, maskValues)
        } else if (colorscale.stops.isNotEmpty() && colorscale.stops[0] is ColorStop) { //single list
            colorBandBitmap =
                arrayOf(
                    colorLookupTable.createColorLookupBitmap(
                        ColorLookupTable.GPU_COLOR_LUT_WIDTH,
                        1,
                        colorscale.stops as List<ColorStop>,
                    ),
                )
            colorBandTexHandles[0] =
                ColorLookupTable.bitmapToTextureHandle(colorBandBitmap[0], paintStyle.sample.colorScale.interpolate)
            tProgram.uniforms["colorBandTexHandle"] = colorBandTexHandles[0]

        } else if (colorscale.stops.size >= 3) { //multiple list, radar
            colorBandBitmap = arrayOf(
                colorLookupTable.createColorLookupBitmap(
                    ColorLookupTable.GPU_COLOR_LUT_WIDTH,
                    1,
                    colorscale.stops[0] as List<ColorStop>,
                ),
                colorLookupTable.createColorLookupBitmap(
                    ColorLookupTable.GPU_COLOR_LUT_WIDTH,
                    1,
                    colorscale.stops[1] as List<ColorStop>,
                ),
                colorLookupTable.createColorLookupBitmap(
                    ColorLookupTable.GPU_COLOR_LUT_WIDTH,
                    1,
                    colorscale.stops[2] as List<ColorStop>,
                ),
            )

            colorBandTexHandles[0] =
                ColorLookupTable.bitmapToTextureHandle(colorBandBitmap[0], paintStyle.sample.colorScale.interpolate)
            tProgram.uniforms["colorBandTexHandle"] = colorBandTexHandles[0]

            colorBandTexHandles[1] =
                ColorLookupTable.bitmapToTextureHandle(colorBandBitmap[1], paintStyle.sample.colorScale.interpolate)
            tProgram.uniforms["colorBandTexHandle1"] = colorBandTexHandles[1]

            colorBandTexHandles[2] =
                ColorLookupTable.bitmapToTextureHandle(colorBandBitmap[2], paintStyle.sample.colorScale.interpolate)
            tProgram.uniforms["colorBandTexHandle2"] = colorBandTexHandles[2]
        }

        // Map normalized sample value into the LUT window using colorscale.range, not the full stop list
        // (precip_accum stops extend to 30 in/hr but range is 0..5 in/hr — the old initialStops span shrank drawHigh ~0.13).
        val filtered = colorLookupTable.filteredStops
        val lutSpan = (lutRange.endInclusive - lutRange.start).coerceAtLeast(1e-9)
        if (filtered.isEmpty()) {
            drawLow = 0f
            drawHigh = 1f
        } else {
            drawLow = ((filtered.first().value - lutRange.start) / lutSpan).toFloat().coerceIn(0f, 1f)
            drawHigh = ((filtered.last().value - lutRange.start) / lutSpan).toFloat().coerceIn(drawLow + 1e-6f, 1f)
        }


        val channel1 = paintStyle.sample.channel[0].rawValue
        var channel2 = -1

        if (paintStyle.sample.channel.size > 1) {
            channel2 = paintStyle.sample.channel[1].rawValue
        }
        val colorValueDelta = (lutRange.endInclusive - lutRange.start).toFloat()
        val dataDelta = (datasetRange.endInclusive - datasetRange.start).toFloat()
        val colorRangeFactor =
            if (sampleDrawRange != null && colorValueDelta > 0f) {
                dataDelta / colorValueDelta
            } else {
                1f
            }

        tProgram.updateChannels(channel1, channel2) //normal
        tProgram.updateOutputRange((_outputRange.min / 255.0).toFloat(), (_outputRange.max / 255.0).toFloat())
        tProgram.updateColorRangeFactor(colorRangeFactor)
        tProgram.updateColorSampleOffset(paintStyle.sample.offset)
        if (sampleDrawRange != null) {
            // MapsGL JS: drawRange = { ...dataRange, ...paint.drawRange } (wind chill, heat index, precip, etc.)
            tProgram.updateDiscardRange(
                sampleDrawRange.start.toFloat(),
                sampleDrawRange.endInclusive.toFloat(),
            )
        } else {
            tProgram.updateDiscardRange(-1f, -1f)
        }
        tProgram.updateDrawRange(drawLow, drawHigh)
        tProgram.setUniform("mode", mode)
        tProgram.updateMode(mode)
        if (md != null) {
            if (md.noData != null) {
                _outputRange.min = md.noData!!.toDouble()
                //tProgram.updateNoData(md.noData!!.toFloat())
                println("EncodedDataRenderer.setup()  noData: set to md.noData!!.toFloat()")
            }
        }


        mode = 0
    } //end of setup()

    fun createColorLookupTables(options: ColorScaleOptions, drawRange: ClosedRange<Double>) {
        _colorLookupTables.clear()
        val masks = options.masks
        if (!masks.isNullOrEmpty()) {
            // JS EncodedDataRenderer: one ColorLookupTable per mask, channel/value from the mask.
            masks.forEach { mask ->
                val merged = mergeMaskColorScale(options, mask)
                val maskRange = merged.range ?: mask.drawRange ?: drawRange
                val lut = ColorLookupTable(
                    merged.stops,
                    maskRange,
                    interpolate = merged.interpolate,
                    interval = merged.interval,
                    roundDown = options.roundDown,
                )
                lut.maskBand = mask.channel
                lut.maskValue = mask.value
                lut.channel = SampleChannel(mask.channel)
                colorLookupTables.add(lut)
            }
            colorLookupTable = colorLookupTables.first()
        } else {
            colorLookupTable = ColorLookupTable(
                options.stops,
                drawRange,
                interpolate = options.interpolate,
                interval = options.interval,
                roundDown = options.roundDown
            )
            colorLookupTables.add(colorLookupTable)
        }
    }

    companion object {
        /**
         * Maps radar ptype mask codes onto [sample-multiband] texture slots after [padBitmapRadar]
         * remaps value 1→G, 3→R, 2→B (shader: G→colorScale, R→colorScale1, B→colorScale2).
         */
        fun colorScaleSlotForMaskValue(value: Int): Int = when (value) {
            1 -> 0
            3 -> 1
            2 -> 2
            else -> (value - 1).coerceIn(0, 2)
        }

        fun mergeMaskColorScale(parent: ColorScaleOptions, mask: ColorMaskOptions): ColorScaleOptions {
            val cs = mask.colorscale
            val usingMaskStops = cs.stops.isNotEmpty()
            return ColorScaleOptions(
                stops = if (usingMaskStops) cs.stops else parent.stops,
                positions = cs.positions ?: parent.positions,
                interval = if (cs.interval != 0.0) cs.interval else parent.interval,
                range = cs.range ?: mask.drawRange ?: parent.range,
                normalized = if (usingMaskStops) cs.normalized else parent.normalized,
                interpolate = if (usingMaskStops) cs.interpolate else parent.interpolate,
                masks = null,
                roundDown = parent.roundDown,
            )
        }
    }
}
