package com.xweather.mapsgl.renderers

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import com.mapbox.geojson.Feature
import com.xweather.mapsgl.map.mapbox.VectorFillStyleExpressionEval
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.StyleValue
import com.xweather.mapsgl.style.TextPaint
import com.xweather.mapsgl.types.Anchor
import com.xweather.mapsgl.types.AnchorOffset
import com.xweather.mapsgl.types.TextTransform
import com.xweather.mapsgl.util.PlaceLabelText
import com.xweather.mapsgl.weather.groups.DataQuery

/**
 * Resolves [TextPaint] layout for GLES label quads (anchor, offset, size, colors).
 */
internal object VectorTextLayout {

    /** Vertical gap between stacked [TextPaint] lines on the same feature (MapsGL JS newline layout). */
    private const val TEXT_LINE_GAP_PX = 2f

    data class TextPlacement(
        val halfWidthPx: Float,
        val halfHeightPx: Float,
        val centerOffsetXPx: Float,
        val centerOffsetYPx: Float,
        val rotationDeg: Float,
        /**
         * Optional collision footprint. When set (data-query stacks), screen culling uses these
         * instead of [halfWidthPx]/[halfHeightPx] so a live temperature digit changing width/height
         * doesn't resize the box.
         */
        val collisionHalfWidthPx: Float = halfWidthPx,
        val collisionHalfHeightPx: Float = halfHeightPx,
        /** When true, this line never becomes its own collision candidate (see stacked-line KDoc). */
        val excludeFromCollision: Boolean = false,
    )

    /** Tracks which [TextPaint] produced each stacked line, so the value line can be identified. */
    private data class StackedLineEntry(
        val paint: TextPaint,
        val line: VectorTextAtlas.StackedLineKey,
    )

    fun resolveTextInstance(
        textPaint: TextPaint,
        feature: Feature,
        zoom: Double,
        densityMult: Float,
        layerOpacity: Float,
        extraOffsetXPx: Float = 0f,
        extraOffsetYPx: Float = 0f,
        layerId: String? = null,
    ): TextInstance? {
        val raw = resolveTextString(textPaint.value, feature, zoom)?.trim().orEmpty()
        if (raw.isEmpty()) return null
        val display = PlaceLabelText.sanitizeForDisplay(
            applyTransform(raw, textPaint.transform, feature, zoom),
        )
        if (display.isEmpty()) return null
        val fontSizePx =
            resolveFontSizePx(textPaint.size, feature, zoom, densityMult, layerId)
                // Rule: place-label-text-scale-tuning. The old 10px floor left place-city's
                // PLACE_LABEL_SIZE_SCALE-shrunk sizes (all computing below 10) rendering with
                // sub-pixel-width letter strokes — anti-aliasing can't produce a solid fill color
                // when no single pixel is fully "inside" the glyph, reading as a smeared gray
                // regardless of the configured color. 14px gives enough physical resolution for a
                // legible fill.
                .coerceIn(14f, 96f)
        val fontSizePxInt = fontSizePx.toInt()
        val colorArgb =
            VectorSymbolPlacementDefaults.textFillColorOverride(layerId)
                ?: resolveGlyphColorArgb(textPaint.color, feature, zoom)
                ?: return null
        val outlineArgb =
            textPaint.outlineColor?.let { resolveGlyphColorArgb(it, feature, zoom) }
        val bold = VectorSymbolPlacementDefaults.textBoldOverride(layerId)
            ?: resolveBold(textPaint.weight, feature, zoom)
        val outlineWidthScale = VectorSymbolPlacementDefaults.textOutlineWidthScale(layerId)
        val key = VectorTextAtlas.Key(display, fontSizePxInt, colorArgb, outlineArgb, bold, outlineWidthScale)
        val glyph = VectorTextAtlas.ensureGlyph(key) ?: return null
        val anchorName = resolveAnchorName(textPaint.anchor, feature, zoom)
        val anchorFrac = VectorSymbolLayout.anchorFraction(anchorName)
        val (offX, offY) = resolveTextOffsetPx(textPaint.offset, feature, zoom)
        val w = glyph.widthPx.toFloat()
        val h = glyph.heightPx.toFloat()
        val placement =
            TextPlacement(
                halfWidthPx = w * 0.5f,
                halfHeightPx = h * 0.5f,
                centerOffsetXPx = extraOffsetXPx + offX + w * anchorFrac.first,
                centerOffsetYPx = extraOffsetYPx + offY + h * anchorFrac.second,
                rotationDeg = resolveRotationDeg(textPaint.rotation, feature, zoom),
            )
        val tint =
            floatArrayOf(
                1f,
                1f,
                1f,
                layerOpacity * (textPaint.opacity.constantValue ?: 1.0).toFloat(),
            )
        return TextInstance(glyph, placement, tint)
    }

    private data class StackLineLayout(
        val paintIndex: Int,
        val paint: TextPaint,
        val stackedKey: VectorTextAtlas.StackedLineKey,
        val quads: List<VectorTextValueCompose.Quad>,
        val widthPx: Float,
        val heightPx: Float,
    )

    /**
     * Lays out multiple [TextPaint] entries as stacked labels (JS `format` + newline layout).
     *
     * City **names** stay one whole-string glyph (shared across features). Data-query **value**
     * lines (`72°F`, `12mph`, …) are composed from reused digit/unit glyphs
     * ([VectorTextValueCompose]) so timeline playback does not pack one unique atlas entry per
     * formatted value. Collision still uses a stable placeholder footprint
     * ([stableCollisionSizePx]); only the first quad of the stack carries the collision box.
     */
    fun resolveStackedTextInstances(
        textPaints: List<TextPaint>,
        feature: Feature,
        zoom: Double,
        densityMult: Float,
        layerOpacity: Float,
        layerId: String? = null,
    ): List<Pair<Int, TextInstance>> {
        if (textPaints.isEmpty()) return emptyList()
        val extraLabelOffsetYPx = VectorSymbolPlacementDefaults.fireObsNamesExtraTextOffsetYPx(layerId)
        if (textPaints.size == 1) {
            val ti =
                resolveTextInstance(
                    textPaints[0],
                    feature,
                    zoom,
                    densityMult,
                    layerOpacity,
                    extraOffsetYPx = extraLabelOffsetYPx,
                    layerId = layerId,
                ) ?: return emptyList()
            return listOf(0 to ti)
        }

        val outlineWidthScale = VectorSymbolPlacementDefaults.textOutlineWidthScale(layerId)
        val composeValues = DataQuery.isValueTextLayerId(layerId)
        val lines = ArrayList<StackLineLayout>(textPaints.size)
        for ((index, textPaint) in textPaints.withIndex()) {
            val stackedKey = resolveStackedLineKey(textPaint, feature, zoom, densityMult) ?: continue
            val composed =
                if (composeValues && isValueTextPaint(textPaint, feature, zoom)) {
                    VectorTextValueCompose.composeValueLine(
                        stackedKey.text,
                        stackedKey.fontSizePx,
                        stackedKey.colorArgb,
                        stackedKey.outlineArgb,
                        stackedKey.bold,
                        outlineWidthScale,
                    )
                } else {
                    null
                }
            if (composed != null) {
                lines.add(
                    StackLineLayout(
                        index,
                        textPaint,
                        stackedKey,
                        composed.quads,
                        composed.widthPx,
                        composed.heightPx,
                    ),
                )
            } else {
                val key =
                    VectorTextAtlas.Key(
                        stackedKey.text,
                        stackedKey.fontSizePx,
                        stackedKey.colorArgb,
                        stackedKey.outlineArgb,
                        stackedKey.bold,
                        outlineWidthScale,
                    )
                val glyph = VectorTextAtlas.ensureGlyph(key) ?: continue
                lines.add(
                    StackLineLayout(
                        index,
                        textPaint,
                        stackedKey,
                        listOf(VectorTextValueCompose.Quad(glyph, glyph.widthPx * 0.5f)),
                        glyph.widthPx.toFloat(),
                        glyph.heightPx.toFloat(),
                    ),
                )
            }
        }
        if (lines.isEmpty()) return emptyList()

        val gap = VectorSymbolPlacementDefaults.stackedLineGapPxOverride(layerId) ?: TEXT_LINE_GAP_PX
        var contentH = 0f
        var contentW = 0f
        for ((i, line) in lines.withIndex()) {
            if (i > 0) contentH += gap
            contentH += line.heightPx
            contentW = maxOf(contentW, line.widthPx)
        }

        val firstPaint = lines.first().paint
        val anchorName = resolveAnchorName(firstPaint.anchor, feature, zoom)
        val anchorFrac = VectorSymbolLayout.anchorFraction(anchorName)
        val (offX, offY) = resolveTextOffsetPx(firstPaint.offset, feature, zoom)
        val rotation = resolveRotationDeg(firstPaint.rotation, feature, zoom)
        val (collW, collH) =
            stableCollisionSizePx(
                feature,
                lines.map { StackedLineEntry(it.paint, it.stackedKey) },
                zoom,
                gap,
            ) ?: (contentW to contentH)

        val centerLines = VectorSymbolPlacementDefaults.centerStackedLinesHorizontally(layerId)
        val blockOriginX = offX + contentW * anchorFrac.first
        val blockOriginY = offY + contentH * anchorFrac.second + extraLabelOffsetYPx
        var yTop = 0f
        val out = ArrayList<Pair<Int, TextInstance>>(lines.sumOf { it.quads.size })
        var emitted = 0
        for (line in lines) {
            val lineLeft =
                if (centerLines) {
                    blockOriginX - line.widthPx * 0.5f
                } else {
                    blockOriginX - contentW * 0.5f
                }
            for (quad in line.quads) {
                val gw = quad.glyph.widthPx.toFloat()
                val gh = quad.glyph.heightPx.toFloat()
                val centerX = lineLeft + quad.centerFromLineLeftPx
                val centerY = blockOriginY - contentH * 0.5f + yTop + line.heightPx * 0.5f
                val placement =
                    TextPlacement(
                        halfWidthPx = gw * 0.5f,
                        halfHeightPx = gh * 0.5f,
                        centerOffsetXPx = centerX,
                        centerOffsetYPx = centerY,
                        rotationDeg = rotation,
                        collisionHalfWidthPx = if (emitted == 0) collW * 0.5f else 0f,
                        collisionHalfHeightPx = if (emitted == 0) collH * 0.5f else 0f,
                        excludeFromCollision = emitted != 0,
                    )
                val tint =
                    floatArrayOf(
                        1f,
                        1f,
                        1f,
                        layerOpacity * (line.paint.opacity.constantValue ?: 1.0).toFloat(),
                    )
                out.add(line.paintIndex to TextInstance(quad.glyph, placement, tint))
                emitted++
            }
            yTop += line.heightPx + gap
        }
        return out
    }

    private fun resolveStackedLineKey(
        textPaint: TextPaint,
        feature: Feature,
        zoom: Double,
        densityMult: Float,
    ): VectorTextAtlas.StackedLineKey? {
        val raw = resolveTextString(textPaint.value, feature, zoom)?.trim().orEmpty()
        if (raw.isEmpty()) return null
        val display = PlaceLabelText.sanitizeForDisplay(
            applyTransform(raw, textPaint.transform, feature, zoom),
        )
        if (display.isEmpty()) return null
        val fontSizePx =
            resolveFontSizePx(textPaint.size, feature, zoom, densityMult)
                .coerceIn(10f, 96f)
                .toInt()
        val colorArgb =
            resolveGlyphColorArgb(textPaint.color, feature, zoom)
                ?: return null
        val outlineArgb =
            textPaint.outlineColor?.let { resolveGlyphColorArgb(it, feature, zoom) }
        val bold = resolveBold(textPaint.weight, feature, zoom)
        return VectorTextAtlas.StackedLineKey(display, fontSizePx, colorArgb, outlineArgb, bold)
    }

    /**
     * For data-query stacks (`value` + `name` properties), sizes the COLLISION box as if the value
     * line were always a fixed 2-digit placeholder ("90°F"/"90°C") instead of the live glyph size.
     * A temperature's digit count changing during playback (e.g. `9°F` -> `108°F`, or a sign flip
     * to `-5°F`) resized the real glyph, which flipped collision outcomes frame to frame and made
     * cities appear/disappear mid-animation. Only the collision box is held stable — the visible
     * glyph still renders and rasterizes the real value normally.
     */
    private fun stableCollisionSizePx(
        feature: Feature,
        lineEntries: List<StackedLineEntry>,
        zoom: Double,
        gapPx: Float,
    ): Pair<Float, Float>? {
        val hasValue = !feature.getStringProperty("value").isNullOrBlank()
        val hasName = !feature.getStringProperty("name").isNullOrBlank()
        if (!hasValue || !hasName || lineEntries.size < 2) return null
        val stableLines =
            lineEntries.map { entry ->
                if (isValueTextPaint(entry.paint, feature, zoom)) {
                    entry.line.copy(text = stableValuePlaceholder(entry.line.text))
                } else {
                    entry.line
                }
            }
        val measured = VectorTextAtlas.measureMultiLineSizePx(stableLines, gapPx) ?: return null
        return measured.first.toFloat() to measured.second.toFloat()
    }

    private fun isValueTextPaint(textPaint: TextPaint, feature: Feature, zoom: Double): Boolean {
        val resolved = resolveTextString(textPaint.value, feature, zoom) ?: return false
        val published = feature.getStringProperty("value") ?: return false
        return resolved == published
    }

    private fun stableValuePlaceholder(sample: String): String {
        val unit =
            when {
                sample.endsWith("°F") -> "°F"
                sample.endsWith("°C") -> "°C"
                sample.endsWith("K") -> "K"
                else -> "°F"
            }
        return "90$unit"
    }

    data class TextInstance(
        val glyph: VectorTextAtlas.Glyph,
        val placement: TextPlacement,
        val tintRgba: FloatArray,
    )

    private fun resolveTextString(
        value: StyleValue<String>,
        feature: Feature,
        zoom: Double,
    ): String? =
        when (value) {
            is StyleValue.Constant -> value.constantValue
            is StyleValue.Expression ->
                VectorFillStyleExpressionEval.evaluateString(value.expression, feature, zoom)
                    ?: VectorFillStyleExpressionEval.evaluateMatchString(value.expression, feature)
        }

    private fun applyTransform(
        text: String,
        transform: StyleValue<TextTransform>,
        feature: Feature,
        zoom: Double,
    ): String {
        val mode =
            when (transform) {
                is StyleValue.Constant -> transform.constantValue ?: TextTransform.NONE
                is StyleValue.Expression -> TextTransform.NONE
            }
        return when (mode) {
            TextTransform.UPPERCASE -> text.uppercase()
            TextTransform.LOWERCASE -> text.lowercase()
            TextTransform.CAPITALIZE -> text.split(' ').joinToString(" ") { word ->
                word.replaceFirstChar { ch ->
                    if (ch.isLowerCase()) ch.titlecase() else ch.toString()
                }
            }
            TextTransform.NONE -> text
        }
    }

    private fun resolveFontSizePx(
        size: StyleValue<Double>?,
        feature: Feature,
        zoom: Double,
        densityMult: Float,
        layerId: String? = null,
    ): Float {
        val base =
            VectorSymbolPlacementDefaults.textFontSizePxOverride(layerId, feature, zoom)?.toDouble()
                ?: when (size) {
                    null -> 12.0
                    is StyleValue.Constant -> size.constantValue ?: 12.0
                    is StyleValue.Expression ->
                        VectorFillStyleExpressionEval.evaluateNumber(size.expression, feature, zoom) ?: 12.0
                }
        return (base * densityMult.coerceAtLeast(1e-3f) * VECTOR_SYMBOL_GL_PIXEL_SCALE).toFloat()
    }

    /** Opaque atlas colors; layer/text opacity is applied at draw time via instance alpha. */
    private fun resolveGlyphColorArgb(
        color: StyleValue<Color>,
        feature: Feature,
        zoom: Double,
    ): Int? {
        val c =
            when (color) {
                is StyleValue.Constant -> color.constantValue
                is StyleValue.Expression ->
                    VectorFillStyleExpressionEval.evaluateFillRgba(color.expression, feature, zoom)?.let { rgba ->
                        Color(rgba[0], rgba[1], rgba[2], rgba[3])
                    }
            } ?: return null
        return c.copy(alpha = 1f).toArgb()
    }

    private fun resolveBold(
        weight: StyleValue<String>?,
        feature: Feature,
        zoom: Double,
    ): Boolean {
        if (weight == null) return false
        val w =
            when (weight) {
                is StyleValue.Constant -> weight.constantValue
                is StyleValue.Expression ->
                    VectorFillStyleExpressionEval.evaluateString(weight.expression, feature)
            }
        return w.equals("bold", ignoreCase = true)
    }

    private fun resolveAnchorName(
        anchor: StyleValue<Anchor>,
        feature: Feature,
        zoom: Double,
    ): String =
        when (anchor) {
            is StyleValue.Constant -> anchor.constantValue?.value ?: "center"
            is StyleValue.Expression ->
                VectorFillStyleExpressionEval.evaluateString(anchor.expression, feature) ?: "center"
        }

  private fun resolveTextOffsetPx(
        offset: StyleValue<AnchorOffset>,
        feature: Feature,
        zoom: Double,
    ): Pair<Float, Float> =
        when (offset) {
            is StyleValue.Constant -> {
                val o = offset.constantValue ?: AnchorOffset()
                o.x.toFloat() to o.y.toFloat()
            }
            is StyleValue.Expression -> evaluateOffsetExpression(offset.expression, feature, zoom) ?: (0f to 0f)
        }

    private fun evaluateOffsetExpression(
        expr: Expression,
        feature: Feature,
        zoom: Double,
    ): Pair<Float, Float>? {
        val raw = expr.raw
        if (raw is List<*>) {
            return when (raw[0] as? String) {
                "literal" -> tokenToOffsetPair(raw.getOrNull(1))
                "step" -> evaluateStepOffsetPair(raw, feature, zoom)
                else -> null
            }
        }
        return null
    }

    private fun evaluateStepOffsetPair(
        list: List<*>,
        feature: Feature,
        zoom: Double,
    ): Pair<Float, Float>? {
        if (list.size < 4) return null
        val input =
            if (list[1] is List<*> && (list[1] as List<*>).firstOrNull() == "zoom") {
                zoom
            } else {
                val stepInput = list[1] ?: return null
                @Suppress("UNCHECKED_CAST")
                VectorFillStyleExpressionEval.evaluateNumber(
                    Expression(stepInput as List<Any>),
                    feature,
                    zoom,
                )
            } ?: return null
        var result = tokenToOffsetPair(list[2]) ?: return null
        var i = 3
        while (i + 1 < list.size) {
            val thr = (list[i] as? Number)?.toDouble() ?: return null
            if (input >= thr) {
                result = tokenToOffsetPair(list[i + 1]) ?: result
            }
            i += 2
        }
        return result
    }

    private fun tokenToOffsetPair(token: Any?): Pair<Float, Float>? {
        return when (token) {
            is List<*> -> {
                if (token.size < 2) return null
                val x = token[0].asNumber() ?: return null
                val y = token[1].asNumber() ?: return null
                x.toFloat() to y.toFloat()
            }
            is Number -> token.toDouble().toFloat() to 0f
            else -> null
        }
    }

    private fun Any?.asNumber(): Double? =
        when (this) {
            is Number -> toDouble()
            is String -> toDoubleOrNull()
            else -> null
        }

    private fun resolveRotationDeg(
        rotation: StyleValue<Double>,
        feature: Feature,
        zoom: Double,
    ): Float =
        when (rotation) {
            is StyleValue.Constant -> (rotation.constantValue ?: 0.0).toFloat()
            is StyleValue.Expression ->
                VectorFillStyleExpressionEval.evaluateNumber(rotation.expression, feature, zoom)?.toFloat() ?: 0f
        }
}
