package com.xweather.mapsgl.util

import android.util.Log
import com.xweather.mapsglmaps.BuildConfig

/**
 * Internal debug logging for MapsGL. When [enabled] is false (release AAR), R8 removes the call
 * bodies so println / Log traffic does not run in production builds.
 */
internal object MapsGLDebug {
    @JvmField
    val enabled: Boolean = BuildConfig.DEBUG

    @JvmStatic
    fun trace(message: String) {
        if (enabled) {
            System.out.println(message)
        }
    }

    @JvmStatic
    fun logD(tag: String, message: String) {
        if (enabled) {
            Log.d(tag, message)
        }
    }

    @JvmStatic
    fun logI(tag: String, message: String) {
        if (enabled) {
            Log.i(tag, message)
        }
    }

    @JvmStatic
    fun logW(tag: String, message: String, throwable: Throwable? = null) {
        if (enabled) {
            if (throwable != null) Log.w(tag, message, throwable)
            else Log.w(tag, message)
        }
    }

    @JvmStatic
    fun logE(tag: String, message: String, throwable: Throwable? = null) {
        if (enabled) {
            if (throwable != null) Log.e(tag, message, throwable)
            else Log.e(tag, message)
        }
    }
}
