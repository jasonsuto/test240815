//
//  Radar.kt
//
//  NOTE: This file is auto-generated and should not be edited directly!
//  Last updated: 2026-08-19T17:54:07.087Z
//

package com.xweather.mapsgl.weather.groups

import com.xweather.mapsgl.controls.legend.Legend
import com.xweather.mapsgl.layers.spec.SampleLayerDescriptor
import com.xweather.mapsgl.sources.source.spec.EncodedSourceDescriptor
import com.xweather.mapsgl.style.ColorScaleOptions
import com.xweather.mapsgl.style.SampleLayerPaint
import com.xweather.mapsgl.style.SamplePaint
import com.xweather.mapsgl.types.ColorBand
import com.xweather.mapsgl.types.DataQuality
import com.xweather.mapsgl.types.InterpolationMode
import com.xweather.mapsgl.weather.BaseEncodedConfiguration
import com.xweather.mapsgl.weather.ColorScales
import com.xweather.mapsgl.weather.LayerCode
import com.xweather.mapsgl.weather.LegendCode
import com.xweather.mapsgl.weather.WeatherService
import com.xweather.mapsgl.weather.WeatherSource
import com.xweather.mapsgl.weather.common.PresentationType
import com.xweather.mapsgl.weather.common.presentations

object Radar {
    class Radar(val service: WeatherService) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.RADAR
        override val source: EncodedSourceDescriptor = WeatherSource.radar_REFC_PTYPESMPL_REFC_ARCHIVE(service)
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "conditions.radar.fill",
            source.id,
            quality = DataQuality.exact,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.red),
                    interpolation = InterpolationMode.BICUBIC,
                    colorScale = ColorScaleOptions(
                        stops = listOf(
                            ColorScales.radarRain.stops,


                            ColorScales.radarSnow.stops,


                            ColorScales.radarMix.stops
                        )
                    )
                )
            )
        )
        override var presentation = presentations[PresentationType.RADAR]?.setTitle("Radar")
        override var legend: Legend? = null


        init {
            legend = LegendCode.RADAR.getLegend()
        }

    }
}