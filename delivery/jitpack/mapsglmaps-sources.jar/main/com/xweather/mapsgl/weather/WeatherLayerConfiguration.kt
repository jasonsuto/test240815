package com.xweather.mapsgl.weather

import android.util.Log
import androidx.compose.ui.graphics.toArgb
import com.xweather.mapsgl.controls.legend.Legend
import com.xweather.mapsgl.controls.legend.Point.PointLegend
import com.xweather.mapsgl.controls.legend.bar.BarLegend
import com.xweather.mapsgl.extensions.Dimension
import com.xweather.mapsgl.layers.spec.CircleLayerDescriptor
import com.xweather.mapsgl.layers.spec.FillLayerDescriptor
import com.xweather.mapsgl.layers.spec.GridLayerDescriptor
import com.xweather.mapsgl.layers.spec.LayerDescriptor
import com.xweather.mapsgl.layers.spec.LayerEventEmitter
import com.xweather.mapsgl.layers.spec.ParticleLayerDescriptor
import com.xweather.mapsgl.layers.spec.RasterLayerDescriptor
import com.xweather.mapsgl.layers.spec.SampleLayerDescriptor
import com.xweather.mapsgl.sources.source.spec.EncodedSourceDescriptor
import com.xweather.mapsgl.sources.source.spec.ImageSourceDescriptor
import com.xweather.mapsgl.sources.source.spec.SourceDescriptor
import com.xweather.mapsgl.sources.source.spec.VectorSourceDescriptor
import com.xweather.mapsgl.util.MapsGLDebug
import com.xweather.mapsgl.style.ColorStop
import com.xweather.mapsgl.style.FillPaint
import com.xweather.mapsgl.style.StyleValue
import com.xweather.mapsgl.weather.common.Presentation


/**
 * Marker for all weather configuration entries exposed by [WeatherService].
 *
 * Every weather configuration has a stable [LayerCode] that is used to discover and register products.
 */
interface WeatherConfiguration {
    val code: LayerCode
}

/**
 * Typed weather-layer configuration pairing one data [source] with one render [layer].
 *
 * This is the core model returned by grouped weather APIs (for example in [LayerCodes]): each product
 * contributes a source descriptor and a layer descriptor that [com.xweather.mapsgl.map.MapController]
 * can register with `addSource` / `addLayer` / `addWeatherLayer`.
 *
 * The generic parameters keep configuration strongly typed:
 * - [S] is the concrete [SourceDescriptor] type (encoded grid, vector, GeoJSON, and so on).
 * - [L] is the concrete [LayerDescriptor] type (sample, particles, line, fill, etc.).
 *
 * Optional UI metadata can be attached through [presentation] and [legend].
 *
 * @param S Source descriptor type used by the weather layer.
 * @param L Layer descriptor type used to render that source.
 *
 * @property source Source definition for tile/data fetching.
 * @property layer Layer definition for style/render behavior.
 * @property presentation Optional product presentation metadata (labels, units, grouping UI).
 * @property legend Optional legend model synchronized with paint updates when supported by the concrete
 *   configuration implementation.
 *
 * @see com.xweather.mapsgl.map.MapController.addSource
 * @see com.xweather.mapsgl.map.MapController.addLayer
 * @see com.xweather.mapsgl.map.MapController.addWeatherLayer
 * @see LayerCodes
 */
interface WeatherLayerConfiguration<
        S : SourceDescriptor,       // The type of the source
        L : LayerDescriptor<*>,      // The type of the LayerDescriptor
        > : WeatherConfiguration {
    val source: S
    val layer: L // layer is of type L, and L guarantees its 'paint' property is of type P

    /**
     * An optional presentation object for this layer.
     * The default implementation is `null`.
     * Classes that have a presentation should override this property.
     */
    var presentation: Presentation?
    var legend: Legend?

}


/** Shorthand for encoded-grid sample products (temperature, radar, …). */
typealias SampleConfiguration = WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor>

/** Shorthand for image/raster products (satellite geocolor, visible, …) with [RasterLayerDescriptor.maskLayerIds]. */
typealias RasterConfiguration = WeatherLayerConfiguration<ImageSourceDescriptor, RasterLayerDescriptor>

/** Shorthand for vector-backed circle layers (e.g. point observations). */
typealias VCircleConfiguration = WeatherLayerConfiguration<VectorSourceDescriptor, CircleLayerDescriptor>

/**
 * Weather product that expands to **multiple** [WeatherLayerConfiguration] layers (stacked fills, icons, labels).
 *
 * Use with APIs that accept composites (for example grouped products under `com.xweather.mapsgl.weather.groups`)
 * so the app adds every
 * sub-layer in [layers] for a single logical product.
 *
 * @property layers Child configurations, each with its own source + descriptor + optional legend.
 */
interface CompositeWeatherLayerConfiguration : WeatherConfiguration {
    val layers: List<WeatherLayerConfiguration<*, *>>
}

/**
 * Modified BaseEncodedConfiguration to support both Sample and Particle layers.
 * It uses a generic L constrained to LayerDescriptor to handle both types.
 */
abstract class BaseEncodedConfiguration<L : LayerDescriptor<*>> :
    WeatherLayerConfiguration<EncodedSourceDescriptor, L> {
    private var isSyncing = false

    override var legend: Legend? = null
        set(value) {
            val oldValue = field
            field = value

            // Only start syncing if we aren't already in the middle of a sync
            if (!isSyncing && value != null && value != oldValue /*&& oldValue != null*/) {
                //println(">>> WeatherService LEGEND OVERRIDE STARTSYNCING")
                startSyncing()
            }
        }

    private fun startSyncing() {
        try {
            // 1. Link the emitter

            val sample = when (val l = layer) {
                is SampleLayerDescriptor -> l.paint.sample
                is ParticleLayerDescriptor -> l.paint.sample
                is GridLayerDescriptor -> l.paint.sample
                else -> null
            }

            sample?.eventEmitter = layer
            0
            // 2. Setup listener (ensure we only have one)
            layer.off("PAINT_CHANGE")
            layer.on("PAINT_CHANGE") {
                //println(">>> WeatherService: trigger detected, calling performSync()")
                performSync()
            }
            //println(">>> WeatherService: initial calling performSync()")
            // performSync()
        } catch (e: Exception) {
            Log.e("BaseEncodedConfig", "Sync failed: ${e.message}")
        }
    }

    private fun performSync() {
        MapsGLDebug.trace(">>> WeatherService: performSync() entered")
        val sample = when (val l = layer) {
            is SampleLayerDescriptor -> l.paint.sample
            is ParticleLayerDescriptor -> l.paint.sample
            is GridLayerDescriptor -> l.paint.sample
            else -> null
        }

        if (sample == null) return

        val currentScale = sample.colorScale
        if (legend is BarLegend<*>) {
            val currentLegend = legend as? BarLegend<Dimension> ?: return
            isSyncing = true
            try {
                val updatedLegend = currentLegend.copy(
                    items = currentLegend.items.map { item ->
                        item.copy(
                            colorScaleOptions = item.colorScaleOptions.copy(
                                stops = currentScale.stops,
                                positions = currentScale.positions,
                                interval = currentScale.interval,
                                range = currentScale.range ?: item.colorScaleOptions.range,
                                normalized = currentScale.normalized,
                                interpolate = currentScale.interpolate,
                                masks = currentScale.masks
                            )
                        )
                    }
                )
                this.legend = updatedLegend
            } finally {
                isSyncing = false
            }
        } else if (legend is PointLegend) {
            //println(">>> WeatherService performSync Entered, detected point legend!!!")
            val currentLegend = legend as? PointLegend ?: return
            isSyncing = true

            try {
                val currentStops = (currentScale.stops as List<ColorStop>)
                /* for (stop in currentScale.stops) {
                    println(">>> WeatherService currentScale stop: ${stop}")
                }
                for ((i, item) in currentLegend.items.withIndex()) {
                    println(">>> WeatherService legend item:: ${item.color}")
                } */
                for ((i, item) in currentLegend.items.withIndex()) {
                    if (currentStops.size > i) {
                        item.color = currentStops[i].color.toArgb()
                    }
                }
            } finally {
                isSyncing = false
            }
        }
    }
}

// --- Implementation Examples ---

/**
 * Example of a Sample implementation
 */
//abstract class BaseSampleConfiguration : BaseEncodedConfiguration<SampleLayerDescriptor>()

/**
 * Example of a Particle implementation
 */
//abstract class BaseParticleConfiguration : BaseEncodedConfiguration<ParticleLayerDescriptor>()


abstract class BaseVectorConfiguration<S : SourceDescriptor, L : LayerDescriptor<*>> : WeatherLayerConfiguration<S, L> {
    private var isSyncing = false

    override var legend: Legend? = null
        set(value) {
            val oldValue = field
            field = value

            if (!isSyncing && value != null && value != oldValue) {
                startSyncing()
            }
        }

    private fun startSyncing() {
        try {
            // Use a helper to get the paint object regardless of descriptor type
            val paintInstance = getFillPaint()

            // Assign the emitter so changes to paint trigger performSync
            (paintInstance as? FillPaint)?.eventEmitter = layer

            val emitter = layer as? LayerEventEmitter ?: return
            emitter.off("PAINT_CHANGE")
            emitter.on("PAINT_CHANGE") {
                performSync()
            }

            performSync()
        } catch (e: Exception) {
            Log.e("BaseVectorConfig", "Sync failed: ${e.message}")
        }
    }

    /**
     * Helper to extract the color-bearing paint object from different descriptor types
     */
    private fun getFillPaint(): Any? {
        return when (val l = layer) {
            is CircleLayerDescriptor -> l.paint.fill
            is FillLayerDescriptor -> l.paint.fill
            else -> null
        }
    }

    /**
     * Rebuilds [PointLegend] swatches from the layer's fill color (constant or match/case expression).
     * Called when fill paint changes and when a legend is registered on the map.
     */
    fun syncPointLegendFromFillPaint() {
        val currentLegend = legend as? PointLegend ?: return
        val paint = getFillPaint()
        val fillColorValue = (paint as? FillPaint)?.color ?: return
        val updatedItems = pointLegendItemsAlignedWithFill(currentLegend.items, fillColorValue) ?: return
        val unchanged = updatedItems.size == currentLegend.items.size &&
            updatedItems.zip(currentLegend.items).all { (a, b) -> a.color == b.color && a.label == b.label }
        if (unchanged) return
        isSyncing = true
        try {
            legend = currentLegend.copy(items = updatedItems)
        } finally {
            isSyncing = false
        }
    }

    private fun performSync() {
        syncPointLegendFromFillPaint()
    }
}

/** Maps categorical fill paint to [PointLegendItem] colors for legend display. */
internal fun pointLegendItemsAlignedWithFill(
    templateItems: List<com.xweather.mapsgl.controls.legend.Point.PointLegendItem>,
    fillColorValue: StyleValue<androidx.compose.ui.graphics.Color>,
): List<com.xweather.mapsgl.controls.legend.Point.PointLegendItem>? {
    return when (fillColorValue) {
        is StyleValue.Constant -> {
            val colorInt = fillColorValue.value.toArgb()
            templateItems.map { it.copy(color = colorInt) }
        }

        is StyleValue.Expression -> {
            val expressionList = fillColorValue.expression.toJSONObject() as? List<*> ?: return null
            if (expressionList.isEmpty()) return null
            val operator = expressionList[0].toString()
            val startIndex = when (operator) {
                "match" -> 3
                "case" -> 2
                else -> return null
            }
            val colorMappings = mutableListOf<Pair<String, Int>>()
            for (i in startIndex until expressionList.size step 2) {
                if (i >= expressionList.size) break
                val conditionRaw = expressionList.getOrNull(i - 1)?.toString() ?: continue
                val colorInt = parseColorFromExpression(expressionList.getOrNull(i)) ?: continue
                val cleanLabel = conditionRaw
                    .replace(Regex("""[\[\]"']"""), "")
                    .replace("==", "")
                    .replace("get, type", "")
                    .replace("report.type", "")
                    .replace(",", "")
                    .trim()
                if (cleanLabel.isNotEmpty()) {
                    colorMappings.add(cleanLabel to colorInt)
                }
            }
            val fallbackColor = parseColorFromExpression(expressionList.last())
            templateItems.map { item ->
                val matched = colorMappings.find { (label, _) ->
                    label.equals(item.label, ignoreCase = true) ||
                        label.contains(item.label, ignoreCase = true) ||
                        item.label.contains(label, ignoreCase = true)
                }
                val color = when {
                    matched != null -> matched.second
                    item.label.equals("Active", ignoreCase = true) ||
                        item.label.equals("Other", ignoreCase = true) ||
                        item.label.equals("Default", ignoreCase = true) ->
                        fallbackColor ?: item.color
                    else -> item.color
                }
                item.copy(color = color)
            }
        }

        else -> null
    }
}

private fun parseColorFromExpression(obj: Any?): Int? {
    val colorStr = obj?.toString() ?: return null

    return try {
        if (colorStr.startsWith("rgba")) {
            // Parses "rgba(111,179,20,1.0)"
            val parts = colorStr.removePrefix("rgba(").removeSuffix(")").split(",")
            val r = parts[0].trim().toInt()
            val g = parts[1].trim().toInt()
            val b = parts[2].trim().toInt()
            val a = (parts[3].trim().toFloat() * 255).toInt()
            android.graphics.Color.argb(a, r, g, b)
        } else if (colorStr.startsWith("#")) {
            android.graphics.Color.parseColor(colorStr)
        } else {
            null
        }
    } catch (e: Exception) {
        null
    }
}

