package com.xweather.mapsgl.weather

/**
 * iOS `WeatherService.LayerCode.mapTimeExempt` / `ignoresMapTimeFilter` parity.
 *
 * Position markers may declare `timestamp <= map-time` in JS/iOS configs so the expression
 * machinery stays consistent, but the current storm location must stay visible for the
 * whole timeline — so [com.xweather.mapsgl.map.MapController.addWeatherLayer] strips the
 * playhead half for these codes (keeping any static clauses).
 *
 * Kept outside generated [LayerCodes] so codegen can refresh without losing this behavior.
 */
val LayerCode.ignoresMapTimeFilter: Boolean
    get() = MAP_TIME_EXEMPT.contains(this)

private val MAP_TIME_EXEMPT: Set<LayerCode> = setOf(
    LayerCode.TROPICAL_CYCLONES_POSITIONS,
    LayerCode.TROPICAL_CYCLONES_POSITION_ICONS,
    LayerCode.TROPICAL_CYCLONES_POSITIONS_INVESTS,
    LayerCode.TROPICAL_CYCLONES_POSITION_ICONS_INVESTS,
    // JS tropical name layers never scrub with map-time (same as live positions).
    LayerCode.TROPICAL_CYCLONES_NAMES,
    LayerCode.TROPICAL_CYCLONES_NAMES_ARCHIVE,
    LayerCode.TROPICAL_CYCLONES_NAMES_INVESTS,
)
