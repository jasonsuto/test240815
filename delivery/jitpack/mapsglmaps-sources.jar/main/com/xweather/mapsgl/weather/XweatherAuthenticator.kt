package com.xweather.mapsgl.weather

import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.xweather.mapsgl.config.weather.account.XweatherAccount
import com.xweather.mapsgl.events.AuthenticatorEvents
import com.xweather.mapsgl.events.EventDispatcher
import com.xweather.mapsgl.events.EventSource
import com.xweather.mapsgl.events.trigger
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.map.MapController
import com.xweather.mapsgl.network.Urls.Companion.mapsGLServer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.time.ZonedDateTime
import java.util.Base64
import java.util.Date

const val TAG = "Authenticator"

enum class AuthenticatorError(val description: String) {
    /** Client id/secret rejected by the token endpoint. */
    InvalidCredentials("Invalid access token credentials provided"),
    /** Returned token could not be used. */
    InvalidAuthToken("Invalid authentication token"),
    /** Token request URL is missing or malformed. */
    InvalidTokenRequestURL(
        "Invalid token request url provided"
    )
}

/** Thrown when [XweatherAuthenticator] cannot obtain a usable token. */
class AuthenticatorException(val error: AuthenticatorError) : Throwable(error.description)

/**
 * Signs MapsGL / AMP HTTP requests with [XweatherAccount] credentials.
 */
interface Authenticator {
    val headers: Map<String, String>
    suspend fun authenticate(): Map<String, String>
}

/**
 * Cached access token plus expiry, parsed from the Xweather token response.
 */
data class AccessToken(
    var accessToken: String, val expires: Date, val tokenType: String
) {
    companion object {
        //todo: Create serializer?

        private val gson: Gson = GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSS").create()

        fun fromResponse(tokenData: String): AccessToken {
            val tokenMap = gson.fromJson(tokenData, Map::class.java)
            if(pr.ON) pr.p(TAG, pr.keepAlive,"fromResponse() tokenMap: $tokenMap")
            return AccessToken(
                tokenMap["access_token"] as String,
                SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSS").parse(tokenMap["expires"] as String)!!,
                tokenMap["token_type"] as String
            )
        }

        fun fromKeys(id: String, secret: String): AccessToken {
            return AccessToken(
                "${id}_${secret}", Date("55"),
                //SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSS")
                "secret"
            )
        }
    }
}
/**
 * Request authenticator used by [WeatherService] and source descriptors.
 *
 * Builds signed headers / query params from [account]. Hosts typically use the instance on
 * [WeatherService.authenticator] rather than constructing this type directly.
 *
 * @param account Client credentials.
 * @param server Token / API host (defaults to the MapsGL production server).
 */
class XweatherAuthenticator(
    private val account: XweatherAccount, private val server: URL
) : Authenticator, EventSource {

    override val eventDispatcher = EventDispatcher()
        get() {
            return field
        }

    var credentials: AccessToken? = null
    override val headers: Map<String, String>
        get() = credentials?.let { mapOf("Authorization" to "Bearer ${it.accessToken}") } ?: emptyMap()

    private var isLoading: Boolean = false
    private var authorizingJob: Job? = null

    val isSessionValid: Boolean
        get() = credentials?.let {

            val timeZoneOffsetMillis = ZonedDateTime.now().offset.totalSeconds.toDouble() * 1000
            val minutesLeft = ((credentials?.expires!!.time + timeZoneOffsetMillis) - System.currentTimeMillis()) / (1000 * 60)
            it.accessToken.isNotEmpty() && minutesLeft > 0.0

        } ?: false

    override suspend fun authenticate(): Map<String, String> {
        fetchAccessToken()
        return headers
    }

    private suspend fun fetchAccessToken(dateValidated: Boolean = false) {

        //if(pr.ON) pr.p(TAG, pr.keepAlive, "fetchAccessToken() date: ${Date(Date().time+(3600000 * 4))}")
        if(dateValidated){
            if(!credentials?.accessToken?.isEmpty()!!)  return
        } else{
            if (isSessionValid) return
        }


        return withContext(Dispatchers.IO) {
            val grantType = "client_credentials"
            val url = URL("$mapsGLServer/auth/token")
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "POST"
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            connection.setRequestProperty(
                "Authorization",
                "Basic " + Base64.getEncoder().encodeToString("${account.id}:${account.secret}".toByteArray())
            )
            if(MapController.packageName!=null){
                if(pr.ON) pr.p(TAG, pr.bundleID, "fetchAccessToken() packageName: ${MapController.packageName}")
                //connection.setRequestProperty("Referer", MapController.packageName)
                //connection.setRequestProperty("Referer", "com.wrongcompany.wrongproject")
            }

            connection.doOutput = true
            val postData = "grant_type=$grantType".toByteArray()

            try {
                connection.outputStream.write(postData)
                val responseCode = connection.responseCode

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    val reader = connection.inputStream.bufferedReader()
                    val tokenData = reader.readText()
                    credentials = AccessToken.fromResponse(tokenData)
                    if(pr.ON) pr.p(TAG, pr.keepAlive, "fetchAccessToken() OK")
                } else {
                    if(pr.ON) pr.p(TAG, pr.keepAlive, "fetchAccessToken() NOT OK")

                }

                if (!isSessionValid) {
                    if(pr.ON) pr.p(TAG, pr.keepAlive, "fetchAccessToken() NOT OK ===============",2 )
                    throw AuthenticatorException(AuthenticatorError.InvalidAuthToken)
                }

                trigger(AuthenticatorEvents.Token(token = credentials!!))
                isLoading = false
            } catch (e: Exception) {
                if(pr.ON) pr.p(TAG, pr.keepAlive, "fetchAccessToken() EXCEPTION: $e",2 )
                //if(pr.ON) pr.p(TAG, pr.dl,"fetchAccessToken() exception getting metadata:$e")
            }
        }
    }

    /**
     * Template variables merged into tile / metadata URLs by [com.xweather.mapsgl.utils.replaceVars].
     * Use `{accessKey}` (id + `_` + secret), `{clientId}`, or `{clientSecret}` in URL strings when the source
     * sets [com.xweather.mapsgl.sources.source.spec.VectorSourceDescriptor.authenticator] (or other descriptors
     * that carry the same authenticator).
     */
    fun appendTileCredentialVariables(target: MutableMap<String, Any>) {
        target["accessKey"] = "${account.id}_${account.secret}"
        target["clientId"] = account.id
        target["clientSecret"] = account.secret
    }
}