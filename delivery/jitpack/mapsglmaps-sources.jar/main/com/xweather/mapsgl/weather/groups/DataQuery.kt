package com.xweather.mapsgl.weather.groups

import com.xweather.mapsgl.layers.spec.DataQueryLayerDescriptor
import com.xweather.mapsgl.sources.source.spec.VectorSourceDescriptor
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.StyleValue
import com.xweather.mapsgl.style.SymbolLayerPaint
import com.xweather.mapsgl.style.SymbolRank
import com.xweather.mapsgl.style.SymbolRankDirection
import com.xweather.mapsgl.style.TextPaint
import com.xweather.mapsgl.types.Anchor
import com.xweather.mapsgl.types.AnchorOffset
import com.xweather.mapsgl.weather.BaseVectorConfiguration
import com.xweather.mapsgl.weather.LayerCode
import com.xweather.mapsgl.weather.WeatherService
import com.xweather.mapsgl.weather.WeatherSource
import com.xweather.mapsgl.weather.common.Presentation
import com.xweather.mapsgl.weather.toColor

/**
 * Hand-configured data-query (`*-text`) layers: sample an encoded weather product at OSM
 * city/town points and publish value + name labels.
 *
 * Matches the iOS/JS catalog of ~30 built-in query text layers (conditions + air quality).
 * Excluded (same as iOS): waterways-text; accum / min / max variants.
 * Skipped here until Android has the sample products: ice-text, sleet-text.
 */
object DataQuery {

    /**
     * One catalog entry: public [code] samples [sampled] at place points.
     * @property group Style-id prefix (`conditions` or `airquality`).
     */
    data class Spec(
        val code: LayerCode,
        val sampled: LayerCode,
        val group: String = "conditions",
    ) {
        val layerId: String
            get() = "$group.${code.value.replace('-', '_')}.symbol"
    }

    /**
     * Full Android data-query catalog (sampled layer must already exist as a [LayerCode]).
     * Order matches typical conditions → air-quality listing.
     */
    val CATALOG: List<Spec> = listOf(
        // Conditions
        Spec(LayerCode.TEMPERATURES_TEXT, LayerCode.TEMPERATURES),
        Spec(LayerCode.TEMPERATURES_24_HOUR_CHANGE_TEXT, LayerCode.TEMPERATURES_24_HOUR_CHANGE),
        Spec(LayerCode.FEELS_LIKE_TEXT, LayerCode.FEELS_LIKE),
        Spec(LayerCode.DEW_POINTS_TEXT, LayerCode.DEW_POINTS),
        Spec(LayerCode.HUMIDITY_TEXT, LayerCode.HUMIDITY),
        Spec(LayerCode.PRESSURE_MSL_TEXT, LayerCode.PRESSURE_MEAN_SEA_LEVEL),
        Spec(LayerCode.WIND_SPEEDS_TEXT, LayerCode.WIND_SPEEDS),
        Spec(LayerCode.WIND_GUSTS_TEXT, LayerCode.WIND_GUSTS),
        Spec(LayerCode.WIND_CHILL_TEXT, LayerCode.WIND_CHILL),
        Spec(LayerCode.HEAT_INDEX_TEXT, LayerCode.HEAT_INDEX),
        Spec(LayerCode.PRECIP_TEXT, LayerCode.PRECIPITATION),
        Spec(LayerCode.SNOW_TEXT, LayerCode.SNOW),
        Spec(LayerCode.VISIBILITY_TEXT, LayerCode.VISIBILITY),
        Spec(LayerCode.UVI_TEXT, LayerCode.ULTRAVIOLET_INDEX),
        // Air quality
        Spec(LayerCode.AIR_QUALITY_CO_TEXT, LayerCode.CARBON_MONOXIDE, group = "airquality"),
        Spec(LayerCode.AIR_QUALITY_NO_TEXT, LayerCode.NITRIC_OXIDE, group = "airquality"),
        Spec(LayerCode.AIR_QUALITY_NO2_TEXT, LayerCode.NITROGEN_DIOXIDE, group = "airquality"),
        Spec(LayerCode.AIR_QUALITY_O3_TEXT, LayerCode.OZONE, group = "airquality"),
        Spec(LayerCode.AIR_QUALITY_PM10_TEXT, LayerCode.PARTICULATE_MATTER_10_MICRON, group = "airquality"),
        Spec(LayerCode.AIR_QUALITY_PM2P5_TEXT, LayerCode.PARTICULATE_MATTER_2P5_MICRON, group = "airquality"),
        Spec(LayerCode.AIR_QUALITY_SO2_TEXT, LayerCode.SULFUR_DIOXIDE, group = "airquality"),
        Spec(LayerCode.AIR_QUALITY_INDEX_TEXT, LayerCode.AIR_QUALITY_INDEX, group = "airquality"),
        Spec(LayerCode.AIR_QUALITY_INDEX_CAI_TEXT, LayerCode.AIR_QUALITY_INDEX_CAI_CATEGORIES, group = "airquality"),
        Spec(LayerCode.AIR_QUALITY_INDEX_CHINA_TEXT, LayerCode.AIR_QUALITY_INDEX_CHINA_CATEGORIES, group = "airquality"),
        Spec(LayerCode.AIR_QUALITY_INDEX_EAQI_TEXT, LayerCode.AIR_QUALITY_INDEX_EAQI_CATEGORIES, group = "airquality"),
        Spec(LayerCode.AIR_QUALITY_INDEX_INDIA_TEXT, LayerCode.AIR_QUALITY_INDEX_INDIA_CATEGORIES, group = "airquality"),
        Spec(LayerCode.AIR_QUALITY_INDEX_UBA_DAQI_TEXT, LayerCode.AIR_QUALITY_INDEX_UBA_DAQI_CATEGORIES, group = "airquality"),
        Spec(LayerCode.AIR_QUALITY_INDEX_UK_DAQI_TEXT, LayerCode.AIR_QUALITY_INDEX_UK_DAQI_CATEGORIES, group = "airquality"),
    )

    private val byCode: Map<LayerCode, Spec> = CATALOG.associateBy { it.code }

    /** True when [layerId] is a catalog data-query symbol layer (value + name stack). */
    fun isValueTextLayerId(layerId: String?): Boolean {
        if (layerId.isNullOrEmpty()) return false
        return CATALOG.any { it.layerId == layerId }
    }

    /**
     * Builds the weather configuration for a data-query (`*-text`) [code] from [CATALOG].
     *
     * @throws IllegalStateException if [code] has no catalog entry.
     * @see LayerCode.DataQueryText
     * @see LayerCode.TemperaturesText
     */
    fun configuration(
        service: WeatherService,
        code: LayerCode,
    ): BaseVectorConfiguration<VectorSourceDescriptor, DataQueryLayerDescriptor> {
        val spec = byCode[code]
            ?: error("No DataQuery catalog entry for $code")
        return PlaceValueText(service, spec)
    }

    /** @deprecated Prefer [configuration]; kept for existing TemperaturesText call sites. */
    class TemperaturesText(
        service: WeatherService,
    ) : BaseVectorConfiguration<VectorSourceDescriptor, DataQueryLayerDescriptor>() {
        private val inner = PlaceValueText(service, byCode.getValue(LayerCode.TEMPERATURES_TEXT))
        override val code: LayerCode = inner.code
        override val source: VectorSourceDescriptor = inner.source
        override val layer: DataQueryLayerDescriptor = inner.layer
        override var presentation: Presentation? = null
    }

    /**
     * Shared place-point value+name text layer. Only [Spec.code] / [Spec.sampled] / [Spec.layerId] differ.
     */
    class PlaceValueText(
        val service: WeatherService,
        val spec: Spec,
    ) : BaseVectorConfiguration<VectorSourceDescriptor, DataQueryLayerDescriptor>() {
        override val code: LayerCode = spec.code
        override val source: VectorSourceDescriptor = WeatherSource.base_osm(service)
        override val layer: DataQueryLayerDescriptor =
            DataQueryLayerDescriptor(
                id = spec.layerId,
                source = source.id,
                sourceLayer = "place",
                sampledLayerCode = spec.sampled,
                labelKeyPath = "name",
                rankKeyPath = "rank",
                filter =
                    Expression.contains(
                        Expression.get("class"),
                        listOf("city", "town"),
                    ),
                paint =
                    SymbolLayerPaint(
                        rank = SymbolRank("rank", SymbolRankDirection.ASC),
                        pitchWithMap = false,
                        rotateWithMap = false,
                        text =
                            listOf(
                                TextPaint(
                                    value = StyleValue.Expression(Expression.get("value")),
                                    size = StyleValue.Constant(14.0),
                                    color = StyleValue.Constant(toColor("#222")),
                                    outlineColor = StyleValue.Constant(toColor("#fff")),
                                    anchor = StyleValue.Constant(Anchor.CENTER),
                                ),
                                TextPaint(
                                    value = StyleValue.Expression(Expression.get("name")),
                                    size = StyleValue.Constant(11.0),
                                    color = StyleValue.Constant(toColor("#333")),
                                    outlineColor = StyleValue.Constant(toColor("#fff")),
                                    anchor = StyleValue.Constant(Anchor.TOP),
                                    offset = StyleValue.Constant(AnchorOffset(0.0, 0.15)),
                                ),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
    }
}
