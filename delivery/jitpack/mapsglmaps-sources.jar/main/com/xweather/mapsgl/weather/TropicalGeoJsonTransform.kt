package com.xweather.mapsgl.weather

import com.google.gson.Gson
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.mapbox.geojson.Feature
import com.mapbox.geojson.FeatureCollection
import com.mapbox.geojson.LineString
import com.mapbox.geojson.Point
import kotlin.math.abs

/**
 * Client-side tropical GeoJSON transforms (parity with MapsGL JS `transformTropicalGeoJSON` and archive
 * position synthesis in `weather/sources.ts`). The API returns track/forecast **points**; line layers
 * require synthesized `trackLine` / `forecastLine` segment features.
 */
internal object TropicalGeoJsonTransform {

    private val gson = Gson()

    private val tropicalSourceIds = setOf(
        WeatherSource.SourceCode.tropical_active.toString(),
        WeatherSource.SourceCode.tropical_archive.toString(),
        WeatherSource.SourceCode.tropical_invests.toString(),
    )

    fun transformIfTropicalSource(sourceId: String, collection: FeatureCollection): FeatureCollection {
        if (sourceId !in tropicalSourceIds) return collection
        return when (sourceId) {
            WeatherSource.SourceCode.tropical_archive.toString() -> transformArchive(collection)
            // Active All (Icons): post-tropical LO/I tips inherit the last tropical track category so
            // position/forecast keep swirl + track-colored stroke (JS demo appearance) instead of blue L.
            WeatherSource.SourceCode.tropical_active.toString() ->
                transformTropicalGeoJSON(collection, promoteLowDisplayCategory = true)
            else -> transformTropicalGeoJSON(collection)
        }
    }

    /** Archive: synthesize `position` features, then build line segments (parity with JS `sources.ts`). */
    private fun transformArchive(collection: FeatureCollection): FeatureCollection {
        val features = collection.features()?.toMutableList() ?: return collection
        synthesizeArchivePositions(features)
        return transformTropicalGeoJSON(FeatureCollection.fromFeatures(features))
    }

    /**
     * Since archive data may not contain position features, create them from the first track point of each
     * storm and update `details` from the last track point (matches JS `tropical_archive` transform).
     */
    private fun synthesizeArchivePositions(features: MutableList<Feature>) {
        val positions = ArrayList<Feature>()
        var currentId: String? = null
        var positionFeature: Feature? = null
        var lastPointFeature: Feature? = null

        for (feature in features) {
            val fid = feature.id() ?: continue
            if (fid.contains("-trackPoint-")) {
                val stormPropertyId = feature.getStringProperty("id") ?: continue
                if (currentId == null || stormPropertyId != currentId) {
                    positionFeature?.let { pos ->
                        positions.add(applyLastPointDetails(pos, lastPointFeature))
                    }
                    positionFeature = createArchivePositionFeature(feature, currentId)
                    currentId = stormPropertyId
                }
                lastPointFeature = feature
            } else if (fid.endsWith("-Position")) {
                positionFeature = null
            }
        }
        positionFeature?.let { pos ->
            positions.add(applyLastPointDetails(pos, lastPointFeature))
        }
        features.addAll(positions)
    }

    private fun createArchivePositionFeature(trackPoint: Feature, previousStormId: String?): Feature {
        val fid = trackPoint.id() ?: ""
        val props = cloneJsonObject(trackPoint.properties())
        // Never write Gson JsonNull into Mapbox Feature properties (throws on style push).
        val stormId = trackPoint.getStringProperty("id") ?: previousStormId
        if (stormId != null) {
            props.addProperty("id", stormId)
        }
        props.addProperty("featureType", "position")
        return Feature.fromGeometry(
            trackPoint.geometry(),
            props,
            fid.replace(Regex("-trackPoint-.*$"), "-Position"),
        )
    }

    private fun applyLastPointDetails(position: Feature, lastPoint: Feature?): Feature {
        if (lastPoint == null) return position
        val lastDetails = lastPoint.properties()?.get("details") ?: return position
        if (lastDetails.isJsonNull) return position
        val props = cloneJsonObject(position.properties())
        props.add("details", cloneJsonElement(lastDetails))
        return Feature.fromGeometry(position.geometry(), props, position.id())
    }

    fun transformTropicalGeoJSON(
        collection: FeatureCollection,
        promoteLowDisplayCategory: Boolean = false,
    ): FeatureCollection {
        val features = collection.features()?.toMutableList() ?: return collection
        removeApiCombinedLineFeatures(features)
        if (promoteLowDisplayCategory) {
            promoteLowCategoriesFromTrack(features)
        }
        if (alreadyHasSynthesizedLineSegments(features) && !hasApiCombinedLineFeatures(features)) {
            return FeatureCollection.fromFeatures(features)
        }
        val stormIds = LinkedHashSet<String>()
        val allPositionPoints = ArrayList<Feature>()
        val allTrackPoints = ArrayList<Feature>()
        val allForecastPoints = ArrayList<Feature>()

        for (feature in features) {
            val fid = feature.id() ?: continue
            val stormId = stormIdFromFeatureId(fid)
            when {
                fid.contains("-Position") -> {
                    stormIds.add(stormId)
                    allPositionPoints.add(feature)
                }
                fid.contains("-trackPoint") -> {
                    stormIds.add(stormId)
                    allTrackPoints.add(feature)
                }
                fid.contains("-forecastPoint") -> {
                    stormIds.add(stormId)
                    allForecastPoints.add(feature)
                }
            }
        }

        for (stormId in stormIds) {
            val positionPoint = allPositionPoints.firstOrNull { (it.id() ?: "").startsWith(stormId) }
            val trackPoints = allTrackPoints.filter { (it.id() ?: "").startsWith(stormId) }.toMutableList()
            val forecastPoints = allForecastPoints.filter { (it.id() ?: "").startsWith(stormId) }.toMutableList()

            if (positionPoint != null) {
                val positionCoord = pointCoordinates(positionPoint)
                if (trackPoints.isNotEmpty() && positionCoord != null) {
                    val firstCoord = pointCoordinates(trackPoints.first())
                    if (firstCoord != null && positionCoord.contentToString() != firstCoord.contentToString()) {
                        trackPoints.add(positionPoint)
                    }
                }
                if (forecastPoints.isNotEmpty()) {
                    forecastPoints.add(0, positionPoint)
                }
            }

            appendLineSegments(features, stormId, trackPoints, "trackLine")
            appendLineSegments(features, stormId, forecastPoints, "forecastLine")

            features.removeAll { feature ->
                val id = feature.id() ?: return@removeAll false
                Regex("-trackLineString(-(NEG|POS))?$").containsMatchIn(id) ||
                    id.endsWith("-forecastLineString")
            }
        }

        return FeatureCollection.fromFeatures(features)
    }

    /**
     * When a storm's live position / forecast points are LO or I but the track still has a tropical
     * category (TD/TS/H…), copy that last tropical `stormCat`/`stormType` onto those tip features.
     * Forecast line segments inherit the (promoted) position properties, so the tip stays
     * swirl-icon + track-colored instead of blue low styling.
     */
    private fun promoteLowCategoriesFromTrack(features: MutableList<Feature>) {
        val trackByStorm = LinkedHashMap<String, MutableList<Feature>>()
        for (feature in features) {
            val fid = feature.id() ?: continue
            if (!fid.contains("-trackPoint")) continue
            trackByStorm.getOrPut(stormIdFromFeatureId(fid)) { ArrayList() }.add(feature)
        }
        for (i in features.indices) {
            val feature = features[i]
            val fid = feature.id() ?: continue
            val isTip =
                fid.contains("-Position") || fid.contains("-forecastPoint")
            if (!isTip || !isLowOrInvestCategory(feature)) continue
            val donor = lastTropicalTrackPoint(trackByStorm[stormIdFromFeatureId(fid)].orEmpty()) ?: continue
            features[i] = copyStormCategory(feature, donor)
        }
    }

    private fun lastTropicalTrackPoint(trackPoints: List<Feature>): Feature? {
        val ordered = trackPoints.sortedBy { featureTimestampSeconds(it) }
        return ordered.lastOrNull { !isLowOrInvestCategory(it) }
    }

    private fun featureTimestampSeconds(feature: Feature): Double {
        val n = feature.getNumberProperty("timestamp") ?: return Double.NEGATIVE_INFINITY
        val v = n.toDouble()
        return if (v > 1e11) v / 1000.0 else v
    }

    private fun isLowOrInvestCategory(feature: Feature): Boolean {
        val cat = stormCatOrType(feature, "stormCat")?.uppercase()
        val type = stormCatOrType(feature, "stormType")?.uppercase()
        return cat == "LO" || cat == "I" || type == "LO" || type == "I"
    }

    private fun stormCatOrType(feature: Feature, key: String): String? {
        val details = feature.properties()?.get("details") ?: return null
        if (!details.isJsonObject) return null
        val el = details.asJsonObject.get(key) ?: return null
        if (!el.isJsonPrimitive || !el.asJsonPrimitive.isString) return null
        return el.asString
    }

    private fun copyStormCategory(target: Feature, donor: Feature): Feature {
        val donorDetails = donor.properties()?.get("details") ?: return target
        if (!donorDetails.isJsonObject) return target
        val donorObj = donorDetails.asJsonObject
        val cat = donorObj.get("stormCat") ?: return target
        val type = donorObj.get("stormType")
        val props = cloneJsonObject(target.properties())
        val detailsEl = props.get("details")
        val details = when {
            detailsEl != null && detailsEl.isJsonObject -> cloneJsonObject(detailsEl.asJsonObject)
            else -> JsonObject()
        }
        if (cat.isJsonPrimitive) details.add("stormCat", cat)
        if (type != null && type.isJsonPrimitive) details.add("stormType", type)
        props.add("details", details)
        return Feature.fromGeometry(target.geometry(), props, target.id())
    }

    private fun appendLineSegments(
        out: MutableList<Feature>,
        stormId: String,
        points: List<Feature>,
        featureType: String,
    ) {
        for (i in 1 until points.size) {
            val num = (i - 1).toString().padStart(3, '0')
            val previousPoint = points[i - 1]
            val currentPoint = points[i]
            var previousCoord = pointCoordinates(previousPoint) ?: continue
            val currentCoord = pointCoordinates(currentPoint) ?: continue

            val lonDelta = abs(previousCoord[0] - currentCoord[0])
            if (lonDelta > 180) {
                val direction = if (previousCoord[0] - currentCoord[0] > 0) -1 else 1
                val crossingLat = getAntimeridianIntersectionLat(
                    previousCoord[1],
                    previousCoord[0],
                    currentCoord[1],
                    currentCoord[0],
                )
                if (crossingLat != null) {
                    val splitCoord = doubleArrayOf(-180.0 * direction, crossingLat)
                    out.add(
                        createLineSegmentFeature(
                            previousCoord,
                            splitCoord,
                            previousPoint,
                            "$stormId-${featureType}String-$num",
                            featureType,
                        ),
                    )
                    previousCoord = doubleArrayOf(180.0 * direction, crossingLat)
                }
            }

            out.add(
                createLineSegmentFeature(
                    previousCoord,
                    currentCoord,
                    previousPoint,
                    "$stormId-${featureType}String-$num",
                    featureType,
                ),
            )
        }
    }

    private fun createLineSegmentFeature(
        coord0: DoubleArray,
        coord1: DoubleArray,
        template: Feature,
        id: String,
        featureType: String,
    ): Feature {
        val props = cloneJsonObject(template.properties())
        normalizeTimestampProperty(props)
        // Line segments scrub by timestamp; inherited MVT `visible` from points must not hide GeoJSON lines.
        props.remove("visible")
        props.addProperty("featureType", featureType)
        val geometry = LineString.fromLngLats(
            listOf(
                Point.fromLngLat(coord0[0], coord0[1]),
                Point.fromLngLat(coord1[0], coord1[1]),
            ),
        )
        return Feature.fromGeometry(geometry, props, id)
    }

    private fun stormIdFromFeatureId(featureId: String): String =
        featureId
            .replace(Regex("-trackPoint-.*$"), "")
            .replace(Regex("-forecastPoint-.*$"), "")
            .replace(Regex("-Position$"), "")

    private fun pointCoordinates(feature: Feature): DoubleArray? {
        val point = feature.geometry() as? Point ?: return null
        return doubleArrayOf(point.longitude(), point.latitude())
    }

    private fun getAntimeridianIntersectionLat(
        lat1: Double,
        lon1: Double,
        lat2: Double,
        lon2: Double,
    ): Double? {
        if (abs(lon1 - lon2) <= 180) return null
        var uLon1 = lon1
        var uLon2 = lon2
        if (uLon1 > 0 && uLon2 < 0) uLon2 += 360
        else if (uLon1 < 0 && uLon2 > 0) uLon1 += 360
        val targetLon = 180.0
        val t = (targetLon - uLon1) / (uLon2 - uLon1)
        if (t < 0 || t > 1) return null
        return lat1 + t * (lat2 - lat1)
    }

    /**
     * Rule: tropical-position-feature-clone-aliasing. [Gson.fromJson] on a `JsonElement` source can
     * return the *same instance* when the target type is already `JsonObject`/`JsonElement` — Gson's
     * default `TypeAdapter` for those types has no conversion to do, so it hands back the input
     * reference rather than a copy. [appendLineSegments] passes a shared point (e.g. the storm's
     * `-Position` feature, reused as the first point of both `trackPoints` and `forecastPoints`) as
     * the `template` for multiple synthesized line segments, each with a different `featureType` —
     * without a real clone here, `createLineSegmentFeature`'s `props.addProperty("featureType", ...)`
     * mutated the original Position feature's properties in place, so by the time the last line
     * segment was synthesized the source's own `featureType` had been overwritten (e.g. to
     * `"forecastLine"`), making it fail every downstream `featureType == "position"` filter. Round-trip
     * through a JSON string to force a genuinely independent copy.
     */
    private fun cloneJsonObject(src: JsonObject?): JsonObject {
        if (src == null) return JsonObject()
        val cloned = gson.fromJson(gson.toJson(src), JsonObject::class.java)
        cloned.entrySet().removeIf { it.value.isJsonNull }
        return cloned
    }

    /** API timestamps are Unix seconds; normalize accidental epoch-ms values for map-time scrub. */
    private fun normalizeTimestampProperty(props: JsonObject) {
        if (!props.has("timestamp")) return
        val el = props.get("timestamp")
        if (!el.isJsonPrimitive || !el.asJsonPrimitive.isNumber) return
        val v = el.asDouble
        if (v > 1e11) {
            props.remove("timestamp")
            props.addProperty("timestamp", v / 1000.0)
        }
    }

    private fun cloneJsonElement(src: JsonElement): JsonElement =
        gson.fromJson(src, JsonElement::class.java)

    /** Numbered `…-trackLineString-###` / `…-forecastLineString-###` segments from a prior transform pass. */
    private fun alreadyHasSynthesizedLineSegments(features: List<Feature>): Boolean =
        features.any { feature ->
            val id = feature.id() ?: return@any false
            SYNTHESIZED_LINE_SEGMENT_ID.matches(id)
        }

    private val SYNTHESIZED_LINE_SEGMENT_ID =
        Regex("-(?:track|forecast)LineString-\\d{3}$")

    /** Drop API-provided combined track/forecast lines before point→segment synthesis. */
    private fun removeApiCombinedLineFeatures(features: MutableList<Feature>) {
        features.removeAll { feature -> isApiCombinedLineFeature(feature) }
    }

    private fun hasApiCombinedLineFeatures(features: List<Feature>): Boolean =
        features.any { isApiCombinedLineFeature(it) }

    private fun isApiCombinedLineFeature(feature: Feature): Boolean {
        val id = feature.id() ?: return false
        if (SYNTHESIZED_LINE_SEGMENT_ID.matches(id)) return false
        return id.contains("trackLineString") || id.contains("forecastLineString")
    }
}
