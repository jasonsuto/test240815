/**
 * Map controller: registration of sources, layers, timeline, and weather APIs for MapsGL on Android.
 *
 * The public entry point is the abstract [MapController]; use [com.xweather.mapsgl.map.mapbox.MapboxMapController]
 * with Mapbox Maps SDK.
 */

package com.xweather.mapsgl.map

import LayerEvents
import android.content.ComponentCallbacks2
import android.content.Context
import android.graphics.RectF
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Choreographer
import androidx.core.view.isVisible
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModel
import androidx.lifecycle.findViewTreeLifecycleOwner
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import com.mapbox.geojson.Point
import com.mapbox.maps.CustomLayerHost
import com.mapbox.maps.MapView
import com.mapbox.maps.extension.style.expressions.dsl.generated.config
import com.mapbox.maps.plugin.gestures.OnMapClickListener
import com.xweather.mapsgl.anim.AnimationEvent
import com.xweather.mapsgl.anim.AnimationOptions
import com.xweather.mapsgl.anim.AnimationState
import com.xweather.mapsgl.anim.StaggeredIntervalPhase
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.anim.Timeline.Companion.timeStrings
import com.xweather.mapsgl.config.weather.account.XweatherAccount
import com.xweather.mapsgl.controls.DataInspectorControl
import com.xweather.mapsgl.controls.legend.LegendControl
import com.xweather.mapsgl.controls.legend.Point.PointLegend
import com.xweather.mapsgl.controls.legend.bar.BarLegend
import com.xweather.mapsgl.data.DataInspectorResult
import com.xweather.mapsgl.data.LayerTileList
import com.xweather.mapsgl.data.Queue
import com.xweather.mapsgl.data.TileList
import com.xweather.mapsgl.data.series.AnimatorSync
import com.xweather.mapsgl.events.Cancellable
import com.xweather.mapsgl.events.EventDispatcher
import com.xweather.mapsgl.events.MapControllerEvents
import com.xweather.mapsgl.extensions.Dimension
import com.xweather.mapsgl.geo.Viewport
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera
import com.xweather.mapsgl.gl.worldObjects.cameras.CameraType
import com.xweather.mapsgl.layers.FeatureQueryResult
import com.xweather.mapsgl.layers.QueriedFeature
import com.xweather.mapsgl.layers.spec.ContourLayerDescriptor
import com.xweather.mapsgl.layers.spec.GridLayerDescriptor
import com.xweather.mapsgl.layers.spec.LayerMaskLayerConfig
import com.xweather.mapsgl.layers.spec.LayerMaskSpec
import com.xweather.mapsgl.layers.spec.MaskFilterFingerprint
import com.xweather.mapsgl.layers.spec.LayerMaskType
import com.xweather.mapsgl.layers.spec.LayerDescriptor
import com.xweather.mapsgl.layers.spec.MaskLayerKind
import com.xweather.mapsgl.layers.spec.ParticleLayerDescriptor
import com.xweather.mapsgl.layers.spec.RasterLayerDescriptor
import com.xweather.mapsgl.layers.spec.SampleLayerDescriptor
import com.xweather.mapsgl.layers.spec.StencilLayerMaskSpec
import com.xweather.mapsgl.layers.spec.StencilMaskLayerRef
import com.xweather.mapsgl.layers.spec.VectorLayerDescriptor
import com.xweather.mapsgl.layers.tile.EncodedTileLayer
import com.xweather.mapsgl.layers.tile.MapLayer
import com.xweather.mapsgl.layers.tile.RenderContext
import com.xweather.mapsgl.layers.tile.TileConversions
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.layers.tile.VectorTileLayer
import com.xweather.mapsgl.map.mapbox.CameraSync
import com.xweather.mapsgl.map.mapbox.CameraSync.Companion.camera
import com.xweather.mapsgl.map.mapbox.CameraSync.Companion.mapZoom
import com.xweather.mapsgl.map.mapbox.GlStencilCountryMask
import com.xweather.mapsgl.map.mapbox.GlStencilCustomMaskCoordinator
import com.xweather.mapsgl.map.mapbox.GlStencilMaskCoordinator
import com.xweather.mapsgl.map.mapbox.GlStencilMaskTileCache
import com.xweather.mapsgl.map.mapbox.GlTextureMaskBuilder
import com.xweather.mapsgl.map.mapbox.MapboxLayerHost
import com.xweather.mapsgl.map.mapbox.MapboxMapController
import com.xweather.mapsgl.map.mapbox.MapboxMapController.Companion.PERSPECTIVECAMERA
import com.xweather.mapsgl.map.mapbox.MapboxMapController.Companion.TAG
import com.xweather.mapsgl.renderers.ContourRenderer
import com.xweather.mapsgl.renderers.EmptyRenderer
import com.xweather.mapsgl.renderers.EncodedDataRenderer
import com.xweather.mapsgl.renderers.GridLayerRenderer
import com.xweather.mapsgl.renderers.ParticleRenderer
import com.xweather.mapsgl.renderers.RasterLayerRenderer
import com.xweather.mapsgl.renderers.WindArrowInstancedRenderer
import com.xweather.mapsgl.renderers.WindBarbInstancedRenderer
import com.xweather.mapsgl.sources.DataSource
import com.xweather.mapsgl.sources.EncodedGridVectorTileSource
import com.xweather.mapsgl.sources.EncodedTileSource
import com.xweather.mapsgl.sources.GeoJSONSource
import com.xweather.mapsgl.sources.GeoJsonAssets
import com.xweather.mapsgl.sources.ImageTileSource
import com.xweather.mapsgl.sources.RasterTileApiEvent
import com.xweather.mapsgl.sources.TileSource
import com.xweather.mapsgl.sources.VectorTileSource
import com.xweather.mapsgl.sources.XweatherEncodedTileSource
import com.xweather.mapsgl.sources.data.EncodedData
import com.xweather.mapsgl.sources.source.spec.EncodedSourceDescriptor
import com.xweather.mapsgl.sources.source.spec.GeoJSONSourceDescriptor
import com.xweather.mapsgl.sources.source.spec.ImageSourceDescriptor
import com.xweather.mapsgl.sources.source.spec.SourceDescriptor
import com.xweather.mapsgl.sources.source.spec.VectorSourceDescriptor
import com.xweather.mapsgl.style.ColorScaleOptions
import com.xweather.mapsgl.style.ContourLayerPaint
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.GridLayerPaint
import com.xweather.mapsgl.style.LayerPaint
import com.xweather.mapsgl.style.ParticleLayerPaint
import com.xweather.mapsgl.style.RasterLayerPaint
import com.xweather.mapsgl.style.SampleLayerPaint
import com.xweather.mapsgl.style.VectorLayerPaint
import com.xweather.mapsgl.style.colorScaleRangeForMagnitudeLookup
import com.xweather.mapsgl.style.colorStopBandsFromOptionsStops
import com.xweather.mapsgl.tiles.LatLonBounds
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.types.Coordinate
import com.xweather.mapsgl.types.DataSourceConsumer
import com.xweather.mapsgl.types.MapProvider
import com.xweather.mapsgl.types.SampleExpression
import com.xweather.mapsgl.types.Size
import com.xweather.mapsgl.types.TileSize
import com.xweather.mapsgl.util.MapsGLDebug
import com.xweather.mapsgl.utils.Signal
import com.xweather.mapsgl.utils.parseDateArrayFromString
import com.xweather.mapsgl.weather.BaseVectorConfiguration
import com.xweather.mapsgl.weather.CompositeWeatherLayerConfiguration
import com.xweather.mapsgl.weather.LayerCode
import com.xweather.mapsgl.weather.WeatherConfiguration
import com.xweather.mapsgl.weather.WeatherLayerConfiguration
import com.xweather.mapsgl.weather.WeatherService
import com.xweather.mapsgl.weather.XweatherAuthenticator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.coroutines.cancellation.CancellationException
import kotlin.collections.set
import kotlin.math.atan
import kotlin.math.floor
import kotlin.math.roundToInt

internal sealed class MapControllerError : Throwable() {
    data class ALREADY_EXISTS(val desc: String = "already exists") : Error()
    data class INVALID_SOURCE(val desc: String = "invalid source") : Error()
}

/**
 * Bridge between the host map view (Mapbox [MapView]) and MapsGL: sources, tile layers, timeline,
 * data inspector, legends, and weather APIs.
 *
 * Use [com.xweather.mapsgl.map.mapbox.MapboxMapController] as the concrete implementation for Mapbox.
 *
 * @param mapView Host [MapView]; used for context, lifecycle, and dimensions.
 * @param account Xweather credentials used by [service] and tile requests.
 */
abstract class MapController(val mapView: MapView, val account: XweatherAccount) : MapProvider, ViewModel(),
    DefaultLifecycleObserver, TileLayer.TileLayerEventListener, ComponentCallbacks2, OnMapClickListener {

    internal companion object {
        var packageName: String? = null

        /** Logcat filter tag for [MapController] init diagnostics (e.g. device density at creation). */
        const val MAP_CONTROLLER_LOG_TAG = "MapsGL.MapController"
    }

    /**
     * Session id assigned at construction; must match [Timeline.mapSessionId] for global tile
     * bookkeeping ([com.xweather.mapsgl.data.TileList]) to apply to this controller.
     */
    val mapSessionId: Long

    init {
        // Wipe the static animation/timeline state before any other init logic in this controller
        // runs. When a previous controller (typically in a now-finished activity) loaded the same
        // sources we're about to register, the per-source `LayerTimeline` entries in
        // `Timeline.sourceTimeHash` still claim those time intervals are downloaded — but the
        // backing GPU/CPU tile data belongs to the dead controller, so the renderer would draw
        // nothing for those phase strings. See [Timeline.resetForNewController] for details.
        mapSessionId = Timeline.resetForNewController()
        TileList.resetForNewController()
        GlStencilMaskCoordinator.prepareForNewMapController()
        GeoJsonAssets.bind(mapView.context)

        val dm = mapView.context.resources.displayMetrics
        MapsGLDebug.logI(
            MAP_CONTROLLER_LOG_TAG,
            "MapController created: density=${dm.density} densityDpi=${dm.densityDpi} " +
                    "scaledDensity=${dm.scaledDensity} xdpi=${dm.xdpi} ydpi=${dm.ydpi} " +
                    "widthPx=${dm.widthPixels} heightPx=${dm.heightPixels}",
        )
    }

    private fun maskCountryIsoFromLayerDescriptor(ld: Any?): String? =
        when (ld) {
            is RasterLayerDescriptor -> ld.maskCountryIso3166Alpha2
            is SampleLayerDescriptor -> ld.maskCountryIso3166Alpha2
            is ContourLayerDescriptor -> ld.maskCountryIso3166Alpha2
            is ParticleLayerDescriptor -> ld.maskCountryIso3166Alpha2
            is GridLayerDescriptor -> ld.maskCountryIso3166Alpha2
            else -> null
        }

    private fun syntheticLayerMaskFromShorthand(
        layerMask: LayerMaskSpec?,
        maskLayerIds: List<String>,
        maskLayerId: String?,
    ): LayerMaskSpec? {
        layerMask?.let { return it }
        if (maskLayerIds.isNotEmpty()) {
            return LayerMaskSpec(layers = maskLayerIds.map { LayerMaskLayerConfig(id = it) })
        }
        val single = maskLayerId?.trim().orEmpty()
        if (single.isNotEmpty()) {
            return LayerMaskSpec(layers = listOf(LayerMaskLayerConfig(id = single)))
        }
        return null
    }

    private fun effectiveLayerMaskSpecForBitmapDescriptor(ld: Any?): LayerMaskSpec? = when (ld) {
        is RasterLayerDescriptor -> syntheticLayerMaskFromShorthand(ld.layerMask, ld.maskLayerIds, ld.maskLayerId)
        is SampleLayerDescriptor -> syntheticLayerMaskFromShorthand(ld.layerMask, ld.maskLayerIds, ld.maskLayerId)
        is ContourLayerDescriptor -> syntheticLayerMaskFromShorthand(ld.layerMask, ld.maskLayerIds, ld.maskLayerId)
        is ParticleLayerDescriptor -> syntheticLayerMaskFromShorthand(ld.layerMask, ld.maskLayerIds, ld.maskLayerId)
        is GridLayerDescriptor -> syntheticLayerMaskFromShorthand(ld.layerMask, ld.maskLayerIds, ld.maskLayerId)
        else -> null
    }

    /**
     * GLES stencil spec from bitmap-style descriptors: [StencilLayerMaskSpec] wins, else [LayerMaskSpec]
     * (including [maskLayerIds] / [maskLayerId] shorthand) is resolved to concrete vector refs.
     */
    private fun bitmapStencilFromLayerDescriptor(ld: Any?, beforeId: String? = null): StencilLayerMaskSpec? =
        when (ld) {
            is RasterLayerDescriptor ->
                ld.stencilLayerMask
                    ?: effectiveLayerMaskSpecForBitmapDescriptor(ld)?.let { resolveUserLayerMaskSpec(it, beforeId) }
            is SampleLayerDescriptor ->
                ld.stencilLayerMask
                    ?: effectiveLayerMaskSpecForBitmapDescriptor(ld)?.let { resolveUserLayerMaskSpec(it, beforeId) }
            is ContourLayerDescriptor ->
                ld.stencilLayerMask
                    ?: effectiveLayerMaskSpecForBitmapDescriptor(ld)?.let { resolveUserLayerMaskSpec(it, beforeId) }
            is ParticleLayerDescriptor ->
                ld.stencilLayerMask
                    ?: effectiveLayerMaskSpecForBitmapDescriptor(ld)?.let { resolveUserLayerMaskSpec(it, beforeId) }
            is GridLayerDescriptor ->
                ld.stencilLayerMask
                    ?: effectiveLayerMaskSpecForBitmapDescriptor(ld)?.let { resolveUserLayerMaskSpec(it, beforeId) }
            else -> null
        }

    private fun setCustomStencilOnLayerDescriptor(ld: Any?, stencil: StencilLayerMaskSpec) {
        when (ld) {
            is RasterLayerDescriptor -> ld.stencilLayerMask = stencil
            is SampleLayerDescriptor -> ld.stencilLayerMask = stencil
            is ContourLayerDescriptor -> ld.stencilLayerMask = stencil
            is ParticleLayerDescriptor -> ld.stencilLayerMask = stencil
            is GridLayerDescriptor -> ld.stencilLayerMask = stencil
        }
    }

    private fun layerCodeFromUserMaskId(id: String): LayerCode? {
        when (id.lowercase()) {
            "countries" -> return LayerCode.LAND
        }
        return LayerCode.entries.firstOrNull { it.value == id || it.name.equals(id, ignoreCase = true) }
    }

    /**
     * JS `countries` in [LayerMaskSpec] means built-in land when no map layer with that id exists
     * (see [com.xweather.mapsgl.layers.spec.LayerMasks.landAndRoads]). If the app added a fill
     * layer literally named `countries`, treat it as a normal mask layer ref — not built-in land.
     */
    private fun isBuiltinLandMaskRef(ref: LayerMaskLayerConfig): Boolean {
        if (getLayer(ref.id) != null) return false
        val code = layerCodeFromUserMaskId(ref.id) ?: return false
        if (code != LayerCode.LAND) return false
        return ref.maskId.isNullOrBlank()
    }

    private fun isLayerMaskLandPlusCustomLines(
        userMask: LayerMaskSpec,
        resolved: StencilLayerMaskSpec,
    ): Boolean {
        if (!userMask.layers.any(::isBuiltinLandMaskRef)) return false
        if (resolved.layers.isEmpty()) return false
        return true
    }

    private fun applyLayerMaskHybridLandLineFlags(
        enc: EncodedTileLayer,
        userMask: LayerMaskSpec,
        customStencilSpec: StencilLayerMaskSpec,
    ) {
        if (!isLayerMaskLandPlusCustomLines(userMask, customStencilSpec)) return
        enc.hybridLandWithCustomLineMask = true
        enc.glStencilMaskKind = MaskLayerKind.LAND
        enc.hasLandMask = true
        GlStencilMaskCoordinator.ensureBaseOsmMaskConsumer(this, service, MaskLayerKind.LAND, null)
    }

    private fun mergeMaskAutoConfigure(
        overrides: ((WeatherConfiguration) -> Unit)?,
        maskFilter: Expression?,
    ): ((WeatherConfiguration) -> Unit)? = when {
        overrides != null && maskFilter != null -> { cfg ->
            overrides.invoke(cfg)
            applyMaskFilterToAutoWeatherConfig(cfg, maskFilter)
        }
        overrides != null -> overrides
        maskFilter != null -> { cfg -> applyMaskFilterToAutoWeatherConfig(cfg, maskFilter) }
        else -> null
    }

    /** Auto-created mask layers are stencil geometry only — never the visible admin fill (#333 water). */
    private fun mergeStencilOnlyMaskConfigure(
        configure: ((WeatherConfiguration) -> Unit)?,
    ): (WeatherConfiguration) -> Unit = { cfg ->
        if (cfg is WeatherLayerConfiguration<*, *>) {
            val ld = cfg.layer
            if (ld is VectorLayerDescriptor<*>) {
                ld.stencilOnly = true
            }
        }
        configure?.invoke(cfg)
    }

    private fun applyMaskFilterToAutoWeatherConfig(cfg: WeatherConfiguration, filter: Expression) {
        if (cfg !is WeatherLayerConfiguration<*, *>) return
        val ld = cfg.layer
        if (ld is VectorLayerDescriptor<*>) {
            @Suppress("UNCHECKED_CAST")
            (ld as VectorLayerDescriptor<LayerPaint>).filter = filter
        }
    }

    /**
     * Resolves JS-style [LayerMaskSpec] into [StencilLayerMaskSpec], auto-adding weather masks when needed.
     */
    private fun resolveUserLayerMaskSpec(mask: LayerMaskSpec, beforeId: String? = null): StencilLayerMaskSpec? {
        val refs = mutableListOf<StencilMaskLayerRef>()
        var invertFromType = false

        if (mask.layers.isNotEmpty()) {
            for (ref in mask.layers) {
                val existing = getLayer(ref.id)
                if (existing != null) {
                    refs += StencilMaskLayerRef(existing.id)
                    continue
                }
                val code = layerCodeFromUserMaskId(ref.id)
                if (code != null) {
                    if (isBuiltinLandMaskRef(ref)) {
                        continue
                    }
                    val filterSuffix = ref.maskFilter?.let { "-f${MaskFilterFingerprint.compactSuffix(it)}" } ?: ""
                    val autoMaskId = ref.maskId ?: "${ref.id}::mask$filterSuffix"
                    val configure = mergeStencilOnlyMaskConfigure(
                        mergeMaskAutoConfigure(ref.overrides, ref.maskFilter),
                    )
                    val added = getLayer(autoMaskId) ?: addWeatherLayer(
                        code,
                        id = autoMaskId,
                        beforeId = beforeId,
                        configure = configure,
                    )
                    if (added != null) {
                        refs += StencilMaskLayerRef(added.id)
                    } else {
                        MapsGLDebug.trace("[MapsGL] layerMask: failed to create weather mask layer for '${ref.id}'")
                    }
                    continue
                }
                MapsGLDebug.trace(
                    "[MapsGL] layerMask: layer '${ref.id}' not found and is not a known weather layer code; skipping",
                )
            }
        }

        when (mask.type) {
            LayerMaskType.WATER -> {
                val waterMaskId = "water::mask"
                val added = getLayer(waterMaskId) ?: addWeatherLayer(
                    LayerCode.WATER,
                    id = waterMaskId,
                    beforeId = beforeId,
                    configure = mergeStencilOnlyMaskConfigure(null),
                )
                if (added != null) refs += StencilMaskLayerRef(added.id)
            }
            LayerMaskType.LAND -> {
                val waterMaskId = "water::mask"
                val added = getLayer(waterMaskId) ?: addWeatherLayer(
                    LayerCode.WATER,
                    id = waterMaskId,
                    beforeId = beforeId,
                    configure = mergeStencilOnlyMaskConfigure(null),
                )
                if (added != null) refs += StencilMaskLayerRef(added.id)
                invertFromType = true
            }
            null -> {}
        }

        val unique = refs.distinctBy { it.layerId }
        if (unique.isEmpty()) return null
        val capped = unique.take(StencilLayerMaskSpec.MAX_STENCIL_MASK_LAYERS)
        if (unique.size > capped.size) {
            MapsGLDebug.trace(
                "[MapsGL] layerMask has ${unique.size} layers; using first ${capped.size} due to stencil slot limit",
            )
        }
        return StencilLayerMaskSpec(
            layers = capped,
            mode = mask.mode,
            invert = mask.invert ?: invertFromType,
        )
    }

    private val listeners: MutableMap<String, MutableList<(Any) -> Unit>> = mutableMapOf()

    /** Geographic center of the map in latitude/longitude degrees, kept in sync with the camera. */
    lateinit var centerLatLng: Coordinate// = Coordinate(viewport.getCenter().y, viewport.getCenterOffset().x)
    private var sources: MutableMap<String, DataSource> = mutableMapOf()
    /** All MapsGL map layers currently registered on this controller, keyed by layer id. */
    var layers: MutableMap<String, MapLayer<*, *>> = mutableMapOf()
    private var layerIdsByWeatherCode: MutableMap<LayerCode, MutableList<String>> = mutableMapOf()
    private var particleLayers: MutableMap<String, MapLayer<*, *>> = mutableMapOf()

    /** Pick/inspect weather values at a tap location; enable with [addDataInspectorControl].
     * Configure off-screen dismissal via [DataInspectorControl.cancelCalloutWhenOffScreen]. */
    val dataInspector = DataInspectorControl(this)
    /** Same instance passed to [on]/[off] for [DataInspectorEvent.VECTOR_UPDATE]; cleared in [removeDataInspectorControl]. */
    private var dataInspectorVectorUpdateListener: ((Any) -> Unit)? = null
    private var _legendControl: LegendControl? = null
    /** Optional UI control for layer legends; install with [add]. */
    var legendControl: LegendControl? = null


    private val downloadTrackingHandler = Handler(Looper.getMainLooper())
    private var downloadStartTime = 0L
    /** Self-reference to this controller instance, used to disambiguate `this` inside nested
     * listener/`Runnable` bodies (e.g. [downloadTrackingRunnable]) where `this` would otherwise
     * refer to the inner object rather than the [MapController]. */
    val thisMap = this

    private val downloadTrackingRunnable = object : Runnable {
        override fun run() {
            val elapsedSeconds = (System.currentTimeMillis() - downloadStartTime) / 1000
            //MapsGLDebug.trace(">>> MapController: Still waiting for encoded downloads... ($elapsedSeconds seconds elapsed)")

            // --- TIMEOUT LOGIC ---
            // Loads past 100s are considered broken; do not wait longer.
            if (elapsedSeconds > 100) {
                MapsGLDebug.trace(">>> MapController: Download timed out after 100 seconds. Clearing pending downloads.")
                if (thisMap is MapboxMapController) {
                    thisMap.clearPending()
                }
                downloadTrackingHandler.removeCallbacks(this)
                downloadStartTime = 0L
                return // Stop the runnable immediately
            }

            // Schedule next check in 1 second
            downloadTrackingHandler.postDelayed(this, 1000)
        }
    }

    internal val layerHosts: MutableMap<String, MapboxLayerHost> = mutableMapOf()
    private var lastUpdated = 0L
    private var currentTime = 0L
    private val minimumDIUpdateInterval = 60

    // If the inspector is active over an area with no loaded tiles yet, we want it to
    // refresh as soon as *any* encoded tile download completes (so new tile data can
    // immediately appear in the callout).
    private var lastPendingEncodedTotal: Int = 0
    private var lastDIUpdateOnEncodedTileLoadAt: Long = 0L
    private val minimumDIUpdateIntervalOnEncodedTileLoadMs = 250L

    /** -1 is fast, 1 is sharper. This is also sent to TileLayer. **/
    internal var zoomOffset = -1 //-1 is quicker to load, less detail, 0 looks sharper.
    internal var animatingTimeline = false

    /**
     * After extending the timeline during playback, metadata refresh must not enqueue tile HTTP
     * until the user presses play or scrubs — only pause, no background prefetch.
     */
    @Volatile
    private var suppressTilePrefetchAfterRangeChangePause = false
    internal var readyToPlay = true

    /** Last global timeline phase indices used to enqueue encoded-tile downloads during playback. */
    private var playbackRefreshPhaseA = -1
    private var playbackRefreshPhaseB = -1
    private var playbackLayerRefreshJob: Job? = null
    /** Set when play starts while a playback refresh job is still running; rerun when it finishes. */
    private var playbackLayerRefreshPending = false
    private val _onLoadStart = MutableLiveData<Unit>() // Unit signifies no specific data
    /** Internal debounce job for camera move-end handling; managed by [MapboxMapController]. */
    var debounceMoveEndJob: Job? = null // Add this property

    /**
     * When `true`, custom [com.xweather.mapsgl.layers.spec.StencilLayerMaskSpec] masks are baked once per
     * dirty frame into an R8 viewport texture (JS `tMask`) instead of per-tile stencil rewrites during
     * weather draw.
     */
    var useGlTextureMaskFbo: Boolean = false

    /** Populated from `base.osm` vector tiles for GLES land/water/custom stencil masking. */
    internal val glStencilMaskTileCache = GlStencilMaskTileCache()

    internal val glTextureMaskBuilder = GlTextureMaskBuilder()

    /** Single main-thread scope for map work — avoids allocating a new [CoroutineScope] on every launch. */
    private val controllerMainJob = SupervisorJob()
    private val controllerMainScope = CoroutineScope(controllerMainJob + Dispatchers.Main)

    /** Posted when loading begins for any tracked data source (e.g. tile wave started). */
    val onLoadStart: LiveData<Unit> = _onLoadStart
    private var loadProgressSessionActive: Boolean = false
    private var loadProgressLastCompletedPct: Int = 0
    private var pendingLoadCompleteJob: Job? = null
    private val loadCompleteDebounceMs: Long = 700L

    /**
     * Quiet period required to end a load session while the timeline is playing. Playback now
     * streams only a playhead window, so a short quiet gap is enough to end the *initial* catch-up
     * load; further phase downloads are suppressed from the load UI via [suppressStreamingLoadUi].
     */
    private val loadCompletePlaybackDebounceMs: Long = 500L
    private val loadCompletePollMs: Long = 250L
    private var pendingLoadStartJob: Job? = null
    private val loadStartDebounceMs: Long = 800L

    /**
     * A wave that appears right after a session completed while playing is nearly always a straggler
     * phase of the same load-in (the playhead reaches the last interval a beat after the quiet window
     * of [loadCompletePlaybackDebounceMs] expired). Such work resolves in a few seconds, so it has to
     * outlive [loadStartPlaybackRegraceDebounceMs] before the indicator comes back — a genuinely new
     * load (e.g. a pan to fresh tiles) keeps its queues busy well past that.
     */
    private val loadStartPlaybackRegraceWindowMs: Long = 3_000L
    private val loadStartPlaybackRegraceDebounceMs: Long = 4_000L
    /** Pending count above which a refill is treated as a genuine new wave, not a straggler blip
     * (see [triggerLoadStart]). A handful of re-verified cache hits is a blip; a pan-triggered
     * viewport refill is realistically in the hundreds. */
    private val loadStartRegraceBlipMaxPending: Int = 30
    private var lastLoadCompleteAtMs: Long = 0L

    /**
     * After the first load session completes during playback, further playhead-lookahead downloads
     * must not revive the spinner — otherwise a multi-day timeline keeps the indicator at 99% for
     * the entire animation. Cleared when the user pans (fresh tile set) or changes the timeline range.
     *
     * This only gates the load UI. Encoded catch-up / GPU re-bind must continue so the layer can
     * animate through resident intervals (pending-empty ≠ all intervals in [TileCache.hashMap]).
     */
    private var suppressStreamingLoadUi: Boolean = false

    /**
     * True once a pending-queue refill has been confirmed as a genuine new load (survived
     * [loadStartDebounceMs]). Gates the visible spinner/percent so brief re-verify blips — e.g.
     * a low-zoom overview tile whose sparse time-window lookup misses even though the tile is
     * still cached — never flash the "loading" UI back on for already-loaded raster data.
     */
    private var loadStartConfirmed: Boolean = false

    private fun emitOnLoadProgressPercent(percent: Int, force: Boolean = false) {
        val clamped = percent.coerceIn(0, 100)
        if (force) {
            loadProgressLastCompletedPct = clamped
            dispatchOnLoadProgress(Queue.Progress(total = 100, completed = clamped))
            return
        }
        if (!loadProgressSessionActive) {
            loadProgressSessionActive = true
            loadProgressLastCompletedPct = 0
        }
        // Keep progress monotonic within one load session so staggered multi-layer waves
        // do not visually jump backward (e.g. 50 -> 0 -> 100).
        val monotonic = maxOf(loadProgressLastCompletedPct, clamped)
        if (monotonic != loadProgressLastCompletedPct) {
            loadProgressLastCompletedPct = monotonic
            dispatchOnLoadProgress(Queue.Progress(total = 100, completed = monotonic))
        }
    }

    /** Posts live percent/spinner updates only after a load start has survived its debounce. */
    private fun postProgressIfLoadConfirmed() {
        if (!loadStartConfirmed) return
        _dlProgress.postValue(Timeline.pendingPercent)
        emitOnLoadProgressPercent(Timeline.pendingPercent.roundToInt())
    }

    private var loadSessionWatchdogJob: Job? = null
    private val loadWatchdogPollMs: Long = 1000L

    /**
     * Age at which a pending-encoded key is treated as abandoned. Comfortably longer than the
     * slowest legitimate wave (per-request timeouts are 20s and a wave's keys are all added before
     * its jobs are queued behind the download semaphore).
     */
    private val loadWatchdogStaleKeyMs: Long = 45_000L

    /**
     * Both completion triggers ([com.xweather.mapsgl.data.LayerTileList.TileListListener.onListEmpty]
     * and the pending-encoded observer) are edge-triggered on a queue emptying. If the last edge is
     * missed — cancelled waves, a queue drained by a purge, or a [triggerLoadStart] that cancels a
     * pending completion and then discards itself — nothing else fires and the indicator stays up at
     * its last percent (which the encoded branch of [Timeline.calcDLPercent] caps at 99%) forever.
     * This poll re-checks the same condition on a level basis while the indicator is visible.
     */
    private fun startLoadSessionWatchdog() {
        loadSessionWatchdogJob?.cancel()
        loadSessionWatchdogJob = controllerMainScope.launch {
            var idlePolls = 0
            var highPctDripPolls = 0
            while (loadStartConfirmed) {
                delay(loadWatchdogPollMs)
                val httpPending = TileList.pendingList.countAllEntries()
                var encodedPending = Timeline.countPendingEncodedAll()

                if (encodedPending > 0) {
                    // During play, orphaned keys from completed/cancelled waves stick the UI near
                    // 96–99%. Age them out faster so [triggerLoadComplete] can fire; background
                    // catch-up after suppress will re-request anything still truly missing.
                    val staleMs =
                        if (Timeline.isGloballyPlaying) 12_000L else loadWatchdogStaleKeyMs
                    val released = Timeline.releaseStalePendingEncodedDownloads(staleMs)
                    if (released > 0) {
                        MapsGLDebug.logI(TAG, "load watchdog released $released stale pending-encoded keys")
                        encodedPending = Timeline.countPendingEncodedAll()
                    }
                }

                val bindBusy = encodedGpuBindQueueBusy()
                if (httpPending > 0 || encodedPending > 0 || bindBusy) {
                    idlePolls = 0
                    // Near-done drip: a handful of leftover pending keys with no HTTP/bind work
                    // kept the spinner at ~96% forever. After a few quiet high-% polls, complete.
                    if (httpPending == 0 &&
                        !bindBusy &&
                        loadProgressLastCompletedPct >= 95 &&
                        encodedPending in 1..24
                    ) {
                        highPctDripPolls++
                        if (highPctDripPolls >= 4 && pendingLoadCompleteJob == null) {
                            MapsGLDebug.logI(
                                TAG,
                                "load watchdog completing high-% drip session (pendingEncoded=$encodedPending)",
                            )
                            Timeline.releaseStalePendingEncodedDownloads(0L)
                            triggerLoadComplete()
                            highPctDripPolls = 0
                        }
                    } else {
                        highPctDripPolls = 0
                    }
                    continue
                }
                highPctDripPolls = 0
                idlePolls++
                if (idlePolls >= 2 && pendingLoadCompleteJob == null) {
                    if (pr.ON) pr.p(TAG, pr.loadTracking, "watchdog completing idle load session")
                    triggerLoadComplete()
                }
            }
        }
    }

    /**
     * True while any visible encoded layer still has tiles queued for GPU upload. Load UI must
     * wait for this — pending-encoded keys clear on download job end, before [TileCache.bindTextures].
     */
    private fun encodedGpuBindQueueBusy(): Boolean {
        for (layer in layers.values) {
            if (layer !is EncodedTileLayer || !layer.visible) continue
            if (layer.source.tileCache.bindList.isNotEmpty()) return true
        }
        return false
    }

    internal fun triggerLoadStart() {
        // After the *initial* catch-up load completes, further waves (lookahead, scrub rebind,
        // cancelled-job retries) must not revive the spinner.
        if (suppressStreamingLoadUi || Timeline.holdFullTimelineResidency) return
        pendingLoadCompleteJob?.cancel()
        pendingLoadCompleteJob = null
        if (loadStartConfirmed || pendingLoadStartJob != null) return
        // A refill can be a genuinely new load (e.g. panning to fresh tiles — hundreds of pairs),
        // or just a handful of already-cached tiles getting re-verified (a sparse time-window miss
        // on a still-cached overview tile) that resolve on their own within a frame or two. The
        // regrace window originally assumed a genuine new load always outlives
        // [loadStartPlaybackRegraceDebounceMs] (4s), so gating purely on elapsed time was enough to
        // tell them apart — but a moderate pan-triggered wave (hundreds of pairs) routinely
        // completes in well under 4s on a normal connection. That silently ate the spinner for real,
        // non-trivial work for the whole 4s regrace window after any prior load, which in continuous
        // playback is most of the time. Use the pending-count *magnitude* at entry instead: a true
        // straggler blip is a handful of keys; treat anything clearly larger as real work and use the
        // short debounce regardless of how recently the last session completed.
        val pendingAtEntry = TileList.pendingList.countAllEntries() + Timeline.countPendingEncodedAll()
        val looksLikeGenuineWave = pendingAtEntry > loadStartRegraceBlipMaxPending
        pendingLoadStartJob = controllerMainScope.launch {
            val sincePrevComplete = SystemClock.elapsedRealtime() - lastLoadCompleteAtMs
            delay(
                if (!looksLikeGenuineWave &&
                    Timeline.isGloballyPlaying &&
                    sincePrevComplete < loadStartPlaybackRegraceWindowMs
                ) {
                    loadStartPlaybackRegraceDebounceMs
                } else {
                    loadStartDebounceMs
                }
            )
            pendingLoadStartJob = null
            if (suppressStreamingLoadUi || Timeline.holdFullTimelineResidency) {
                return@launch
            }
            if (TileList.pendingList.countAllEntries() <= 0 && Timeline.countPendingEncodedAll() <= 0) {
                return@launch
            }
            loadStartConfirmed = true
            startLoadSessionWatchdog()
            _onLoadStart.postValue(Unit)
            if (!loadProgressSessionActive) {
                loadProgressSessionActive = true
                loadProgressLastCompletedPct = 0
            }
            // Seed with live progress (may already be >0 after the debounce) so the percent label
            // is not left blank at a forced 0 while tiles are already in flight.
            Timeline.calcDLPercent(TileList.pendingList.countAllEntries())
            emitOnLoadProgressPercent(Timeline.pendingPercent.roundToInt(), force = true)
            //this.trigger(MapControllerEvents.LOAD_PROGRESS, true)
            //if (pr.ON) pr.p(TAG, pr.loadTracking, "Loading Started")
        }
    }

    internal fun triggerLoadComplete() {
        pendingLoadStartJob?.cancel()
        pendingLoadStartJob = null
        pendingLoadCompleteJob?.cancel()
        pendingLoadCompleteJob = controllerMainScope.launch {
            // Two-layer loads can briefly drain then refill pending queues; require the queues to
            // stay empty for the whole window so onLoadProgress does not reset (0 -> 50 -> 0 -> 100)
            // between near-adjacent waves.
            val quietMs =
                if (Timeline.isGloballyPlaying) loadCompletePlaybackDebounceMs
                else loadCompleteDebounceMs
            val quietSince = SystemClock.elapsedRealtime()
            while (true) {
                delay(minOf(quietMs, loadCompletePollMs))
                if (TileList.pendingList.countAllEntries() > 0 ||
                    Timeline.countPendingEncodedAll() > 0 ||
                    encodedGpuBindQueueBusy()
                ) {
                    // Another wave arrived (or GPU bind still draining): leave the session running.
                    pendingLoadCompleteJob = null
                    return@launch
                }
                if (SystemClock.elapsedRealtime() - quietSince >= quietMs) break
            }

            // Progressive playback: this is the *coarse* pass finishing, not the whole thing —
            // per the standing rule, the visible percent must stay up (at 50%) and pass 2 must
            // keep it climbing to 100%, not hide here. Only the real completion (after pass 2
            // drains, when this function runs a second time with coarseLoadConfirmedDone already
            // true) falls through to the full finalize below.
            if (Timeline.isGloballyPlaying && Timeline.isCoarsePlayback && !Timeline.coarseLoadConfirmedDone) {
                Timeline.coarseLoadConfirmedDone = true
                Timeline.pendingPercent = 50f
                _dlProgress.postValue(Timeline.pendingPercent)
                emitOnLoadProgressPercent(50, force = true)
                beginProgressiveFullGridPrefetchIfNeeded()
                pendingLoadCompleteJob = null
                return@launch
            }

            Timeline.currentDLCount = 0
            Timeline.resetEncodedDownloadProgressCounters()
            Timeline.pendingPercent = 0f
            loadStartConfirmed = false
            lastLoadCompleteAtMs = SystemClock.elapsedRealtime()
            if (Timeline.isGloballyPlaying) {
                // Pin residency for pause/scrub after a play catch-up. Do not set this on a
                // paused single-interval load — that blocked the subsequent play download wave
                // and froze animation on one frame.
                suppressStreamingLoadUi = true
                Timeline.holdFullTimelineResidency = true
            }
            _dlProgress.postValue(Timeline.pendingPercent)
            emitOnLoadProgressPercent(100, force = true)
            loadProgressSessionActive = false
            _onLoadComplete.postValue(Unit)
            //trigger(MapControllerEvents.LOAD_COMPLETE, true)
            if (pr.ON) pr.p(TAG, pr.loadTracking, "Loading Done")

            // do a final datainspector here
            //if (pr.ON) pr.p("MapController", pr.queryTrack, "onLoadComplete() triggered, doing a query...")
            dataInspector.targetCoordinate?.let { coords ->
                val allLayerIds = layers.values.map { it.id }
                viewModelScope.launch {
                    if (pr.ON) pr.p(
                        "MapController",
                        pr.queryTrack,
                        "onLoadComplete()  calling query with $coords, $allLayerIds..."
                    )
                    query(coords, allLayerIds, true)
                }
            }
            pendingLoadCompleteJob = null
        }
    }

    private var progressiveFullGridJob: Job? = null

    /**
     * Progressive playback pass 2: once the coarse (every-other-interval) first pass has fully
     * loaded and playback has started (see [Timeline.isCoarsePlayback]), fetch the intervals the
     * coarse grid skipped for the currently visible tiles. Standing rule: this must keep the
     * visible load percent climbing from 50% to 100% (not hide it) — so unlike other background
     * continuations in this class, these downloads *do* use `trackDownloadProgress = true`,
     * reusing the same [TileList.pendingList]/[Timeline.currentDLCount] machinery the initial
     * catch-up load uses, just re-armed for this second target. [Timeline.calcDLPercent] blends
     * that 0-100 into the 50-100 half of the display. Marks [Timeline.fullGridReadyToSwap] once
     * done; [Timeline.nextPhase] upgrades playback to the full grid at the next loop wrap.
     */
    private fun beginProgressiveFullGridPrefetchIfNeeded() {
        if (!Timeline.isCoarsePlayback) return
        if (progressiveFullGridJob?.isActive == true) return
        // Capture by reference: if a new range is set mid-prefetch, generateHourlyIntervals()
        // replaces this list wholesale, so an identity mismatch means this job is stale and must
        // not mark a since-superseded coarse session as ready.
        val targetFullList = Timeline.pendingFullTimeStrings
        val targetFullLongs = Timeline.pendingFullTimeLongs
        if (targetFullList.isEmpty()) return
        val coarseSet = Timeline.timeStrings.toHashSet()
        val remainingIndices = targetFullList.indices.filter { targetFullList[it] !in coarseSet }
        if (remainingIndices.isEmpty()) {
            if (Timeline.pendingFullTimeStrings === targetFullList) {
                Timeline.fullGridReadyToSwap = true
            }
            return
        }
        val remainingStrings = remainingIndices.map { targetFullList[it] }
        val remainingLongs = remainingIndices.map { targetFullLongs[it] }
        // Re-arm the same counters the initial catch-up load uses, so calcDLPercent computes a
        // fresh 0-100 for *this* pass instead of reading stale totals from the coarse pass.
        Timeline.currentDLCount = 0
        Timeline.resetEncodedDownloadProgressCounters()
        progressiveFullGridJob = controllerMainScope.launch {
            try {
                for (layer in getMapsGLRenderedLayers()) {
                    if (layer.visible && layer is TileLayer && layer.source.isEncoded) {
                        layer.pyramid.prefetchAdditionalIntervalsQuietly(
                            layer.getVisibleTileCoords(),
                            layer.tileRequestOptions,
                            remainingStrings,
                            remainingLongs,
                        )
                    }
                }
                if (Timeline.pendingFullTimeStrings === targetFullList) {
                    Timeline.fullGridReadyToSwap = true
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                MapsGLDebug.logE(TAG, "progressive full-grid prefetch failed", e)
            }
        }
    }

    private val _onLoadComplete = MutableLiveData<Unit>() // Unit signifies no specific data
    private val _dlProgress = MutableLiveData<Float>() // Unit signifies no specific data
    private val _onLoadProgressLiveData = MutableLiveData<MapLoadProgress>()


    /** Posted when the current load session completes (encoded downloads and bind pipeline idle). */
    val onLoadComplete: LiveData<Unit> = _onLoadComplete
    /** Approximate download progress fraction (0f–1f) while tiles are in flight. */
    val dlProgress: LiveData<Float> = _dlProgress
    /** Same progress as [onLoadProgress], exposed as a [Signal] for coroutine collectors. */
    val onLoadProgressValue = Signal.eventOnly<MapLoadProgress>(scope = viewModelScope)

    /**
     * Emits [MapLoadProgress] while map data loads. Use
     * `onLoadProgress.observe(this) { progress -> ... }` like other [LiveData] on this controller.
     * For coroutine / flow access, see [onLoadProgressValue].
     */
    val onLoadProgress: LiveData<MapLoadProgress> = _onLoadProgressLiveData

    private fun dispatchOnLoadProgress(progress: Queue.Progress) {
        val payload = MapLoadProgress.fromQueue(progress)
        onLoadProgressValue.send(payload)
        _onLoadProgressLiveData.postValue(payload)
    }

    /** Fires with a source id after [addSource] registers it and the source is ready for layers. */
    val onSourceAdded = Signal.eventOnly<String>(scope = viewModelScope)

    private val onSourceRemoved = Signal.eventOnly<String>(scope = viewModelScope)
    private val onLayerAdded = Signal.eventOnly<String>(scope = viewModelScope)
    private val onLayerRemoved = Signal.eventOnly<String>(scope = viewModelScope)


    private var customLayerUpdatesHaveStarted = false
    internal val type = PERSPECTIVECAMERA
    private var frameCallback: Choreographer.FrameCallback? = null
    private val choreographer = Choreographer.getInstance()

    /** False while the host lifecycle is stopped (background); gates redraw and Choreographer work. */
    @Volatile
    internal var mapLifecycleStarted = true

    private var resumeTimelineAfterLifecycleStop = false
    private var lifecycleObserverRegistered = false
    private var mapLifecycleOwner: LifecycleOwner? = null
    private var shutdownInvoked = false
    //private val griddedOverlaySourceByParent = mutableMapOf<String, String>()

    //** This may not be needed. onMove was being used in instances other than when the camera moved **/
    internal suspend fun onMoveNoMove(pauseParticles: Boolean = true, tag: String = "empty") {

        //if(pr.ON) pr.p(TAG, pr.onMove, "onMoveNoMove()")
        if (pauseParticles) camera.moveState = Camera.MOVING
        for (layer in getMapsGLRenderedLayers()) {
            if (layer.visible) {
                layer.onMove() // calls:  bounds = mapController?.getBounds()?: return AND requestVisibleTiles(bounds!!)
            }
        }
    }

    internal val eventDispatcher = EventDispatcher()

    /**
     * Configuration options that control the behavior of timeline animations and data preloading.
     *
     * Use this object to modify settings such as playback speed, loop behavior, and
     * whether the system should aggressively pre-fetch tiles ([AnimationOptions.shouldPreloadData])
     * to ensure seamless, buffer-free playback across the active time range.
     */
    val animationOptions: AnimationOptions = AnimationOptions()

    /** instance used for managing animation and time-based data. **/
    val timeline: Timeline = Timeline(animationOptions, this)

    private val animatorSync: AnimatorSync = AnimatorSync(timeline)
    internal val viewport: Viewport = Viewport(this)
    internal val tileSize = 512f
    internal var worldSize = 0f
    internal var cameraTriggered = false

    /**
     * Bumped by demo activities on each mask-demo button tap so in-flight
     * [scheduleCustomStencilMaskDemoRefresh] / [schedulePausedDemoLandWaterMaskRefresh] coroutines
     * from a previous selection are abandoned (same [Timeline.mapSessionId], different demo).
     */
    @Volatile
    private var maskDemoRefreshGeneration = 0

    /** Cancel scheduled mask-demo refresh work; call when the user picks another demo. */
    fun cancelMaskDemoRefreshWork() {
        maskDemoRefreshGeneration++
    }

    private fun maskDemoRefreshStillValid(expectedGeneration: Int): Boolean =
        expectedGeneration == maskDemoRefreshGeneration

    /** Discrete zoom from [MapboxMapController.updateCamera] (`mapZoom.toInt() + zoomOffset`). Encoded data-inspector tile Z follows [TileLayer.getTileBounds] instead. Matrix scale uses fractional `mapZoom + zoomOffset` there. */
    internal var zoomInt = 0
    internal var densityMult = 1.0f
    internal var scaleCalc = 0f
    internal var translationCalc = 0.0

    /** Last laid-out [MapView] size; used to detect orientation changes and vertical resizes (e.g. timeline settings). **/
    internal var lastWidth = 0
    internal var lastHeight = 0

    /**Usually 60, 90, 120 fps **/
    internal var refreshRate: Float

    /**
     * The primary interface for communicating with the Xweather backend.
     *
     * This service handles the construction of API requests, authentication
     * using the provided [account] credentials, and the retrieval of
     * weather data for the various layers and data sources managed by this controller.
     */
    val service: WeatherService = WeatherService(account)

    init {

        // added 260311 for individual layer anim

        // Example: Tracking the pending list
        TileList.pendingList.listener = object : LayerTileList.TileListListener {
            override fun onListStarted() {
                if (pr.ON) pr.p(
                    "MapboxMapController",
                    pr.download26,
                    "Downloads started: Showing progress bar..."
                )
                // UI code: progressBar.visibility = View.VISIBLE
                triggerLoadStart()
            }

            override fun onListEmpty() {
                if (pr.ON) {
                    pr.p(
                        "MapboxMapController",
                        pr.download26,
                        "TileList pending queue empty (HTTP + decode done for tracked intervals). " +
                                "Progress UI still waits for GPU bind (Timeline pending map).",
                    )
                }
                // pendingList clears when bytes are received and processed, while textures may not be
                // bound yet. The primary completion trigger is [Timeline.pendingEncodedDownloadsLiveData]
                // emptying after bindTextures() (below) — but that observer only re-checks when *that*
                // map changes. If this list (HTTP-in-flight) drains *after* the last encoded-map update,
                // nothing re-fires it and the load indicator sticks at its last percent forever.
                Timeline.calcDLPercent(0)
                postProgressIfLoadConfirmed()
                // When the map is otherwise idle, Mapbox may not render again; nudge a repaint so
                // [MapboxLayerHost.bindTextures] can drain the bind queue (max binds/frame) and clear Timeline pending.
                controllerMainScope.launch {
                    redraw()
                }
                // Safe to call speculatively: triggerLoadComplete() re-checks both queues internally and
                // bails out if either is still non-empty (e.g. GPU bind not done yet), so this only
                // actually completes the session when it is genuinely finished.
                triggerLoadComplete()
            }

            override fun onSubListEmpty(layerId: String) {
                if (pr.ON) pr.p("MapboxMapController", pr.download26, "All downloads finished: Hiding progress bar.")
            }

            override fun onTick() {
                // This prints every 0.5 seconds while items exist in pendingList

                val pendingCount = TileList.pendingList.countAllEntries()
                Timeline.calcDLPercent(pendingCount)
                postProgressIfLoadConfirmed()

                if (pr.ON) {
                    if (Timeline.currentDLCount != 0)
                        pr.p(
                            "MapboxMapController",
                            pr.download26,
                            "Still downloading ${pendingCount}/${Timeline.currentDLCount}  " +
                                    "----- ${Timeline.pendingPercent}% ----- "
                        )
                    else {
                        pr.p(
                            "MapboxMapController",
                            pr.download26,
                            "Still downloading ${pendingCount}) "
                        )
                    }

                }
            }
        }

        // end added 260311 for individual layer anim

        // Setup the listener for option changes
        timeline.opts.onPreloadChanged = { isEnabled ->
            if (isEnabled) {
                viewModelScope.launch {
                    preloadVisibleTiles()
                }
            }
        }

        val timelineAdvanceListener: (Any) -> Unit = {
            // This runs on the thread the timeline uses
            //binding.timelineView.timelineControls.setPosition(controller.timeline.position)

            if (dataInspector.isActive == true) {
                currentTime = System.currentTimeMillis()
                if (currentTime - lastUpdated > minimumDIUpdateInterval) {
                    lastUpdated = currentTime
                    val lifecycleOwner = mapView.findViewTreeLifecycleOwner()
                    lifecycleOwner?.lifecycleScope?.launch(Dispatchers.Main) { //260226 was .Main
                        //MapsGLDebug.trace(">> CALLING update()")
                        dataInspector.update()
                    }
                }
            }
        }
        timeline.on(AnimationEvent.advance, timelineAdvanceListener)

        packageName = mapView.context.packageName
        setZoom(1.0)
        refreshRate = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
            getScreenRefreshRate(mapView.context)
        else 60f

        Timeline.frameRate = refreshRate

        // Update the `timeRange` property on data sources when the timeline range changes
        timeline.on(AnimationEvent.range_change) {
            sources.values.forEach {
                if (it is TileSource<*>) {
                    if (pr.ON) pr.p(TAG, pr.timeLineListener, "range change:")
                    it.timeRange = timeline.start..timeline.end
                }
            }
        }

        timeline.on(AnimationEvent.INTERVAL_CHANGE) {
            val vt = parseDateArrayFromString(timeStrings[Timeline.currentPhaseA]).first()
            layers.forEach {
                val source = it.value.source
                if (source is VectorTileSource && source !is EncodedGridVectorTileSource) {
                    source.validTime = vt
                    if (!animatingTimeline) {
                        source.invalidate()
                    }
                }
            }
            forEachEncodedGridVectorTileSource { grid ->
                grid.validTime = vt
                if (!animatingTimeline) {
                    grid.invalidate()
                }
            }
        }

        Timeline.pendingVectorDownloadsLiveData.observe(
            this.mapView.context as LifecycleOwner
        ) { count ->
            if (count == 0) {
                //MapsGLDebug.trace(">> MapController Vector DONE LOADING!!!!!!")
                if (layers.values.any {
                        val source = it.source as? VectorTileSource
                        source?.dlCount == 1
                    }) {
                    if (dataInspector.on) {
                        dataInspector.updateVector()
                    }

                }
                //timeline.setIsDownloading(false)
            }
        }

        Timeline.pendingEncodedDownloadsLiveData.observe(
            mapView.findViewTreeLifecycleOwner() ?: (mapView.context as LifecycleOwner)
        ) { hashMap ->
            if (hashMap.isNotEmpty()) {
                val pendingTotal = hashMap.values.sumOf { it.size }
                val completedAny = pendingTotal < lastPendingEncodedTotal
                lastPendingEncodedTotal = pendingTotal

                val target = dataInspector.targetCoordinate
                val diActive = dataInspector.on && dataInspector.isActive && target != null
                val now = System.currentTimeMillis()
                if (completedAny && diActive && now - lastDIUpdateOnEncodedTileLoadAt > minimumDIUpdateIntervalOnEncodedTileLoadMs) {
                    lastDIUpdateOnEncodedTileLoadAt = now
                    dataInspector.update()
                }

                Timeline.calcDLPercent(TileList.pendingList.countAllEntries())
                postProgressIfLoadConfirmed()

                // Start tracking if not already started
                if (downloadStartTime == 0L) {
                    downloadStartTime = System.currentTimeMillis()
                    downloadTrackingHandler.post(downloadTrackingRunnable)
                    if (pr.ON) pr.p(TAG, pr.loadTracking, "Downloads started. Timer initiated.")
                }
                //timeline.setIsDownloading(true)
                // [TileList.pendingList]'s onListStarted is edge-triggered on that HTTP queue going
                // 0 -> nonzero. A zoom during active playback overlaps the new zoom level's burst
                // with still-draining requests from the old level, so that queue never actually
                // hits zero and the edge never fires — the spinner silently never appears for a
                // real, large wave. This encoded-pending map is the source of truth for genuine
                // work; triggerLoadStart() already no-ops when a session is confirmed/pending/
                // suppressed, so calling it here on every update is safe and catches that case.
                triggerLoadStart()
            } else {
                lastPendingEncodedTotal = 0
                // During timeline animation, encoded pending can briefly empty between phase waves
                // (one batch bound, next batch not yet scheduled). If HTTP is still in flight in
                // [TileList.pendingList], that means more encoded tiles will be scheduled shortly;
                // firing [triggerLoadComplete] now would prematurely hide the load indicator.
                // The 700ms debounce inside [triggerLoadComplete] is not enough across long gaps.
                val httpStillInFlight = TileList.pendingList.countAllEntries() > 0
                if (httpStillInFlight) {
                    if (pr.ON) pr.p(
                        TAG,
                        pr.loadTracking,
                        "Encoded pending empty but HTTP still in flight; deferring loadComplete",
                    )
                    return@observe
                }
                if (encodedGpuBindQueueBusy()) {
                    if (pr.ON) pr.p(
                        TAG,
                        pr.loadTracking,
                        "Encoded pending empty but GPU bind queue still draining; deferring loadComplete",
                    )
                    // Keep requesting frames so [bindTextures] can finish the residency set.
                    redraw()
                    return@observe
                }
                // CLEANUP: Stop the timer and reset start time
                downloadTrackingHandler.removeCallbacks(downloadTrackingRunnable)
                val totalSeconds = (System.currentTimeMillis() - downloadStartTime) / 1000
                downloadStartTime = 0L
                //MapsGLDebug.trace(">>> MapController: All downloads finished! Total time: $totalSeconds seconds.")
                //timeline.setIsDownloading(false)
                triggerLoadComplete()
            }
        }

    } // end init{}

    /**
     * Triggers a manual pre-fetch of tile animation data.
     *
     * This function caches tiles for the visible viewport across the timeline's active
     * time range.
     * This is typically used to ensure smooth playback and minimize loading time
     */
    fun preloadAnimationData() {
        viewModelScope.launch {
            try {
                Timeline.fullTimelinePreloadActive = true
                animationOptions.forcePreloadOneTime = true
                preloadVisibleTiles()
            } finally {
                animationOptions.forcePreloadOneTime = false
                Timeline.fullTimelinePreloadActive = false
            }
        }
    }

    /**
     * After land/water-mask demos add a weather layer with a paused timeline, wait for camera idle
     * and (on Mapbox) the custom style layer, then prefetch encoded tiles with current bounds.
     */
    internal suspend fun awaitCameraIdleForDemoSetup(maxWaitMs: Long = 6_000L) {
        val deadline = System.currentTimeMillis() + maxWaitMs
        while (cameraTriggered && System.currentTimeMillis() < deadline) {
            delay(50)
        }
    }

    /**
     * One-shot encoded setup for paused land/water mask demos: refresh bounds and fetch encoded
     * tiles for the **current scrub position** only (not the full timeline range).
     *
     * Do not set [AnimationOptions.forcePreloadOneTime] here — that flag makes
     * [com.xweather.mapsgl.tiles.TilePyramid.resolveDownloadTimes] use
     * [filterTimelineByValidTimes] (every valid time in the animation window), which looks like
     * full animation preload on demo entry.
     */
    internal suspend fun preloadPausedDemoEncodedTiles(layerId: String) {
        getLayer(layerId)?.let { layer ->
            if (layer.visible && layer is TileLayer) {
                layer.bounds = getBounds()
            }
        }
        preloadVisibleTiles()
        refreshVisibleLayers(requestDL = true)
    }

    /**
     * Ensures the invisible Mapbox fetch layer for [GlStencilOsm] exists and seeds a small tile
     * neighborhood. Call after adding a stencil-only motorway mask layer and before the weather layer.
     */
    fun warmCustomMaskVectorTileSource() {
        (this as? com.xweather.mapsgl.map.mapbox.MapboxMapController)?.ensureGlStencilBaseOsmFetchLayer()
    }

    /**
     * Queue [GlStencilOsm] MVT fetches for the tiles that cover the current viewport. Custom line
     * masks (motorways) need these bytes before ALL-mode intersection can draw anything.
     */
    internal fun prefetchCustomMaskVectorTilesForLayer(layerId: String) {
        val mapbox = this as? com.xweather.mapsgl.map.mapbox.MapboxMapController ?: return
        val layer = getLayer(layerId) as? TileLayer ?: return
        layer.bounds = getBounds()
        val coords = layer.visibleTileCoordsForSidecarSampling()
        if (coords.isEmpty()) return
        mapbox.ensureGlStencilBaseOsmFetchLayer()
        mapbox.schedulePrefetchGlStencilOsmTilesForCustomMask(coords)
    }

    /**
     * True when every custom mask layer in [EncodedTileLayer.stencilLayerMask] has a CPU mesh for
     * each visible weather tile. Needed for ALL-mode intersection and for inverted single-layer
     * masks ([LayerMasks.land] / [LayerMasks.water]) — those call [failOpenNoStencil] when mesh
     * geometry is missing, which looks like an unmasked layer.
     */
    internal fun customStencilMaskMeshesReadyForVisibleTiles(layerId: String): Boolean {
        val layer = getLayer(layerId) as? EncodedTileLayer ?: return true
        val spec = layer.stencilLayerMask ?: return true
        if (spec.layers.isEmpty()) return true
        layer.bounds = getBounds()
        val coords = layer.visibleTileCoordsForSidecarSampling()
        if (coords.isEmpty()) return false
        val cache = glStencilMaskTileCache
        return coords.all { coord ->
            val key = coord.hash()
            spec.layers.all { ref ->
                val mesh = cache.getCpuMeshForCustomMask(ref.layerId, key)
                mesh != null && mesh.first.vertexCount >= 3
            }
        }
    }

    /**
     * Land/water mask demos start paused; encoded preload must run only after the custom Mapbox
     * layer exists and the camera has settled (fixes partial tiles on menu → demo re-entry).
     */
    fun schedulePausedDemoLandWaterMaskRefresh(layerId: String) {
        // Must compare to [Timeline.mapSessionId], not [mapSessionId]: each controller keeps its
        // construction-time id forever, so a finished Demo 2 coroutine would otherwise still think
        // its session is valid after Demo 3 starts and corrupt stencil / encoded preload state.
        val session = mapSessionId
        val refreshGen = maskDemoRefreshGeneration
        val mapbox = this as? com.xweather.mapsgl.map.mapbox.MapboxMapController
        controllerMainScope.launch {
            awaitCameraIdleForDemoSetup()
            if (session != Timeline.mapSessionId || !maskDemoRefreshStillValid(refreshGen)) return@launch
            if (getLayer(layerId) == null) return@launch
            mapbox?.finalizeBuiltInGlStencilMask(layerId)
            var styleAttempts = 0
            while (mapbox?.mapboxMap?.style?.styleLayerExists(layerId) != true && styleAttempts < 120) {
                delay(50)
                if (session != Timeline.mapSessionId || !maskDemoRefreshStillValid(refreshGen)) return@launch
                styleAttempts++
            }
            if (!maskDemoRefreshStillValid(refreshGen) || getLayer(layerId) == null) return@launch
            if (mapbox?.mapboxMap?.style?.styleLayerExists(layerId) == true) {
                preloadPausedDemoEncodedTiles(layerId)
            }
            mapbox?.requestRepaintCoalesced()
            mapbox?.mapboxMap?.triggerRepaint()
        }
    }

    /**
     * Instanced gridded layers (wind arrows / barbs) need encoded tiles fetched **after** the Mapbox
     * persistent custom layer exists. [addToMap] can call [refreshVisibleLayers] too early; schedule this
     * from demo activities right after [addWeatherLayer].
     */
    fun scheduleInstancedGriddedLayerEncodedRefresh(layerId: String) {
        val session = mapSessionId
        val refreshGen = maskDemoRefreshGeneration
        val mapbox = this as? com.xweather.mapsgl.map.mapbox.MapboxMapController
        controllerMainScope.launch {
            awaitCameraIdleForDemoSetup()
            if (session != Timeline.mapSessionId || !maskDemoRefreshStillValid(refreshGen)) return@launch
            if (getLayer(layerId) == null) return@launch
            var styleAttempts = 0
            while (mapbox?.mapboxMap?.style?.styleLayerExists(layerId) != true && styleAttempts < 120) {
                delay(50)
                if (session != Timeline.mapSessionId || !maskDemoRefreshStillValid(refreshGen)) return@launch
                styleAttempts++
            }
            if (!maskDemoRefreshStillValid(refreshGen) || getLayer(layerId) == null) return@launch
            if (mapbox?.mapboxMap?.style?.styleLayerExists(layerId) == true) {
                preloadPausedDemoEncodedTiles(layerId)
                val tileLayer = getLayer(layerId) as? TileLayer
                (tileLayer?.tileLayerRenderer as? GridLayerRenderer)?.setNeedsUpdate(true)
                tileLayer?.setNeedsUpdate(force = true)
            }
            mapbox?.requestRepaintCoalesced()
            mapbox?.mapboxMap?.triggerRepaint()
        }
    }

    /**
     * Custom [StencilLayerMaskSpec] / [LayerMaskSpec] demos need the Mapbox persistent custom layer,
     * mask geometry, and encoded weather tiles before the first paint. Schedule after
     * [addWeatherLayer] when the camera may still be moving (e.g. [setCenter] / [setZoom]).
     *
     * @param waitForMaskMeshes When true, poll until every custom mask layer has stencil CPU meshes
     * for visible tiles. Required for ALL-mode intersection, [LayerMasks.land], and [LayerMasks.water]
     * (inverted masks call [failOpenNoStencil] while MVT geometry is still loading).
     */
    fun scheduleCustomStencilMaskDemoRefresh(
        layerId: String,
        waitForMaskMeshes: Boolean = false,
    ) {
        val session = mapSessionId
        val refreshGen = maskDemoRefreshGeneration
        val mapbox = this as? com.xweather.mapsgl.map.mapbox.MapboxMapController
        controllerMainScope.launch {
            awaitCameraIdleForDemoSetup()
            if (session != Timeline.mapSessionId || !maskDemoRefreshStillValid(refreshGen)) return@launch
            if (getLayer(layerId) == null) return@launch
            var styleAttempts = 0
            while (mapbox?.mapboxMap?.style?.styleLayerExists(layerId) != true && styleAttempts < 120) {
                delay(50)
                if (session != Timeline.mapSessionId || !maskDemoRefreshStillValid(refreshGen)) return@launch
                if (getLayer(layerId) == null) return@launch
                styleAttempts++
            }
            if (!maskDemoRefreshStillValid(refreshGen) || getLayer(layerId) == null) return@launch
            prefetchCustomMaskVectorTilesForLayer(layerId)
            mapbox?.reregisterCustomStencilMask(layerId, forceInvalidate = true)
            if (mapbox?.mapboxMap?.style?.styleLayerExists(layerId) == true) {
                preloadPausedDemoEncodedTiles(layerId)
            }
            if (waitForMaskMeshes) {
                var meshAttempts = 0
                while (meshAttempts < 150) {
                    if (session != Timeline.mapSessionId ||
                        !maskDemoRefreshStillValid(refreshGen) ||
                        getLayer(layerId) == null
                    ) {
                        return@launch
                    }
                    if (customStencilMaskMeshesReadyForVisibleTiles(layerId)) break
                    prefetchCustomMaskVectorTilesForLayer(layerId)
                    mapbox?.reregisterCustomStencilMask(layerId)
                    delay(100)
                    meshAttempts++
                }
                if (session != Timeline.mapSessionId ||
                    !maskDemoRefreshStillValid(refreshGen) ||
                    getLayer(layerId) == null
                ) {
                    return@launch
                }
                preloadPausedDemoEncodedTiles(layerId)
            }
            if (session != Timeline.mapSessionId ||
                !maskDemoRefreshStillValid(refreshGen) ||
                getLayer(layerId) == null
            ) {
                return@launch
            }
            mapbox?.reregisterCustomStencilMask(layerId)
            mapbox?.requestRepaintCoalesced()
            mapbox?.mapboxMap?.triggerRepaint()
        }
    }

    /**
     * Activates and initializes the Data Inspector control for the map.
     *
     * This function enables the "pick" or "inspect" mode which allows users to retrieve
     * underlying weather data values from specific coordinates on the map. It ensures
     * that listeners are only initialized once and sets up the synchronization
     * for vector data updates.
     *
     * After installation, you may set [DataInspectorControl.cancelCalloutWhenOffScreen] on the returned
     * instance (or on [dataInspector]) to choose whether the callout is dismissed when the picked point
     * pans off-screen (`true`, default) or only hidden with [View.INVISIBLE] while staying active (`false`).
     *
     * @param mapView The [MapView] instance where the data inspector UI should be hosted.
     * @return The initialized [DataInspectorControl] instance.
     */
    fun addDataInspectorControl(mapView: MapView): DataInspectorControl {
        if (!dataInspector.on) {
            dataInspector.initializeListeners(this)

            val listener: (Any) -> Unit = {
                dataInspector.updateVector()
            }
            dataInspectorVectorUpdateListener = listener
            this.on(DataInspectorEvent.VECTOR_UPDATE, listener)
        }

        dataInspector.on = true
        return dataInspector
    }

    /**
     * Deactivates the Data Inspector control and cleans up its associated resources.
     *
     * This function performs the following cleanup steps:
     * 1. Sets the [DataInspectorControl.on] state to `false`.
     * 2. Triggers the UI to hide its overlay/view components.
     * 3. Unregisters all event listeners (such as `VECTOR_UPDATE`) previously attached
     *    to this [MapController] to prevent memory leaks and unnecessary background processing.
     *
     * Call this when the user exits "inspection" or "picker" mode.
     */
    fun removeDataInspectorControl() {
        dataInspector.on = false
        dataInspector.hide()
        dataInspectorVectorUpdateListener?.let { listener ->
            off(DataInspectorEvent.VECTOR_UPDATE, listener)
        }
        dataInspectorVectorUpdateListener = null
        dataInspector.removeEvents(this)
        //dataInspector = null
    }

    /**
     * Returns whether the map currently contains a weather layer with the specified identifier.
     * @param code Weather product to check.
     * @return `true` if that product (or every sub-layer of a composite) is present.
     */
    fun hasWeatherLayer(code: LayerCode): Boolean {
        // If code corresponds to a composite layer, then iterate through the composite's layers and check if all layers exist.
        val config = LayerCode.getConfigurationForLayerCode(code, service)
        if (config is CompositeWeatherLayerConfiguration) {
            val results = config.layers.map { hasWeatherLayer(it.code) }
            return results.all { it }
        }
        return layerIdsByWeatherCode[code] != null
    }

    /**
     *
     * Returns A layer given its LayerCode.
     *
     * example: LayerCode.Temperatures
     *
     * @param code Weather product to resolve.
     * @return The single [MapLayer] for that code, or `null` if missing or if multiple layers share the same code.
     */
    fun getWeatherLayer(code: LayerCode): MapLayer<*, *>? {
        layerIdsByWeatherCode[code]?.let {
            if (it.size > 1) {
                MapsGLDebug.trace(
                    "[MapsGL] There are multiple layers associated with the weather code ${code.value}: ${
                        it.joinToString(
                            ", "
                        )
                    }"
                )
                return null
            }
            return getLayer(it.first())
        }
        return null
    }

    /**
     * Adds a weather layer from a [LayerCode] preset (source + descriptor + paint from [service]).
     *
     * @param layerCode Built-in or configured weather product.
     * @param id Optional stable id prefix; composite children get derived ids.
     * @param beforeId Optional existing layer id to insert below in the stack.
     * @param configure Optional callback to adjust the configuration before layers are added.
     * Each call receives a **new** configuration instance (safe to mutate). Example — motorways
     * with stroke thickness 5 (JS `paint.stroke.thickness`):
     * ```
     * controller.addWeatherLayer(LayerCode.ROAD_MOTORWAY) { it.setLineStrokeThickness(5.0) }
     * ```
     * For [CompositeWeatherLayerConfiguration], [configure] receives the composite; use
     * [com.xweather.mapsgl.weather.setLineStrokeThicknessOnAllLineLayers] or edit
     * [CompositeWeatherLayerConfiguration.layers] explicitly.
     * @return The primary new [TileLayer], or `null` if configuration is invalid.
     */
    fun addWeatherLayer(
        layerCode: LayerCode,
        id: String? = null,
        beforeId: String? = null,
        configure: ((WeatherConfiguration) -> Unit)? = null,
    ): TileLayer? {
        val configuration = LayerCode.getConfigurationForLayerCode(layerCode, service)
        configure?.invoke(configuration)
        return addWeatherLayer(configuration, id, beforeId)
    }

    /**
     * Adds a weather layer from an explicit [WeatherConfiguration] (use when you built the config
     * from [WeatherService] factories instead of [LayerCode]).
     *
     * @param config Source + layer descriptor + optional legend; composites recurse into sub-configs.
     * @param id Optional id prefix for the new layer(s).
     * @param beforeId Optional insertion anchor in the layer stack.
     * @param isCompoundLayer Internal flag when recursing for composite layers.
     * @return The primary new [TileLayer], or `null` if the configuration cannot be applied.
     */
    fun addWeatherLayer(
        config: WeatherConfiguration,
        id: String? = null,
        beforeId: String? = null,
        isCompoundLayer: Boolean = false
    ): TileLayer? {
        if (config is CompositeWeatherLayerConfiguration) {
            var addedLayer: TileLayer? = null
            for (subConfig in config.layers) { // subConfig is AnyWeatherLayerConfiguration
                //val subId = if (id != null) "${id}__${subConfig.code.value}" else null // old code, always null
                val subId =
                    if (id != null) "${id}__${subConfig.code.value}" else "${config.code.name}__${subConfig.code.value}"
                // Recursive call, subConfig is still AnyWeatherLayerConfiguration
                val result = addWeatherLayer(subConfig, subId, beforeId, true)
                result?.code = config.code.value // Use the composite's code
                if (addedLayer == null && result != null) {
                    addedLayer = result
                }
            }

            setPresentation(config, addedLayer)
            trigger(MapControllerEvents.LAYER_ADDED, (addedLayer is VectorTileLayer))
            return addedLayer
        }

        // We expect a WeatherLayerConfiguration<S, LD, P> here for individual layers.
        // If LayerCode.getConfigurationForLayerCode returns a non-generic WeatherConfiguration,
        // you might need to reconsider its return type or handle it.
        // For now, let's assume if it's not Composite, it's our generic WeatherLayerConfiguration.
        if (config !is WeatherLayerConfiguration<*, *>) { // Check against the generic form
            MapsGLDebug.trace("[MapsGL] Warning: addWeatherLayer received a WeatherConfiguration that is not a WeatherLayerConfiguration for ${config.code.value}. Layer not added.")
            return null
        }
        val userLayerMask = effectiveLayerMaskSpecForBitmapDescriptor(config.layer)
        userLayerMask?.let { userMask ->
            val resolved = resolveUserLayerMaskSpec(userMask, beforeId)
            if (resolved != null) {
                setCustomStencilOnLayerDescriptor(config.layer, resolved)
            } else if (!userMask.layers.any(::isBuiltinLandMaskRef)) {
                MapsGLDebug.trace("[MapsGL] layerMask resolved to no usable layers for ${config.code.value}")
            }
        }
        // Now 'config' is known to be WeatherLayerConfiguration<S, LD, P>
        // S, LD, P are star-projected here but will be specific if the `config` instance was created that way.

        getWeatherLayer(config.code)?.let {
            moveLayer(it.id, beforeId)
            setLayerVisible(it.id, true)
            trigger(MapControllerEvents.VISIBILITY_CHANGED, it.id)
            if (this is MapboxMapController) {
                val layerDescriptorEarly = config.layer
                val customStencilEarly = when (layerDescriptorEarly) {
                    is SampleLayerDescriptor -> layerDescriptorEarly.stencilLayerMask
                    is ContourLayerDescriptor -> layerDescriptorEarly.stencilLayerMask
                    is ParticleLayerDescriptor -> layerDescriptorEarly.stencilLayerMask
                    is GridLayerDescriptor -> layerDescriptorEarly.stencilLayerMask
                    else -> null
                }
                if (customStencilEarly != null &&
                    (customStencilEarly.layers.isNotEmpty() || customStencilEarly.clipBounds != null)
                ) {
                    val enc = it as? EncodedTileLayer
                    if (enc != null) {
                        val maskKindEarly = when (val ld = config.layer) {
                            is SampleLayerDescriptor -> ld.mask
                            is ContourLayerDescriptor -> ld.mask
                            is ParticleLayerDescriptor -> ld.mask
                            is GridLayerDescriptor -> ld.mask
                            else -> MaskLayerKind.NONE
                        }
                        val hybridEarly = isHybridLandLineStencil(maskKindEarly, customStencilEarly, layers) ||
                            (userLayerMask != null && isLayerMaskLandPlusCustomLines(userLayerMask, customStencilEarly))
                        enc.stencilLayerMask = customStencilEarly
                        enc.hybridLandWithCustomLineMask = hybridEarly
                        if (hybridEarly) {
                            userLayerMask?.let { applyLayerMaskHybridLandLineFlags(enc, it, customStencilEarly) }
                        } else {
                            enc.glStencilMaskKind = MaskLayerKind.NONE
                        }
                        if (customStencilEarly.layers.isNotEmpty()) {
                            GlStencilCustomMaskCoordinator.register(this, enc.id, customStencilEarly)
                        }
                    }
                }
            }

            // Do not call add() again when the layer already exists: add() increments legendRefCounts
            // but only attaches one LegendView, so a second add leaves refcount > 1 and removeWeatherLayer
            // removes the map layer once while the legend stays (ref never reaches 0).
            if (config.legend != null) {
                val legend = config.legend!!
                if (legendControl?.getLegend(legend.id) == null) {
                    legendControl?.add(legend)
                }
            }

            return it as TileLayer // Assuming all weather layers are TileLayers
        }

        val insertBeforeId: String? = beforeId

        // Add the source from the configuration
        addSource(config.source) // config.source is SourceDescriptor (S)
        val layerDescriptor = config.layer

        // Special handling for EncodedSourceDescriptor and paint properties
        // This section becomes much cleaner as 'layerDescriptor.paint' is now specifically typed.
        if (config.source is EncodedSourceDescriptor) {
            val source = config.source as EncodedSourceDescriptor // Cast for dataset access
            val paint = layerDescriptor.paint

            val channels = when (paint) {
                is SampleLayerPaint -> paint.sample.channel
                is ParticleLayerPaint -> paint.sample.channel
                is ContourLayerPaint -> paint.sample.channel
                is GridLayerPaint -> paint.sample?.channel ?: emptyList()
                else -> emptyList()
            }

            if (channels.isNotEmpty()) {
                val datasetRange = source.datasets?.get(channels[0].rawValue)?.dataRange
                val paintColorRange =
                    datasetRange?.let { range ->
                        val expression = when (paint) {
                            is SampleLayerPaint -> paint.sample.expression
                            is ParticleLayerPaint -> paint.sample.expression
                            is ContourLayerPaint -> paint.sample.expression
                            is GridLayerPaint -> paint.sample?.expression ?: SampleExpression.NUMBER
                            else -> SampleExpression.NUMBER
                        }
                        colorScaleRangeForMagnitudeLookup(expression, range)
                    }
                when (paint) {
                    is ContourLayerPaint -> {
                        if (pr.ON) pr.p(TAG, pr.contour, "addWeatherLayer() detected contourLayerPaint 300 ")
                        if (paint.sample.colorScale.range == null) {
                            paint.sample.colorScale.range = paintColorRange
                        }
                        if (paint.sample.expression != SampleExpression.DIFFERENCE) {
                            paint.sample.colorScale.range = paintColorRange
                        }
                        val tempQuality = paint.sample.quality
                        zoomOffset = 0
                    }

                    is SampleLayerPaint -> {
                        if (paint.sample.colorScale.range == null) {
                            paint.sample.colorScale.range = paintColorRange
                        }
                        if (paint.sample.expression != SampleExpression.DIFFERENCE) {
                            paint.sample.colorScale.range = paintColorRange
                        }
                        val tempQuality = paint.sample.quality
                        zoomOffset = 0
                    }

                    is ParticleLayerPaint -> {
                        paint.sample.colorScale.range = paintColorRange
                        val tempQuality = paint.sample.quality
                        zoomOffset = 0
                    }

                    is GridLayerPaint -> {
                        paint.sample?.let { sp ->
                            if (sp.colorScale.range == null) {
                                sp.colorScale.range = paintColorRange
                            }
                            if (sp.expression != SampleExpression.DIFFERENCE) {
                                sp.colorScale.range = paintColorRange
                            }
                            zoomOffset = 0
                        }
                    }

                    else -> {}
                }
            }
        }

        val layer = addLayer(layerDescriptor, insertBeforeId) ?: return null // Pass the correctly typed layerDescriptor

        if (!isCompoundLayer) {
            if (pr.ON) pr.p(TAG, pr.vectorRefactor, "triggering LAYER_ADDED from addweatherLayer() NORMALLY")
            trigger(MapControllerEvents.LAYER_ADDED, (layer is VectorTileLayer))
        }


        if (layerIdsByWeatherCode[config.code] == null) {
            layerIdsByWeatherCode[config.code] = mutableListOf()
        }
        layerIdsByWeatherCode[config.code]?.add(layer.id)
        layer.code = config.code.value

        if (this is MapboxMapController) {
            val customStencilSpec = when (layerDescriptor) {
                is SampleLayerDescriptor -> layerDescriptor.stencilLayerMask
                is ContourLayerDescriptor -> layerDescriptor.stencilLayerMask
                is ParticleLayerDescriptor -> layerDescriptor.stencilLayerMask
                is GridLayerDescriptor -> layerDescriptor.stencilLayerMask
                else -> null
            }
            if (layer is EncodedTileLayer &&
                customStencilSpec != null &&
                (customStencilSpec.layers.isNotEmpty() || customStencilSpec.clipBounds != null)
            ) {
                val maskKindForHybrid = when (layerDescriptor) {
                    is SampleLayerDescriptor -> layerDescriptor.mask
                    is ContourLayerDescriptor -> layerDescriptor.mask
                    is ParticleLayerDescriptor -> layerDescriptor.mask
                    is GridLayerDescriptor -> layerDescriptor.mask
                    else -> MaskLayerKind.NONE
                }
                val userMaskForHybrid = effectiveLayerMaskSpecForBitmapDescriptor(layerDescriptor)
                val hybridLandHighway = isHybridLandLineStencil(maskKindForHybrid, customStencilSpec, layers) ||
                    (userMaskForHybrid != null && isLayerMaskLandPlusCustomLines(userMaskForHybrid, customStencilSpec))
                layer.stencilLayerMask = customStencilSpec
                layer.hybridLandWithCustomLineMask = hybridLandHighway
                if (hybridLandHighway) {
                    if (layer is EncodedTileLayer && userMaskForHybrid != null) {
                        applyLayerMaskHybridLandLineFlags(layer, userMaskForHybrid, customStencilSpec)
                    }
                } else {
                    layer.glStencilMaskKind = MaskLayerKind.NONE
                }
                if (customStencilSpec.layers.isNotEmpty()) {
                    GlStencilCustomMaskCoordinator.register(this, layer.id, customStencilSpec)
                }
            }
            var maskKindFromDescriptor: MaskLayerKind? = when (layerDescriptor) {
                is SampleLayerDescriptor -> layerDescriptor.mask
                is ContourLayerDescriptor -> layerDescriptor.mask
                is ParticleLayerDescriptor -> layerDescriptor.mask
                is GridLayerDescriptor -> layerDescriptor.mask
                else -> null // Or MaskLayerKind.NONE if that makes more sense to avoid a null check later
            }
            if (maskKindFromDescriptor != null && maskKindFromDescriptor != MaskLayerKind.NONE) {
                val useCustomStencilOnly =
                    customStencilSpec != null &&
                        (customStencilSpec.layers.isNotEmpty() || customStencilSpec.clipBounds != null) &&
                        !(layer is EncodedTileLayer && layer.hybridLandWithCustomLineMask)
                if (!useCustomStencilOnly) {
                    val countryIsoParam =
                        if (maskKindFromDescriptor == MaskLayerKind.COUNTRY) {
                            GlStencilCountryMask.normalizeIso(
                                maskCountryIsoFromLayerDescriptor(layerDescriptor),
                            )
                        } else {
                            null
                        }
                    if (maskKindFromDescriptor == MaskLayerKind.COUNTRY && countryIsoParam == null) {
                        MapsGLDebug.trace(
                            "[GlStencilMask] COUNTRY mask requires maskCountryIso3166Alpha2 " +
                                "on the layer descriptor (e.g. \"US\", \"ES\")",
                        )
                    } else {
                        GlStencilMaskCoordinator.ensureBaseOsmMaskConsumer(
                            this,
                            service,
                            maskKindFromDescriptor,
                            countryIsoParam,
                        )
                        if (layer is EncodedTileLayer) {
                            layer.glStencilMaskKind = maskKindFromDescriptor
                            layer.glStencilMaskCountryIso = countryIsoParam
                            if (maskKindFromDescriptor == MaskLayerKind.LAND) {
                                layer.hasLandMask = true
                            }
                        }
                    }
                }
            }
        }

        addLegend(config)
        if (layer.id == "severe.alerts.fill") {
            controllerMainScope.launch {
                delay(1500) // Wait for 2 seconds (non-blocking)
                updateLegendsForMap()
                delay(2500) // Wait for 2 seconds (non-blocking)
                updateLegendsForMap()
                //MapsGLDebug.trace(">>> MaoController MapsGL: 2 seconds have passed for severe alerts, called updateLegendsForMap")
            }
        }

        setPresentation(config, layer)
        return layer
    }

    /**
     * Resolves the [WeatherConfiguration] that would be used for [addWeatherLayer] with this [layerCode].
     */
    fun getConfigForCode(layerCode: LayerCode): WeatherConfiguration {
        return LayerCode.getConfigurationForLayerCode(layerCode, service)
    }

    /**
     * Shows or hides every map layer (and optional legend) belonging to [code], including composite children.
     *
     * @param code Weather product to affect.
     * @param visible `true` to show and request tiles; `false` to hide and detach legend if configured.
     */
    fun setWeatherLayerVisibility(code: LayerCode, visible: Boolean) {
        // Check if the code corresponds to a composite layer. If so, then iterate through each of its layers and set the visibility.
        val config = LayerCode.getConfigurationForLayerCode(code, service)
        if (config is CompositeWeatherLayerConfiguration) {
            config.layers.forEach { setWeatherLayerVisibility(it.code, visible) }
            trigger(MapControllerEvents.VISIBILITY_CHANGED, config.code)
            return

        }

        getWeatherLayer(code)?.let {
            if (visible) {
                it.show()
            } else {
                it.hide()
                if ((config is WeatherLayerConfiguration<*, *>)) {
                    config.legend?.let { it1 ->
                        legendControl?.removeLegend(it1.id)
                    }
                }
            }

            setLayerVisible(it.id, visible)

            if (this is MapboxMapController) {
                MapsGLDebug.trace(">>> MapController: setWeatherLayerVisibility() calling showOrHideLandMask()")
                this.showOrHideLandMask(it.id)
            }
            trigger(MapControllerEvents.VISIBILITY_CHANGED, it.id)
        }
    }

    /**
     * Removes the weather layer(s) for [code] from the map, sources, legends, and mask sidecars as needed.
     */
    fun removeWeatherLayer(code: LayerCode) {
        val config = LayerCode.getConfigurationForLayerCode(code, service)

        if (config is CompositeWeatherLayerConfiguration) {
            for (subConfig in config.layers) {
                removeLayer(subConfig.layer.id, true)
                layerIdsByWeatherCode[subConfig.code]?.let {
                    layerIdsByWeatherCode.remove(subConfig.code)
                }

                subConfig.legend?.let { it1 -> legendControl?.removeLegend(it1.id) }
            }
            trigger(MapControllerEvents.LAYER_REMOVED, config.layers.first().layer.id)
            return
        }

        layerIdsByWeatherCode[code]?.let {
            if (it.size == 0) return
            if (it.size > 1) {
                // TODO: print warning to console that multiple layers exist for the same layer code
                MapsGLDebug.trace("Warning: Multiple layers exist for the same layer code: $code")
                return
            }

            val layerId = it.first()
            removeLayer(layerId)
            layerIdsByWeatherCode.remove(code)

            //added to try to fix issue 17 crash
            layerHosts.remove(layerId)
            if (pr.ON) pr.p(TAG, pr.lHost, "removeWeatherlayer() $layerId removed")

            if ((config is WeatherLayerConfiguration<*, *>)) {
                val layerDescriptor = config.layer

                if (this is MapboxMapController) {
                    GlStencilCustomMaskCoordinator.unregister(this, layerId)
                    val hadCustomStencilOnly = when (layerDescriptor) {
                        is SampleLayerDescriptor ->
                            layerDescriptor.stencilLayerMask?.let { m ->
                                m.layers.isNotEmpty() || m.clipBounds != null
                            } == true
                        is ContourLayerDescriptor ->
                            layerDescriptor.stencilLayerMask?.let { m ->
                                m.layers.isNotEmpty() || m.clipBounds != null
                            } == true
                        is ParticleLayerDescriptor ->
                            layerDescriptor.stencilLayerMask?.let { m ->
                                m.layers.isNotEmpty() || m.clipBounds != null
                            } == true
                        is GridLayerDescriptor ->
                            layerDescriptor.stencilLayerMask?.let { m ->
                                m.layers.isNotEmpty() || m.clipBounds != null
                            } == true
                        else -> false
                    }
                    val maskKindToRelease = when (layerDescriptor) {
                        is SampleLayerDescriptor -> layerDescriptor.mask
                        is ContourLayerDescriptor -> layerDescriptor.mask
                        is ParticleLayerDescriptor -> layerDescriptor.mask
                        is GridLayerDescriptor -> layerDescriptor.mask
                        else -> MaskLayerKind.NONE
                    }
                    if (maskKindToRelease != MaskLayerKind.NONE && !hadCustomStencilOnly) {
                        val isoRelease =
                            if (maskKindToRelease == MaskLayerKind.COUNTRY) {
                                GlStencilCountryMask.normalizeIso(
                                    maskCountryIsoFromLayerDescriptor(layerDescriptor),
                                )
                            } else {
                                null
                            }
                        GlStencilMaskCoordinator.releaseBaseOsmMaskConsumer(
                            this,
                            service,
                            maskKindToRelease,
                            isoRelease,
                        )
                    }
                }

                config.legend?.let { it1 -> legendControl?.removeLegend(it1.id) }

            }
        }
    }

    private fun setPresentation(config: WeatherConfiguration, layer: TileLayer?) {
        if (layer != null && config is WeatherLayerConfiguration<*, *>) {
            if (config.presentation != null) {
                dataInspector.setPresentation(layer.id, config.presentation!!)
            }
        }
    }

    /**
     * Returns the map's container size.
     */
    override fun getSize(): Size {
        throw Error("Subclasses must override `getSize`")
    }

    /**
     * Returns the map's geographical center coordinate.
     */
    override fun getCenter(): Coordinate {
        throw Error("Subclasses must override `getCenter`")
    }

    /**
     * Sets the map's geographical center coordinate.
     *
     * @param center Latitude/longitude in degrees.
     */
    open fun setCenter(center: Coordinate) {
        throw Error("Subclasses must override `setCenter`")
    }

    /**
     * Visible geographic bounds in latitude/longitude (implementation wraps Mapbox camera).
     *
     * @return South/west/north/east extents used for tile selection and the data inspector.
     */
    override fun getBounds(): LatLonBounds {
        throw Error("Subclasses must override `getBounds`")
    }

    /**
     * Returns the map's current zoom level.
     */
    override fun getZoom(): Double {
        throw Error("Subclasses must override `getZoom`")
        return mapZoom
    }

    /**
     * Sets the map's zoom level.
     *
     * @param zoom Map zoom level understood by the host map SDK.
     */
    open fun setZoom(zoom: Double) {
        throw Error("Subclasses must override `setZoom`")
    }

    /**
     * Returns the map's current rotational bearing in degrees, if supported. A bearing of `0` orients the map so that
     * north is up.
     */
    override fun getBearing(): Double {
        throw Error("Subclasses must override `getBearing`")
    }

    /**
     * Returns the map's current pitch/tilt in degrees, if supported.
     */
    override fun getPitch(): Double {
        throw Error("Subclasses must override `getPitch`")
    }

    /**
     * Returns the map camera's current field-of-view in degrees.
     */
    override fun getFov(): Double {
        throw Error("Subclasses must override `getFov`")
    }

    //==============================================================================================================

    /**
     * [DefaultLifecycleObserver] callback: begins observing raster tile API events for [owner]'s lifetime.
     * Invoked automatically once [registerMapLifecycleObserver] has attached this controller.
     */
    override fun onCreate(owner: LifecycleOwner) {
        // Start observing when the owner is created
        ImageTileSource.apiEvent.observe(owner, ::onRasterTileEvent)
    }

    /**
     * [DefaultLifecycleObserver] callback: resumes timeline playback, tile polling, and custom-layer
     * updates when the host [owner] returns to the foreground. See [resumeFromBackground].
     */
    override fun onStart(owner: LifecycleOwner) {
        resumeFromBackground()
    }

    /**
     * [DefaultLifecycleObserver] callback: pauses timeline playback, tile polling, and custom-layer
     * updates while the host [owner] is backgrounded. See [pauseForBackground].
     */
    override fun onStop(owner: LifecycleOwner) {
        pauseForBackground()
    }

    /**
     * Registers this controller with the [MapView]'s lifecycle (Activity or fragment owner).
     * Safe to call multiple times; typically invoked from [MapboxMapController] after attach.
     */
    fun registerMapLifecycleObserver() {
        if (lifecycleObserverRegistered) return
        val owner = mapView.findViewTreeLifecycleOwner()
            ?: (mapView.context as? LifecycleOwner)
        owner?.lifecycle?.addObserver(this)
        mapLifecycleOwner = owner
        lifecycleObserverRegistered = owner != null
    }

    /** Stops timeline playback, tile polling, and per-frame custom-layer work while backgrounded. */
    internal fun pauseForBackground() {
        if (!mapLifecycleStarted) return
        mapLifecycleStarted = false
        stopCustomLayerUpdates()
        downloadTrackingHandler.removeCallbacks(downloadTrackingRunnable)
        TileList.pendingList.pauseBackgroundPolling()
        if (timeline.state == AnimationState.playing) {
            timeline.pause()
            resumeTimelineAfterLifecycleStop = true
        }
    }

    /** Restores timeline, tile polling, and custom-layer updates after returning to the foreground. */
    internal fun resumeFromBackground() {
        if (mapLifecycleStarted) return
        mapLifecycleStarted = true
        TileList.pendingList.resumeBackgroundPollingIfNeeded()
        if (resumeTimelineAfterLifecycleStop && timeline.state == AnimationState.paused) {
            timeline.resume()
            resumeTimelineAfterLifecycleStop = false
        }
        maybeRestartCustomLayerUpdates()
    }

    internal fun stopCustomLayerUpdates() {
        frameCallback?.let { choreographer.removeFrameCallback(it) }
        frameCallback = null
        customLayerUpdatesHaveStarted = false
    }

    /** True while the choreographer loop should keep posting (timeline motion or visible particles). */
    private fun shouldPostNextCustomLayerFrame(): Boolean {
        if (!mapLifecycleStarted) return false
        if (timeline.state == AnimationState.playing) return true
        if (timeline.seekBarMoved) return true
        if (particleLayers.values.any { it.visible }) return true
        return false
    }

    /**
     * If meld/seek state requires [updateCustomLayer] but the vsync loop was idled, schedule it again.
     * [Timeline.setProgress] sets [Timeline.seekBarMoved] and calls [updateTiles] without [startAnimatingTimeline].
     */
    private fun kickCustomLayerChoreographerIfNeeded() {
        if (!shouldPostNextCustomLayerFrame()) return
        if (frameCallback != null) return
        startCustomLayerUpdates(isParticleLayer = particleLayers.values.any { it.visible })
    }

    private fun maybeRestartCustomLayerUpdates() {
        val hasVisibleParticles = particleLayers.values.any { it.visible }
        if (timeline.state == AnimationState.playing) {
            startCustomLayerUpdates(isParticleLayer = false)
        } else if (hasVisibleParticles) {
            startCustomLayerUpdates(isParticleLayer = true)
        }
    }

    private fun getScreenRefreshRate(context: Context): Float {
        if (Build.VERSION.SDK_INT >= 30)
            return context.display.refreshRate ?: 60f
        else return 60f
    }

    /**
     * Observes encoded-tile metadata keys; when a layer id is emitted, that [TileLayer] refreshes visible tiles.
     * Attach only if you extend encoded sources; normally the controller wires this internally.
     */
    val metadataObserver = Observer<String> { newValue ->
        controllerMainScope.launch {
            val layer = layers[newValue] ?: return@launch
            if (timeline.state == AnimationState.playing) {
                // Metadata often arrives after a paused layer-add scrub fetch; refresh now that valid
                // times are known. Preflight inside [refreshVisibleLayers] skips HTTP when cached.
                refreshVisibleLayers(requestDL = true)
            } else if (!suppressTilePrefetchAfterRangeChangePause &&
                !Timeline.holdFullTimelineResidency
            ) {
                (layer as TileLayer).requestVisibleTiles(getBounds(), true)
            } else if (Timeline.holdFullTimelineResidency && layer is TileLayer) {
                layer.requeueVisibleBindsForScrub()
            }
        }
    }
    /** Library-internal: previous frame had pending tile downloads. */
    var wasWaitingOnDL = false
    /** Library-internal: at least one visible layer is waiting on tile data. */
    var waitingOnDL = false
    /** Library-internal: edge detection for post-download refresh. */
    var wasWaitCheck = false

    /** Requests a redraw of custom / GL layers on the next frame. */
    internal open fun redraw() {
        throw Error("Subclasses must override `redraw`")
    }

    /**
     * Sets a paint-related property on a layer (reserved for future Mapbox style parity; not fully implemented).
     *
     * @param layerId Target layer id.
     * @param property Key path of the paint field.
     * @param value New value to apply.
     */
    fun setPaintProperty(layerId: String, property: String, value: Any) {
        //TODO: implement
    }

    internal open fun updateCenterLatLngFromMap() {
        throw Error("Subclasses must override `updateCenterLatLngFromMap`")
    }

    /**
     * Hook for map SDK–specific registration of a custom layer host after MapsGL created the layer.
     *
     * @param layerID Layer id.
     * @param layerHost Mapbox [CustomLayerHost] implementation for that layer.
     */
    open fun add(layerID: String, layerHost: CustomLayerHost) {}

    /**
     * Toggles visibility of a MapsGL layer by id and triggers a redraw.
     *
     * @param id Layer id previously returned by [addLayer] / [addWeatherLayer].
     * @param visible `true` to draw and participate in tile requests; `false` to hide.
     */
    open fun setLayerVisible(id: String, visible: Boolean = true) {
        MapsGLDebug.trace(">>> MapController: setLayerVisible($id, $visible) entered")
        //if(pr.ON) pr.p(TAG, pr.ordering, "setLayerVisible() id:$id visible:$visible")

        mapZoom = getZoom()

        MapsGLDebug.trace(">>> MapController: setLayerVisible() before: visible:(${layers[id]?.visible}) ")


        if (layers[id]?.visible != visible) {
            layers[id]?.visible = visible
            redraw()
        }
        MapsGLDebug.trace(">>> MapController: setLayerVisible() after: visible:(${layers[id]?.visible}) ")

    }

    internal open fun addToMap(source: DataSource, onSourceAdded: () -> Unit) {}

    internal open fun addToMap(layer: MapLayer<*, *>, beforeId: String?) {
        if (pr.ON) pr.p(
            "MapController",
            pr.waaveRenderpath,
            ">> addToMap(source: DataSource, onSourceAdded: () -> Unit) {}  ENTERED"
        )
        layers[layer.id] = layer
        if (layer.paint is ParticleLayerPaint) {
            particleLayers[layer.id] = layer
        }
        layer.visible = true
        if (pr.ON) pr.p("MapController", pr.waaveRenderpath, ">> layer.onAdd(context, this controller)")
        layer.onAdd(mapView.context, this)
        controllerMainScope.launch {
            timeline.updateDataMeld(timeline.state == AnimationState.playing)
            refreshVisibleLayers()
            redraw()
        }
    }

    internal open fun removeFromMap(source: DataSource) {
    }

    internal open fun removeFromMap(layer: MapLayer<*, *>) {
        layer.visible = false
        particleLayers.remove(layer.id)
        layer.onRemove()
    }

    // ========================================================================================================

    /**
     * Returns whether the map currently contains a data source with the specified identifier.
     *
     * @param id Identifier of the data source to check for.
     * @return True if the map contains the data source, false otherwise.
     */
    fun hasSource(id: String): Boolean {
        return sources[id] != null
    }

    /**
     * @param id Layer id.
     * @return `true` if a layer with that id is registered.
     */
    fun hasLayer(id: String): Boolean {
        return layers[id] != null
    }

    /**
     * @param id Source id passed to [addSource].
     * @return The [DataSource] instance, or `null` if not registered.
     */
    fun getSource(id: String): DataSource? {
//        if (sources[id] == null) {
//            return sources.get("source")
//        }
        return sources[id]
    }

    /**
     * When GLES stencil masking is on, ensures [GlStencilOsm] MVTs are loaded for the same tile grid as
     * weather renderables (Mapbox's zero-opacity fetch layer does not always request every z/x/y).
     */
    open fun schedulePrefetchGlStencilMaskTilesForWeatherRender(
        coords: List<TileCoord>,
        maskKind: MaskLayerKind,
        countryIso3166Alpha2: String? = null,
    ) {
    }

    /**
     * Queues [GlStencilOsm] vector tile fetches for the same z/x/y grid as the encoded weather layer,
     * without consulting built-in land/water/transport mesh caches. Used when masking is driven only
     * by [TileLayer.stencilLayerMask] ([EncodedTileLayer.glStencilMaskKind] may be [MaskLayerKind.NONE]);
     * without this, base-OSM MVTs for custom vector masks (e.g. Demo 3 motorways) load only on demand
     * during draw, which makes panning feel choppy.
     */
    open fun schedulePrefetchGlStencilOsmTilesForCustomMask(coords: List<TileCoord>) {
    }

    /**
     * Every [EncodedGridVectorTileSource] in [sources], including GL-only gridded symbol sidecars that have no
     * [VectorTileLayer] consuming the Mapbox vector source.
     */
    protected fun forEachEncodedGridVectorTileSource(action: (EncodedGridVectorTileSource) -> Unit) {
        sources.values.filterIsInstance<EncodedGridVectorTileSource>().forEach(action)
    }

    private fun encodedGridVectorSidecarSourceId(parentLayerId: String): String =
        "${parentLayerId}__encodedGridVectors_argb_v2"

    /**
     * Instanced wind barbs/arrows register a sidecar [EncodedGridVectorTileSource] whose id is
     * [encodedGridVectorSidecarSourceId]. It must be removed when the parent tile layer goes away or the next add
     * would reuse a stale palette from [sources.getOrPut].
     */
    private fun removeEncodedGridSidecarForLayer(weatherLayerId: String) {
        val sidecarId = encodedGridVectorSidecarSourceId(weatherLayerId)
        getSource(sidecarId)?.let { sidecar ->
            sidecar.removeConsumer(weatherLayerId)
            sources.remove(sidecar.id)
            removeFromMap(sidecar)
            onSourceRemoved.send(sidecar.id)
        }
    }

    /**
     * True if any encoded-grid sidecar still drives Mapbox custom geometry during timeline meld
     * (vs. GPU-only instanced wind, which sets [EncodedGridVectorTileSource.timelineMeldInvalidatesMapboxTiles] false).
     */
    protected fun anyEncodedGridVectorUsesMapboxTimelineMeld(): Boolean =
        sources.values.filterIsInstance<EncodedGridVectorTileSource>().any { it.timelineMeldInvalidatesMapboxTiles }

    /**
     * @param id Layer id.
     * @return The [MapLayer] for that id, or `null`.
     */
    fun getLayer(id: String): MapLayer<*, *>? {
        return layers[id]
    }

    /**
     * Resolves [XweatherAuthenticator] for a new source: uses the descriptor value when set, otherwise
     * [service.authenticator] so URL templates (`{accessKey}`, etc.) and bearer auth work without app code wiring.
     */
    private fun authenticatorForSource(descriptorAuth: XweatherAuthenticator?): XweatherAuthenticator =
        descriptorAuth ?: service.authenticator

    /**
     * Registers a data source. When the descriptor leaves [ImageSourceDescriptor.authenticator] /
     * [EncodedSourceDescriptor.authenticator] / [VectorSourceDescriptor.authenticator] / [GeoJSONSourceDescriptor.authenticator]
     * unset, this controller supplies [service.authenticator] automatically.
     */
    fun addSource(descriptor: SourceDescriptor): DataSource {
        val id = descriptor.id
        sources[id]?.let { existing ->
            if (existing is TileSource<*>) {
                existing.ownerMapSessionId = mapSessionId
            }
            return existing
        }

        val source: DataSource = when (descriptor) {
            is ImageSourceDescriptor -> {
                ImageTileSource(id, id, authenticatorForSource(descriptor.authenticator)).apply {
                    tileURL = descriptor.url
                    metadataURL = descriptor.metadataUrl
                    minZoom = descriptor.minZoom ?: 0f
                    maxZoom = descriptor.maxZoom ?: 21f
                    bounds = descriptor.bounds
                    tileSize = descriptor.tileSize ?: TileSize(256)
                }
            }

            is EncodedSourceDescriptor -> {
                val tileSource = sources.getOrPut(id) {
                    XweatherEncodedTileSource(id, authenticatorForSource(descriptor.authenticator)).apply {
                        tileURL = descriptor.url
                        metadataURL = descriptor.metadataUrl
                        minZoom = descriptor.minZoom ?: 0f
                        maxZoom = descriptor.maxZoom ?: 21f
                        bounds = descriptor.bounds
                        tileSize = descriptor.tileSize ?: TileSize(512, 512)
                        datasets = descriptor.datasets ?: emptyList()
                    }
                }
                tileSource
            }

            is VectorSourceDescriptor -> {
                if (pr.ON) pr.p("MapController", pr.adminLayers, "addSource() descriptor.id: ${descriptor.id}}")
                val tileSource = sources.getOrPut(id) {
                    VectorTileSource(id, authenticatorForSource(descriptor.authenticator)).apply {
                        tileURL = descriptor.url
                        metadataURL = descriptor.metadataUrl
                        minZoom = descriptor.minZoom ?: 0f
                        maxZoom = descriptor.maxZoom ?: 21f
                        bounds = descriptor.bounds
                        tileSize = descriptor.tileSize ?: TileSize(512, 512)
                    }
                }
                tileSource
            }

            is GeoJSONSourceDescriptor -> {
                val dataSource = sources.getOrPut(id) {
                    GeoJSONSource(id).apply {
                        url = descriptor.url
                        attribution = descriptor.attribution
                        authenticator = authenticatorForSource(descriptor.authenticator)
                    }
                }
                val bundledAsset = descriptor.bundledAssetPath
                if (bundledAsset != null && (dataSource as GeoJSONSource).data == null) {
                    (dataSource as GeoJSONSource).data =
                        GeoJSONSource.parseJsonOrAsset(bundledAsset)
                }
                dataSource
            }

            else -> throw IllegalArgumentException("Unsupported source descriptor type: ${descriptor::class}")
        }

        source.timeRange = timeline.start..timeline.end
        sources[id] = source
        if (source is TileSource<*>) {
            source.ownerMapSessionId = mapSessionId
        }

        if (source is VectorTileSource || source is GeoJSONSource) {
            addToMap(source) {
                onSourceAdded.send(source.id)
            }
        } else {
            onSourceAdded.send(source.id)
        }

        return source
    }

    /**
     * Adds a new layer to the map.
     * @param descriptor Layer definition referencing an existing source id and paint.
     * @param beforeID Optional existing layer id to insert **below** in the stack; `null` appends on top.
     * @return The new [TileLayer], or `null` if the source is missing or the descriptor is unsupported.
     */
    fun <P : LayerPaint> addLayer(
        descriptor: LayerDescriptor<P>,
        beforeID: String?,
    ): TileLayer? {
        val source = getSource(descriptor.source) ?: return null
        //MapsGLDebug.trace(">>> MapController addLayer() about to create DataRenderer for ${descriptor.id}")

        val layer: TileLayer? = when {
            source is EncodedTileSource -> {
                when (descriptor) {
                    is SampleLayerDescriptor -> {
                        EncodedTileLayer(
                            descriptor.id,
                            source as TileSource<TileData>,
                            descriptor.paint,
                            EncodedDataRenderer<EncodedData, RenderContext<Any>>(descriptor.id),
                            zoomOffset,
                            viewModelScope,
                            descriptor.quality
                        )
                    }

                    is ContourLayerDescriptor -> {
                        EncodedTileLayer(
                            descriptor.id,
                            source as TileSource<TileData>,
                            descriptor.paint,
                            ContourRenderer(descriptor.id),
                            zoomOffset,
                            viewModelScope,
                            descriptor.quality
                        )
                    }

                    is ParticleLayerDescriptor -> {
                        EncodedTileLayer(
                            descriptor.id,
                            source as TileSource<TileData>,
                            descriptor.paint,
                            ParticleRenderer(descriptor.id),
                            zoomOffset,
                            viewModelScope,
                            descriptor.quality
                        )
                    }

                    is GridLayerDescriptor -> {
                        val renderer =
                            when {
                                isGlInstancedWindBarbs(descriptor) -> WindBarbInstancedRenderer(descriptor.id)
                                isGlInstancedWindArrows(descriptor) -> WindArrowInstancedRenderer(descriptor.id)
                                else -> EmptyRenderer(descriptor.id)
                            }
                        EncodedTileLayer(
                            descriptor.id,
                            source as TileSource<TileData>,
                            descriptor.paint,
                            renderer,
                            zoomOffset,
                            viewModelScope,
                            descriptor.quality
                        )
                    }

                    else -> null
                }?.also {
                    (source as XweatherEncodedTileSource).setObserver(metadataObserver, it.id)
                }
            }

            descriptor is RasterLayerDescriptor -> {
                ImageTileSource.setKey(account.id, account.secret)
                TileLayer(
                    descriptor.id,
                    source as TileSource<TileData>,
                    descriptor.paint as RasterLayerPaint,
                    RasterLayerRenderer(),
                    zoomOffset,
                    viewModelScope,
                    descriptor.quality
                )
            }

            descriptor is VectorLayerDescriptor<*> -> {
                VectorTileLayer(
                    descriptor.id,
                    source as TileSource<TileData>,
                    descriptor.paint as VectorLayerPaint,
                    RasterLayerRenderer(),
                    zoomOffset,
                    viewModelScope
                ).apply {
                    sourceLayer = descriptor.sourceLayer
                    filter = descriptor.filter
                    stencilOnly = descriptor.stencilOnly
                }
            }

            descriptor is GridLayerDescriptor -> {
                EncodedTileLayer(
                    descriptor.id,
                    source as TileSource<TileData>,
                    descriptor.paint,
                    EmptyRenderer(descriptor.id), //ParticleRenderer(descriptor.id),
                    zoomOffset,
                    viewModelScope,
                    descriptor.quality
                )
            }

            else -> null
        }

        if (layer == null) return null

        layer.type = descriptor.type
        layer.animator?.let {
            animatorSync.add(layer)
            timeline.add(it.animation)
            layer.enabled = it.canShowForDate()
        }

        layers[layer.id] = layer
        layer.mapController = this
        if (pr.ON) pr.p("MapController", pr.waaveRenderpath, ">> addLayer() calling: addToMap(layer, beforeId)")
        addToMap(layer, beforeID)

        val sourceConsumer = DataSourceConsumer(layerId = layer.id)
        when (layer) {
            is VectorTileLayer -> {
                sourceConsumer.sourceLayerId = layer.sourceLayer
            }
        }
        layer.source.addConsumer(sourceConsumer)

        if (this is MapboxMapController && descriptor is RasterLayerDescriptor) {
            val customStencilSpec = bitmapStencilFromLayerDescriptor(descriptor)
            if (customStencilSpec != null &&
                (customStencilSpec.layers.isNotEmpty() || customStencilSpec.clipBounds != null)
            ) {
                layer.stencilLayerMask = customStencilSpec
                layer.glStencilMaskKind = MaskLayerKind.NONE
                if (customStencilSpec.layers.isNotEmpty()) {
                    GlStencilCustomMaskCoordinator.register(this, layer.id, customStencilSpec)
                }
            } else if (descriptor.mask != MaskLayerKind.NONE) {
                val countryIsoParam =
                    if (descriptor.mask == MaskLayerKind.COUNTRY) {
                        GlStencilCountryMask.normalizeIso(descriptor.maskCountryIso3166Alpha2)
                    } else {
                        null
                    }
                if (descriptor.mask == MaskLayerKind.COUNTRY && countryIsoParam == null) {
                    MapsGLDebug.trace(
                        "[GlStencilMask] COUNTRY mask requires maskCountryIso3166Alpha2 " +
                            "on the layer descriptor (e.g. \"US\", \"ES\")",
                    )
                } else {
                    GlStencilMaskCoordinator.ensureBaseOsmMaskConsumer(
                        this,
                        service,
                        descriptor.mask,
                        countryIsoParam,
                    )
                    layer.glStencilMaskKind = descriptor.mask
                    layer.glStencilMaskCountryIso = countryIsoParam
                }
            }
        }

        if (descriptor is GridLayerDescriptor && source is XweatherEncodedTileSource && layer is EncodedTileLayer) {
            if (isGlInstancedWindBarbs(descriptor) || isGlInstancedWindArrows(descriptor)) {
                addGriddedGridSourceForGlWindBarbs(
                    parentLayer = layer,
                    descriptor = descriptor,
                    encodedSource = source,
                )
            }
        }




        onLayerAdded.send(layer.id)
        return layer
    }

    private fun isGlInstancedWindBarbs(descriptor: GridLayerDescriptor): Boolean =
        descriptor.id == "conditions.wind_speed.symbol"

    private fun isGlInstancedWindArrows(descriptor: GridLayerDescriptor): Boolean =
        descriptor.id == "conditions.wind_speed.arrow" ||
                (descriptor.id.startsWith("maritime.") && descriptor.id.endsWith("_dir.fill"))

    /**
     * Wind barbs drawn as instanced GL quads in the custom layer pass (pitch-correct); no Mapbox vector symbol layer.
     * Still registers the [EncodedGridVectorTileSource] in [sources] for geometry/sampling and lifecycle cleanup.
     */
    private fun addGriddedGridSourceForGlWindBarbs(
        parentLayer: EncodedTileLayer,
        descriptor: GridLayerDescriptor,
        encodedSource: XweatherEncodedTileSource,
    ) {
        val vectorSourceId = encodedGridVectorSidecarSourceId(parentLayer.id)
        val maritimeDirWhite =
            descriptor.id.startsWith("maritime.") && descriptor.id.endsWith("_dir.fill")
        val displayDensity = mapView.resources.displayMetrics.density.let { if (it > 0f) it else 1f }
        val vectorSource = sources.getOrPut(vectorSourceId) {
            EncodedGridVectorTileSource(
                id = vectorSourceId,
                encodedSource = encodedSource,
                gridSpacing = descriptor.paint.grid.spacing,
                iconEncodedColorScale = descriptor.paint.sample?.colorScale,
                iconEncodedScalarMax = descriptor.paint.sample?.encodedScalarNormMax,
                timelineMeldInvalidatesMapboxTiles = false,
                instancedQuadMonochromeWhite = maritimeDirWhite,
            )
        } as EncodedGridVectorTileSource

        vectorSource.syncGridSpacingFromPaint(descriptor.paint.grid.spacing, displayDensity)

        // Sidecar source may be reused from a prior add (see [removeEncodedGridSidecarForLayer]); always sync palette.
        vectorSource.applyIconColorOptions(
            descriptor.paint.sample?.colorScale,
            descriptor.paint.sample?.encodedScalarNormMax,
        )

        vectorSource.timeRange = timeline.start..timeline.end
        vectorSource.validTime = parseDateArrayFromString(timeStrings[Timeline.currentPhaseA]).first()
        //griddedOverlaySourceByParent[parentLayer.id] = vectorSourceId
        vectorSource.addConsumer(DataSourceConsumer(layerId = parentLayer.id))
        when (val r = parentLayer.tileLayerRenderer) {
            is GridLayerRenderer -> r.attachGridSource(vectorSource)
            else -> return
        }
    }

    /**
     * Reorders an existing layer in the host map style.
     *
     * @param id Layer to move.
     * @param beforeId Layer id to insert before, or `null` to move to the top.
     */
    open fun moveLayer(id: String, beforeId: String?) {}

    /**
     * Unregisters a data source from this controller (does not remove layers that still reference it).
     *
     * @param id Source id.
     */
    fun removeSource(id: String) {
        getSource(id)?.let {
            sources.remove(it.id)
            onSourceRemoved.send(it.id)
        }
    }

    /**
     * Removes a layer by id, detaches consumers, and cleans encoded-grid sidecars when present.
     *
     * @param id Layer id.
     * @param isCompounLayer When removing a composite child, skips duplicate [MapControllerEvents.LAYER_REMOVED] emits.
     */
    fun removeLayer(id: String, isCompounLayer: Boolean = false) {
        removeEncodedGridSidecarForLayer(id)
        /*
        val hadGriddedVectorOverlay = griddedOverlayLayerByParent.containsKey(id)
        griddedOverlayLayerByParent.remove(id)?.let { overlayId ->
            getLayer(overlayId)?.let { overlay ->
                removeFromMap(overlay)
                layers.remove(overlay.id)
                overlay.source.removeConsumer(layerId = overlay.id)
                onLayerRemoved.send(overlay.id)
                overlay.mapController = null
            }
        }
        griddedOverlaySourceByParent.remove(id)?.let { sourceId ->
            val source = sources[sourceId]
            if (source is EncodedGridVectorTileSource) {
                if (!hadGriddedVectorOverlay) {
                    source.removeConsumer(id)
                }
                removeFromMap(source)
                sources.remove(source.id)
            }
        }
        */
        getLayer(id)?.let {
            if (this is MapboxMapController && it is TileLayer) {
                val custom = it.stencilLayerMask
                if (custom != null && custom.layers.isNotEmpty()) {
                    GlStencilCustomMaskCoordinator.unregister(this, it.id)
                }
                val kind = it.glStencilMaskKind
                if (kind != MaskLayerKind.NONE) {
                    val isoRelease = if (kind == MaskLayerKind.COUNTRY) it.glStencilMaskCountryIso else null
                    GlStencilMaskCoordinator.releaseBaseOsmMaskConsumer(
                        this,
                        service,
                        kind,
                        isoRelease,
                    )
                }
            }
            removeFromMap(it)
            layers.remove(it.id)
            it.source.removeConsumer(layerId = it.id)
            if (it is TileLayer && it.source.isEncoded) {
                com.xweather.mapsgl.data.TileList.purgeLayerFromAllLists(it.id)
            }
            onLayerRemoved.send(it.id)
            it.mapController = null

            if (!isCompounLayer) {
                trigger(MapControllerEvents.LAYER_REMOVED, it.id)
            }
        }
    }

    /**
     * Returns the list of layers that are rendered by MapsGL (not layers rendered by Mapbox).
     */
    internal fun getMapsGLRenderedLayers(): List<MapLayer<*, *>> {
        return layers.values.filter { it !is VectorTileLayer }
    }

    /**
     * Counts coord×time pairs that would be newly queued for visible encoded layers at the current
     * timeline phase(s). Zero means cached/native/ready tiles already cover the viewport.
     */
    private suspend fun countVisibleEncodedDownloadPairsNeeded(): Int {
        var total = 0
        for (layer in getMapsGLRenderedLayers()) {
            if (!layer.visible || layer !is TileLayer) continue
            val tl = layer as TileLayer
            if (tl.source.isEncoded) {
                total += tl.preflightEncodedDownloadPairCount()
            }
        }
        return total
    }

    private fun beginEncodedDownloadSessionIfNeeded(encodedPairsNeeded: Int) {
        if (encodedPairsNeeded <= 0) return
        if (!Timeline.isEncodedDownloadSessionTargetUnset()) return
        Timeline.resetEncodedDownloadProgressCounters()
        Timeline.setEncodedSessionDownloadTarget(encodedPairsNeeded)
    }

    /**
     * After the camera stops, encoded tile layers need current [getBounds] on each [TileLayer] before we preflight,
     * otherwise [TileLayer.preflightEncodedDownloadPairCount] uses a stale viewport and [refreshVisibleLayers]
     * skips preflight once [addPendingEncodedDownload] runs — causing 100% then ~50% when the second request wave adds work.
     */
    private suspend fun establishEncodedDownloadSessionAfterCameraIdleIfNothingPending() {
        val playingOrPreload =
            timeline.state == AnimationState.playing ||
                    timeline.opts.shouldPreloadData ||
                    timeline.opts.forcePreloadOneTime
        if (!playingOrPreload) return
        if (Timeline.countPendingEncodedAll() != 0) return

        val mapBounds = getBounds()
        for (layer in getMapsGLRenderedLayers()) {
            if (layer.visible && layer is TileLayer) {
                (layer as TileLayer).bounds = mapBounds
            }
        }
        beginEncodedDownloadSessionIfNeeded(countVisibleEncodedDownloadPairsNeeded())
    }

    internal suspend fun onMoveEnd() {
        camera.moveState = Camera.STOPPED
        // Only drop residency when the camera actually moved (caller gates on cameraTriggered).
        // Clearing these on every MapIdle made scrub/redraw re-open a full download wave.
        suppressStreamingLoadUi = false
        Timeline.holdFullTimelineResidency = false

        establishEncodedDownloadSessionAfterCameraIdleIfNothingPending()

        for (layer in getMapsGLRenderedLayers()) {
            if (layer.visible) {
                layer.onMoveEnd()
            }
        }

        // Pan/zoom while playing: force a playback refresh against the new viewport. Layer
        // onMove is skipped during play, so without this the choreographer keeps refreshing
        // the old tile set and new areas stay empty.
        if (timeline.state == AnimationState.playing) {
            ensureEncodedCacheCapacityForFullPlayback()
            schedulePlaybackLayerRefreshIfNeeded(force = true)
        }
    }

    internal fun updateTiles(updateCamera: Boolean = false) {
        controllerMainScope.launch {
            if (updateCamera) {
            } else { //particles use this
                timeline.updateDataMeld(timeline.state == AnimationState.playing)
                // Paused/scrub: refreshVisibleLayers only enqueues missing scrub pairs (see encodedPairSatisfied).
                // While playing, keep requesting — TilePyramid dedupes pending/ready pairs.
                refreshVisibleLayers(requestDL = timeline.state == AnimationState.playing)
            }
            redraw() //This causes render to happen
            kickCustomLayerChoreographerIfNeeded()
        }
    }

    internal suspend fun onMove(pauseParticles: Boolean = true, tag: String = "empty") {
        if (pauseParticles) camera.moveState = Camera.MOVING

        for (layer in getMapsGLRenderedLayers()) {
            if (layer.visible) {
                if (timeline.state != AnimationState.playing || !pauseParticles || Timeline.pausedForDownload) {
                    layer.onMove() // calls:  bounds = mapController?.getBounds()?: return AND requestVisibleTiles(bounds!!)
                }
            }
        }
    }

    /**
     * Recomputes visible tiles for every visible MapsGL layer and marks custom layer hosts dirty.
     *
     * @param requestDL When `true`, layers may enqueue HTTP/decodes for missing tiles; when `false`,
     * only binding / draw state is refreshed (e.g. after downloads complete).
     */
    suspend fun refreshVisibleLayers(requestDL: Boolean = true) { //called from updateTiles
        // Defer staggered fill until playback resumes; draining on pause/scrub downloaded odd
        // intervals the user was not viewing and looked like spurious new tiles.
        val staggeredFillSources =
            if (timeline.state == AnimationState.playing) {
                Timeline.drainStaggeredFillDownloadRequests()
            } else {
                emptySet()
            }
        val pausedScrub =
            timeline.state != AnimationState.playing &&
                !timeline.opts.shouldPreloadData &&
                !timeline.opts.forcePreloadOneTime
        val encodedPairsNeeded = countVisibleEncodedDownloadPairsNeeded()
        var needsNonEncodedDownload = false
        if (requestDL || pausedScrub) {
            for (layer in getMapsGLRenderedLayers()) {
                if (!layer.visible || layer !is TileLayer) continue
                if (!(layer as TileLayer).source.isEncoded) {
                    needsNonEncodedDownload = true
                    break
                }
            }
        }
        var effectiveRequestDL =
            staggeredFillSources.isNotEmpty() ||
                (requestDL && (encodedPairsNeeded > 0 || needsNonEncodedDownload))
        if (pausedScrub && requestDL) {
            // Idle scrub with an explicit download request: fetch only missing scrub-target pairs.
            effectiveRequestDL =
                staggeredFillSources.isNotEmpty() ||
                    encodedPairsNeeded > 0 ||
                    needsNonEncodedDownload
        }
        // While the initial play catch-up is still streaming, preflight can briefly report 0 and
        // must not skip [TileLayer.update]. After the load UI is suppressed, keep calling update()
        // while playing so missing GPU binds / true holes can still catch up — spinner stays off
        // via [suppressStreamingLoadUi]. Scrub uses requestDL=false (re-bind only).
        if (requestDL && timeline.state == AnimationState.playing) {
            effectiveRequestDL = true
        }
        // After a completed play load, idle scrub must not open another HTTP wave. While still
        // playing, keep downloading true holes — hold only protects eviction / scrub reload.
        if (Timeline.holdFullTimelineResidency && timeline.state != AnimationState.playing) {
            effectiveRequestDL = false
        }
        if (effectiveRequestDL) {
            val playingOrPreload =
                timeline.state == AnimationState.playing ||
                        timeline.opts.shouldPreloadData ||
                        timeline.opts.forcePreloadOneTime
            // Avoid opening a new progress session once the spinner is suppressed mid-play.
            if (playingOrPreload && !suppressStreamingLoadUi) {
                beginEncodedDownloadSessionIfNeeded(encodedPairsNeeded)
            } else if (
                !suppressStreamingLoadUi &&
                    staggeredFillSources.isNotEmpty() &&
                    Timeline.isEncodedDownloadSessionTargetUnset() &&
                    encodedPairsNeeded > 0
            ) {
                beginEncodedDownloadSessionIfNeeded(encodedPairsNeeded)
            }
        }
        for (layer in getMapsGLRenderedLayers()) {
            if (layer.visible) {
                if (effectiveRequestDL) {
                    layer.update() // request download of visible tiles without updating camera
                } else if (layer is TileLayer && layer.source.isEncoded) {
                    layer.requeueVisibleBindsForScrub()
                }
                setLayerHostToUpdate(layer.id)
            }
        }
    }

    /**
     * Marks the custom layer host for [layerId] so textures/uniforms are uploaded on the next draw pass.
     */
    open fun setLayerHostToUpdate(layerId: String) {}

    /**
     * Stops GL frame updates when the timeline range changes during playback. Metadata refresh and
     * tile loading are left to the user (scrub / play) — no automatic full-range prefetch.
     */
    internal fun onTimelineRangeChangedWhilePlaying(wasPlaying: Boolean) {
        if (wasPlaying) {
            suppressTilePrefetchAfterRangeChangePause = true
            animatingTimeline = false
            stopCustomLayerUpdates()
        }
        suppressStreamingLoadUi = false
        Timeline.holdFullTimelineResidency = false
        Timeline.sourceTimeHash.values.forEach { layerTimeline ->
            layerTimeline.viewportHoldPhase = ""
            layerTimeline.viewportPlaybackReady = false
        }
        resetPlaybackLayerRefreshTracking()
    }

    internal fun clearPostRangeChangeTilePrefetchSuppress() {
        suppressTilePrefetchAfterRangeChangePause = false
    }

    /**
     * Scrub while paused/stopped: refresh draw state for the **current** phase pair only.
     * Phases must already be updated ([Timeline.setProgress]) before this runs.
     */
    internal fun onTimelineScrubbedWhileIdle() {
        controllerMainScope.launch {
            timeline.updateDataMeld(false)
            // Re-bind only — do not open a download wave for intervals already resident.
            refreshVisibleLayers(requestDL = false)
            redraw()
            kickCustomLayerChoreographerIfNeeded()
        }
    }

    /**
     * Pause after playback: cancel in-flight playback refresh jobs and re-bind visible tiles
     * without enqueueing another full-timeline download pass.
     */
    internal fun onTimelinePlaybackPaused() {
        // Keep [suppressStreamingLoadUi] / [Timeline.holdFullTimelineResidency] when the play
        // catch-up already finished — scrubbing after pause must not re-open encode/decode of the
        // resident interval set (OOM / multi-minute reload).
        resetPlaybackLayerRefreshTracking()
        controllerMainScope.launch {
            timeline.updateDataMeld(false)
            refreshVisibleLayers(requestDL = false)
            redraw()
        }
    }

    /**
     * Scrub during active playback: jump the playhead to an already-requested interval and re-bind.
     * Must not force another full-timeline download — that revived the load spinner and re-decoded
     * resident tiles until the Java heap OOM'd.
     *
     * Also must **not** cancel the in-flight catch-up wave. [Timeline.setProgress] runs on every
     * ~2s loop wrap while playing; cancelling there permanently starved the full-range load
     * (hold forever, 100s watchdog). Coalesce instead.
     */
    internal fun schedulePlaybackLayerRefreshAfterScrub() {
        playbackRefreshPhaseA = Timeline.currentPhaseA
        playbackRefreshPhaseB = Timeline.currentPhaseB
        // After the initial full-range load, do **not** cancel in-flight work: cancellation
        // released pending keys and made the next refresh treat resident gaps as a brand-new
        // multi-minute download (spinner on scrub). Only re-bind the new playhead pair.
        if (Timeline.holdFullTimelineResidency || suppressStreamingLoadUi) {
            playbackLayerRefreshPending = false
            controllerMainScope.launch {
                timeline.updateDataMeld(true)
                refreshVisibleLayers(requestDL = false)
                redraw()
                kickCustomLayerChoreographerIfNeeded()
            }
            return
        }
        // Mid-load (including automatic loop setProgress): keep the catch-up wave alive and
        // queue another pass after it finishes. Never cancel here.
        controllerMainScope.launch {
            timeline.updateDataMeld(true)
            redraw()
            kickCustomLayerChoreographerIfNeeded()
        }
        if (timeline.state == AnimationState.playing) {
            schedulePlaybackLayerRefreshIfNeeded(force = true)
        }
    }

    /** This functionality needs to be moved to the timeline classes **/
    internal fun startAnimatingTimeline(playPressed: Boolean) {
        if (playPressed) {
            clearPostRangeChangeTilePrefetchSuppress()
            animatingTimeline = true
            // Keep load UI active while the playhead window streams in. Hiding it on play made it
            // look like intervals "never load" while downloads were still queued / dropped.
            // [suppressStreamingLoadUi] is set only after a real load session completes mid-play.
            resetPlaybackLayerRefreshTracking()
            // Drop orphan Timeline pending keys left by cancelled metadata / partial layer-add waves
            // so [isEncodedBindPending] and the 100s watchdog do not start play already stuck.
            Timeline.releaseStalePendingEncodedDownloads(0)
            Timeline.sourceTimeHash.values.forEach { layerTimeline ->
                // Keep [viewportHoldPhase] so eviction / draw can retain the last covering interval
                // until the playhead window is ready (timeline raster rule: cover the screen).
                if (layerTimeline.useStaggeredDownload()) {
                    layerTimeline.staggeredPhase = StaggeredIntervalPhase.Full
                }
            }
            // Full-range loop residency: ensure each encoded cache can hold viewport×all intervals.
            ensureEncodedCacheCapacityForFullPlayback()
        } else {
            timeline.seekBarMoved = true
            // Do not clear [suppressStreamingLoadUi] / [Timeline.holdFullTimelineResidency] on pause.
            // That dropped LRU protection and freed native pixels, so scrubbing after a completed
            // play load re-downloaded the whole range (lengthy load spinner).
        }

        if (animatingTimeline) {
            startCustomLayerUpdates()
            schedulePlaybackLayerRefreshIfNeeded(force = true)
        }
    }

    /**
     * Playback loops every timeline interval in ~2s; size each encoded LRU so capacity eviction
     * cannot drop an in-range tile×time mid-loop.
     */
    private fun ensureEncodedCacheCapacityForFullPlayback() {
        val intervals = maxOf(
            Timeline.timeStrings.size,
            Timeline.sourceTimeHash.values.maxOfOrNull { it.timeStrings.size } ?: 0,
            1,
        )
        for (layer in layers.values) {
            if (layer !is EncodedTileLayer || !layer.visible) continue
            val visibleEstimate = layer.getVisibleTileCoords().size.coerceIn(16, 80)
            val needed = (visibleEstimate * intervals * 2).coerceIn(800, 8_000)
            if (layer.source.tileCache.tiles.capacity < needed) {
                layer.source.tileCache.tiles.capacity = needed
            }
        }
    }

    private suspend fun preloadVisibleTiles() {
        for (layer in getMapsGLRenderedLayers()) {
            if (layer.visible) {
                if (true) {

                    if (pr.ON) pr.p(TAG, pr.preload, "calling layer.onMove for ${layer.id}")
                    layer.onMove() // calls:  bounds = mapController?.getBounds()?: return AND requestVisibleTiles(bounds!!)
                }
            }
        }
    }

    internal fun startCustomLayerUpdates(isParticleLayer: Boolean = false) {
        if (!customLayerUpdatesHaveStarted || isParticleLayer) {
            customLayerUpdatesHaveStarted = true

            // This prevents doubling up on animations and also prevents timeline animation states from stopping particles.
            if (isParticleLayer) {
                if (frameCallback != null) {
                    choreographer.removeFrameCallback(frameCallback!!)
                }
                frameCallback = null // Clear the reference
            }

            frameCallback = object : Choreographer.FrameCallback {
                override fun doFrame(frameTimeNanos: Long) {
                    if (!mapLifecycleStarted) {
                        frameCallback = null
                        customLayerUpdatesHaveStarted = false
                        return
                    }
                    if (timeline.state == AnimationState.playing || timeline.seekBarMoved || isParticleLayer) {
                        updateCustomLayer()
                    }
                    if (shouldPostNextCustomLayerFrame()) {
                        choreographer.postFrameCallback(this)
                    } else {
                        frameCallback = null
                        customLayerUpdatesHaveStarted = false
                    }
                }
            }
            choreographer.postFrameCallback(frameCallback!!)
        }
    }

    private var lastPlaybackPrefetchAtMs: Long = 0L
    private val playbackPrefetchIntervalMs: Long = 400L

    private fun updateCustomLayer() {
        if (!mapLifecycleStarted) return
        // Choreographer.FrameCallback runs on the main looper; avoid coroutine allocation every frame during playback.
        if (timeline.state == AnimationState.playing || timeline.seekBarMoved) {
            timeline.seekBarMoved = false
            val playing = timeline.state == AnimationState.playing
            timeline.updateDataMeld(playing)
            if (playing) {
                // Encoded layers (radar, temperature, …) need [refreshVisibleLayers] while playing so
                // [TilePyramid.resolveDownloadTimes] runs filterTimelineByValidTimes and queues the
                // current phase pair. Without this, meld advances but tiles stay on the paused interval.
                schedulePlaybackLayerRefreshIfNeeded()
                maybePrefetchPlaybackLookahead()
                markVisibleCustomLayersDirty()
            }
            redraw()
        } else if (particleLayers.values.any { it.visible }) {
            timeline.updateDataMeld(timeline.state == AnimationState.playing)
            redraw()
        }
    }

    /**
     * After the initial play load UI finishes ([suppressStreamingLoadUi]), keep requesting any
     * remaining missing intervals in the background without reviving the spinner.
     *
     * Must **not** run while the load session is still open: force-prefetch was continuously
     * re-arming pending-encoded keys so the indicator never went quiet and stuck near ~96%.
     */
    private fun maybePrefetchPlaybackLookahead() {
        if (timeline.state != AnimationState.playing) return
        if (!suppressStreamingLoadUi) return
        if (playbackLayerRefreshJob?.isActive == true) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastPlaybackPrefetchAtMs < playbackPrefetchIntervalMs) return
        // Still churning through a large wave — let it finish before asking for more.
        if (Timeline.countPendingEncodedAll() > 12) return
        lastPlaybackPrefetchAtMs = now
        // force=true must NOT cancel an in-flight job (see schedulePlaybackLayerRefreshIfNeeded);
        // it only marks that another full refresh is required after the current one finishes.
        schedulePlaybackLayerRefreshIfNeeded(force = true)
    }

    private fun resetPlaybackLayerRefreshTracking() {
        playbackRefreshPhaseA = -1
        playbackRefreshPhaseB = -1
        playbackLayerRefreshPending = false
        playbackLayerRefreshJob?.cancel()
        playbackLayerRefreshJob = null
    }

    /**
     * Enqueue encoded-tile downloads for the active global phase pair during timeline playback.
     * [TileLayer.onMove] intentionally skips [requestVisibleTiles] while playing to avoid pan storms;
     * this path keeps animation fed without re-running full camera move logic.
     */
    internal fun schedulePlaybackLayerRefreshIfNeeded(force: Boolean = false) {
        val phaseA = Timeline.currentPhaseA
        val phaseB = Timeline.currentPhaseB
        val phaseChanged = phaseA != playbackRefreshPhaseA || phaseB != playbackRefreshPhaseB
        if (!force && !phaseChanged) return

        if (force) {
            playbackLayerRefreshPending = true
            playbackRefreshPhaseA = -1
            playbackRefreshPhaseB = -1
            // Do not cancel an in-flight refresh. Cancelling mid-wave left `_requestedTiles` /
            // half-decoded batches behind and permanently starved later intervals of GPU binds
            // (frozen layer while the clock kept advancing). Queue another pass after this one.
        }

        if (playbackLayerRefreshJob?.isActive == true) {
            // A multi-day timeline advances phases faster than one refresh finishes. Previously we
            // only re-queued on force=true, so every phase change during the in-flight job was
            // dropped and later intervals never downloaded (frozen layer, no load UI).
            playbackLayerRefreshPending = true
            return
        }

        playbackRefreshPhaseA = phaseA
        playbackRefreshPhaseB = phaseB
        val runForce = force || playbackLayerRefreshPending
        playbackLayerRefreshPending = false
        val shouldEvictAfterRefresh = phaseChanged

        playbackLayerRefreshJob = controllerMainScope.launch {
            try {
                // Download the new playhead window first. Evicting beforehand dropped the last
                // covering interval while the clock raced ahead, leaving holes and a frozen layer.
                // Residency hold must not block play downloads — only idle scrub / eviction.
                refreshVisibleLayers(
                    requestDL = runForce || timeline.state == AnimationState.playing,
                )
                if (shouldEvictAfterRefresh) {
                    evictStaleEncodedTimelineCaches()
                }
            } finally {
                playbackLayerRefreshJob = null
                if (playbackLayerRefreshPending) {
                    playbackLayerRefreshPending = false
                    // While the load spinner is still up, do not immediately chain another wave
                    // when queues are already idle — that re-armed pending keys and stuck the
                    // indicator near ~96%. Let [triggerLoadComplete] / the watchdog observe quiet.
                    if (!suppressStreamingLoadUi && loadStartConfirmed) {
                        val stillBusy =
                            Timeline.countPendingEncodedAll() > 0 ||
                                TileList.pendingList.countAllEntries() > 0 ||
                                encodedGpuBindQueueBusy()
                        if (!stillBusy) {
                            return@launch
                        }
                    }
                    schedulePlaybackLayerRefreshIfNeeded(force = true)
                }
            }
        }
    }

    /**
     * Keep only intervals near the playhead (plus per-layer retain candidates) in encoded tile
     * caches. Without this, each phase step permanently retains another ~1MB×visibleTiles.
     *
     * The keep-set is computed from each layer's **own** valid times rather than the global phase
     * indices: a layer whose intervals don't line up with [Timeline.timeStrings] would otherwise
     * have freshly downloaded tiles evicted on arrival and re-requested forever.
     */
    private fun evictStaleEncodedTimelineCaches(margin: Int = 12) {
        // Full-range residency while playing / after a completed play load: the timeline loops all
        // intervals in ~2s repeatedly. Evicting "passed" phases drops frames needed on the next
        // loop and makes post-load scrub re-download.
        if (timeline.state == AnimationState.playing ||
            Timeline.isGloballyPlaying ||
            Timeline.holdFullTimelineResidency
        ) {
            return
        }
        // Full-range prefetch deliberately loads every interval; don't fight it.
        if (Timeline.fullTimelinePreloadActive) return
        if (timeline.opts.shouldPreloadData || timeline.opts.forcePreloadOneTime) return

        for (layer in layers.values) {
            if (layer !is EncodedTileLayer || !layer.visible) continue
            // LayerTimeline is keyed by source id (same as RenderPass.label / pending-encoded map).
            val layerTimeline = Timeline.sourceTimeHash[layer.source.id] ?: continue

            val layerStrings = layerTimeline.playbackTimeStrings()
            // Nothing to reclaim when the whole series already fits inside the retain window.
            if (layerStrings.size <= margin * 2 + 1) continue

            val target = layerTimeline.computeGlobalAnimationTarget()
            val keep = linkedSetOf<String>()
            keep.addAll(layerTimeline.retainPhaseCandidates())
            if (layerTimeline.phaseAString.length > 4) keep.add(layerTimeline.phaseAString)
            if (layerTimeline.phaseBString.length > 4) keep.add(layerTimeline.phaseBString)
            if (layerTimeline.viewportHoldPhase.length > 4) keep.add(layerTimeline.viewportHoldPhase)
            if (target.phaseA.length > 4) keep.add(target.phaseA)
            if (target.phaseB.length > 4) keep.add(target.phaseB)

            // Until we know what is on screen, do not evict — protects coverage at play start.
            if (keep.isEmpty()) continue

            fun addWindowAround(phase: String) {
                val idx = layerStrings.indexOf(phase)
                if (idx < 0) return
                for (i in (idx - margin).coerceAtLeast(0)..(idx + margin).coerceAtMost(layerStrings.lastIndex)) {
                    keep.add(layerStrings[i])
                }
            }
            addWindowAround(layerTimeline.viewportHoldPhase)
            addWindowAround(layerTimeline.phaseAString)
            addWindowAround(target.phaseA)
            addWindowAround(target.phaseB)

            if (keep.isEmpty()) continue
            layer.source.tileCache.evictTimesNotIn(keep)
        }
    }

    private fun markVisibleCustomLayersDirty() {
        for (layer in getMapsGLRenderedLayers()) {
            if (layer.visible) {
                setLayerHostToUpdate(layer.id)
            }
        }
    }

    private fun changeZoomOffset(change: Int) {
        zoomOffset += change
        for (layer in layers) {
            (layer.value as TileLayer).zoomOffset += change
        }
    }

    internal fun setupCamera(initial: Boolean = true) {
        if (pr.ON) pr.p(TAG, pr.rotS, " setupCamera($initial")
        val width = mapView.width.toFloat()
        val height = mapView.height.toFloat()
        densityMult = ((mapView.resources.displayMetrics.density / height) * 800)

        val nz = height * .02f;
        /** from Mapbox https://github.com/mapbox/mapbox-gl-js/blob/main/src/geo/transform.js#L93 **/
        val fov = atan(3f * .25f)
        val pitchAngle = Math.cos((Math.PI * .5) - getPitch())
        val nearZ = Math.max((nz * pitchAngle).toFloat(), nz)
        // Large far plane for map-scale world coordinates; cap avoids the worst float32 precision loss
        // from 1e21 while staying generous enough not to clip tile geometry after pitch/translation.
        val farZ = (nearZ * 1e6f).coerceIn(nearZ * 500f, 1e15f)
        val right = width * .5f
        val left = -right
        val top = height * .5f
        val bottom = -top

        if (type == PERSPECTIVECAMERA) {
            if (initial) {
                camera = Camera(
                    CameraType.Perspective,
                    fov = fov,
                    near = nearZ,
                    far = farZ,
                    bounds = RectF(left, top, right, bottom)
                )
            } else {
                camera.setup(
                    CameraType.Perspective,
                    fov = fov,
                    near = nearZ,
                    far = farZ,
                    bounds = RectF(left, top, right, bottom)
                )
            }

            camera.projectionMatrix = camera.projectionMatrix.perspective(
                Math.toDegrees(fov.toDouble()).toFloat(),
                width / height,
                nearZ,
                farZ
            )
        } else { //ORTHOCAMERA
            if (initial) {
                camera = Camera(
                    CameraType.Orthographic,
                    near = nearZ,
                    far = farZ,
                    fov = fov,
                    bounds = RectF(left, top, right, bottom)
                )
            } else {
                camera.setup(
                    CameraType.Orthographic,
                    near = nearZ,
                    far = farZ,
                    fov = fov,
                    bounds = RectF(left, top, right, bottom)
                )
            }
            camera.projectionMatrix = camera.projectionMatrix.orthographic(left, right, top, bottom, nearZ, farZ)
        }
        camera.resX = width.toInt()
        camera.resY = height.toInt()
        camera.aspect = width / height
    }

    private fun onRasterTileEvent(event: RasterTileApiEvent) {
        if (pr.ON) pr.p(TAG, pr.onMove, "onMoveNoMove() onRasterTileEvent ${event}")
        if (pr.ON) pr.p("MapboxMapController", pr.lag, "onRasterTileEvent")
        when (event) {
            is RasterTileApiEvent.Success -> {}
            is RasterTileApiEvent.Error -> MapsGLDebug.trace("$TAG event Error")
            is RasterTileApiEvent.Reload -> {
                //updateTiles(false)
                controllerMainScope.launch {
                    if (pr.ON) pr.p(TAG, pr.onMove, "calling onMoveNoMove() from event")
                    onMoveNoMove(false, tag = "from onRasterTileEvent")
                }
            }
        }
    }

    internal open fun setupEvents() {}

    /**
     * Adds a new weather layer to the map.
     * @param layerCode - An enum of type LayerCode that indicates the desired layer.
     * @returns The newly added map layer
     */
    internal fun checkDownloadStatus(layerID: String, pendingTileNum: Int) {
        val currentLayer = layers[layerID]

        if (currentLayer != null) {
            if (pendingTileNum != 0) {
                if (pr.ON) pr.p(TAG, pr.threadDL, "checkDLStatus() pendingTile: $pendingTileNum")
            }

            val tAnimation = currentLayer.animator!!.animation
            tAnimation.pendingCount = pendingTileNum
            if (pendingTileNum != tAnimation.lastPendingCount) { //change in status
                if (pendingTileNum == 0) {
                    //if(pr.ON) pr.p(TAG, pr.requestTracker,"checkDownloadStatus()  ${currentLayer.id} is done with downloads!")
                } else if (tAnimation.lastPendingCount == 0) {
                    if (pr.ON) pr.p(TAG, pr.threadDL, "checkDLStatus() detected DL start: $pendingTileNum")
                    //if(pr.ON) pr.p(TAG, pr.requestTracker,"checkDownloadStatus()  ${currentLayer.id} is starting to download!")
                    //timeline.setIsDownloading(true)
                    //triggerLoadStart()
                }
            }
            tAnimation.lastPendingCount = tAnimation.pendingCount
        }

        waitingOnDL = false
        var waitCheck = false

        for (layer in layers.values) {
            if (layer.visible && layer.animator!!.animation.pendingCount != 0) {
                //MapsGLDebug.trace("GL1 found PendingDL: ${layer.value.id} has ${layer.value.animator!!.animation.pendingCount}")
                layer.waitingOnDL = true
                waitCheck = true
                //waitingOnDL = true
            }
        }

        if (waitCheck/*waitingOnDL*/) { // if you are waiting on DL and the timeline doesn't know it yet, trigger
            if (!Timeline.isDownloading) {
                Timeline.isDownloading = true
                downloadsStarted()
            }
        } else { // If not waiting on DL, and timeline still thinks it is dl, dl is done.
            if (Timeline.isDownloading) {
                Timeline.isDownloading = false
                downloadsDone()
            }
        }

        if (waitCheck != wasWaitCheck) { // If you are newly not waiting, make sure to updateTiles() (bind)
            if (pr.ON) pr.p(TAG, pr.blankNonAnim, "checkDownloadStatus()  waitingOnDL: $waitingOnDL")
            if (!waitCheck) {
                //updateTiles(false)
                controllerMainScope.launch {
                    timeline.updateDataMeld(timeline.state == AnimationState.playing)
                    val continueDownloading =
                        timeline.state == AnimationState.playing ||
                            timeline.opts.shouldPreloadData ||
                            timeline.opts.forcePreloadOneTime
                    refreshVisibleLayers(requestDL = continueDownloading)
                    // Defer the redraw to the next frame to avoid stalling the current one
                    // right when downloads complete and layers start binding textures.
                    choreographer.postFrameCallback {
                        redraw()
                    }
                }
            }
        }

        if (true /*!waitingOnDL*/) {
            readyToPlay = true
        }

        wasWaitingOnDL = waitingOnDL

        wasWaitCheck = waitCheck
    }

    private fun downloadsStarted() {
        if (pr.ON) pr.p(
            TAG,
            pr.threadDL,
            "downloadsStarted() isPlaying: ${timeline.state == AnimationState.playing} --------------------------------"
        )
        // Timeline keeps advancing; per-tile draw holds last ready interval in [RenderPass].
    }

    private fun downloadsDone() {
        if (pr.ON) pr.p(TAG, pr.autoPlay, "downloadsDone() Timeline.pausedForDownload: $${Timeline.pausedForDownload}")
        if (Timeline.pausedForDownload) {
            Timeline.pausedForDownload = false
            if (pr.ON) pr.p(TAG, pr.autoPlay, "downloadsDone() NOW GOING TO TIMELINE.PLAY() ")
            timeline.play(startImmediately = true)
        }
    }

    /** Get information from Encoded Tile Layers**/
    internal fun query(point: Point, layerList: List<TileLayer>, onTouch: Boolean = true): DataInspectorResult {
        var i = 0

        if (pr.ON) pr.p(TAG, pr.dIAnimation, "<< MapController query(): onTouch: $onTouch")

        val result: DataInspectorResult = if (onTouch) {
            dataInspector.dIResult
        } else {
            dataInspector.queryResult
        }

        result.clearEncoded()
        val seenSourcePresentation = mutableSetOf<String>()
        var fnVal: String
        for (layer in layerList) {
            // Match [TileLayer.getTileBounds]: tile Z = floor(renderZoom + layer.zoomOffset). Render path
            // prefers [CustomLayerRenderParameters.zoom] when the custom layer is drawing.
            val zoomBase = CameraSync.customLayerRenderZoom ?: camera.zoom
            val zoomVar = floor(zoomBase + layer.zoomOffset).toInt().coerceAtLeast(0)
            val latTile = TileConversions.latToTile(point.latitude(), zoomVar)
            val lonTile = TileConversions.lonToTileNormalized(point.longitude(), zoomVar)
            val latPix = TileConversions.getLatPixelInTile(point.latitude(), zoomVar, 512).toInt()
            val lonPix = TileConversions.getLonPixelInTile(point.longitude(), zoomVar, 512).toInt()
            val returnVal =
                layer.queryFeatures(
                    zoomVar,
                    latTile,
                    lonTile,
                    latPix,
                    lonPix,
                    point.longitude(),
                    point.latitude(),
                )

            if (pr.ON) pr.p(
                TAG,
                pr.dIAnimation,
                "<< MapController query(): z:$zoomVar, lat: $latTile, lonT: $lonTile, lapPix:$latPix, lonPix: $lonPix   "
            )
            if (pr.ON) pr.p(TAG, pr.dIAnimation, "<< MapController query():returnVal: $returnVal")

            if (returnVal != null) {

                val props = encodedQueriedFeatureProperties(returnVal, layer)

                result.queriedFeatures.add(
                    QueriedFeature(
                        null, layer.source.id, null,
                        props,
                        layer.id,
                    )
                )

                val presentation = dataInspector.presentationsByLayerId[layer.id]

                if (presentation != null) {
                    // Pass merged props (value, optional unit, timestamp) so formatters match MapsGL JS / iOS.
                    fnVal = presentation.fn(props)
                    // Several wind render paths (fill, particles, barbs, arrows) share one source + "Winds" presentation.
                    val dedupeKey = "${layer.source.id}:${presentation.title}"
                    if (seenSourcePresentation.add(dedupeKey)) {
                        result.encodedTitles.add(presentation.title.toString())
                        result.encodedLayerIds.add(layer.id)
                        result.encodedValues.add(fnVal)
                        result.encodedRawValues.add(returnVal)
                    }
                }
                i++
            }
        }

        return result
    }


    /**
     * Queries encoded tile layers and Mapbox vector layers at [point] for the given layer ids.
     *
     * @param point Map click / inspect location in WGS84.
     * @param layerList Layer ids to include (encoded + vector as applicable).
     * @param onTouch When `true`, merges with the active data-inspector touch buffer.
     * @return Per-layer [FeatureQueryResult] entries suitable for UI callouts.
     */
    suspend fun query(
        point: Point,
        layerList: List<String>,
        onTouch: Boolean = false
    ): HashMap<String, FeatureQueryResult> {
        var returnVector: HashMap<String, FeatureQueryResult>? = null

        if (pr.ON) pr.p(TAG, pr.queryNoInsp, "query() entered")

        if (this is MapboxMapController) {
            val vectorLayerList = getVectorLayersById(layerList)
            // Await the result directly, no need for an arbitrary delay
            returnVector = queryFeatures(point, vectorLayerList)
        }

        val result = query(point, getEncodedLayersById(layerList), onTouch)

        if (pr.ON) {
            pr.p("MapController", pr.query11, "<<  query(): encodedLayerIds: ${result?.encodedLayerIds}")
            pr.p("MapController", pr.query11, "<<  query(): encodedRawValues: ${result?.encodedTitles}")
            pr.p("MapController", pr.query11, "<<  query(): encodedRawValues: ${result?.encodedRawValues}")
            pr.p("MapController", pr.query11, "<<  query(): vectorTitles: ${result?.vectorLayerIds}")
            pr.p("MapController", pr.query11, "<<  query(): vectorTitles: ${result?.vectorTitles}")
            pr.p("MapController", pr.query11, "<<  query(): vectorValues: ${result?.vectorValues}|")
        }

        val returnHashMap = hashMapOf<String, FeatureQueryResult>()
        if (result != null) {
            for (item in result.encodedLayerIds) {
                val forLayer =
                    result.queriedFeatures.filter { it.mapLayerId == item }
                returnHashMap[item] = FeatureQueryResult(item, forLayer)
            }

        }

        if (returnVector != null) {
            returnHashMap.putAll(returnVector)
        }
        return returnHashMap

        /*
        return if (result != null) {
            result.toHashMap()
        } else hashMapOf()
        */
    }

    private fun getEncodedLayersById(layerIds: List<String>): List<EncodedTileLayer> {
        return layerIds.mapNotNull { id ->
            layers[id] as? EncodedTileLayer
        }
    }

    private fun getVectorLayersById(layerIds: List<String>): List<VectorTileLayer> {
        return layerIds.mapNotNull { id ->
            layers[id] as? VectorTileLayer
        }
    }

    /**
     * Mapbox map click: forwards to the data inspector when it is enabled.
     *
     * @return Always `false` so Mapbox may continue propagating the click.
     */
    override fun onMapClick(point: Point): Boolean {
        if (dataInspector.on) {
            dataInspector.showInternal(point)
        }

        return false
    }

    /**
     * Dispatches a named event to listeners registered with [on] for [type].
     *
     * @param type Event name (see [MapControllerEvents] for built-ins).
     * @param data Optional payload passed to each listener.
     */
    fun trigger(type: String, data: Any? = null) {
        listeners[type]?.let { eventListeners ->
            val listenersToTrigger = ArrayList(eventListeners)
            listenersToTrigger.forEach { listener ->
                try {
                    if (data != null) {
                        listener(data)
                    }

                } catch (e: Exception) {
                    MapsGLDebug.trace("Error in event listener for type '$type': ${e.message}")
                }
            }
        }
    }

    /**
     * Registers [callback] for controller-issued events named [name] (see [MapControllerEvents]).
     */
    override fun on(name: String, callback: (Any) -> Unit) {
        if (!listeners.containsKey(name)) {
            listeners[name] = mutableListOf()
        }
        listeners[name]?.add(callback)
    }

    /**
     * Removes a previously registered [callback] for [name].
     */
    override fun off(name: String, callback: (Any) -> Unit) {
        listeners[name]?.remove(callback)

    }

    internal class DataInspectorEvent {
        companion object {
            const val VECTOR_UPDATE = "VectorUpdate"
        }
    }

    private val legendControlCancellables = mutableListOf<Cancellable>()

    /**
     * Installs the provided legend control, wiring it to map events and populating initial legends.
     */
    fun add(legendControl: LegendControl?) {
        if (this.legendControl === legendControl) {
            legendControl?.getView()?.isVisible = true
            return
        }

        if (legendControl == null) {
            return
        }

        if (this.legendControl != null) {
            removeLegendControl()
        }

        this.legendControl = legendControl
        legendControl.setup(this.mapView)
        legendControl.getView().isVisible = true
        addLegends(forWeatherLayerCodes = layerIdsByWeatherCode.keys.toList())
        updateLegendsForMap()
    }

    /**
     * Removes the currently installed legend control and clears any associated observers.
     */

    fun removeLegendControl() {
        legendControlCancellables.forEach { it.cancel() }
        legendControlCancellables.clear()

        // 1. Get the view reference before nulling the control
        val viewToRemove = legendControl?.getView()

        // 2. Hide it
        viewToRemove?.isVisible = false

        // 3. CRITICAL: Detach it from whatever parent it currently has (MapView or outerConstraint)
        // (viewToRemove?.parent as? ViewGroup)?.removeView(viewToRemove)

        // 4. Null the reference
        this.legendControl = null
    }

    private fun addLegends(forWeatherLayerCodes: List<LayerCode>) {
        if (pr.ON) pr.p("MapController", pr.legend, "addLegends()")
        val control = legendControl ?: return
        for (layerCode in forWeatherLayerCodes) {
            val config = LayerCode.getConfigurationForLayerCode(layerCode, service) ?: continue

            if (config is CompositeWeatherLayerConfiguration) {
                val compositeLayerCodes = config.layers.map { it.code }
                addLegends(forWeatherLayerCodes = compositeLayerCodes)
                continue
            }

            if (config is WeatherLayerConfiguration<*, *>) {
                if (pr.ON) pr.p("MapController", pr.legend, "addLegends() calling addLegend for ${config.code}")
                addLegend(forConfig = config)
            }
        }
    }

    internal fun updateLegendsForMap() {
        controllerMainScope.launch {
            updateFeatureDrivenPointLegends()
        }
    }

    /**
     * Adds or refreshes the legend defined on [forConfig] into the current [legendControl].
     */
    fun addLegend(forConfig: WeatherLayerConfiguration<*, *>) {
        val legend = forConfig.legend ?: return
        val control = legendControl ?: return

        if (forConfig is BaseVectorConfiguration<*, *>) {
            forConfig.syncPointLegendFromFillPaint()
        }
        val legendToShow = forConfig.legend ?: return

        // For bar legends, update the color scale options to align with the layer's paint configuration
        control.add(legendToShow)
        setupLegendEvents(forConfig)
        syncLegend(forConfig)
    }

    private suspend fun updateFeatureDrivenPointLegends() {
        val control = legendControl ?: return
        val legends = control.legends.values
        val pointLegends = legends
            .filterIsInstance<PointLegend>()
            .filter { it.layerId != null && it.itemResolver != null }

        for (pointLegend in pointLegends) {
            val layerIdRegex = pointLegend.layerIdRegex ?: continue
            val itemResolver = pointLegend.itemResolver ?: continue

            for (layerCode in layerIdsByWeatherCode.keys) {
                if (layerIdRegex.matches(layerCode.value)) {
                    val vectorLayer = getWeatherLayer(layerCode) as? VectorTileLayer ?: continue
                    val features = vectorLayer.getVisibleFeatures()

                    if (features != null) {
                        val flattenedFeatures: List<QueriedFeature> = features.values.flatMap { it.features }
                        val items = itemResolver.resolveGL(flattenedFeatures)
                        //control.update(pointLegend.items(items))
                        control.update(pointLegend.copy(items = items))
                    }
                }
            }
        }
    }

    private fun refreshPointLegendOnControl(config: WeatherLayerConfiguration<*, *>) {
        val legend = config.legend as? PointLegend ?: return
        val control = legendControl ?: return
        if (!control.legends.containsKey(legend.id)) return
        control.update(legend)
    }

    /**
     * Sets up event listeners for a weather layer to ensure its legend stays in sync
     * with paint changes and data updates. Only works AFTER the layer has been added to the map.
     */
    private fun setupLegendEvents(config: WeatherLayerConfiguration<*, *>) {
        val layer = config.layer
        layer.on("PAINT_CHANGE") { data ->
            // Cast to our nested class
            val event = data as? LayerEvents.SamplePaintChangeEvent ?: return@on

            if (config.legend is BarLegend<*>) {
                // Check the property name we sent in the trigger
                if (event.property == "sample.colorscale") {
                    syncLegend(config)
                }
            } else if (config.legend is PointLegend && event.property == "fill.color") {
                if (config is BaseVectorConfiguration<*, *>) {
                    config.syncPointLegendFromFillPaint()
                }
                refreshPointLegendOnControl(config)
            }

            /*
            else if (legend is PointLegend && legend.layerId != null) {
                val sourceId = config.source.id
                // Find the source and listen for data changes to refresh visible features
                getSource(sourceId)?.on("DATA_CHANGE") {
                    updateLegendsForMap()
                }
            }
            */
        }
    }

    /**
     * Color ramp used by bar legends: [SampleLayerPaint], [GridLayerPaint.sample] (e.g. wind barbs), or contour sample paint.
     */
    private fun barLegendColorScaleFromPaint(paint: LayerPaint): ColorScaleOptions? {
        return when (paint) {
            is SampleLayerPaint -> paint.sample.colorScale
            is GridLayerPaint -> paint.sample?.colorScale
            is ContourLayerPaint -> paint.sample.colorScale
            else -> null
        }
    }

    /** Bar legend ticks for VECTOR wind (same magnitude span as encoded fill LUT). */
    private fun colorScaleForBarLegend(paint: LayerPaint, colorScale: ColorScaleOptions): ColorScaleOptions {
        val range = colorScale.range ?: return colorScale
        val expression = when (paint) {
            is SampleLayerPaint -> paint.sample.expression
            is ContourLayerPaint -> paint.sample.expression
            is GridLayerPaint -> paint.sample?.expression
            else -> null
        } ?: return colorScale
        return colorScale.copy(range = colorScaleRangeForMagnitudeLookup(expression, range))
    }

    /**
     * Intersection of two numeric ranges for bar-legend color span.
     *
     * [syncLegend] replaces template [ColorScaleOptions.range] with paint. When paint uses a default
     * span (e.g. first stop..last stop over the whole `precip_accum` palette), the bar would sample
     * the entire ramp (purple/cyan) while ticks still show 1-hour rates. Intersecting with the
     * template range keeps presentation (hour precip) aligned with [LegendCode] until paint is
     * explicitly narrower.
     */
    private fun intersectClosedRanges(
        paintRange: ClosedRange<Double>?,
        templateRange: ClosedRange<Double>?,
    ): ClosedRange<Double>? {
        if (paintRange == null) return templateRange
        if (templateRange == null) return paintRange
        val start = maxOf(paintRange.start, templateRange.start)
        val end = minOf(paintRange.endInclusive, templateRange.endInclusive)
        return if (start <= end) start..end else null
    }

    /**
     * Helper to trigger a legend sync specifically for a configuration.
     */
    private fun syncLegend(config: WeatherLayerConfiguration<*, *>) {

        val control = legendControl ?: return
        val currentLegend = config.legend ?: return
        val currentScale = barLegendColorScaleFromPaint(config.layer.paint) ?: return
        val legendScale = colorScaleForBarLegend(config.layer.paint, currentScale)

        if (currentLegend !is BarLegend<*>) return

        @Suppress("UNCHECKED_CAST")
        val barLegend = currentLegend as BarLegend<Dimension>
        val multibandStops = colorStopBandsFromOptionsStops(legendScale.stops)
        val updatedLegend = barLegend.copy(
            items = barLegend.items.mapIndexed { index, item ->
                // Multiband radar paint uses one nested stops list; each legend bar is one band (rain / mix / snow).
                val paintAlignedScale =
                    if (multibandStops != null && multibandStops.isNotEmpty()) {
                        val bandIndex = index.coerceIn(0, multibandStops.lastIndex)
                        legendScale.copy(stops = multibandStops[bandIndex])
                    } else {
                        legendScale
                    }
                // Paint carries raster/sample ramp settings (stops, range, interval). Legend templates
                // may set presentation-only flags such as interpolate=false for a stepped bar; do not let
                // paint defaults (interpolate=true) wipe those.
                val mergedRange =
                    intersectClosedRanges(paintAlignedScale.range, item.colorScaleOptions.range)
                        ?: paintAlignedScale.range
                        ?: item.colorScaleOptions.range
                item.copy(
                    colorScaleOptions = paintAlignedScale.copy(
                        interpolate = item.colorScaleOptions.interpolate,
                        range = mergedRange,
                    ),
                )
            },
        )

        control.update(updatedLegend)
    }

    /**
     * Tears down this controller's tile work, stencil registrations, and lifecycle observer.
     * Demo activities call this from [android.app.Activity.onStop] so the next screen gets a fresh
     * [MapController] instead of reusing stale Mapbox / timeline state.
     */
    open fun shutdown() {
        if (shutdownInvoked) return
        shutdownInvoked = true
        pauseForBackground()
        stopCustomLayerUpdates()
        downloadTrackingHandler.removeCallbacks(downloadTrackingRunnable)
        controllerMainJob.cancel()
        for (layerId in layers.keys.toList()) {
            runCatching { removeLayer(layerId) }
        }
        for (sourceId in sources.keys.toList()) {
            TileList.purgeSourceFromAllLists(sourceId)
        }
        if (this is com.xweather.mapsgl.map.mapbox.MapboxMapController) {
            GlStencilMaskCoordinator.releaseAllForController(this, service)
        }
        mapLifecycleOwner?.lifecycle?.removeObserver(this)
        lifecycleObserverRegistered = false
        mapLifecycleOwner = null
    }

    /**
     * [DefaultLifecycleObserver] callback: tears down this controller when the host [owner] is destroyed.
     * Delegates to [shutdown]; safe even if [shutdown] was already called explicitly.
     */
    override fun onDestroy(owner: LifecycleOwner) {
        shutdown()
    }

    /**
     * [MaskLayerKind.LAND] marine clip plus line-only [StencilLayerMaskSpec] layers (e.g. OSM motorways).
     */
    private fun isHybridLandLineStencil(
        maskKind: MaskLayerKind,
        customSpec: StencilLayerMaskSpec?,
        layerMap: Map<String, MapLayer<*, *>>,
    ): Boolean {
        if (maskKind != MaskLayerKind.LAND) return false
        val spec = customSpec ?: return false
        if (spec.layers.isEmpty() || spec.clipBounds != null) return false
        return spec.layers.all { ref ->
            val layer = layerMap[ref.layerId]
            layer == null || layer is VectorTileLayer
        }
    }

}
