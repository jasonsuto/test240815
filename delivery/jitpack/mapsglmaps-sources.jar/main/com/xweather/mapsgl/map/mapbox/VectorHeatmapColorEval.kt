package com.xweather.mapsgl.map.mapbox

import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.StyleValue

/**
 * Evaluates MapsGL / Mapbox `heatmap-color` expressions that interpolate on `heatmap-density`.
 */
internal object VectorHeatmapColorEval {

    data class RampStop(val density: Float, val rgba: FloatArray)

    fun buildRampStops(color: StyleValue<*>?): List<RampStop> {
        val expr = (color as? StyleValue.Expression)?.expression ?: return defaultRamp()
        return parseInterpolateStops(expr.raw) ?: defaultRamp()
    }

    fun sampleRamp(stops: List<RampStop>, density: Float): FloatArray {
        if (stops.isEmpty()) return floatArrayOf(0f, 0f, 0f, 0f)
        val d = density.coerceIn(0f, 1f)
        if (d <= stops.first().density) return stops.first().rgba.copyOf()
        if (d >= stops.last().density) return stops.last().rgba.copyOf()
        for (i in 0 until stops.size - 1) {
            val a = stops[i]
            val b = stops[i + 1]
            if (d >= a.density && d <= b.density) {
                val span = (b.density - a.density).coerceAtLeast(1e-6f)
                val t = (d - a.density) / span
                return floatArrayOf(
                    a.rgba[0] + (b.rgba[0] - a.rgba[0]) * t,
                    a.rgba[1] + (b.rgba[1] - a.rgba[1]) * t,
                    a.rgba[2] + (b.rgba[2] - a.rgba[2]) * t,
                    a.rgba[3] + (b.rgba[3] - a.rgba[3]) * t,
                )
            }
        }
        return stops.last().rgba.copyOf()
    }

    fun rampToTextureBytes(stops: List<RampStop>, size: Int = 256): ByteArray {
        val out = ByteArray(size * 4)
        for (i in 0 until size) {
            val density = i / (size - 1).toFloat()
            val rgba = sampleRamp(stops, density)
            val o = i * 4
            out[o] = (rgba[0] * 255f).toInt().coerceIn(0, 255).toByte()
            out[o + 1] = (rgba[1] * 255f).toInt().coerceIn(0, 255).toByte()
            out[o + 2] = (rgba[2] * 255f).toInt().coerceIn(0, 255).toByte()
            out[o + 3] = (rgba[3] * 255f).toInt().coerceIn(0, 255).toByte()
        }
        return out
    }

    fun rampToTexturePixels(stops: List<RampStop>, size: Int = 256): FloatArray {
        val out = FloatArray(size * 4)
        for (i in 0 until size) {
            val density = i / (size - 1).toFloat()
            val rgba = sampleRamp(stops, density)
            val o = i * 4
            out[o] = rgba[0]
            out[o + 1] = rgba[1]
            out[o + 2] = rgba[2]
            out[o + 3] = rgba[3]
        }
        return out
    }

    private fun defaultRamp(): List<RampStop> = listOf(
        RampStop(0f, floatArrayOf(0f, 0f, 0f, 0f)),
        RampStop(1f, floatArrayOf(1f, 0f, 0f, 1f)),
    )

    private fun parseInterpolateStops(raw: Any?): List<RampStop>? {
        val list = raw as? List<*> ?: return null
        if (list.isEmpty() || list[0] != "interpolate") return null
        if (list.size < 5) return null
        val input = list[2]
        if (!isHeatmapDensityInput(input)) return null
        val stops = ArrayList<RampStop>(8)
        var i = 3
        while (i + 1 < list.size) {
            val density = (list[i] as? Number)?.toFloat() ?: return null
            val rgba = colorTokenToRgba(list[i + 1]) ?: return null
            stops.add(RampStop(density, rgba))
            i += 2
        }
        return stops.ifEmpty { null }
    }

    private fun isHeatmapDensityInput(raw: Any?): Boolean = when (raw) {
        is List<*> -> raw.size == 1 && raw[0] == "heatmap-density"
        else -> false
    }

    private fun colorTokenToRgba(token: Any?): FloatArray? {
        when (token) {
            is String -> {
                val s = token.trim()
                if (s.startsWith("rgba(", ignoreCase = true) && s.endsWith(")")) {
                    val inner = s.substring(5, s.length - 1).split(',')
                    if (inner.size >= 4) {
                        val r = inner[0].trim().toIntOrNull() ?: return null
                        val g = inner[1].trim().toIntOrNull() ?: return null
                        val b = inner[2].trim().toIntOrNull() ?: return null
                        val a = inner[3].trim().toFloatOrNull() ?: return null
                        return floatArrayOf(r / 255f, g / 255f, b / 255f, a.coerceIn(0f, 1f))
                    }
                }
            }
            is androidx.compose.ui.graphics.Color -> {
                return floatArrayOf(token.red, token.green, token.blue, token.alpha)
            }
        }
        return null
    }
}
