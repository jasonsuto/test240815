package com.xweather.mapsgl.map.mapbox

import android.content.ComponentCallbacks2
import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.os.Looper
import android.os.SystemClock
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.google.gson.JsonElement
import com.mapbox.bindgen.Value
import com.mapbox.common.Cancelable
import com.mapbox.geojson.FeatureCollection
import com.mapbox.geojson.Point
import com.mapbox.maps.CameraChangedCallback
import com.mapbox.maps.CameraOptions
import com.mapbox.maps.CoordinateBounds
import com.mapbox.maps.LayerPosition
import com.mapbox.maps.MapIdleCallback
import com.mapbox.maps.MapView
import com.mapbox.maps.MapboxMap
import com.mapbox.maps.QueriedRenderedFeature
import com.mapbox.maps.RenderFrameFinishedCallback
import com.mapbox.maps.RenderedQueryGeometry
import com.mapbox.maps.RenderedQueryOptions
import com.mapbox.maps.ScreenBox
import com.mapbox.maps.ScreenCoordinate
import com.mapbox.maps.Size
import com.mapbox.maps.extension.style.layers.getLayer
import com.mapbox.maps.extension.style.layers.properties.generated.Visibility
import com.mapbox.maps.extension.style.sources.addSource
import com.mapbox.maps.extension.style.sources.generated.GeoJsonSource
import com.mapbox.maps.extension.style.sources.generated.geoJsonSource
import com.mapbox.maps.extension.style.sources.getSource
import com.mapbox.maps.plugin.gestures.gestures
import com.mapbox.maps.toCameraOptions
import com.xweather.mapsgl.anim.AnimationEvent
import com.xweather.mapsgl.anim.AnimationState
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.config.weather.account.XweatherAccount
import com.xweather.mapsgl.data.DataInspectorResult
import com.xweather.mapsgl.data.TileList
import com.xweather.mapsgl.events.MapControllerEvents
import com.xweather.mapsgl.geo.Geo
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.gl.math.PowerTable.Companion.powerTableI
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera
import com.xweather.mapsgl.layers.FeatureQueryResult
import com.xweather.mapsgl.layers.QueriedFeature
import com.xweather.mapsgl.layers.spec.MaskLayerKind
import com.xweather.mapsgl.layers.spec.StyleJSON
import com.xweather.mapsgl.layers.tile.EncodedTileLayer
import com.xweather.mapsgl.layers.tile.MapLayer
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.layers.tile.VectorTileLayer
import com.xweather.mapsgl.map.ImageRegisteringMap
import com.xweather.mapsgl.map.MapController
import com.xweather.mapsgl.map.MaskUtils
import com.xweather.mapsgl.map.MaskUtils.Companion._masks
import com.xweather.mapsgl.map.MaskUtils.Companion.getBackgroundColorRBGStringFromLayer
import com.xweather.mapsgl.map.mapbox.CameraSync.Companion.camera
import com.xweather.mapsgl.map.mapbox.CameraSync.Companion.mapZoom
import com.xweather.mapsgl.map.mapbox.CameraSync.Companion.rotScalePitchMatrix
import com.xweather.mapsgl.map.mapbox.CameraSync.Companion.scaleMatrix
import com.xweather.mapsgl.map.mapbox.CameraSync.Companion.translationMatrix
import com.xweather.mapsgl.map.mapbox.CameraSync.Companion.worldMatrix
import com.xweather.mapsgl.sources.DataSource
import com.xweather.mapsgl.sources.EncodedGridVectorTileSource
import com.xweather.mapsgl.sources.GeoJSONSource
import com.xweather.mapsgl.sources.VectorTileSource
import com.xweather.mapsgl.sources.VisibleGeoBounds
import com.xweather.mapsgl.sources.XweatherEncodedTileSource
import com.xweather.mapsgl.style.ParticleLayerPaint
import com.xweather.mapsgl.style.StyleValue
import com.xweather.mapsgl.style.VectorLayerPaint
import com.xweather.mapsgl.tiles.GLCoordinate2D
import com.xweather.mapsgl.tiles.LatLonBounds
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.types.Coordinate
import com.xweather.mapsgl.weather.WeatherSource
import com.xweather.mapsgl.util.MapsGLDebug
import com.xweather.mapsgl.utils.parseDateArrayFromString
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Date
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.tan

/**
 * [MapController] implementation backed by Mapbox Maps SDK: wires style sources/layers, custom GL
 * weather layers ([MapboxLayerHost]), camera sync ([CameraSync]), and Mapbox gestures (e.g. map clicks).
 *
 * Construct with the same [MapView] you show in your activity and an [XweatherAccount] for API access.
 *
 * @see MapController for weather layers, timeline, data inspector, and legends.
 */
class MapboxMapController : MapController, DefaultLifecycleObserver {
    /** Mapbox map handle; non-null after construction. Safe to use from the main thread once the view is attached. */
    var mapboxMap: MapboxMap? = null

    /**
     * Last [coordinateBoundsForCameraUnwrapped] snapshot from the owning (main) thread.
     * Mapbox forbids reading [MapboxMap.cameraState] / coordinate bounds from other threads
     * (e.g. render thread during custom layer draw, or IO during tile download).
     */
    @Volatile
    private var cachedMapboxBounds: CoordinateBounds? = null

    /** Main-thread compute time of [cachedMapboxBounds], for the short-lived reuse window in [getMapboxBounds]. */
    private var mapboxBoundsComputedAtMs: Long = -1L

    private val mapboxCancelables = mutableListOf<Cancelable>()
    internal var i = 0
    internal var i2 = 0

    /**
     * Last zoom density bin used for [EncodedGridVectorTileSource] ([EncodedGridVectorTileSource.densityKeyForMapZoom], 64 bins/level).
     * When the bin changes, sidecar symbol grids are invalidated so Mapbox refetches with the new spacing.
     */
    private var lastEncodedGridDensityKey: Int? = null

    /**
     * Last quantized visible bounds (see [EncodedGridVectorTileSource.viewportKeyForVisibleBounds]).
     * When pan / pitch / bearing changes the viewport, sidecars refetch so icons stay clipped and dense for the screen.
     */
    private var lastEncodedGridViewportKey: String? = null

    /** Floor zoom (integer zoom level). Used to ensure invalidation when Mapbox swaps tile z. */
    private var lastEncodedGridZoomFloor: Int? = null

    /** Log throttle so we only print once per integer zoom floor change. */
    private var lastLoggedEncodedGridZoomFloor: Int? = null

    /** Debug: last [mapZoom] printed to Logcat (encoded tile alignment vs zoom). */
    private var lastDebugLoggedMapZoom: Double? = null

    /** Poll camera during gestures (debounce alone never fires while the map is moving). */
    private var lastEncodedGridCameraFramePollMs: Long = 0L

    /** Throttle timeline meld-driven invalidation when camera is stationary. */
    private var lastEncodedGridTimelineInvalidateMs: Long = 0L

    /** Last quantized meld key invalidated for encoded-grid symbols. */
    private var lastEncodedGridTimelineMeldKey: Int? = null

    /**
     * Retries for [ensureGlStencilBaseOsmFetchLayer] while [GlStencilOsm.SOURCE_ID] is still being
     * registered on the Mapbox style (addSource is asynchronous).
     */
    private var glStencilBaseOsmFetchLayerSourceWaitRetries: Int = 0
    private var glStencilPrefetchKey: String? = null
    private val glStencilPrefetchInFlight = ConcurrentHashMap.newKeySet<String>()
    private val glStencilPrefetchQueued = ConcurrentHashMap.newKeySet<String>()
    private val glStencilPrefetchRetryCount = ConcurrentHashMap<String, Int>()
    private var glStencilTransportationZoomBin: Int = Int.MIN_VALUE
    @Volatile
    private var glStencilPrefetchWorkerRunning: Boolean = false

    /** Guards concurrent [addToMap] for [GlStencilOsm.SOURCE_ID] (avoids "already exists" crash). */
    private val glStencilOsmAddToMapInFlight = java.util.concurrent.atomic.AtomicBoolean(false)

    private fun stencilOsmSourceKindChanged(): Boolean {
        val last = GlStencilOsm.lastWiredSource ?: return false
        return last != GlStencilOsm.source
    }

    /**
     * Mapbox can keep [GlStencilOsm.SOURCE_ID] on the style after Demo 3 (MAPBOX) while MapsGL's
     * adapter was torn down with the previous [MapView]. Demo 2 (MAPSGL) must drop that entry and
     * register a fresh [CustomGeometrySource] or land-mask tiles stay fail-closed / invisible.
     */
    internal fun dropStaleGlStencilOsmStyleSource(vectorSrc: VectorTileSource?) {
        runCatching {
            mapboxMap?.style?.let { s ->
                if (s.styleLayerExists(GL_STENCIL_BASE_OSM_FETCH_LAYER_ID)) {
                    s.removeStyleLayer(GL_STENCIL_BASE_OSM_FETCH_LAYER_ID)
                }
            }
            if (mapboxMap?.style?.styleSourceExists(GlStencilOsm.SOURCE_ID) == true) {
                mapboxMap?.removeStyleSource(GlStencilOsm.SOURCE_ID)
            }
        }
        vectorSrc?.setInvalidateFunction(null)
        vectorSrc?.setBatchInvalidateFunction(null)
    }

    private fun syncGlStencilOsmTileUrls(vectorSrc: VectorTileSource) {
        val desc = GlStencilOsm.sourceDescriptor(service)
        if (vectorSrc.tileURL != desc.url) {
            vectorSrc.tileURL = desc.url
            vectorSrc.metadataURL = desc.metadataUrl
            vectorSrc.invalidate()
        }
    }

    /**
     * @deprecated v1.1.0 — use [MapboxMapController] `(mapView, account)` only.
     *
     * @param mapView Host [MapView].
     * @param baseContext Unused; retained for binary compatibility.
     * @param account Xweather credentials.
     * @param lifecycleOwner Unused; retained for binary compatibility.
     */
    @Deprecated(
        message = "Please use MapboxMapController(mapView: MapView, account: XweatherAccount) instead.",
        level = DeprecationLevel.WARNING
    )
    constructor(
        mapView: MapView,
        baseContext: Context,
        account: XweatherAccount,
        lifecycleOwner: LifecycleOwner,
    ) : this(mapView, account)

    /**
     * @param mapView Host [MapView] (must be the Mapbox map you display).
     * @param account Xweather credentials for [MapController.service] and tile URLs.
     */
    constructor(
        mapView: MapView,
        account: XweatherAccount,
    ) : super(mapView, account) {

        mapView.context.registerComponentCallbacks(this)
        mapboxMap = mapView.mapboxMap
        centerLatLng = Coordinate(mapboxMap!!.cameraState.center.latitude(), mapboxMap!!.cameraState.center.longitude())
        cachedMapboxBounds = mapboxMap!!.coordinateBoundsForCameraUnwrapped(
            mapboxMap!!.cameraState.toCameraOptions()
        )

        setupCamera(true)
        camera.refreshRateFactor = 60f / refreshRate
        /** dpi of 2 results in dpiMult of 1. dpi of 4 results in dpiMult of 2 **/
        camera.dpiMult = mapView.context.resources.displayMetrics.density / 2f
        handleCallbackSubscriptions()
        setupEvents()

        mapView.gestures.addOnMapClickListener(this)

        mapView.post { registerMapLifecycleObserver() }

        mapView.addOnLayoutChangeListener { _, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom ->
            val w = right - left
            val h = bottom - top
            val ow = oldRight - oldLeft
            val oh = oldBottom - oldTop
            if (w != ow || h != oh) {
                applyMapViewSizeChangeIfNeeded(
                    cameraTriggeredForOnMove = false,
                    tag = "from mapView onLayoutChange",
                )
            }
        }

        // Drain throttled stencil-VBO uploads automatically: every time the renderer denies an
        // upload because we're over budget for the current 16 ms window, fold a follow-up frame
        // into the coalesced repaint pipeline so all 19 tiles eventually upload after a slider
        // commit instead of stalling at one tile / frame.
        GlStencilMaskRendererHolder.renderer.onUploadThrottled = { requestRepaintCoalesced() }

        timeline.on(AnimationEvent.stop) {
            //MapsGLDebug.trace("DETECTED EVENT STOP FROM MapBoxMap")
            invalidateVector()
        }

        timeline.on(AnimationEvent.PAUSE) {
            //MapsGLDebug.trace("DETECTED EVENT STOP FROM MapboxMap")
            invalidateVector()
        }

        timeline.on(AnimationEvent.advance) {
            if (!anyEncodedGridVectorUsesMapboxTimelineMeld()) {
                return@on
            }
            val now = SystemClock.elapsedRealtime()
            val minIntervalMs = (1000.0 / refreshRate).toLong().coerceIn(4L, 50L)
            val m = Timeline.dataMeld
            val inMeldCrossfade = m > 1e-3f && m < 1f - 1e-3f
            if (inMeldCrossfade) {
                if (now - lastEncodedGridTimelineInvalidateMs >= minIntervalMs) {
                    lastEncodedGridTimelineInvalidateMs = now
                    CoroutineScope(Dispatchers.Main).launch {
                        invalidateEncodedGridVectorSourcesForTimelineMeld()
                    }
                }
            } else {
                val meldKey = (m * 2048f).toInt().coerceIn(0, 2048)
                val meldChanged = lastEncodedGridTimelineMeldKey == null || meldKey != lastEncodedGridTimelineMeldKey
                if (meldChanged && now - lastEncodedGridTimelineInvalidateMs >= minIntervalMs) {
                    lastEncodedGridTimelineInvalidateMs = now
                    lastEncodedGridTimelineMeldKey = meldKey
                    CoroutineScope(Dispatchers.Main).launch {
                        invalidateEncodedGridVectorSourcesForTimelineMeld()
                    }
                }
            }
        }


    }

    private fun invalidateVector() {
        for (layer in layers) {
            if (layer.value is VectorTileLayer) {
                if (layer.value.source !is GeoJSONSource) {
                    (layer.value.source as VectorTileSource).invalidate()
                } else {
                    // MapsGLDebug.trace("Detected event is  GeoJSONSource")
                }
            }
        }
    }

    /**
     * Invalidate encoded-grid symbol sources when zoom density or visible viewport changes so Mapbox refetches
     * tiles with updated spacing and [VisibleGeoBounds] clipping.
     */
    private fun invalidateEncodedGridVectorSourcesOnCameraChange() {
        val map = mapboxMap ?: return
        val zoom = map.cameraState.zoom
        val zoomFloor = kotlin.math.floor(zoom).toInt()
        if (lastLoggedEncodedGridZoomFloor == null || zoomFloor != lastLoggedEncodedGridZoomFloor) {
            lastLoggedEncodedGridZoomFloor = zoomFloor
            //MapsGLDebug.trace(">>> EncodedGridVector zoom update zoom=$zoom floor=$zoomFloor")
        }
        val densityKey = EncodedGridVectorTileSource.densityKeyForMapZoom(zoom)
        val visibleBounds =
            runCatching {
                val b = map.coordinateBoundsForCameraUnwrapped(map.cameraState.toCameraOptions())
                VisibleGeoBounds.fromMapboxUnwrappedCamera(
                    b,
                    map.cameraState.center.longitude(),
                    zoom,
                )
            }.getOrNull()
        val viewportKey =
            visibleBounds?.let { EncodedGridVectorTileSource.viewportKeyForVisibleBounds(it) } ?: "none"

        val densityChanged = lastEncodedGridDensityKey != null && densityKey != lastEncodedGridDensityKey
        val viewportChanged = lastEncodedGridViewportKey != null && viewportKey != lastEncodedGridViewportKey
        val zoomFloorChanged = lastEncodedGridZoomFloor != null && zoomFloor != lastEncodedGridZoomFloor

        if (densityChanged || viewportChanged || zoomFloorChanged) {
            forEachEncodedGridVectorTileSource { it.invalidate() }
        }
        lastEncodedGridDensityKey = densityKey
        lastEncodedGridViewportKey = viewportKey
        lastEncodedGridZoomFloor = zoomFloor
    }

    /**
     * Timeline meld updates can change vector icon direction/color with no camera movement.
     * Force encoded-grid source invalidation in that case so Mapbox refetches tile features.
     */
    private fun invalidateEncodedGridVectorSourcesForTimelineMeld() {
        forEachEncodedGridVectorTileSource { it.invalidateDynamicIconData() }
    }

    /** Shared constants for [MapboxMapController]: logging tag, camera projection modes, and GL-stencil ids. */
    companion object {
        /** Logcat tag for this controller. */
        val TAG = "MapboxMapController"
        // Comma-separated "z/x/y" tiles to trace stencil pipeline end-to-end.
        private const val MASK_DEBUG_TARGETS = "6/19/21,6/19/22,6/20/21,6/20/22,6/19/23,6/20/23"

        /** Camera projection mode matching MapsGL perspective setup. */
        const val PERSPECTIVECAMERA = 0

        /** Camera projection mode matching MapsGL orthographic setup. */
        const val ORTHOCAMERA = 1

        /**
         * Mapbox only invokes [com.mapbox.maps.CustomGeometrySource] [fetchTileFunction] when a style
         * layer references the source. This invisible fill (opacity 0) is added while GLES stencil
         * masking uses [GlStencilOsm.SOURCE_ID] so `requestTile` runs and the stencil cache fills. Id: [GL_STENCIL_BASE_OSM_FETCH_LAYER_ID].
         */
        internal const val GL_STENCIL_BASE_OSM_FETCH_LAYER_ID = "__mapsGlStencilBaseOsmFetch"
        internal const val MAX_STENCIL_PREFETCH_PER_CALL = 32
    }

    private fun maskDebugMatchesCanonical0zxy(key: String): Boolean {
        if (MASK_DEBUG_TARGETS.isEmpty()) return false
        val normalized = key.removePrefix("0:")
        return MASK_DEBUG_TARGETS.split(',').any { it.trim() == normalized }
    }

    /** Mapbox drawable size in pixels (width/height). */
    internal val size: Size
        get() = mapboxMap!!.getSize()

    private val cameraChangedCallBack = CameraChangedCallback { event ->
        if (!mapLifecycleStarted) return@CameraChangedCallback

        cameraTriggered = true
        if (timeline.state == AnimationState.playing) {
            Timeline.pausedForMovement = true
        }
        // Do not call timeline.pause() here. Mapbox can emit CAMERA_CHANGED every frame at high pitch
        // (and other continuous camera updates), which cancels the debounced job below before its 150ms
        // delay completes — so timeline.resume() never runs, playback stays paused, and encoded-tile
        // timeline meld stops advancing. Tile refresh still runs from renderFrameFinished / debounced work.
        if (pr.ON) pr.p(TAG, pr.autoPlay, "cameraChangedCallback, $event")

        applyMapViewSizeChangeIfNeeded(cameraTriggeredForOnMove = cameraTriggered, tag = "from cameraChangeCallback")

        debounceMoveEndJob?.cancel()
        debounceMoveEndJob = CoroutineScope(Dispatchers.Main).launch {
            delay(150)

            if (Timeline.pausedForMovement) {
                Timeline.pausedForMovement = false
            }

            updateLegendsForMap()
            invalidateEncodedGridVectorSourcesOnCameraChange()
        }

        // Reposition only: do not call updateWithSameData() here. That path runs finalizeLayoutAndMove(),
        // which posts moveView() to the next frame with stale screen coords while this callback also calls
        // move() immediately — the deferred move fights the fresh one and causes flicker/jumping during pan.
        if (dataInspector.isActive == true && mapboxMap != null && dataInspector.targetCoordinate != null) {
            dataInspector.move(mapboxMap!!.pixelForCoordinate(dataInspector.targetCoordinate!!))
        }
    }

    /**
     * When [MapView] width or height changes (rotation, timeline chrome, IME), refresh projection and GL.
     * The camera callback used to compare width only, so shrinking the map vertically (timeline settings)
     * left the old aspect and drew a stretched map until the next width change.
     */
    private fun applyMapViewSizeChangeIfNeeded(cameraTriggeredForOnMove: Boolean, tag: String) {
        if (mapView.width != lastWidth || mapView.height != lastHeight) {
            if (lastWidth != 0) {
                setupCamera(false)
                lastWidth = mapView.width
                lastHeight = mapView.height
                camera.orientationChanged = true

                for (layer in layers) {
                    if (layer.value.paint is ParticleLayerPaint) {
                        camera.needsRotationHandled = true
                    }
                }

                CoroutineScope(Dispatchers.Main).launch {
                    updateCamera()
                    if (timeline.state != AnimationState.playing /*|| Timeline.pausedForMovement*/) {
                        onMove(cameraTriggeredForOnMove, tag)
                    }
                }
            }
            lastWidth = mapView.width
            lastHeight = mapView.height
        }
    }

    /** Called from constuctor **/
    private fun handleCallbackSubscriptions() {

        val mapIdleCallback = MapIdleCallback {
            if (!mapLifecycleStarted) return@MapIdleCallback
            // Mapbox fires MapIdle after many non-camera settles (custom-layer redraw, scrub
            // rebind, style updates). Those must NOT run [onMoveEnd]: that path used to clear
            // full-timeline residency and re-request every visible tile — scrub after load
            // looked like a brand-new multi-minute download.
            if (Timeline.pausedForMovement) {
                Timeline.pausedForMovement = false
            }
            if (!cameraTriggered) {
                camera.moveState = Camera.STOPPED
                return@MapIdleCallback
            }
            cameraTriggered = false
            CoroutineScope(Dispatchers.Main).launch {
                onMoveEnd()
                invalidateEncodedGridVectorSourcesOnCameraChange()
            }
        }

        val renderFrameFinishedCallback = RenderFrameFinishedCallback {
            if (!mapLifecycleStarted) return@RenderFrameFinishedCallback
            CoroutineScope(Dispatchers.Main).launch {
                updateCamera() //Update matrices based on camera position
                onMoveNoMove(cameraTriggered, "from cameraChangeCallback")
                // Debounced camera callbacks are cancelled while the map moves; poll here so encoded-grid
                // sources still invalidate during pinch-zoom and drag.
                val now = SystemClock.elapsedRealtime()
                if (now - lastEncodedGridCameraFramePollMs >= 75L) {
                    lastEncodedGridCameraFramePollMs = now
                    invalidateEncodedGridVectorSourcesOnCameraChange()
                }
            }
        }

        mapboxMap?.subscribeRenderFrameFinished(renderFrameFinishedCallback)
            ?.let { mapboxCancelables += it }
        mapboxMap?.subscribeCameraChanged(cameraChangedCallBack)
            ?.let { mapboxCancelables += it }
        mapboxMap?.subscribeMapIdle(mapIdleCallback)
            ?.let { mapboxCancelables += it }
        mapboxMap?.subscribeStyleLoaded {
            if (!mapLifecycleStarted) return@subscribeStyleLoaded
            updateMaskLayersForMap()
        }?.let { mapboxCancelables += it }
    }

    /**
     * [LifecycleOwner] stop hook: cancels the pending move-end debounce and drops any queued
     * GL-stencil OSM prefetch work before delegating to [MapController.onStop].
     */
    override fun onStop(owner: LifecycleOwner) {
        debounceMoveEndJob?.cancel()
        debounceMoveEndJob = null
        glStencilPrefetchQueued.clear()
        super<MapController>.onStop(owner)
    }

    /**
     * Tears down this controller: cancels pending jobs, clears GL-stencil prefetch bookkeeping,
     * cancels all Mapbox subscriptions ([mapboxCancelables]), removes the GL-stencil base OSM
     * fetch layer, and clears [MapController.layerHosts]. Safe to call more than once.
     */
    override fun shutdown() {
        debounceMoveEndJob?.cancel()
        debounceMoveEndJob = null
        glStencilPrefetchQueued.clear()
        glStencilPrefetchInFlight.clear()
        glStencilPrefetchRetryCount.clear()
        glStencilOsmAddToMapInFlight.set(false)
        mapboxCancelables.forEach { it.cancel() }
        mapboxCancelables.clear()
        super.shutdown()
        runCatching { removeGlStencilBaseOsmFetchLayer() }
        layerHosts.clear()
    }

    /** [LifecycleOwner] destroy hook: delegates to [shutdown]. */
    override fun onDestroy(owner: LifecycleOwner) {
        shutdown()
    }

    private fun updateMaskLayersForMap() {
        // Land/water masking uses GLES stencil + base.osm, not Mapbox mask::* fill layers.
    }

    /** This is in the CameraSync class in the typescript version */
    private fun updateCamera() {
        mapZoom = mapboxMap!!.cameraState.zoom
        /**Center of viewable map from 0 to 1, top to bottom*/
        val c = getCenter()
        val lonNorm = (c.lon % 360.0 + 360.0 + 180.0) % 360.0 - 180.0
        val point = viewport.projection.project(Coordinate(c.lat, lonNorm))
        viewport.centerCoordinate = GLCoordinate2D(point.x, point.y)
        worldSize = densityMult * Geo.TILE_SIZE * 2.0.pow(mapZoom).toFloat()
        zoomInt = mapZoom.toInt() + zoomOffset

        val prevLogged = lastDebugLoggedMapZoom
        if (prevLogged == null || kotlin.math.abs(mapZoom - prevLogged) > 1e-4) {
            lastDebugLoggedMapZoom = mapZoom
            MapsGLDebug.logD(TAG, "mapZoom=$mapZoom zoomInt=$zoomInt (encoded tile / camera sync)")
        }

        // Mercator scale must track fractional mapZoom: worldSize uses 2^mapZoom, so using
        // discrete zoomInt here caused ~2x jumps at integer zooms (e.g. 0.9999 vs 1.0).
        val zoomForMercatorScale = mapZoom + zoomOffset
        scaleCalc = (tileSize / worldSize) * 2f.pow(zoomForMercatorScale.toFloat())
        scaleMatrix.elements[0] = scaleCalc
        scaleMatrix.elements[5] = -scaleCalc

        translationCalc = tileSize * 2.0.pow(zoomForMercatorScale + 1.0) // +1: Mapbox tile space
        translationMatrix.elements[12] = (point.x * translationCalc).toFloat()
        translationMatrix.elements[13] = (point.y * translationCalc).toFloat()

        rotScalePitchMatrix = CameraSync.calculateCameraMatrixDeg(
            getPitch().toFloat(), getBearing().toFloat(), scaleMatrix
        )
        worldMatrix.multiply(rotScalePitchMatrix, translationMatrix)
        camera.zoom =
            mapZoom // This is used in render to compare to maxZoom and scale tiles, 4.9999 can turn into 5.0...
        camera.worldMatrix = worldMatrix
        camera.updateMatrixWorld() //  camera.viewMatrix= worldMatrix.invert(), strips translation out of world matrix

        // Keep [cachedMapboxBounds] current for any thread that must not call Mapbox Camera APIs (render, tile IO).
        // Also stamps the reuse window used by getMapboxBounds() so the onMoveNoMove()/refreshVisibleLayers()
        // calls later in this same frame do not immediately redo the same native computation.
        runCatching {
            val m = mapboxMap!!
            cachedMapboxBounds = m.coordinateBoundsForCameraUnwrapped(m.cameraState.toCameraOptions())
            mapboxBoundsComputedAtMs = SystemClock.elapsedRealtime()
        }
    }

    /**
     * @return Mapbox camera zoom (fractional allowed).
     */
    override fun getZoom(): Double {
        mapZoom = mapboxMap!!.cameraState.zoom
        return mapZoom
        // Mapbox zoom is 1 less than normal zoom levels
    }

    /**
     * Animates or jumps the camera to the given Mapbox zoom.
     *
     * @param zoom Mapbox zoom level.
     */
    override fun setZoom(zoom: Double) {
        mapZoom = zoom
        mapboxMap?.setCamera(CameraOptions.Builder().zoom(zoom).build())
    }

    /**
     * Sets map bearing (rotation in degrees; 0 = north up).
     *
     * @param bearing Degrees clockwise from north.
     */
    fun setBearing(bearing: Double) {
        mapboxMap?.setCamera(
            CameraOptions.Builder().bearing(bearing).build()
        )
    }

    /**
     * Sets map pitch / tilt in degrees.
     *
     * @param pitch Degrees from vertical (Mapbox convention).
     */
    fun setPitch(pitch: Double) {
        mapboxMap?.setCamera(
            CameraOptions.Builder().pitch(pitch).build()
        )
    }

    /**
     * @return Current bearing in degrees.
     */
    override fun getBearing(): Double {
        return mapboxMap!!.cameraState.bearing
    }

    /**
     * @return Current pitch in degrees.
     */
    override fun getPitch(): Double {
        return mapboxMap!!.cameraState.pitch
    }

    /**
     * @return Camera center as latitude/longitude degrees.
     */
    override fun getCenter(): Coordinate {
        return Coordinate(
            mapboxMap!!.cameraState.center.latitude(), mapboxMap!!.cameraState.center.longitude()
        )
    }

    /**
     * Moves the camera center while preserving the current [getZoom].
     *
     * @param center Target latitude/longitude.
     */
    override fun setCenter(center: Coordinate) {
        centerLatLng = center
        mapboxMap?.setCamera(
            CameraOptions.Builder().center(
                Point.fromLngLat(center.lon, center.lat)
            ).zoom(getZoom()).build()
        )
    }

    /**
     * Visible geographic bounds derived from Mapbox unwrapped camera bounds and [VisibleGeoBounds].
     *
     * @return South, west, north, east in degrees for tile and UI logic.
     */
    override fun getBounds(): LatLonBounds {
        val boundingBox = getMapboxBounds()
        val v =
            VisibleGeoBounds.fromMapboxUnwrappedCamera(
                boundingBox,
                getCenter().lon,
                getZoom(),
            )

        // MapsGLDebug.trace(">>> MapboxMapController: getBounds() bnding bx: ${boundingBox.west()} to ${boundingBox.east()}")
        // MapsGLDebug.trace(">>> MapboxMapController: getBounds() bnding v: ${v.west} to ${v.east}")
        return LatLonBounds(v.west, v.south, v.east, v.north)
    }

    /**
     * Raw unwrapped longitudes from Mapbox — not passed through [VisibleGeoBounds], which can collapse
     * the viewport to a single [-180,180] strip and hide extra world copies for encoded tile draws.
     */
    override fun getUnwrappedCameraLonBoundsForTiles(): Pair<Double, Double> {
        val b = getMapboxBounds()
        return b.west() to b.east()
    }

    /**
     * Loads Xweather/MapsGL style assets once the Mapbox style is ready (images, DPR-aware resources).
     */
    override fun setupEvents() {
        val dpr = mapView.context.resources.displayMetrics.density
        doEnsuringStyleLoaded {
            mapboxMap?.let { map ->
                CoroutineScope(Dispatchers.Main).launch {
                    val registrar = MapboxImageRegistrar(map)
                    service.loadStyles(registrar, dpr)
                }
            }
        }
    }

    /**
     * [TileLayer.TileLayerEventListener] hook; reserved for future tile-layer events from Mapbox path.
     */
    override fun onTileLayerEvent(layerId: String, eventType: TileLayer.TileLayerEventType, data: Any?) {
    }


    internal fun testForceClear() {
        for (layer in layers.values) {
            if (layer is EncodedTileLayer) {
                val bounds = layer.getTileBounds()
                //MapsGLDebug.trace("MapboxMapController n cache size before: ${layer.source.tileCache.nativeCache.getCacheSize()}")

                layer.source.tileCache.clearOutsideBounds(bounds)
                //MapsGLDebug.trace("MapboxMapController n cache size after: ${layer.source.tileCache.nativeCache.getCacheSize()}")
            }
        }
    }

    /** [ComponentCallbacks2]: no-op; orientation is handled via camera callbacks. */
    override fun onConfigurationChanged(p0: Configuration) {}

    /** [ComponentCallbacks2]: no-op; deprecated in favor of [onTrimMemory]. */
    @Deprecated("Deprecated in Java")
    override fun onLowMemory() {
    }

    /**
     * Clears encoded tile caches outside the visible viewport when the OS reports memory pressure
     * ([ComponentCallbacks2]); aggressive only for background / UI-hidden levels.
     *
     * @param level Android memory trim level.
     */
    override fun onTrimMemory(level: Int) {
        // Determine how aggressively to clear caches based on the memory pressure level.
        val aggressive = when (level) {
            // Your app is running, but the device is getting low on memory.
            // A non-aggressive cleanup is appropriate.
            ComponentCallbacks2.TRIM_MEMORY_RUNNING_MODERATE, ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW -> {
                if (pr.ON) pr.p(
                    TAG,
                    pr.onMemoryTrim,
                    "onTrimMemory: Foreground memory pressure detected. Performing normal cleanup."
                )
                false
            }

            // This constant is deprecated in API 35 and can be safely removed.
            // The system will no longer send this signal to a foreground app.

            // Your app's UI is no longer visible. A great time to be aggressive with cleanup.
            ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN -> {
                if (pr.ON) pr.p(TAG, pr.onMemoryTrim, "onTrimMemory: UI is hidden")
                true
            }

            // Your app is in the background and is on the LRU list to be killed.
            // This is your last chance to clean up. This is the same as onLowMemory().
            ComponentCallbacks2.TRIM_MEMORY_COMPLETE, ComponentCallbacks2.TRIM_MEMORY_MODERATE -> {
                if (pr.ON) pr.p(
                    TAG,
                    pr.onMemoryTrim,
                    "onTrimMemory: Background memory pressure is high. Releasing as much as possible."
                )
                true
            }

            else -> false
        }

        // Only purge aggressively when the OS is asking for it.
        // Doing it for TRIM_MEMORY_RUNNING_LOW/MODERATE causes visible "rebind/reload" hitches
        // even though the GPU isn't actually out of room.
        if (!aggressive) return

        for (layer in layers.values) {
            if (layer is EncodedTileLayer) {
                val bounds = layer.getTileBounds()
                layer.source.tileCache.clearOutsideBounds(bounds)
            }
        }
    }

    /**
     * Reorders a style layer in the Mapbox style stack.
     *
     * @param id Style layer id to move.
     * @param beforeId Insert **before** this layer id, or `null` for top of stack.
     */
    override fun moveLayer(id: String, beforeId: String?) {
        val style = mapboxMap?.style ?: return
        if (!style.styleLayerExists(id)) return
        mapboxMap?.moveStyleLayer(id, LayerPosition(null, beforeId, null))
    }

    private fun doEnsuringStyleLoaded(block: () -> Unit) {
        mapboxMap?.let {
            if (it.style != null) {
                block()
            } else {
                val cancelable = it.subscribeStyleLoaded {
                    block()
                }
                mapboxCancelables += cancelable
            }
        }
    }

    private fun getMapboxBounds(): CoordinateBounds {
        val map = mapboxMap!!
        if (Looper.myLooper() == Looper.getMainLooper()) {
            // refreshVisibleLayers() calls this once per visible layer, and renderFrameFinished's
            // onMoveNoMove() calls it again every frame — all for the same camera state within a
            // single frame. Re-entering the native coordinateBoundsForCameraUnwrapped()/cameraState
            // JNI calls that many times per frame was measured (live thread-dump sampling during a
            // tile-load burst) as real main-thread contention. 8ms is well under one frame at 60fps,
            // so this only collapses same-frame redundant calls — it does not introduce stale bounds
            // across an actual camera move.
            val now = SystemClock.elapsedRealtime()
            val cached = cachedMapboxBounds
            if (cached != null && now - mapboxBoundsComputedAtMs < 8L) {
                return cached
            }
            val b = map.coordinateBoundsForCameraUnwrapped(map.cameraState.toCameraOptions())
            cachedMapboxBounds = b
            mapboxBoundsComputedAtMs = now
            return b
        }
        val cached = cachedMapboxBounds
        if (cached != null) {
            return cached
        }
        // Should not happen after [cachedMapboxBounds] is set in the constructor; avoid touching Mapbox off main.
        throw IllegalStateException(
            "coordinateBoundsForCameraUnwrapped cache unavailable off main thread"
        )
    }

    /** Refreshes [MapController.centerLatLng] from the current Mapbox camera center. */
    override fun updateCenterLatLngFromMap() {
        centerLatLng = Coordinate(mapboxMap!!.cameraState.center.latitude(), mapboxMap!!.cameraState.center.longitude())
    }

    /**
     * Formats a [Date] as an ISO-8601-like UTC string (first 19 chars + `Z`) for display or logging.
     *
     * @param date Instant to format using the system default zone then normalized for output.
     */
    fun formatDate(date: Date): String {
        return Timeline.formatDateToUTCString(date)
    }

    /**
     * Syncs MapsGL layer visibility, custom layer host visibility, and Mapbox style `visibility` for [id].
     */
    override fun setLayerVisible(id: String, visible: Boolean) {
        // Keep host + Mapbox style in sync before MapsGL redraw(). Previously super() ran first and could
        // triggerRepaint while layerHosts still had the old showLayer and/or before style visibility updated,
        // which matches “mask only updates after zoom” for custom layers.
        layerHosts[id]?.showLayer = visible
        //MapsGLDebug.trace(">>> MapboxMapController: setLayerVisible() visibility setting: #visible: $visible")
        doEnsuringStyleLoaded {
            mapboxMap?.style?.getLayer(id)?.visibility(if (visible) Visibility.VISIBLE else Visibility.NONE)
        }
        super.setLayerVisible(id, visible)
        triggerRepaintOnOwningThread()
    }

    /** Marks the custom [MapboxLayerHost] for [layerId] as needing its GL textures rebound. */
    override fun setLayerHostToUpdate(layerId: String) {
        layerHosts[layerId]?.setTexturesToBind()
    }

    /**
     * Refresh the custom stencil mask for the weather layer [layerId] after a mask vector
     * layer's paint has been mutated in place (e.g. new line thickness / cap / join). Updates
     * the coordinator's per-tile listeners so subsequent mesh builds use the new paint, replays
     * cached MVT features through the new listeners so already-loaded tiles rebuild their
     * stencil meshes, and asks Mapbox for a repaint.
     *
     * Crucially this path performs **no** `VectorTileSource.invalidate()` calls. Going through
     * the full register flow ends up calling `invalidate()` 5–6 times per refresh, each of which
     * expires every cached tile in the source and triggers Mapbox to call back into
     * `parseVectorTile` to re-decode the MVT bytes from scratch. For Demo 3 with a populated
     * tile cache that turned a single slider commit into a minute-long freeze followed by OOM as
     * hundreds of redundant mesh-build coroutines piled up. Skipping invalidate keeps the work
     * proportional to "rebuild meshes for cached tiles", not "redo every MVT decode".
     *
     * No-ops if [layerId] isn't a [TileLayer], or if the layer has no custom stencil mask spec.
     */
    /**
     * Activates GLES hybrid land ∩ line stencil on a weather layer (marine clip + motorways on land).
     * Call after [addWeatherLayer] when the layer uses [MaskLayerKind.LAND] plus line-only
     * [com.xweather.mapsgl.layers.spec.StencilLayerMaskSpec] refs.
     */
    /**
     * Ensures [GlStencilOsm.SOURCE_ID] is registered on the Mapbox style with a live
     * [MapboxVectorSourceAdapter]. Without this, [VectorTileSource.invalidate] is a no-op and
     * stencil MVT bytes never reach [GlStencilMaskCoordinator] after activity transitions.
     */
    internal fun ensureGlStencilOsmSourceWired(onReady: (() -> Unit)? = null) {
        val sourceDesc = GlStencilOsm.sourceDescriptor(service)
        if (getSource(GlStencilOsm.SOURCE_ID) == null) {
            addSource(sourceDesc)
        }
        val vectorSrc = getSource(GlStencilOsm.SOURCE_ID) as? VectorTileSource
        if (vectorSrc == null) {
            onReady?.invoke()
            return
        }

        fun whenReady() {
            GlStencilOsm.lastWiredSource = GlStencilOsm.source
            ensureGlStencilBaseOsmFetchLayer()
            onReady?.invoke()
        }

        syncGlStencilOsmTileUrls(vectorSrc)
        if (stencilOsmSourceKindChanged()) {
            dropStaleGlStencilOsmStyleSource(vectorSrc)
            glStencilMaskTileCache.clearAll()
        }

        if (vectorSrc.isWiredToMapboxCustomGeometrySource() && !stencilOsmSourceKindChanged()) {
            whenReady()
            return
        }

        // Another path is already adding this source; wait for it instead of a second addToMap.
        if (glStencilOsmAddToMapInFlight.get()) {
            pollUntilGlStencilOsmWired(0, onReady)
            return
        }

        doEnsuringStyleLoaded {
            if (mapboxMap?.style?.styleSourceExists(GlStencilOsm.SOURCE_ID) == true &&
                (!vectorSrc.isWiredToMapboxCustomGeometrySource() || stencilOsmSourceKindChanged())
            ) {
                dropStaleGlStencilOsmStyleSource(vectorSrc)
            }
            if (vectorSrc.isWiredToMapboxCustomGeometrySource() && !stencilOsmSourceKindChanged()) {
                whenReady()
            } else {
                addToMap(vectorSrc) { whenReady() }
            }
        }
    }

    private fun pollUntilGlStencilOsmWired(
        attempt: Int,
        onReady: (() -> Unit)?,
        wireSession: Long = mapSessionId,
    ) {
        if (wireSession != Timeline.mapSessionId) return
        val vectorSrc = getSource(GlStencilOsm.SOURCE_ID) as? VectorTileSource
        if (vectorSrc?.isWiredToMapboxCustomGeometrySource() == true) {
            ensureGlStencilBaseOsmFetchLayer()
            onReady?.invoke()
            return
        }
        if (attempt >= 80) {
            MapsGLDebug.trace(
                "[GlStencilMask] ${GlStencilOsm.SOURCE_ID} not wired after 4s; stencil mask may stay empty",
            )
            onReady?.invoke()
            return
        }
        mapView.postDelayed({ pollUntilGlStencilOsmWired(attempt + 1, onReady, wireSession) }, 50L)
    }

    /**
     * Re-binds OSM stencil fetch, tile-cache replay, and per-layer render hooks after
     * [addWeatherLayer] with a built-in [MaskLayerKind]. Call from app demos when switching
     * mask types across activities (land → water).
     */
    fun finalizeBuiltInGlStencilMask(layerId: String) {
        val tileLayer = getLayer(layerId) as? TileLayer ?: return
        val kind = tileLayer.glStencilMaskKind
        if (kind == MaskLayerKind.NONE) return
        val iso = if (kind == MaskLayerKind.COUNTRY) tileLayer.glStencilMaskCountryIso else null
        GlStencilMaskCoordinator.ensureBaseOsmMaskConsumer(this, service, kind, iso)
        tileLayer.tileLayerRenderer.invalidateGlStencilMaskHooks()

        val wireSession = mapSessionId
        ensureGlStencilOsmSourceWired {
            if (wireSession != Timeline.mapSessionId) return@ensureGlStencilOsmSourceWired
            (getSource(GlStencilOsm.SOURCE_ID) as? VectorTileSource)?.let { src ->
                // One replay after land→water activity switch: vector tiles may already be
                // parsed while the CustomGeometrySource adapter was still unwired.
                src.replayGlStencilFeedsFromCachedVectorTiles()
                src.invalidate()
            }
            requestRepaintCoalesced()
            triggerRepaintOnOwningThread()
        }
    }

    /**
     * Activates GLES hybrid land ∩ line stencil on a weather layer (marine clip + motorways on land).
     * Call after [addWeatherLayer] when the layer uses [MaskLayerKind.LAND] plus line-only
     * [com.xweather.mapsgl.layers.spec.StencilLayerMaskSpec] refs.
     */
    fun configureHybridLandHighwayStencil(layerId: String) {
        val tileLayer = getLayer(layerId) as? TileLayer ?: return
        val spec = tileLayer.stencilLayerMask ?: return
        if (spec.layers.isEmpty()) return
        tileLayer.hybridLandWithCustomLineMask = true
        tileLayer.glStencilMaskKind = MaskLayerKind.LAND
        if (tileLayer is EncodedTileLayer) {
            tileLayer.hasLandMask = true
        }
        GlStencilMaskCoordinator.ensureBaseOsmMaskConsumer(this, service, MaskLayerKind.LAND, null)
        tileLayer.tileLayerRenderer.invalidateGlStencilMaskHooks()
        reregisterCustomStencilMask(layerId)
    }

    /**
     * Refresh the custom stencil mask for the weather layer [layerId] after a mask vector
     * layer's paint has been mutated in place (e.g. new line thickness / cap / join). Updates
     * the coordinator's per-tile listeners so subsequent mesh builds use the new paint, replays
     * cached MVT features through the new listeners so already-loaded tiles rebuild their
     * stencil meshes, and asks Mapbox for a repaint.
     *
     * Crucially this path performs **no** `VectorTileSource.invalidate()` calls. Going through
     * the full register flow ends up calling `invalidate()` 5–6 times per refresh, each of which
     * expires every cached tile in the source and triggers Mapbox to call back into
     * `parseVectorTile` to re-decode the MVT bytes from scratch. For Demo 3 with a populated
     * tile cache that turned a single slider commit into a minute-long freeze followed by OOM as
     * hundreds of redundant mesh-build coroutines piled up. Skipping invalidate keeps the work
     * proportional to "rebuild meshes for cached tiles", not "redo every MVT decode".
     *
     * No-ops if [layerId] isn't a [TileLayer], or if the layer has no custom stencil mask spec.
     */
    fun refreshCustomStencilMask(layerId: String) {
        val tileLayer = getLayer(layerId) as? TileLayer ?: return
        val spec = tileLayer.stencilLayerMask ?: return
        if (spec.layers.isEmpty() && spec.clipBounds == null) return
        if (useGlTextureMaskFbo) {
            glTextureMaskBuilder.markDirty()
        }
        GlStencilCustomMaskCoordinator.refreshPaint(this, layerId, spec)
        triggerRepaintOnOwningThread()
    }

    /**
     * Rebinds MVT/GeoJSON stencil listeners after [TileLayer.stencilLayerMask.layers] changes
     * (e.g. toggling individual mask layers in Demo 3). Paint-only updates should use
     * [refreshCustomStencilMask] instead.
     */
    fun reregisterCustomStencilMask(layerId: String, forceInvalidate: Boolean = false) {
        val tileLayer = getLayer(layerId) as? TileLayer ?: return
        val spec = tileLayer.stencilLayerMask ?: return
        if (spec.layers.isEmpty() && spec.clipBounds == null) return
        // Check resolvability *before* touching the existing registration. Unregistering
        // unconditionally here and letting `register()` bail internally left a window where
        // rapid demo switching (mid teardown/recreate of mask vector layers) could destroy a
        // working registration and replace it with nothing, permanently, until the next
        // successful reregister call — the mask coordinator's own internal pre-check couldn't
        // help because by the time it ran, this function had already unregistered.
        if (!GlStencilCustomMaskCoordinator.hasResolvableMaskLayer(this, spec)) {
            MapsGLDebug.logW(
                "GlStencilCustomMask",
                "reregisterCustomStencilMask: none of ${spec.layers.map { it.layerId }} resolved " +
                    "to a live VectorTileLayer for \"$layerId\"; leaving the existing registration " +
                    "(if any) untouched instead of tearing it down.",
            )
            return
        }
        tileLayer.tileLayerRenderer.invalidateGlStencilMaskHooks()
        GlStencilCustomMaskCoordinator.unregister(this, layerId, clearMeshCache = false)
        if (useGlTextureMaskFbo) {
            glTextureMaskBuilder.markDirty()
        }
        GlStencilCustomMaskCoordinator.register(this, layerId, spec, replayOnly = !forceInvalidate)
        requestRepaintCoalesced()
        triggerRepaintOnOwningThread()
    }

    /**
     * Removes the custom stencil/texture mask from [layerId] so weather draws unmasked. Mask
     * vector layers (motorway, CONUS fill) stay on the map and can be re-enabled via
     * [reregisterCustomStencilMask] after restoring [TileLayer.stencilLayerMask].
     */
    fun clearCustomStencilMask(layerId: String) {
        val tileLayer = getLayer(layerId) as? TileLayer ?: return
        tileLayer.tileLayerRenderer.invalidateGlStencilMaskHooks()
        GlStencilCustomMaskCoordinator.unregister(this, layerId, clearMeshCache = false)
        tileLayer.stencilLayerMask = null
        if (useGlTextureMaskFbo) {
            glTextureMaskBuilder.markDirty()
        }
        requestRepaintCoalesced()
        triggerRepaintOnOwningThread()
    }

    /**
     * Registers [source] as a Mapbox style source ([VectorTileSource] via [MapboxVectorSourceAdapter]
     * custom geometry, [GeoJSONSource] as a native `GeoJsonSource`), waiting for style load first.
     * Handles the [GlStencilOsm.SOURCE_ID] special case (re-wiring a stale/mismatched adapter left
     * over from a previous [MapView]) and invokes [onSourceAdded] once registration completes.
     */
    override fun addToMap(source: DataSource, onSourceAdded: () -> Unit) {
        doEnsuringStyleLoaded {
            if (mapboxMap?.style?.styleSourceExists(source.id) == true) {
                val vectorSource = source as? VectorTileSource
                val isStencilOsm = source.id == GlStencilOsm.SOURCE_ID
                val mustReplaceStencil =
                    isStencilOsm &&
                        vectorSource != null &&
                        (!vectorSource.isWiredToMapboxCustomGeometrySource() || stencilOsmSourceKindChanged())
                if (vectorSource != null &&
                    (!vectorSource.isWiredToMapboxCustomGeometrySource() || mustReplaceStencil)
                ) {
                    // Mapbox v11 can preserve style sources across activities while MapsGL's
                    // CustomGeometrySource adapter was torn down with the previous MapView (e.g.
                    // Demo 3 MAPBOX → Demo 2 MAPSGL). Without this, addToMap returns early and
                    // stencil tiles never reach glStencilMaskTileListener.
                    if (isStencilOsm) {
                        syncGlStencilOsmTileUrls(vectorSource)
                        if (mustReplaceStencil) {
                            glStencilMaskTileCache.clearAll()
                        }
                    }
                    dropStaleGlStencilOsmStyleSource(vectorSource)
                } else {
                    onSourceAdded.invoke()
                    if (vectorSource?.id == GlStencilOsm.SOURCE_ID) {
                        GlStencilOsm.lastWiredSource = GlStencilOsm.source
                        ensureGlStencilBaseOsmFetchLayer()
                    }
                    return@doEnsuringStyleLoaded
                }
            }
            if (pr.ON) pr.p("MapboxMapController", pr.adminLayers, "addToMap() 100")
            try {
                when (source) {
                    is VectorTileSource -> {
                        val isStencilOsm = source.id == GlStencilOsm.SOURCE_ID
                        if (isStencilOsm && !glStencilOsmAddToMapInFlight.compareAndSet(false, true)) {
                            pollUntilGlStencilOsmWired(0, onSourceAdded)
                            return@doEnsuringStyleLoaded
                        }
                        mapboxMap?.let {
                            val adapter = MapboxVectorSourceAdapter(source, it)
                            MainScope().launch {
                                try {
                                    val customSource = adapter.makeSource()
                                    source.validTime =
                                        parseDateArrayFromString(Timeline.timeStrings[Timeline.currentPhaseA]).first()
                                    source.setInvalidateFunction(adapter::invalidate)
                                    if (source is EncodedGridVectorTileSource) {
                                        source.setBatchInvalidateFunction { coords ->
                                            adapter.invalidateTilesBatch(coords)
                                        }
                                    }
                                    val style = mapboxMap?.style
                                    if (isStencilOsm) {
                                        syncGlStencilOsmTileUrls(source)
                                        if (stencilOsmSourceKindChanged() ||
                                            style?.styleSourceExists(source.id) == true
                                        ) {
                                            dropStaleGlStencilOsmStyleSource(source)
                                        }
                                        runCatching {
                                            mapboxMap?.addSource(customSource)
                                        }.onFailure { e ->
                                            val msg = e.message.orEmpty()
                                            if (!msg.contains("already exists", ignoreCase = true)) {
                                                throw e
                                            }
                                        }
                                        GlStencilOsm.lastWiredSource = GlStencilOsm.source
                                    } else if (style?.styleSourceExists(source.id) != true) {
                                        runCatching {
                                            mapboxMap?.addSource(customSource)
                                        }.onFailure { e ->
                                            val msg = e.message.orEmpty()
                                            if (!msg.contains("already exists", ignoreCase = true)) {
                                                throw e
                                            }
                                        }
                                    }
                                    onSourceAdded.invoke()
                                    if (source.id == WeatherSource.SourceCode.base_osm.value ||
                                        source.id == GlStencilOsm.SOURCE_ID
                                    ) {
                                        ensureGlStencilBaseOsmFetchLayer()
                                    }
                                } finally {
                                    if (isStencilOsm) {
                                        glStencilOsmAddToMapInFlight.set(false)
                                    }
                                }
                            }
                        }
                    }

                    is GeoJSONSource -> {
                        val emptyCollection = FeatureCollection.fromFeatures(emptyList())
                        source.pushGeoJsonToMapStyle = { fc ->
                            // Style mutations must run on the MapView / main thread.
                            mapView.post {
                                doEnsuringStyleLoaded {
                                    val style = mapboxMap?.style ?: return@doEnsuringStyleLoaded
                                    if (!style.styleSourceExists(source.id)) return@doEnsuringStyleLoaded
                                    val mb =
                                        style.getSource(source.id) as? GeoJsonSource ?: return@doEnsuringStyleLoaded
                                    mb.featureCollection(fc ?: emptyCollection)
                                }
                                mapboxMap?.triggerRepaint()
                            }
                        }
                        val geoJsonSource = geoJsonSource(source.id) {
                            when {
                                source.data != null -> featureCollection(source.data!!)
                                !source.url.isNullOrBlank() -> {
                                    val resolved = source.makeDataURL()
                                    if (resolved != null) {
                                        data(resolved.toString())
                                    } else {
                                        featureCollection(emptyCollection)
                                    }
                                }

                                else -> featureCollection(emptyCollection)
                            }
                        }
                        mapboxMap?.style?.addSource(geoJsonSource)
                        mapView.post { mapboxMap?.triggerRepaint() }
                        onSourceAdded.invoke()
                    }

                    else -> {}
                }
            } catch (e: Exception) {
                MapsGLDebug.trace(">>> MapController: Failed to add source to map: ${e.localizedMessage}")
            }
        }
    }

    /**
     * Adds [layer] to the Mapbox style: vector layers as Mapbox style layers, encoded/custom layers
     * via [MapboxLayerHost] persistent custom layers. Waits for style load and optionally for source readiness.
     */
    override fun addToMap(layer: MapLayer<*, *>, beforeId: String?) {
        // This ensures that the code inside only runs after the style is loaded.
        doEnsuringStyleLoaded {
            // Do not call super.addToMap for VectorTileLayer: TileLayer.onAdd runs RasterLayerRenderer.setUpRenderPass,
            // which casts paint to RasterLayerPaint; vector style layers use CircleLayerPaint / FillLayerPaint / etc.
            MainScope().launch {
                while (cameraTriggered) { // Don't add while mapbox is moving. Prevents crashes if added while moving.
                    delay(50)
                }

                val style = mapboxMap?.style ?: return@launch

                when (layer) {
                    is VectorTileLayer -> {
                        if (layer.stencilOnly) {
                            mapView.post { mapboxMap?.triggerRepaint() }
                            MainScope().launch {
                                delay(1000)
                                trigger(MapControllerEvents.VECTOR_LAYER_ADDED, "")
                            }
                        } else if (layer.paint is VectorLayerPaint) {
                            if (style.styleLayerExists(layer.id)) return@launch
                            val vectorPaint = layer.paint as VectorLayerPaint
                            val paintStyle = vectorPaint.asStyleJSON(
                                id = layer.id, source = layer.source.id, sourceLayer = layer.sourceLayer
                            )
                            paintStyle.filter = layer.filter
                            val styleJSON = paintStyle.asStyleJSONObject()
                            val fillStrokeOutlineStyle =
                                (vectorPaint as? com.xweather.mapsgl.style.FillLayerPaint)
                                    ?.strokeOutlineStyleJSON(
                                        com.xweather.mapsgl.style.FillLayerPaint.strokeOutlineLayerId(layer.id),
                                        layer.source.id,
                                        layer.sourceLayer,
                                    )
                                    ?.also { it.filter = layer.filter }
                                    ?.asStyleJSONObject()

                            fun addStyleLayer(json: Map<String, Any>, layerId: String) {
                                if (mapboxMap?.style?.styleLayerExists(layerId) == true) return
                                mapboxMap?.styleManager?.addPersistentStyleLayer(
                                    Value.valueOf(json.toValueMap()), LayerPosition(null, beforeId, null)
                                )
                            }

                            fun addStyleLayers() {
                                addStyleLayer(styleJSON, layer.id)
                                fillStrokeOutlineStyle?.let { outlineJson ->
                                    addStyleLayer(
                                        outlineJson,
                                        com.xweather.mapsgl.style.FillLayerPaint.strokeOutlineLayerId(layer.id),
                                    )
                                }
                                mapView.post { mapboxMap?.triggerRepaint() }
                            }

                            if (mapboxMap?.style?.styleSourceExists(layer.source.id) == false) {
                                var job: Job? = null
                                job = onSourceAdded.observe(onEach = {
                                    if (it == layer.source.id) {
                                        addStyleLayers()
                                        job?.cancel()
                                    }
                                })

                                // Fallback in case onSourceAdded fires before observer registration.
                                MainScope().launch {
                                    repeat(30) {
                                        delay(100)
                                        if (mapboxMap?.style?.styleSourceExists(layer.source.id) == true) {
                                            addStyleLayers()
                                            job?.cancel()
                                            return@launch
                                        }
                                    }
                                }
                            } else {
                                addStyleLayers()
                            }

                            MainScope().launch {
                                delay(1000) // Wait for 1000 milliseconds (1 second)
                                trigger(MapControllerEvents.VECTOR_LAYER_ADDED, "")
                            }
                        }
                    }

                    is TileLayer -> {
                        // This coroutine can sit behind the `while (cameraTriggered)` wait above for
                        // an arbitrary amount of time. Rapid demo/layer switching that removes and
                        // re-adds the same layer id (e.g. mask-demo buttons) queues one of these per
                        // add call with no cancellation and no staleness check; once the camera
                        // settles they all fire in a burst and, without this guard, whichever one
                        // happens to run *last* wins the layerHosts/addPersistentStyleCustomLayer
                        // binding — independent of which TileLayer instance is actually current in
                        // [layers]. That silently detaches rendering from whatever the mask
                        // coordinator has correctly configured against the current instance.
                        if (layers[layer.id] !== layer) {
                            MapsGLDebug.logW(
                                TAG,
                                "addToMap: skipping stale TileLayer id=${layer.id} " +
                                    "identity=${System.identityHashCode(layer)} " +
                                    "current=${System.identityHashCode(layers[layer.id])}",
                            )
                            return@launch
                        }
                        super.addToMap(layer, beforeId)
                        layer.addTileLayerEventListener(this@MapboxMapController)
                        if (style.styleLayerExists(layer.id)) {
                            runCatching { style.removeStyleLayer(layer.id) }
                            layerHosts.remove(layer.id)
                        }
                        try {
                            if (!layerHosts.contains(layer.id)) {
                                val layerHost = MapboxLayerHost(mapView.context, layer)
                                startCustomLayerUpdates(layer.paint is ParticleLayerPaint)
                                layerHosts[layer.id] = layerHost
                                layerHost.setLayerHostCamera(camera)
                            }
                        } catch (e: Exception) {
                            MapsGLDebug.trace("$TAG Failed to add layer to map: $e")
                        }

                        mapboxMap?.style!!.addPersistentStyleCustomLayer(
                            layer.id, layerHosts[layer.id] as MapboxLayerHost, LayerPosition(null, beforeId, null)
                        )
                        if (layer.glStencilMaskKind != MaskLayerKind.NONE) {
                            finalizeBuiltInGlStencilMask(layer.id)
                        }
                        // Gridded wind sidecars are registered before this style layer exists; without a post-add
                        // invalidate, Mapbox may not refetch custom geometry until the next camera change (e.g. zoom 0).
                        forEachEncodedGridVectorTileSource { it.invalidate() }
                        mapView.post { mapboxMap?.triggerRepaint() }
                    }
                }
            }
        }
    }

    /** Removes a style source from Mapbox when the [DataSource] is removed from the controller. */
    override fun removeFromMap(source: DataSource) {
        super.removeFromMap(source)

        doEnsuringStyleLoaded {
            if (source is VectorTileSource || source is GeoJSONSource) {
                if (source is GeoJSONSource) {
                    source.pushGeoJsonToMapStyle = null
                }
                mapboxMap?.style?.let {
                    if (it.styleSourceExists(source.id)) {
                        mapboxMap?.removeStyleSource(source.id)
                    }
                }
            }
        }
    }

    /**
     * Removes [layer]'s Mapbox style layer(s) — including its fill/stroke-outline companion layer,
     * if any — and its [MapboxLayerHost] entry when the [MapLayer] is removed from the controller.
     */
    override fun removeFromMap(layer: MapLayer<*, *>) {
        super.removeFromMap(layer)
        if (layer is TileLayer) layer.removeTileLayerEventListener(this)
        doEnsuringStyleLoaded {
            mapboxMap?.style?.let {
                if (it.styleLayerExists(layer.id)) {
                    it.removeStyleLayer(layer.id)
                }
                val fillStrokeId =
                    com.xweather.mapsgl.style.FillLayerPaint.strokeOutlineLayerId(layer.id)
                if (it.styleLayerExists(fillStrokeId)) {
                    it.removeStyleLayer(fillStrokeId)
                }
                layerHosts.remove(layer.id)
                //hostLayerIds.remove(layer.id)
            }
        }
    }

    /**
     * Mapbox [MapboxMap.triggerRepaint] must run on the thread that owns the native [Map] (the UI/main thread).
     * [redraw] is also invoked from the custom-layer render path (e.g. [MapboxLayerHost.bindTextures]), which runs
     * on the renderer thread — posting avoids bindgen "not owning the object" errors during timeline playback.
     */
    private fun triggerRepaintOnOwningThread() {
        val map = mapboxMap ?: return
        if (Looper.myLooper() == Looper.getMainLooper()) {
            map.triggerRepaint()
        } else {
            mapView.post { mapboxMap?.triggerRepaint() }
        }
    }

    private val coalescedRepaintPending = java.util.concurrent.atomic.AtomicBoolean(false)

    /**
     * Asks Mapbox for a follow-up render frame, coalescing concurrent callers. Used by the stencil
     * coordinator's build coroutines: each completed mesh needs Mapbox to draw again so the
     * renderer can upload the fresh VBO, but the builds finish in bursts and 19 individual
     * [triggerRepaintOnOwningThread] posts would cascade into Mapbox's render loop (and back into
     * our tile listeners, the same fan-out that caused the rebuild loop). The atomic flag is
     * cleared inside the posted runnable so at most one repaint can be queued at a time — extra
     * builds finishing in the same window get folded into the next frame for free.
     */
    internal fun requestRepaintCoalesced() {
        if (!coalescedRepaintPending.compareAndSet(false, true)) return
        mapView.post {
            coalescedRepaintPending.set(false)
            mapboxMap?.triggerRepaint()
        }
    }

    /**
     * Schedules [MapboxMap.triggerRepaint] on the Mapbox map thread (posts if called from a worker or GL thread).
     */
    override fun redraw() {
        triggerRepaintOnOwningThread()
    }

    /**
     * Adds a zero-opacity `fill` layer for [GlStencilOsm.SOURCE_ID] so Mapbox requests
     * [CustomGeometrySource] tiles; otherwise [VectorTileSource.requestTile] / stencil cache may never run.
     * Normally invoked from [addToMap] as soon as `mapboxMap.addSource` finishes (source is then on the style);
     * a short postDelayed retry exists for the rare race where this runs before the async [addToMap] completes.
     */
    internal fun ensureGlStencilBaseOsmFetchLayer() {
        doEnsuringStyleLoaded {
            val style = mapboxMap?.style ?: return@doEnsuringStyleLoaded
            if (style.styleLayerExists(GL_STENCIL_BASE_OSM_FETCH_LAYER_ID)) {
                glStencilBaseOsmFetchLayerSourceWaitRetries = 0
                prefetchGlStencilBaseOsmTiles()
                return@doEnsuringStyleLoaded
            }
            val baseId = GlStencilOsm.SOURCE_ID
            if (!style.styleSourceExists(baseId)) {
                if (glStencilBaseOsmFetchLayerSourceWaitRetries < 120) {
                    glStencilBaseOsmFetchLayerSourceWaitRetries++
                    mapView.postDelayed({ ensureGlStencilBaseOsmFetchLayer() }, 200L)
                } else {
                    MapsGLDebug.trace(
                        "[GlStencilMask] $baseId not in style after 24s; is the map style still loading, or is addToMap for vector sources blocked?",
                    )
                }
                return@doEnsuringStyleLoaded
            }
            glStencilBaseOsmFetchLayerSourceWaitRetries = 0
            try {
                val styleJSON = StyleJSON(
                    id = GL_STENCIL_BASE_OSM_FETCH_LAYER_ID,
                    type = StyleJSON.LayerType.FILL,
                    sourceID = baseId,
                    sourceLayer = "water",
                ).apply {
                    fillOpacity = StyleValue.Constant(0.0)
                }
                mapboxMap?.styleManager?.addPersistentStyleLayer(
                    Value.valueOf(styleJSON.asStyleJSONObject().toValueMap()),
                    LayerPosition(null, null, null),
                )
            } catch (e: Exception) {
                MapsGLDebug.trace("[GlStencilMask] ensureGlStencilBaseOsmFetchLayer failed: ${e.message}")
            }
            mapView.post { mapboxMap?.triggerRepaint() }
            prefetchGlStencilBaseOsmTiles()
        }
    }

    /**
     * Queues GL-stencil mesh prefetch for the weather tile [coords] currently being rendered under
     * [maskKind] (and [countryIso3166Alpha2] for [MaskLayerKind.COUNTRY]), then kicks off
     * [runGlStencilPrefetchWorker]. Tiles that already have a renderable mesh are skipped unless a
     * transportation zoom-bin change forces a visible-tile refresh at the new stroke width.
     */
    override fun schedulePrefetchGlStencilMaskTilesForWeatherRender(
        coords: List<TileCoord>,
        maskKind: MaskLayerKind,
        countryIso3166Alpha2: String?,
    ) {
        if (coords.isEmpty()) return
        val meshKind = if (maskKind == MaskLayerKind.LAND) MaskLayerKind.WATER else maskKind
        if (meshKind == MaskLayerKind.NONE) return
        if (meshKind == MaskLayerKind.COUNTRY && countryIso3166Alpha2.isNullOrBlank()) return
        var forceVisibleRefresh = false
        if (meshKind == MaskLayerKind.TRANSPORTATION) {
            val zBin = (mapZoom * 8.0).toInt()
            if (zBin != glStencilTransportationZoomBin) {
                glStencilTransportationZoomBin = zBin
                // Rebuild only currently visible stencil tiles at the new zoom-scaled width.
                // Avoid replaying all cached vector tiles here (can freeze while pinch-zooming).
                forceVisibleRefresh = true
            }
        }
        val seen = HashSet<Triple<Int, Int, Int>>(coords.size * 2)
        val meshCache = glStencilMaskTileCache
        for (c in coords) {
            val z = c.z
            if (z < 0 || z >= powerTableI.size) continue
            val n = powerTableI[z]
            if (n <= 0 || c.x < 0 || c.y < 0 || c.x >= n || c.y >= n) continue
            val t = Triple(c.x, c.y, z)
            if (!seen.add(t)) continue
            val key = "0:$z/${c.x}/${c.y}"
            // Presence of an ancestor mesh is not always enough: child remap can still fail
            // (degenerate clip), which would leave LAND draw with "no mesh". Skip only when
            // a renderable mesh is actually available for this exact weather tile key.
            val hasMesh =
                if (meshKind == MaskLayerKind.COUNTRY) {
                    meshCache.hasMeshForCountry(countryIso3166Alpha2!!, key)
                } else if (meshKind == MaskLayerKind.TRANSPORTATION) {
                    // Keep requesting exact child-z transportation meshes even when an ancestor
                    // remap can currently draw, to reduce width jumps near integer zoom crossings.
                    meshCache.hasExactMeshForRender(key, meshKind)
                } else {
                    meshCache.getCpuMeshForRender(key, meshKind) != null
                }
            if (!forceVisibleRefresh && hasMesh) continue
            if (glStencilPrefetchInFlight.contains(key)) continue
            glStencilPrefetchQueued.add(key)
            if (maskDebugMatchesCanonical0zxy(key)) {
                MapsGLDebug.trace("[MaskDebug][Queue] enqueued key=$key maskKind=$maskKind meshKind=$meshKind")
            }
        }
        runGlStencilPrefetchWorker()
    }

    /**
     * Unconditionally queues [coords] as GL-stencil OSM prefetch keys for a custom stencil mask
     * (no existing-mesh check, unlike [schedulePrefetchGlStencilMaskTilesForWeatherRender]) and
     * kicks off [runGlStencilPrefetchWorker].
     */
    override fun schedulePrefetchGlStencilOsmTilesForCustomMask(coords: List<TileCoord>) {
        if (coords.isEmpty()) return
        val seen = HashSet<Triple<Int, Int, Int>>(coords.size * 2)
        for (c in coords) {
            val z = c.z
            if (z < 0 || z >= powerTableI.size) continue
            val n = powerTableI[z]
            if (n <= 0 || c.x < 0 || c.y < 0 || c.x >= n || c.y >= n) continue
            val t = Triple(c.x, c.y, z)
            if (!seen.add(t)) continue
            val key = "0:$z/${c.x}/${c.y}"
            if (glStencilPrefetchInFlight.contains(key)) continue
            glStencilPrefetchQueued.add(key)
        }
        runGlStencilPrefetchWorker()
    }

    private fun runGlStencilPrefetchWorker() {
        if (glStencilPrefetchWorkerRunning) return
        glStencilPrefetchWorkerRunning = true
        CoroutineScope(Dispatchers.IO).launch {
            try {
                while (true) {
                    val src = getSource(GlStencilOsm.SOURCE_ID) as? VectorTileSource
                    if (src == null) {
                        // Keep queued work alive across brief style/source churn.
                        ensureGlStencilBaseOsmFetchLayer()
                        if (glStencilPrefetchQueued.isEmpty()) break
                        delay(100L)
                        continue
                    }
                    val batch = ArrayList<String>(MAX_STENCIL_PREFETCH_PER_CALL)
                    val it = glStencilPrefetchQueued.iterator()
                    while (it.hasNext() && batch.size < MAX_STENCIL_PREFETCH_PER_CALL) {
                        val key = it.next()
                        it.remove()
                        if (glStencilPrefetchInFlight.add(key)) {
                            batch.add(key)
                        }
                    }
                    if (batch.isEmpty()) break
                    for (key in batch) {
                        val path = key.removePrefix("0:")
                        val s1 = path.indexOf('/')
                        val s2 = if (s1 >= 0) path.indexOf('/', s1 + 1) else -1
                        val z = if (s1 > 0) path.substring(0, s1).toIntOrNull() else null
                        val x = if (s2 > s1 + 1) path.substring(s1 + 1, s2).toIntOrNull() else null
                        val y = if (s2 >= 0 && s2 + 1 < path.length) path.substring(s2 + 1).toIntOrNull() else null
                        try {
                            if (z != null && x != null && y != null) {
                                val result = runCatching { src.requestTile(x, y, z) }.getOrNull()
                                if (result == null) {
                                    val retries = (glStencilPrefetchRetryCount[key] ?: 0) + 1
                                    if (retries <= 3) {
                                        glStencilPrefetchRetryCount[key] = retries
                                        glStencilPrefetchQueued.add(key)
                                        if (maskDebugMatchesCanonical0zxy(key)) {
                                            MapsGLDebug.trace("[MaskDebug][Queue] retry key=$key attempt=$retries")
                                        }
                                    } else {
                                        glStencilPrefetchRetryCount.remove(key)
                                        MapsGLDebug.trace("[GlStencilMask] DROPPED key=$key after 3 retries (will not retry until pan/zoom)")
                                    }
                                } else {
                                    glStencilPrefetchRetryCount.remove(key)
                                    if (maskDebugMatchesCanonical0zxy(key)) {
                                        MapsGLDebug.trace("[MaskDebug][Queue] fetched key=$key")
                                    }
                                }
                            }
                        } finally {
                            glStencilPrefetchInFlight.remove(key)
                        }
                    }
                    if (glStencilPrefetchQueued.isNotEmpty()) delay(16L)
                }
            } finally {
                glStencilPrefetchWorkerRunning = false
                if (glStencilPrefetchQueued.isNotEmpty()) runGlStencilPrefetchWorker()
            }
        }
    }

    /**
     * Warm a small z2/z3 neighborhood around current center so same-zoom stencil meshes are
     * available quickly near startup (instead of relying on delayed parent remap fallback).
     */
    private fun prefetchGlStencilBaseOsmTiles() {
        val src = getSource(GlStencilOsm.SOURCE_ID) as? VectorTileSource ?: return
        val center = getCenter()
        val centerLonQ = floor(center.lon * 4.0) / 4.0
        val centerLatQ = floor(center.lat * 4.0) / 4.0
        val key = "${centerLonQ}_${centerLatQ}"
        if (glStencilPrefetchKey == key) return
        glStencilPrefetchKey = key
        val jobs = ArrayList<Triple<Int, Int, Int>>(18)
        for (z in 2..3) {
            val n = 1 shl z
            val x = floor((center.lon + 180.0) / 360.0 * n).toInt().coerceIn(0, n - 1)
            val latRad = Math.toRadians(center.lat)
            val yFloat = (1.0 - ln(tan(latRad) + 1.0 / cos(latRad)) / PI) / 2.0 * n
            val y = floor(yFloat).toInt().coerceIn(0, n - 1)
            for (dx in -1..1) {
                for (dy in -1..1) {
                    val xx = ((x + dx) % n + n) % n
                    val yy = (y + dy).coerceIn(0, n - 1)
                    jobs.add(Triple(xx, yy, z))
                }
            }
        }
        CoroutineScope(Dispatchers.IO).launch {
            for ((x, y, z) in jobs) {
                runCatching { src.requestTile(x, y, z) }
            }
            MapsGLDebug.trace("[GlStencilMask] prefetch seeded ${jobs.size} base.osm tiles around center for z2/z3")
        }
    }

    /**
     * Removes the invisible fetch layer and [GlStencilOsm.SOURCE_ID] style source when GLES stencil
     * masking no longer needs them. Dropping only the fetch layer leaves a stale CustomGeometrySource
     * on recycled Mapbox maps (common after switching demo activities), which breaks the next mask.
     */
    internal fun removeGlStencilBaseOsmFetchLayer() {
        glStencilBaseOsmFetchLayerSourceWaitRetries = 0
        glStencilPrefetchKey = null
        glStencilPrefetchQueued.clear()
        glStencilPrefetchInFlight.clear()
        glStencilPrefetchRetryCount.clear()
        doEnsuringStyleLoaded {
            mapboxMap?.style?.let { s ->
                if (s.styleLayerExists(GL_STENCIL_BASE_OSM_FETCH_LAYER_ID)) {
                    s.removeStyleLayer(GL_STENCIL_BASE_OSM_FETCH_LAYER_ID)
                }
            }
            val srcId = GlStencilOsm.SOURCE_ID
            if (mapboxMap?.style?.styleSourceExists(srcId) == true) {
                mapboxMap?.removeStyleSource(srcId)
            }
            getSource(srcId)?.let { src ->
                if (src is VectorTileSource) {
                    src.setInvalidateFunction(null)
                    src.setBatchInvalidateFunction(null)
                }
            }
        }
    }

    /**
     * Mapbox `queryRenderedFeatures` at a screen point for the given vector layers; fills data-inspector
     * vector fields when [onTouch] matches the active inspector buffer.
     *
     * @param point Geographic point (converted to screen via Mapbox).
     * @param vectorLayerList Vector style layers to include in the query.
     * @param onTouch When `true`, uses touch-buffer results; when `false`, uses programmatic query buffer.
     * @return Per-layer [FeatureQueryResult], or `null` if nothing queried or timeline blocks queries.
     */
    suspend fun queryFeatures(
        point: Point,
        vectorLayerList: List<VectorTileLayer>,
        onTouch: Boolean = true
    ): HashMap<String, FeatureQueryResult>? {


        ///MapsGLDebug.trace(">>> queryFeatures Entered")
        if (pr.ON) pr.p(TAG, pr.fireVector, "queryFeatures() entered, layerCount: ${vectorLayerList.size}")

        val result: DataInspectorResult? = if (onTouch) {
            dataInspector.dIResult
        } else {
            dataInspector.queryResult
        }

        if (vectorLayerList.isNotEmpty() && (timeline.state != AnimationState.playing || dataInspector.hasMoved || dataInspector.isActive)) {
            val queryGeometry = RenderedQueryGeometry(mapboxMap!!.pixelForCoordinate(point))
            i2 = 0

            val layerIds = vectorLayerList.map { it.id }
            val queryOptions = RenderedQueryOptions(layerIds, null)
            val renderedFeatures = queryRenderedFeatures(queryGeometry, queryOptions)
            val featuresBySourceId = renderedFeatures.groupBy { it.queriedFeature.source }
            result?.clearVector()

            val returnMap: HashMap<String, FeatureQueryResult> = hashMapOf()

            for (layer in vectorLayerList) {
                if (pr.ON) pr.p(TAG, pr.fireVector, "queryFeatures() layer.id: ${layer.id}")
                val featuresForThisLayer = featuresBySourceId[layer.source.id]
                //dataInspector?.dIResult?.queriedFeatures?.add(featuresForThisLayer)
                if (featuresForThisLayer.isNullOrEmpty()) {
                    if (pr.ON) pr.p(TAG, pr.fireVector, "queryFeatures() exiting, features For ${layer.id} is null")
                    continue
                }

                if (pr.ON) pr.p(
                    TAG,
                    pr.fireVector,
                    "queryFeatures() featuresForThisLayer ${layer.id} size: ${featuresForThisLayer.size}"
                )

                val presentation = dataInspector.presentationsByLayerId[layer.id]

                if (presentation != null) {
                    val resultString = presentation.fn(featuresForThisLayer)
                    if (resultString.length > 5) {
                        result?.vectorTitles?.add(presentation.title.toString())
                        result?.vectorLayerIds?.add(layer.id)
                        result?.vectorRawValues?.add(featuresForThisLayer)
                        result?.vectorValues?.add(resultString)
                        i2++
                    }
                }

                val queriedFeatureList: MutableList<QueriedFeature> = mutableListOf()

                if (pr.ON) pr.p(
                    TAG,
                    pr.fireVector,
                    "queryFeatures() featuresForThisLayer count: ${featuresForThisLayer.size} "
                )

                for (item in featuresForThisLayer) {
                    // CORRECT: Access the properties and feature through the 'queriedFeature' property of item.
                    val originalProperties = item.queriedFeature.feature.properties()
                    val featureId = item.queriedFeature.feature.id()


                    val myMap: Map<String, Any?>? = originalProperties?.entrySet()?.associate { (key, jsonElement) ->
                        // This is a recursive function defined right where it's used
                        fun toKotlinType(element: JsonElement): Any? {
                            return when {
                                element.isJsonNull -> null
                                element.isJsonPrimitive -> {
                                    val primitive = element.asJsonPrimitive
                                    when {
                                        primitive.isBoolean -> primitive.asBoolean
                                        primitive.isNumber -> primitive.asNumber // Can be Long, Double, etc.
                                        primitive.isString -> primitive.asString
                                        else -> primitive.toString()
                                    }
                                }

                                element.isJsonArray -> {
                                    // Recursively convert each element in the array
                                    element.asJsonArray.map { toKotlinType(it) }
                                }

                                element.isJsonObject -> {
                                    // Recursively convert the nested object to a map
                                    element.asJsonObject.entrySet().associate { (k, v) -> k to toKotlinType(v) }
                                }

                                else -> null
                            }
                        }
                        // Convert the value for the current key
                        key to toKotlinType(jsonElement)
                    }

                    if (myMap == null) {
                        return hashMapOf()
                    }

                    val queriedFeature = QueriedFeature(
                        featureId,
                        layer.source.id,
                        item.queriedFeature.sourceLayer, // Use the sourceLayer from the inner feature
                        myMap // Pass the original properties
                    )
                    queriedFeatureList.add(queriedFeature)
                    if (pr.ON) pr.p(
                        TAG,
                        pr.fireVector,
                        "queryFeatures() adding queried feature: ${queriedFeature.properties}"
                    )

                }

                val featureQueryResult = FeatureQueryResult(layer.id, queriedFeatureList)
                returnMap[layer.id] = featureQueryResult

            }
            if (i2 > 0 && pr.ON) {
                pr.p(
                    TAG, pr.flickerFix, "queryFeatures() vectorlist not empty, results found, update trigger vector!"
                )
            }
            this.trigger(DataInspectorEvent.VECTOR_UPDATE, "")
            return returnMap

        } else if (vectorLayerList.isEmpty()) {
            if (pr.ON) pr.p(TAG, pr.flickerFix, "queryFeatures() found EMPTY, CLEARING DI Result!")
            result?.clearVector()
            this.trigger(DataInspectorEvent.VECTOR_UPDATE, "")
            return null
            //}
        }
        return null
    }

    /**
     * Queries features within a rectangular area.
     * @param boxTopLeft The top-left screen coordinate of the rectangle.
     * @param boxBottomRight The bottom-right screen coordinate of the rectangle.
     */
    suspend fun queryFeaturesInBox(
        boxTopLeft: ScreenCoordinate,
        boxBottomRight: ScreenCoordinate,
        vectorLayerList: List<VectorTileLayer>,
        onTouch: Boolean = true
    ): HashMap<String, FeatureQueryResult>? {

        if (pr.ON) pr.p(TAG, pr.fireVector, "queryFeaturesInBox() entered, layerCount: ${vectorLayerList.size}")

        val result: DataInspectorResult = if (onTouch) {
            dataInspector.dIResult
        } else {
            dataInspector.queryResult
        }

        if (vectorLayerList.isNotEmpty() && (timeline.state != AnimationState.playing || dataInspector.hasMoved || dataInspector.isActive)) {
            // CHANGE: Use ScreenBox instead of pixelForCoordinate(point)
            val screenBox = ScreenBox(boxTopLeft, boxBottomRight)
            val queryGeometry = RenderedQueryGeometry(screenBox)

            i2 = 0

            val layerIds = vectorLayerList.map { it.id }
            val queryOptions = RenderedQueryOptions(layerIds, null)

            // This call remains the same, but it now uses the geometry containing the ScreenBox
            val renderedFeatures = queryRenderedFeatures(queryGeometry, queryOptions)

            val featuresBySourceId = renderedFeatures.groupBy { it.queriedFeature.source }
            result.clearVector()

            val returnMap: HashMap<String, FeatureQueryResult> = hashMapOf()

            for (layer in vectorLayerList) {
                val featuresForThisLayer = featuresBySourceId[layer.source.id]

                if (featuresForThisLayer.isNullOrEmpty()) {
                    continue
                }

                val presentation = dataInspector.presentationsByLayerId[layer.id]
                if (presentation != null) {
                    val resultString = presentation.fn(featuresForThisLayer)
                    if (resultString.length > 5) {
                        result.vectorTitles.add(presentation.title.toString())
                        result.vectorLayerIds.add(layer.id)
                        result.vectorRawValues.add(featuresForThisLayer)
                        result.vectorValues.add(resultString)
                        i2++
                    }
                }

                val queriedFeatureList: MutableList<QueriedFeature> = mutableListOf()

                for (item in featuresForThisLayer) {
                    val originalProperties = item.queriedFeature.feature.properties()
                    val featureId = item.queriedFeature.feature.id()

                    val myMap: Map<String, Any?>? = originalProperties?.entrySet()?.associate { (key, jsonElement) ->
                        fun toKotlinType(element: JsonElement): Any? {
                            return when {
                                element.isJsonNull -> null
                                element.isJsonPrimitive -> {
                                    val primitive = element.asJsonPrimitive
                                    when {
                                        primitive.isBoolean -> primitive.asBoolean
                                        primitive.isNumber -> primitive.asNumber
                                        primitive.isString -> primitive.asString
                                        else -> primitive.toString()
                                    }
                                }

                                element.isJsonArray -> element.asJsonArray.map { toKotlinType(it) }
                                element.isJsonObject -> element.asJsonObject.entrySet()
                                    .associate { (k, v) -> k to toKotlinType(v) }

                                else -> null
                            }
                        }
                        key to toKotlinType(jsonElement)
                    }

                    if (myMap != null) {
                        val queriedFeature = QueriedFeature(
                            featureId,
                            layer.source.id,
                            item.queriedFeature.sourceLayer,
                            myMap
                        )
                        queriedFeatureList.add(queriedFeature)
                    }
                }

                val featureQueryResult = FeatureQueryResult(layer.id, queriedFeatureList)
                returnMap[layer.id] = featureQueryResult
            }

            this.trigger(DataInspectorEvent.VECTOR_UPDATE, "")
            return returnMap

        } else if (vectorLayerList.isEmpty()) {
            result?.clearVector()
            this.trigger(DataInspectorEvent.VECTOR_UPDATE, "")
            return null
        }
        return null
    }

    /**
     * Legacy vector query implementation kept for compatibility; prefer [queryFeatures].
     */
    suspend fun queryFeaturesOld(
        point: Point,
        vectorLayerList: List<VectorTileLayer>,
        onTouch: Boolean = true
    ): HashMap<String, FeatureQueryResult>? {
        if (pr.ON) pr.p(TAG, pr.flickerFix, "queryFeatures() entered, layerCount: ${vectorLayerList.size}")
        if (dataInspector == null) return null

        val result: DataInspectorResult? = if (onTouch) {
            dataInspector?.dIResult
        } else {
            dataInspector?.queryResult
        }

        if (vectorLayerList.isNotEmpty() && (timeline.state != AnimationState.playing || dataInspector!!.hasMoved || dataInspector!!.isActive)) {
            val queryGeometry = RenderedQueryGeometry(mapboxMap!!.pixelForCoordinate(point))
            i2 = 0

            val layerIds = vectorLayerList.map { it.id }
            val queryOptions = RenderedQueryOptions(layerIds, null)
            val renderedFeatures = queryRenderedFeatures(queryGeometry, queryOptions)
            val featuresBySourceId = renderedFeatures.groupBy { it.queriedFeature.source }
            result?.clearVector()

            val returnMap: HashMap<String, FeatureQueryResult> = hashMapOf()

            for (layer in vectorLayerList) {
                if (pr.ON) pr.p(TAG, pr.flickerFix, "queryFeatures() layer.id: ${layer.id}")
                val featuresForThisLayer = featuresBySourceId[layer.source.id]
                //dataInspector?.dIResult?.queriedFeatures?.add(featuresForThisLayer)
                if (featuresForThisLayer.isNullOrEmpty()) {
                    continue
                }

                val presentation = dataInspector?.presentationsByLayerId?.get(layer.id)
                if (presentation != null) {
                    val resultString = presentation.fn(featuresForThisLayer)
                    if (resultString.length > 5) {
                        result?.vectorTitles?.add(presentation.title.toString())
                        result?.vectorLayerIds?.add(layer.id)
                        result?.vectorRawValues?.add(featuresForThisLayer)
                        result?.vectorValues?.add(resultString)
                        i2++
                    }
                }

                val queriedFeatureList: MutableList<QueriedFeature> = mutableListOf()

                for (item in featuresForThisLayer) {
                    val stringValueMapItem = mapOf("layerName" to item)
                    val queriedFeature = QueriedFeature(
                        item.queriedFeature.feature.id(), layer.source.id, item.queriedFeature.sourceLayer,
                        stringValueMapItem
                    )
                    queriedFeatureList.add(queriedFeature)
                }

                val featureQueryResult = FeatureQueryResult(layer.id, queriedFeatureList)
                returnMap[layer.id] = featureQueryResult

            }
            if (i2 > 0 && pr.ON) {
                pr.p(
                    TAG, pr.flickerFix, "queryFeatures() vectorlist not empty, results found, update trigger vector!"
                )
            }
            this.trigger(DataInspectorEvent.VECTOR_UPDATE, "")
            return returnMap

        } else if (vectorLayerList.isEmpty()) {
            if (pr.ON) pr.p(TAG, pr.flickerFix, "queryFeatures() found EMPTY, CLEARING DI Result!")
            result?.clearVector()
            this.trigger(DataInspectorEvent.VECTOR_UPDATE, "")
            return null
            //}
        }
        return null
    }

    /**
     * Wraps the callback-based `queryRenderedFeatures` function in a suspending coroutine.
     *
     * This function can be called from within a coroutine scope and will suspend until the
     * query is complete, then return the result or throw an exception.
     *
     * @param queryGeometry The geometry to query.
     * @param queryOptions The options for the query.
     * @return A `List<QueriedRenderedFeature>` containing the query results.
     * @throws Exception if the query fails.
     */
    private suspend fun queryRenderedFeatures(
        queryGeometry: RenderedQueryGeometry, queryOptions: RenderedQueryOptions
    ): List<QueriedRenderedFeature> {
        // This bridges the callback API with the coroutine world.
        // It suspends the coroutine until 'continuation.resume' or 'resumeWithException' is called.
        return suspendCancellableCoroutine { continuation ->
            mapboxMap!!.queryRenderedFeatures(queryGeometry, queryOptions) { result ->
                if (result.isValue) {
                    // On success, resume the coroutine with the list of features.
                    /*
                    continuation.resume(result.value ?: emptyList()) { cause, _, _ ->
                        null
                        (cause)
                    }*/
                    continuation.resume(result.value ?: emptyList()) // older version for compatibility.

                } else {
                    // On failure, resume the coroutine by throwing an exception.
                    continuation.resumeWithException(
                        Exception(result.error ?: "Mapbox queryRenderedFeatures failed with an unknown error.")
                    )
                }
            }
        }
    }

    /**
     * [addToMap] adds both the weather custom layer and (on first use) the mask vector layer asynchronously.
     * Wait until both ids exist, then place **every** encoded layer that uses this mask **below** the mask.
     * Moving only the newly-added layer leaves earlier layers (e.g. swell-heights) above the mask, so the
     * land fill vanishes visually when multiple masked layers are active.
     */
    internal fun syncLandMaskStackAfterWeatherLayerAdded(
        @Suppress("UNUSED_PARAMETER") weatherLayerId: String,
        @Suppress("UNUSED_PARAMETER") insertBeforeId: String?,
        @Suppress("UNUSED_PARAMETER") maskKind: MaskLayerKind,
    ) {
        // Legacy Mapbox mask::* stack ordering; unused with GLES stencil masking (JS-aligned path).
    }

    internal fun showOrHideLandMask(@Suppress("UNUSED_PARAMETER") beforeId: String? = null): String? {
        // Legacy Mapbox mask::* visibility; unused with GLES stencil masking (JS-aligned path).
        return null
    }

    internal fun getLog() {
        /*
        MapsGLDebug.trace("GL1--------------------------------------------------------------")
        MapsGLDebug.trace("GL1 pausedForMovement:${Timeline.pausedForMovement}")
        MapsGLDebug.trace("GL1 pausedForDownload:${Timeline.pausedForDownload}")
        MapsGLDebug.trace("GL1 timeLine State:${timeline.state}")
        MapsGLDebug.trace("GL1 Camera MoveState:${camera.moveState}")
        MapsGLDebug.trace("GL1 tl.isDownloading: ${Timeline.isDownloading}")
        MapsGLDebug.trace("GL1 waitingOnDL: $waitingOnDL")
        MapsGLDebug.trace("GL1 wasWaitingOnDL: ${wasWaitingOnDL}")

        for (layer in layers) {
            if (layer.value.visible && layer.value.animator!!.animation.pendingCount != 0) {
                MapsGLDebug.trace("GL1 found PendingDL: ${layer.value.id} has ${layer.value.animator!!.animation.pendingCount}")
                MapsGLDebug.trace("GL1 tileCache pending: ${layer.value.source.tileCache._pending}")
            }
        }
        */
    }

    /**
     * Clears all pending-download bookkeeping across every [EncodedTileLayer] and the shared
     * [Timeline] load-session state (pending tile lists, download-progress counters, and the
     * downloading/waiting flags). Use to force-recover a controller stuck reporting outstanding
     * downloads that will never resolve (e.g. after a watchdog timeout).
     */
    fun clearPending() {
        for (layer in layers) {
            if (layer.value is EncodedTileLayer) {
                layer.value.source.tileCache._pending.clear()
                layer.value.animator!!.animation.pendingCount = 0
                (layer.value.source as XweatherEncodedTileSource).pendingRequestedTiles.clear()
                checkDownloadStatus(layer.value.id, 0)
            }

        }

        // Must clear the Timeline load-session map too — otherwise [isEncodedBindPending] keeps
        // reporting phases as unready and the per-layer gate holds forever after a watchdog timeout.
        Timeline.clearPendingEncodedDownloads()
        Timeline.resetEncodedDownloadProgressCounters()
        TileList.pendingList.layers.clear()
        TileList.requestedList.layers.clear()

        Timeline.isDownloading = false
        waitingOnDL = false
        wasWaitingOnDL = true
        Timeline.pausedForDownload = false
        //timeline.state = AnimationState.playing
        //trigger(MapControllerEvents.LOAD_COMPLETE, true)

    }
}

/**
 * Bridges [ImageRegisteringMap] to Mapbox: registers bitmaps into the active style for symbol layers and sprites.
 * Used while loading style images during [MapboxMapController.setupEvents] (weather style load path).
 */
class MapboxImageRegistrar(private val mapboxMap: MapboxMap) : ImageRegisteringMap {
    /**
     * @param id Style image id referenced from layer paint.
     * @param image Raster to upload.
     * @param sdf When `true`, registers as an SDF image for tintable icons.
     */
    override fun addImage(id: String, image: Bitmap, sdf: Boolean) {
        mapboxMap.getStyle { style ->
            style.addImage(id, image, sdf)
        }
    }
}

// Utility extension functions to convert Map<String, Any> recursively into HashMap<String, Value>
private fun Any.toValue(): Value {
    return when (this) {
        is Map<*, *> -> {
            val map = HashMap<String, Value>()
            for ((k, v) in this) {
                if (k is String && v != null) {
                    map[k] = v.toValue()
                }
            }
            Value.valueOf(map)
        }

        is List<*> -> Value.valueOf(this.mapNotNull { it?.toValue() })
        is String -> Value.valueOf(this)
        is Int -> Value.valueOf(this.toLong())
        is Double -> Value.valueOf(this)
        is Float -> Value.valueOf(this.toDouble())
        is Long -> Value.valueOf(this)
        is Boolean -> Value.valueOf(this)
        else -> Value.nullValue()
    }
}

private fun Map<String, Any>.toValueMap(): HashMap<String, Value> {
    val result = HashMap<String, Value>()
    for ((key, value) in this) {
        result[key] = value.toValue()
    }
    return result
}