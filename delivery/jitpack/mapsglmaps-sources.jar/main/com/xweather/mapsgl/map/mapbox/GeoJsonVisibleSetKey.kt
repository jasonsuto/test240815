package com.xweather.mapsgl.map.mapbox

import com.mapbox.geojson.Feature

/**
 * Stable cache key for CPU map-time–filtered GeoJSON meshes.
 *
 * Range filters (e.g. convective outlook) keep the same visible feature set for long stretches
 * of playhead motion. Keying meshes by wall-clock map-time seconds forced a rebuild every tick
 * and raced playback cache trim — visible flicker. Fingerprint the filtered set instead.
 */
internal fun geoJsonVisibleFeatureSetKey(features: List<Feature>): Int {
    var xor = 0
    for (f in features) {
        val idHash =
            f.id()?.hashCode()
                ?: f.getStringProperty("id")?.hashCode()
                ?: f.getNumberProperty("id")?.hashCode()
                ?: System.identityHashCode(f)
        // Order-independent mix so filter iteration order cannot churn the key.
        xor = xor xor (idHash * -0x61c88647)
    }
    return features.size * 0x9e3779b9.toInt() xor xor
}
