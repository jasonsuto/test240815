package com.xweather.mapsgl.map.mapbox

import android.util.Log
import android.graphics.Color
import com.mapbox.geojson.Feature
import com.xweather.mapsgl.style.Expression
import com.mapbox.geojson.LineString
import com.mapbox.geojson.MultiLineString
import com.mapbox.geojson.MultiPoint
import com.mapbox.geojson.MultiPolygon
import com.mapbox.geojson.Point
import com.mapbox.geojson.Polygon
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.renderers.VECTOR_CIRCLE_GL_PIXEL_SCALE
import com.xweather.mapsgl.weather.WeatherLayerStrokeDefaults
import com.xweather.mapsgl.sources.VectorTileSource
import com.xweather.mapsgl.sources.nestedDictionary
import no.ecc.vectortile.VectorTileDecoder
import org.locationtech.jts.geom.Point as JtsPoint
import org.locationtech.jts.geom.MultiPoint as JtsMultiPoint
import org.locationtech.jts.geom.LineString as JtsLineString
import org.locationtech.jts.geom.MultiLineString as JtsMultiLineString
import org.locationtech.jts.geom.Polygon as JtsPolygon
import org.locationtech.jts.geom.MultiPolygon as JtsMultiPolygon
import org.maplibre.earcut4j.Earcut
import java.util.Locale
import kotlin.math.abs
import kotlin.math.PI
import kotlin.math.hypot
import kotlin.math.ln

/**
 * Earcut triangulation of MVT polygon features into **tile UV space** (u,v in [0,1]) with per-vertex RGBA,
 * matching [GlStencilMaskMeshBuilder] / encoded raster tile placement in Mapbox custom layers.
 */
internal object VectorPolygonFillTriangulator {
    private const val TAG = "VectorPolygonFillTriangulator"

    /**
     * Rule: native-fill-triangulation. `NativeLibCache.nativeTriangulateFillPolygon` is a pure,
     * stateless computation (no per-sourceID native state, unlike the namespaced byte-cache methods
     * on this same class) — a single lazily-created instance is safe to share across every tile/
     * layer that opts into the native path, avoiding the need to thread a `VectorTileSource`/
     * `NativeLibCache` reference through the whole triangulateFeaturesRaw -> triangulatePolygonRaw
     * call chain just for this one call.
     */
    private val nativeTriHandle by lazy { com.xweather.mapsgl.NativeLibCache("fill-tri") }

    /**
     * Fill vertex: [u, v, r, g, b, a, featureTime]. `featureTime` is the GPU map-time reveal
     * playhead (offset Unix seconds); [VectorMapTime.ALWAYS_VISIBLE] never discards.
     */
    internal const val FILL_FLOATS_PER_VERTEX = 7

    /**
     * Outline ribbon vertex: [cx,cy,nx,ny,packed_rgba,edge_dist,half_width_uv,featureTime].
     * `packed_rgba` is 4 unsigned bytes (r,g,b,a) bit-reinterpreted as a float (see [packColorFloat])
     * — the GPU reads it back as a normalized vec4 via GL_UNSIGNED_BYTE + normalized=true.
     * `featureTime` matches the fill layout for map-time reveal.
     */
    internal const val OUTLINE_FLOATS_PER_VERTEX = 8

    /**
     * Rule: outline-tile-clip-edge-skip. MVT encoders clip every polygon to the tile's *buffered*
     * extent, so the ring that reaches us carries synthetic axis-aligned edges running along that
     * buffer boundary — edges that exist only because of tiling, never in the source geometry.
     * Stroking them paints a black grid over the map, and because each of the two tiles sharing a
     * boundary clips at its own buffer limit, every tile edge shows up as a *pair* of parallel lines
     * straddling it (seen live over Spain/France: verticals straddling 0° lon, horizontals
     * straddling the z3 40.98°N row boundary).
     *
     * A segment is dropped only when it lies wholly on or beyond one side of the tile in UV space.
     * Real border segments that merely *cross* the boundary still stroke through in full and overlap
     * the neighbouring tile's copy inside the buffer overhang, which is invisible for an opaque
     * outline and is what the fill already does.
     *
     * Closed rings only. Clipping a LineString truncates it, it never introduces a
     * boundary-parallel run, so polylines are left alone — and GeoJSON sources aren't tile-clipped
     * at all (features are bucketed whole into the tiles they intersect), so their outlines must
     * never be subjected to this test.
     */
    internal fun isTileClipEdgeSegment(u0: Float, v0: Float, u1: Float, v1: Float): Boolean =
        (u0 <= 0f && u1 <= 0f) ||
            (u0 >= 1f && u1 >= 1f) ||
            (v0 <= 0f && v1 <= 0f) ||
            (v0 >= 1f && v1 >= 1f)

    /**
     * Packs a linear 0-1 RGBA color into the 4 bytes of a single 32-bit slot, bit-reinterpreted as
     * a Float so it can live in a plain FloatArray vertex buffer. Byte order assumes a
     * little-endian [java.nio.ByteBuffer] (nativeOrder() on every current Android device) will
     * serialize this Float — see [repackColorAlpha] for the opacity-only repack used at draw time.
     */
    internal fun packColorFloat(rgba: FloatArray): Float {
        val r = (rgba[0].coerceIn(0f, 1f) * 255f + 0.5f).toInt()
        val g = (rgba[1].coerceIn(0f, 1f) * 255f + 0.5f).toInt()
        val b = (rgba[2].coerceIn(0f, 1f) * 255f + 0.5f).toInt()
        val a = (rgba[3].coerceIn(0f, 1f) * 255f + 0.5f).toInt()
        val bits = (a shl 24) or (b shl 16) or (g shl 8) or r
        return Float.fromBits(bits)
    }

    /** Rescales just the alpha byte of a [packColorFloat]-packed color, leaving RGB untouched. */
    internal fun repackColorAlpha(packed: Float, opacity: Float): Float {
        val bits = packed.toRawBits()
        val r = bits and 0xFF
        val g = (bits ushr 8) and 0xFF
        val b = (bits ushr 16) and 0xFF
        val a = (bits ushr 24) and 0xFF
        val newA = (a * opacity).toInt().coerceIn(0, 255)
        val newBits = (newA shl 24) or (b shl 16) or (g shl 8) or r
        return Float.fromBits(newBits)
    }

    /**
     * Circle instance record (rule: circle-gpu-instancing): [cx,cy,r,g,b,a,radius_scale], one per
     * point. The quad corner offset is a static per-vertex GPU attribute (divisor 0), not baked in
     * here — see [com.xweather.mapsgl.renderers.VectorCircleLayerRenderer.ensureCircleProgram]. This
     * replaces the old 9-floats-per-vertex x 6-vertices-per-point CPU-expanded quad; moving the quad
     * expansion to the GPU (matching the JS reference SDK's instanced-rendering approach) cuts
     * per-point CPU emission ~6x.
     */
    internal const val CIRCLE_FLOATS_PER_INSTANCE = 7

    /**
     * Optional parallel featureTime channel for CPU map-time reveal. Same length as instance count
     * (`interleaved.size / CIRCLE_FLOATS_PER_INSTANCE`); [VectorMapTime.ALWAYS_VISIBLE] when absent.
     */
    internal class CircleTriangulationResult(
        val interleaved: FloatArray,
        val featureTimes: FloatArray? = null,
    )

    private const val UV_EPS = 1e-5f

    private const val MESH_FINGERPRINT_MAX_FEATURES = 128

    /**
     * Stable fragment for triangulation cache keys (not identity-hash of the tile payload instance) so scrubbing the
     * timeline back to an already-decoded interval reuses CPU meshes instead of re-triangulating on every new object.
     */
    fun meshCacheFingerprint(
        features: List<Feature>,
        validTimeMillis: Long,
        sourceLayerFilter: String?,
    ): Int {
        var h = (validTimeMillis xor (validTimeMillis ushr 32)).toInt()
        h = 31 * h + (sourceLayerFilter?.lowercase(Locale.US)?.hashCode() ?: 0)
        var matched = 0
        for (f in features) {
            if (!layerMatches(f, sourceLayerFilter)) continue
            h = 31 * h + f.hashCode()
            matched++
            if (matched >= MESH_FINGERPRINT_MAX_FEATURES) break
        }
        h = 31 * h + matched
        h = 31 * h + features.size
        return h
    }

    /**
     * [meshCacheFingerprint]'s counterpart for the raw circle fast path (rule: raw-circle-fast-path).
     * [no.ecc.vectortile.VectorTileDecoder.Feature] has no custom `equals`/`hashCode` (confirmed
     * against the library source — it's a plain data holder with only a constructor and getters), so
     * hashing the feature object itself would be identity-based and defeat the mesh cache on every
     * parse. Its `attributes` field is a `java.util.HashMap`, which does have structural equality, so
     * hashing that (plus the feature id) is stable across re-parses of byte-identical tile content.
     */
    fun meshCacheFingerprintRaw(
        rawFeatures: List<VectorTileDecoder.Feature>,
        validTimeMillis: Long,
    ): Int {
        var h = (validTimeMillis xor (validTimeMillis ushr 32)).toInt()
        var matched = 0
        for (f in rawFeatures) {
            h = 31 * h + f.id.hashCode()
            h = 31 * h + f.attributes.hashCode()
            matched++
            if (matched >= MESH_FINGERPRINT_MAX_FEATURES) break
        }
        h = 31 * h + matched
        h = 31 * h + rawFeatures.size
        return h
    }

    /**
     * Half-width in tile UV space for extruding [LineString] alerts on a 512px logical tile
     * ([WeatherLayerStrokeDefaults.ALERTS_FILL_LINE_RIBBON_THICKNESS_PX] screen px full width).
     */
    private val lineRibbonHalfWidthUv: Float
        get() = (WeatherLayerStrokeDefaults.ALERTS_FILL_LINE_RIBBON_THICKNESS_PX.toFloat() / 2f) / 512f

    /** Triangulates polygon features for one tile. Returns interleaved [u,v,r,g,b,a,featureTime] per vertex. */
    fun triangulateFeatures(
        features: List<Feature>,
        coord: TileCoord,
        sourceLayerFilter: String?,
        /** When features lack a `COLOR` property, use this RGBA (e.g. from [FillLayerPaint.fill]) so GL matches Mapbox fill color. */
        layerFallbackFillRgba: FloatArray? = null,
        /** Data-driven fill (e.g. [com.xweather.mapsgl.style.StyleValue.Expression] `step` on feature properties). */
        fillColorExpression: Expression? = null,
        /** Some products (alerts) ship fills as line geometry; allow ribbon extrusion for those only. */
        allowLineRibbonFallback: Boolean = false,
        /** Use expression result ahead of feature COLOR for problematic layers (e.g. stormcells cones). */
        expressionColorExclusive: Boolean = false,
        /**
         * Property key for GPU map-time reveal (usually `timestamp`). When null, every vertex uses
         * [VectorMapTime.ALWAYS_VISIBLE].
         */
        mapTimeRevealKey: String? = null,
    ): FloatArray {
        val z = coord.z
        val tx = coord.x
        val ty = coord.y
        val world = 1 shl z
        val out = GrowableFloatArray(512)
        fun accumulate(filter: String?) {
            for (f in features) {
                if (!layerMatches(f, filter)) continue
                val featureTime = VectorMapTime.featureTimeFromProperty(f, mapTimeRevealKey)
                try {
                    when (val g = f.geometry()) {
                        is Polygon -> triangulatePolygon(
                            f,
                            z,
                            tx,
                            ty,
                            world,
                            g,
                            out,
                            layerFallbackFillRgba,
                            fillColorExpression,
                            expressionColorExclusive,
                            featureTime,
                        )
                        is MultiPolygon -> {
                            for (rings in g.coordinates()) {
                                val poly = Polygon.fromLngLats(rings)
                                triangulatePolygon(
                                    f,
                                    z,
                                    tx,
                                    ty,
                                    world,
                                    poly,
                                    out,
                                    layerFallbackFillRgba,
                                    fillColorExpression,
                                    expressionColorExclusive,
                                    featureTime,
                                )
                            }
                        }
                        is LineString ->
                            if (allowLineRibbonFallback) {
                                triangulateLineRibbon(
                                    f,
                                    z,
                                    tx,
                                    ty,
                                    world,
                                    g,
                                    lineRibbonHalfWidthUv,
                                    out,
                                    layerFallbackFillRgba,
                                    fillColorExpression,
                                    expressionColorExclusive,
                                    featureTime,
                                )
                            }
                        is MultiLineString ->
                            if (allowLineRibbonFallback) {
                                for (lineCoords in g.coordinates()) {
                                    val ls = LineString.fromLngLats(lineCoords)
                                    triangulateLineRibbon(
                                        f,
                                        z,
                                        tx,
                                        ty,
                                        world,
                                        ls,
                                        lineRibbonHalfWidthUv,
                                        out,
                                        layerFallbackFillRgba,
                                        fillColorExpression,
                                        expressionColorExclusive,
                                        featureTime,
                                    )
                                }
                            }
                        else -> {}
                    }
                } catch (t: Throwable) {
                    Log.w(TAG, "triangulateFeatures(): skipping malformed feature", t)
                }
            }
        }
        accumulate(sourceLayerFilter)
        if (out.isEmpty() && sourceLayerFilter != null) {
            out.clear()
            accumulate(null)
        }
        return out.toFloatArray()
    }

    /**
     * Hit-tests MVT features using the same tile UV basis as [triangulateFeatures] (polygons + line ribbons).
     * Used when Mapbox `queryRenderedFeatures` misses the near-invisible vector-fetch hook layer.
     */
    internal fun hitTestLngLat(
        features: List<Feature>,
        coord: TileCoord,
        sourceLayerFilter: String?,
        tapLon: Double,
        tapLat: Double,
        circleRadiusPx: Float = 6f,
        circleRadiusExpression: Expression? = null,
        tileOverscale: Float = 1f,
        circlePixelDensityMult: Float = 1f,
        minCircleHitRadiusPx: Float = 0f,
    ): List<Feature> {
        val z = coord.z
        val tx = coord.x
        val ty = coord.y
        val world = 1 shl z
        val tuTv = lonLatToTileUv(z, tx, ty, world, tapLon, tapLat)
        val tu = tuTv.u
        val tv = tuTv.v
        val hits = LinkedHashSet<Feature>()
        val overscale = tileOverscale.coerceAtLeast(1f)
        fun circleHitsUv(f: Feature, cu: Float, cv: Float): Boolean {
            val radiusPx = (circleRadiusExpression?.let { expr ->
                VectorFillStyleExpressionEval.evaluateNumber(expr, f, z.toDouble())?.toFloat()
            } ?: circleRadiusPx)
                .coerceAtLeast(minCircleHitRadiusPx) *
                VECTOR_CIRCLE_GL_PIXEL_SCALE *
                circlePixelDensityMult.coerceAtLeast(1e-3f)
            val radiusUv = radiusPx.coerceAtLeast(0.5f) / 512f / overscale
            val dist = hypot((tu - cu).toDouble(), (tv - cv).toDouble()).toFloat()
            return dist <= radiusUv
        }
        fun run(filter: String?) {
            for (f in features) {
                if (!layerMatches(f, filter)) continue
                when (val g = f.geometry()) {
                    is Point -> {
                        val (cu, cv) = lonLatToTileUv(z, tx, ty, world, g.longitude(), g.latitude())
                        if (circleHitsUv(f, cu, cv)) hits.add(f)
                    }
                    is MultiPoint -> {
                        for (p in g.coordinates()) {
                            val (cu, cv) = lonLatToTileUv(z, tx, ty, world, p.longitude(), p.latitude())
                            if (circleHitsUv(f, cu, cv)) {
                                hits.add(f)
                                break
                            }
                        }
                    }
                    is Polygon -> if (polygonContainsUv(g, z, tx, ty, world, tu, tv)) hits.add(f)
                    is MultiPolygon -> {
                        for (rings in g.coordinates()) {
                            val poly = Polygon.fromLngLats(rings)
                            if (polygonContainsUv(poly, z, tx, ty, world, tu, tv)) {
                                hits.add(f)
                                break
                            }
                        }
                    }
                    is LineString -> if (lineRibbonHitsUv(g, z, tx, ty, world, tu, tv)) hits.add(f)
                    is MultiLineString -> {
                        for (lineCoords in g.coordinates()) {
                            val ls = LineString.fromLngLats(lineCoords)
                            if (lineRibbonHitsUv(ls, z, tx, ty, world, tu, tv)) {
                                hits.add(f)
                                break
                            }
                        }
                    }
                    else -> {}
                }
            }
        }
        run(sourceLayerFilter)
        if (hits.isEmpty() && sourceLayerFilter != null) run(null)
        return hits.toList()
    }

    /**
     * Rule: raw-vector-fast-path. [hitTestLngLat]'s raw counterpart — the data inspector's custom
     * hit-test fallback (`MapboxMapController.hitTestCustomVectorFillCached`) only ever checked
     * `VectorData.features`, which is empty whenever a tile was parsed via the raw fast path
     * (`VectorData.rawFeatures` non-null instead) — this generalized from single- to multi-consumer
     * eligibility this session, so alerts (fill+outline, 2 consumers) now routinely takes the raw
     * path, and tap-to-inspect silently returned nothing. Mirrors [triangulateFeaturesRaw]'s existing
     * raw/JTS geometry handling and reuses [pointInPolygonUv]/[lineRibbonHitsUv]'s UV-space math —
     * only the geometry-walking step differs (JTS types, tile-local pixel coords) from the heavy
     * [hitTestLngLat] path. No source-layer filter, matching [triangulateFeaturesRaw]'s existing
     * behavior for raw features. Circle radius here is always the constant fallback (no per-feature
     * expression evaluation) — a minor simplification, since alerts (the reported case) is
     * polygon-only; add raw expression-based radius support here if a raw-eligible circle layer
     * ever needs precise tap-radius hit-testing.
     */
    internal fun hitTestLngLatRaw(
        rawFeatures: List<VectorTileDecoder.Feature>,
        coord: TileCoord,
        tapLon: Double,
        tapLat: Double,
        circleRadiusPx: Float = 6f,
        tileOverscale: Float = 1f,
        circlePixelDensityMult: Float = 1f,
        minCircleHitRadiusPx: Float = 0f,
    ): List<VectorTileDecoder.Feature> {
        val z = coord.z
        val tx = coord.x
        val ty = coord.y
        val world = 1 shl z
        val tuTv = lonLatToTileUv(z, tx, ty, world, tapLon, tapLat)
        val tu = tuTv.u
        val tv = tuTv.v
        val hits = LinkedHashSet<VectorTileDecoder.Feature>()
        val overscale = tileOverscale.coerceAtLeast(1f)
        fun circleHitsUv(cu: Float, cv: Float): Boolean {
            val radiusPx = circleRadiusPx.coerceAtLeast(minCircleHitRadiusPx) *
                VECTOR_CIRCLE_GL_PIXEL_SCALE *
                circlePixelDensityMult.coerceAtLeast(1e-3f)
            val radiusUv = radiusPx.coerceAtLeast(0.5f) / 512f / overscale
            val dist = hypot((tu - cu).toDouble(), (tv - cv).toDouble()).toFloat()
            return dist <= radiusUv
        }
        for (f in rawFeatures) {
            try {
                @Suppress("UNCHECKED_CAST")
                val attrs = nestedDictionary(f.attributes as Map<String, Any>)
                if (!rawFeatureVisible(attrs)) continue
                when (val g = f.geometry) {
                    is JtsPoint -> {
                        val (cu, cv) = tileLocalXYToTileUv(g.x, g.y, coord, z, tx, ty, world)
                        if (circleHitsUv(cu, cv)) hits.add(f)
                    }
                    is JtsMultiPoint -> {
                        for (i in 0 until g.numGeometries) {
                            val p = g.getGeometryN(i) as JtsPoint
                            val (cu, cv) = tileLocalXYToTileUv(p.x, p.y, coord, z, tx, ty, world)
                            if (circleHitsUv(cu, cv)) {
                                hits.add(f)
                                break
                            }
                        }
                    }
                    is JtsPolygon -> if (polygonContainsUvRaw(g, coord, tu, tv)) hits.add(f)
                    is JtsMultiPolygon -> {
                        for (i in 0 until g.numGeometries) {
                            if (polygonContainsUvRaw(g.getGeometryN(i) as JtsPolygon, coord, tu, tv)) {
                                hits.add(f)
                                break
                            }
                        }
                    }
                    is JtsLineString -> if (lineRibbonHitsUvRaw(g, coord, tu, tv)) hits.add(f)
                    is JtsMultiLineString -> {
                        for (i in 0 until g.numGeometries) {
                            if (lineRibbonHitsUvRaw(g.getGeometryN(i) as JtsLineString, coord, tu, tv)) {
                                hits.add(f)
                                break
                            }
                        }
                    }
                    else -> {}
                }
            } catch (t: Throwable) {
                Log.w(TAG, "hitTestLngLatRaw(): skipping malformed feature", t)
            }
        }
        return hits.toList()
    }

    private fun ringToUvPairsRaw(coord: TileCoord, ring: JtsLineString): List<Pair<Float, Float>> {
        val z = coord.z
        val tx = coord.x
        val ty = coord.y
        val world = 1 shl z
        val coords = ring.coordinates
        val n = if (coords.size > 1 && coords.first() == coords.last()) coords.size - 1 else coords.size
        if (n < 3) return emptyList()
        val out = ArrayList<Pair<Float, Float>>(n)
        for (i in 0 until n) {
            val c = coords[i]
            val (u, v) = tileLocalXYToTileUv(c.x, c.y, coord, z, tx, ty, world)
            out.add(Pair(u, v))
        }
        return out
    }

    private fun polygonContainsUvRaw(poly: JtsPolygon, coord: TileCoord, tu: Float, tv: Float): Boolean {
        val outer = ringToUvPairsRaw(coord, poly.exteriorRing)
        if (!pointInPolygonUv(tu, tv, outer)) return false
        for (i in 0 until poly.numInteriorRing) {
            val hole = ringToUvPairsRaw(coord, poly.getInteriorRingN(i))
            if (pointInPolygonUv(tu, tv, hole)) return false
        }
        return true
    }

    private fun lineRibbonHitsUvRaw(line: JtsLineString, coord: TileCoord, tu: Float, tv: Float): Boolean {
        val z = coord.z
        val tx = coord.x
        val ty = coord.y
        val world = 1 shl z
        val coords = line.coordinates
        if (coords.size < 2) return false
        var i = 0
        while (i + 1 < coords.size) {
            val (u0, v0) = tileLocalXYToTileUv(coords[i].x, coords[i].y, coord, z, tx, ty, world)
            val (u1, v1) = tileLocalXYToTileUv(coords[i + 1].x, coords[i + 1].y, coord, z, tx, ty, world)
            if (minDistPointSegmentUv(tu, tv, u0, v0, u1, v1) <= lineRibbonHalfWidthUv) return true
            i++
        }
        return false
    }

    private fun polygonContainsUv(
        poly: Polygon,
        z: Int,
        tx: Int,
        ty: Int,
        world: Int,
        tu: Float,
        tv: Float,
    ): Boolean {
        val rings = poly.coordinates()
        if (rings.isEmpty()) return false
        val outer = ringToUvPairs(rings[0], z, tx, ty, world)
        if (!pointInPolygonUv(tu, tv, outer)) return false
        for (i in 1 until rings.size) {
            val hole = ringToUvPairs(rings[i], z, tx, ty, world)
            if (pointInPolygonUv(tu, tv, hole)) return false
        }
        return true
    }

    private fun ringToUvPairs(
        ring: List<com.mapbox.geojson.Point>,
        z: Int,
        tx: Int,
        ty: Int,
        world: Int,
    ): List<Pair<Float, Float>> {
        val n = when {
            ring.size > 1 && ring.first().longitude() == ring.last().longitude() &&
                ring.first().latitude() == ring.last().latitude() -> ring.size - 1
            else -> ring.size
        }
        if (n < 3) return emptyList()
        val out = ArrayList<Pair<Float, Float>>(n)
        for (i in 0 until n) {
            val p = ring[i]
            val (u, v) = lonLatToTileUv(z, tx, ty, world, p.longitude(), p.latitude())
            out.add(u to v)
        }
        return out
    }

    private fun pointInPolygonUv(x: Float, y: Float, ring: List<Pair<Float, Float>>): Boolean {
        if (ring.size < 3) return false
        var inside = false
        var j = ring.size - 1
        val xp = x.toDouble()
        val yp = y.toDouble()
        for (i in ring.indices) {
            val xi = ring[i].first.toDouble()
            val yi = ring[i].second.toDouble()
            val xj = ring[j].first.toDouble()
            val yj = ring[j].second.toDouble()
            val crossesHorizontal = (yi > yp) != (yj > yp)
            if (crossesHorizontal && kotlin.math.abs(yj - yi) > 1e-18) {
                val xIntersect = (xj - xi) * (yp - yi) / (yj - yi) + xi
                if (xp < xIntersect) inside = !inside
            }
            j = i
        }
        return inside
    }

    private fun lineRibbonHitsUv(
        ls: LineString,
        z: Int,
        tx: Int,
        ty: Int,
        world: Int,
        tu: Float,
        tv: Float,
    ): Boolean {
        val coords = ls.coordinates()
        if (coords.size < 2) return false
        var i = 0
        while (i + 1 < coords.size) {
            val (u0, v0) = lonLatToTileUv(z, tx, ty, world, coords[i].longitude(), coords[i].latitude())
            val (u1, v1) = lonLatToTileUv(z, tx, ty, world, coords[i + 1].longitude(), coords[i + 1].latitude())
            if (minDistPointSegmentUv(tu, tv, u0, v0, u1, v1) <= lineRibbonHalfWidthUv) return true
            i++
        }
        return false
    }

    private fun minDistPointSegmentUv(px: Float, py: Float, ax: Float, ay: Float, bx: Float, by: Float): Float {
        val vx = bx - ax
        val vy = by - ay
        val wx = px - ax
        val wy = py - ay
        val c1 = vx * wx + vy * wy
        if (c1 <= 0f) return hypot((px - ax).toDouble(), (py - ay).toDouble()).toFloat()
        val c2 = vx * vx + vy * vy
        if (c2 <= c1) return hypot((px - bx).toDouble(), (py - by).toDouble()).toFloat()
        val t = c1 / c2
        val projx = ax + t * vx
        val projy = ay + t * vy
        return hypot((px - projx).toDouble(), (py - projy).toDouble()).toFloat()
    }

    private fun layerMatches(f: Feature, sourceLayerFilter: String?): Boolean {
        if (sourceLayerFilter == null) return true
        val tag = f.getStringProperty("layer") ?: return false
        return tag.equals(sourceLayerFilter, ignoreCase = true) ||
            tag.startsWith("$sourceLayerFilter::", ignoreCase = true)
    }

    private fun parseFillColor(
        feature: Feature,
        layerFallbackFillRgba: FloatArray?,
        fillColorExpression: Expression?,
        expressionColorExclusive: Boolean,
        zoom: Double? = null,
    ): FloatArray {
        if (expressionColorExclusive) {
            fillColorExpression?.let { expr ->
                return VectorFillStyleExpressionEval.evaluateFillRgba(expr, feature, zoom)
                    ?: layerFallbackFillRgba?.copyOf()
                    ?: floatArrayOf(0.55f, 0.55f, 0.55f, 0.75f)
            }
        }
        val raw = mvtFeatureStringProperty(feature, "COLOR")
        if (raw != null && raw.isNotBlank()) {
            try {
                val s = raw.trim()
                val parseInput =
                    when {
                        s.startsWith("#") || s.startsWith("rgb(", ignoreCase = true) || s.startsWith(
                            "rgba(",
                            ignoreCase = true
                        ) -> s
                        else -> "#$s"
                    }
                val argb = Color.parseColor(parseInput)
                return floatArrayOf(
                    Color.red(argb) / 255f,
                    Color.green(argb) / 255f,
                    Color.blue(argb) / 255f,
                    Color.alpha(argb) / 255f,
                )
            } catch (_: Exception) {
                // Invalid hex: try data-driven fill / layer paint like Mapbox would.
            }
        }
        fillColorExpression?.let { expr ->
            VectorFillStyleExpressionEval.evaluateFillRgba(expr, feature, zoom)?.let { return it }
        }
        return layerFallbackFillRgba?.copyOf()
            ?: floatArrayOf(0.55f, 0.55f, 0.55f, 0.75f)
    }

    /**
     * Extrudes a polyline to a triangle ribbon in tile UV space (same basis as polygon fills).
     */
    private fun triangulateLineRibbon(
        feature: Feature,
        z: Int,
        tx: Int,
        ty: Int,
        world: Int,
        line: LineString,
        halfWidthUv: Float,
        out: GrowableFloatArray,
        layerFallbackFillRgba: FloatArray?,
        fillColorExpression: Expression?,
        expressionColorExclusive: Boolean,
        featureTime: Float = VectorMapTime.ALWAYS_VISIBLE,
    ) {
        val pts = line.coordinates()
        if (pts.size < 2) return
        val rgba = parseFillColor(
            feature,
            layerFallbackFillRgba,
            fillColorExpression,
            expressionColorExclusive,
            z.toDouble(),
        )
        var i = 0
        while (i < pts.size - 1) {
            val p0 = pts[i]
            val p1 = pts[i + 1]
            val (u0, v0) = lonLatToTileUv(z, tx, ty, world, p0.longitude(), p0.latitude())
            val (u1, v1) = lonLatToTileUv(z, tx, ty, world, p1.longitude(), p1.latitude())
            val dx = u1 - u0
            val dy = v1 - v0
            val len = kotlin.math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
            if (len < 1e-6f) {
                i++
                continue
            }
            val nx = (-dy / len) * halfWidthUv
            val ny = (dx / len) * halfWidthUv
            emitTriangleClipped(u0 + nx, v0 + ny, u0 - nx, v0 - ny, u1 - nx, v1 - ny, rgba, out, featureTime)
            emitTriangleClipped(u0 + nx, v0 + ny, u1 - nx, v1 - ny, u1 + nx, v1 + ny, rgba, out, featureTime)
            i++
        }
    }

    private fun triangulatePolygon(
        feature: Feature,
        z: Int,
        tx: Int,
        ty: Int,
        world: Int,
        poly: Polygon,
        out: GrowableFloatArray,
        layerFallbackFillRgba: FloatArray?,
        fillColorExpression: Expression?,
        expressionColorExclusive: Boolean,
        featureTime: Float = VectorMapTime.ALWAYS_VISIBLE,
    ) {
        val rgba = parseFillColor(
            feature,
            layerFallbackFillRgba,
            fillColorExpression,
            expressionColorExclusive,
            z.toDouble(),
        )
        val rings = poly.coordinates()
        if (rings.isEmpty()) return

        // GeoJSON / lon-lat path: unwrap antimeridian jumps then slice into unit-u strips so Earcut
        // never sees a world-spanning self-crossing ring (Apple projectedPolygonRings parity).
        // MVT raw triangulation uses tile-local XY and does not call this path.
        val uvRings = ArrayList<List<UvPoint>>(rings.size)
        for (ring in rings) {
            val uv = unwrapRingToTileUv(ring, z, tx, ty, world) ?: continue
            if (uv.size >= 3) uvRings.add(uv)
        }
        if (uvRings.isEmpty()) return

        var minU = Float.POSITIVE_INFINITY
        var maxU = Float.NEGATIVE_INFINITY
        for (p in uvRings[0]) {
            if (p.u < minU) minU = p.u
            if (p.u > maxU) maxU = p.u
        }
        if (minU > maxU) return

        val kStart = kotlin.math.floor(minU.toDouble()).toInt()
        val kEnd = kotlin.math.floor(maxU.toDouble()).toInt()
        for (k in kStart..kEnd) {
            val stripMin = k.toFloat()
            val stripMax = (k + 1).toFloat()
            val clipped = ArrayList<List<UvPoint>>(uvRings.size)
            for (ring in uvRings) {
                val piece = clipUvRingToURange(ring, stripMin, stripMax)
                if (piece.size >= 3) {
                    clipped.add(piece.map { UvPoint(it.u - stripMin, it.v) })
                }
            }
            if (clipped.isEmpty() || clipped[0].size < 3) continue
            earcutUvRingsAndEmit(clipped, rgba, out, featureTime)
        }
    }

    private data class UvPoint(val u: Float, val v: Float)

    /**
     * Maps a lon/lat ring to tile UV and unwraps consecutive u so |Δu| ≤ world/2
     * (Apple `unwrapWorldRingPoints`). Returns null when the ring has fewer than 3 distinct points.
     */
    private fun unwrapRingToTileUv(
        ring: List<com.mapbox.geojson.Point>,
        z: Int,
        tx: Int,
        ty: Int,
        world: Int,
    ): List<UvPoint>? {
        if (ring.size < 3) return null
        val n = if (
            ring.size > 1 &&
            ring.first().longitude() == ring.last().longitude() &&
            ring.first().latitude() == ring.last().latitude()
        ) {
            ring.size - 1
        } else {
            ring.size
        }
        if (n < 3) return null
        val halfWorld = world * 0.5f
        val worldF = world.toFloat()
        val out = ArrayList<UvPoint>(n)
        var prevU = Float.NaN
        for (i in 0 until n) {
            val p = ring[i]
            val (rawU, v) = lonLatToTileUv(z, tx, ty, world, p.longitude(), p.latitude())
            var u = rawU
            if (!prevU.isNaN()) {
                while (u - prevU > halfWorld) u -= worldF
                while (u - prevU < -halfWorld) u += worldF
            }
            out.add(UvPoint(u, v))
            prevU = u
        }
        return out
    }

    /** Sutherland–Hodgman clip of a closed UV ring to u ∈ [uMin, uMax]. */
    private fun clipUvRingToURange(ring: List<UvPoint>, uMin: Float, uMax: Float): List<UvPoint> {
        if (ring.size < 3) return emptyList()
        fun intersectU(a: UvPoint, b: UvPoint, edge: Float): UvPoint {
            val du = b.u - a.u
            if (abs(du) < 1e-8f) return UvPoint(edge, a.v)
            val t = (edge - a.u) / du
            return UvPoint(edge, a.v + t * (b.v - a.v))
        }
        fun clip(poly: List<UvPoint>, inside: (UvPoint) -> Boolean, edge: Float): List<UvPoint> {
            if (poly.isEmpty()) return emptyList()
            val res = ArrayList<UvPoint>(poly.size + 2)
            var prev = poly.last()
            var prevInside = inside(prev)
            for (cur in poly) {
                val curInside = inside(cur)
                if (curInside) {
                    if (!prevInside) res.add(intersectU(prev, cur, edge))
                    res.add(cur)
                } else if (prevInside) {
                    res.add(intersectU(prev, cur, edge))
                }
                prev = cur
                prevInside = curInside
            }
            return res
        }
        var poly = clip(ring, { it.u >= uMin - UV_EPS }, uMin)
        poly = clip(poly, { it.u <= uMax + UV_EPS }, uMax)
        return poly
    }

    private fun earcutUvRingsAndEmit(
        rings: List<List<UvPoint>>,
        rgba: FloatArray,
        out: GrowableFloatArray,
        featureTime: Float,
    ) {
        val flat = GrowableDoubleArray(64)
        val holeIndices = ArrayList<Int>()
        for ((idx, ring) in rings.withIndex()) {
            if (idx > 0) holeIndices.add(flat.size / 2)
            if (ring.size < 3) continue
            for (p in ring) {
                flat.add(p.u.toDouble())
                flat.add(p.v.toDouble())
            }
        }
        if (flat.size < 6) return
        val holes = if (holeIndices.isEmpty()) null else holeIndices.toIntArray()
        val triangles = Earcut.earcut(flat.toDoubleArray(), holes, 2)
        var ti = 0
        while (ti + 2 < triangles.size) {
            val a = triangles[ti++].toInt()
            val b = triangles[ti++].toInt()
            val c = triangles[ti++].toInt()
            emitTriangleClipped(
                flat[a * 2].toFloat(), flat[a * 2 + 1].toFloat(),
                flat[b * 2].toFloat(), flat[b * 2 + 1].toFloat(),
                flat[c * 2].toFloat(), flat[c * 2 + 1].toFloat(),
                rgba,
                out,
                featureTime,
            )
        }
    }

    private fun emitTriangleClipped(
        ax: Float,
        ay: Float,
        bx: Float,
        by: Float,
        cx: Float,
        cy: Float,
        rgba: FloatArray,
        out: GrowableFloatArray,
        featureTime: Float = VectorMapTime.ALWAYS_VISIBLE,
    ) {
        val minU = minOf(ax, bx, cx)
        val maxU = maxOf(ax, bx, cx)
        val minV = minOf(ay, by, cy)
        val maxV = maxOf(ay, by, cy)
        if (maxU < -UV_EPS || minU > 1f + UV_EPS || maxV < -UV_EPS || minV > 1f + UV_EPS) return

        data class P2(val u: Float, val v: Float)

        fun clipAgainst(poly: List<P2>, inside: (P2) -> Boolean, intersect: (P2, P2) -> P2): List<P2> {
            if (poly.isEmpty()) return emptyList()
            val res = ArrayList<P2>(poly.size + 2)
            var prev = poly.last()
            var prevInside = inside(prev)
            for (cur in poly) {
                val curInside = inside(cur)
                if (curInside) {
                    if (!prevInside) res.add(intersect(prev, cur))
                    res.add(cur)
                } else if (prevInside) {
                    res.add(intersect(prev, cur))
                }
                prev = cur
                prevInside = curInside
            }
            return res
        }

        fun intersectVertical(a: P2, b: P2, xEdge: Float): P2 {
            val du = b.u - a.u
            if (abs(du) < 1e-8f) return P2(xEdge, a.v)
            val t = (xEdge - a.u) / du
            return P2(xEdge, a.v + t * (b.v - a.v))
        }

        fun intersectHorizontal(a: P2, b: P2, yEdge: Float): P2 {
            val dv = b.v - a.v
            if (abs(dv) < 1e-8f) return P2(a.u, yEdge)
            val t = (yEdge - a.v) / dv
            return P2(a.u + t * (b.u - a.u), yEdge)
        }

        var poly: List<P2> = listOf(P2(ax, ay), P2(bx, by), P2(cx, cy))
        poly = clipAgainst(poly, { it.u >= -UV_EPS }, { p0, p1 -> intersectVertical(p0, p1, 0f) })
        poly = clipAgainst(poly, { it.u <= 1f + UV_EPS }, { p0, p1 -> intersectVertical(p0, p1, 1f) })
        poly = clipAgainst(poly, { it.v >= -UV_EPS }, { p0, p1 -> intersectHorizontal(p0, p1, 0f) })
        poly = clipAgainst(poly, { it.v <= 1f + UV_EPS }, { p0, p1 -> intersectHorizontal(p0, p1, 1f) })
        if (poly.size < 3) return

        val root = poly[0]
        var i = 1
        while (i + 1 < poly.size) {
            val p1 = poly[i]
            val p2 = poly[i + 1]
            val area2 = (p1.u - root.u) * (p2.v - root.v) - (p2.u - root.u) * (p1.v - root.v)
            if (abs(area2) > 1e-8f) {
                emitVertex(root.u.coerceIn(0f, 1f), root.v.coerceIn(0f, 1f), rgba, out, featureTime)
                emitVertex(p1.u.coerceIn(0f, 1f), p1.v.coerceIn(0f, 1f), rgba, out, featureTime)
                emitVertex(p2.u.coerceIn(0f, 1f), p2.v.coerceIn(0f, 1f), rgba, out, featureTime)
            }
            i++
        }
    }

    private fun emitVertex(
        u: Float,
        v: Float,
        rgba: FloatArray,
        out: GrowableFloatArray,
        featureTime: Float = VectorMapTime.ALWAYS_VISIBLE,
    ) {
        out.add(u)
        out.add(v)
        out.add(rgba[0])
        out.add(rgba[1])
        out.add(rgba[2])
        out.add(rgba[3])
        out.add(featureTime)
    }

    /**
     * Triangulates line / polygon ring boundaries as extruded ribbons. Returns interleaved
     * **[cx,cy,nx,ny,packed_rgba,edge_dist,half_width_uv,featureTime]** per vertex
     * ([OUTLINE_FLOATS_PER_VERTEX] floats). Half-width is scaled at draw time by tile overscale;
     * [edge_dist] drives AA fade in the shader.
     *
     * When [strokeRgba] is set, every feature uses that color. Otherwise per-feature color comes from [strokeColorExpression]
     * and MVT `COLOR` (same rules as [triangulateFeatures]). Per-feature width uses [strokeThicknessExpression]
     * when set, else [layerFallbackThicknessPx] (screen px before [lineThicknessScale]).
     */
    fun triangulateOutlines(
        features: List<Feature>,
        coord: TileCoord,
        sourceLayerFilter: String?,
        strokeRgba: FloatArray? = null,
        layerFallbackStrokeRgba: FloatArray? = null,
        strokeColorExpression: Expression? = null,
        expressionColorExclusive: Boolean = false,
        layerFallbackThicknessPx: Float? = null,
        strokeThicknessExpression: Expression? = null,
        lineThicknessScale: Float = 1f,
        mapTimeRevealKey: String? = null,
        /** Rule: outline-tile-clip-edge-skip. True only for MVT-sourced features — see
         * [isTileClipEdgeSegment] for why GeoJSON callers must leave this off. */
        skipTileClipEdges: Boolean = false,
    ): FloatArray {
        val z = coord.z
        val tx = coord.x
        val ty = coord.y
        val world = 1 shl z
        val out = GrowableFloatArray(256)
        fun accumulate(filter: String?) {
            for (f in features) {
                if (!layerMatches(f, filter)) continue
                val featureTime = VectorMapTime.featureTimeFromProperty(f, mapTimeRevealKey)
                val rgba =
                    strokeRgba
                        ?: parseFillColor(
                            f,
                            layerFallbackStrokeRgba,
                            strokeColorExpression,
                            expressionColorExclusive,
                            z.toDouble(),
                        )
                val thicknessPx =
                    if (strokeRgba != null) {
                        (layerFallbackThicknessPx ?: 0f) * lineThicknessScale
                    } else {
                        parseStrokeThicknessPx(
                            f,
                            layerFallbackThicknessPx,
                            strokeThicknessExpression,
                            lineThicknessScale,
                            z.toDouble(),
                        )
                    }
                if (thicknessPx <= 0f) continue
                val halfWidthUv = thicknessPx / 2f / 512f
                when (val g = f.geometry()) {
                    is Polygon -> triangulatePolygonOutline(
                        z, tx, ty, world, g, rgba, halfWidthUv, out, featureTime, skipTileClipEdges,
                    )
                    is MultiPolygon -> {
                        for (rings in g.coordinates()) {
                            triangulatePolygonOutline(
                                z,
                                tx,
                                ty,
                                world,
                                Polygon.fromLngLats(rings),
                                rgba,
                                halfWidthUv,
                                out,
                                featureTime,
                                skipTileClipEdges,
                            )
                        }
                    }
                    is LineString -> triangulatePolylineOutline(
                        z, tx, ty, world, g.coordinates(), rgba, halfWidthUv, out, featureTime,
                    )
                    is MultiLineString -> {
                        for (lineCoords in g.coordinates()) {
                            triangulatePolylineOutline(
                                z, tx, ty, world, lineCoords, rgba, halfWidthUv, out, featureTime,
                            )
                        }
                    }
                    else -> {}
                }
            }
        }
        accumulate(sourceLayerFilter)
        if (out.isEmpty() && sourceLayerFilter != null) {
            out.clear()
            accumulate(null)
        }
        return out.toFloatArray()
    }

    private fun parseStrokeThicknessPx(
        feature: Feature,
        layerFallbackThicknessPx: Float?,
        strokeThicknessExpression: Expression?,
        lineThicknessScale: Float,
        zoom: Double? = null,
    ): Float {
        val px =
            when {
                strokeThicknessExpression != null ->
                    VectorFillStyleExpressionEval.evaluateNumber(
                        strokeThicknessExpression,
                        feature,
                        zoom,
                    )?.toFloat()
                else -> layerFallbackThicknessPx
            } ?: 0f
        return px * lineThicknessScale
    }

    private fun triangulatePolylineOutline(
        z: Int,
        tx: Int,
        ty: Int,
        world: Int,
        pts: List<com.mapbox.geojson.Point>,
        rgba: FloatArray,
        halfWidthUv: Float,
        out: GrowableFloatArray,
        featureTime: Float = VectorMapTime.ALWAYS_VISIBLE,
    ) {
        if (pts.size < 2) return
        var i = 0
        while (i < pts.size - 1) {
            val p0 = pts[i]
            val p1 = pts[i + 1]
            val (u0, v0) = lonLatToTileUv(z, tx, ty, world, p0.longitude(), p0.latitude())
            val (u1, v1) = lonLatToTileUv(z, tx, ty, world, p1.longitude(), p1.latitude())
            emitOutlineSegment(u0, v0, u1, v1, rgba, halfWidthUv, out, featureTime)
            i++
        }
    }

    private fun emitOutlineSegment(
        u0: Float,
        v0: Float,
        u1: Float,
        v1: Float,
        rgba: FloatArray,
        halfWidthUv: Float,
        out: GrowableFloatArray,
        featureTime: Float = VectorMapTime.ALWAYS_VISIBLE,
    ) {
        val dx = u1 - u0
        val dy = v1 - v0
        val len = hypot(dx.toDouble(), dy.toDouble()).toFloat()
        if (len < 1e-6f) return
        val nx = -dy / len
        val ny = dx / len
        emitOutlineVertex(u0, v0, nx, ny, rgba, +1f, halfWidthUv, out, featureTime)
        emitOutlineVertex(u0, v0, -nx, -ny, rgba, -1f, halfWidthUv, out, featureTime)
        emitOutlineVertex(u1, v1, -nx, -ny, rgba, -1f, halfWidthUv, out, featureTime)
        emitOutlineVertex(u0, v0, nx, ny, rgba, +1f, halfWidthUv, out, featureTime)
        emitOutlineVertex(u1, v1, -nx, -ny, rgba, -1f, halfWidthUv, out, featureTime)
        emitOutlineVertex(u1, v1, nx, ny, rgba, +1f, halfWidthUv, out, featureTime)
    }

    private fun triangulatePolygonOutline(
        z: Int,
        tx: Int,
        ty: Int,
        world: Int,
        poly: Polygon,
        rgba: FloatArray,
        halfWidthUv: Float,
        out: GrowableFloatArray,
        featureTime: Float = VectorMapTime.ALWAYS_VISIBLE,
        skipTileClipEdges: Boolean = false,
    ) {
        for (ring in poly.coordinates()) {
            val uv = unwrapRingToTileUv(ring, z, tx, ty, world) ?: continue
            if (uv.size < 2) continue
            val n = uv.size
            for (i in 0 until n) {
                val p0 = uv[i]
                val p1 = uv[(i + 1) % n]
                val dx = p1.u - p0.u
                val dy = p1.v - p0.v
                val len = kotlin.math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
                if (len < 1e-6f) continue
                emitOutlineSegmentAcrossUnitCells(
                    p0.u, p0.v, p1.u, p1.v, rgba, halfWidthUv, out, featureTime, skipTileClipEdges,
                )
            }
        }
    }

    /**
     * Emits outline geometry for an already-unwrapped UV segment, one piece per unit-u cell, so
     * antimeridian-crossing edges become short edges near u=0 and u=1 (GeoJSON world-copy safe).
     */
    private fun emitOutlineSegmentAcrossUnitCells(
        u0: Float,
        v0: Float,
        u1: Float,
        v1: Float,
        rgba: FloatArray,
        halfWidthUv: Float,
        out: GrowableFloatArray,
        featureTime: Float,
        skipTileClipEdges: Boolean,
    ) {
        val du = u1 - u0
        val dv = v1 - v0
        if (abs(du) < 1e-8f) {
            val k = kotlin.math.floor(u0.toDouble()).toInt()
            val su0 = u0 - k
            val su1 = u1 - k
            if (skipTileClipEdges && isTileClipEdgeSegment(su0, v0, su1, v1)) return
            emitOutlineSegment(su0, v0, su1, v1, rgba, halfWidthUv, out, featureTime)
            return
        }
        val minU = minOf(u0, u1)
        val maxU = maxOf(u0, u1)
        val kStart = kotlin.math.floor(minU.toDouble()).toInt()
        val kEnd = kotlin.math.floor(maxU.toDouble()).toInt()
        for (k in kStart..kEnd) {
            val lo = k.toFloat()
            val hi = (k + 1).toFloat()
            val tLo = ((lo - u0) / du).coerceIn(0f, 1f)
            val tHi = ((hi - u0) / du).coerceIn(0f, 1f)
            val t0 = minOf(tLo, tHi)
            val t1 = maxOf(tLo, tHi)
            if (t1 - t0 < 1e-8f) continue
            val su0 = u0 + t0 * du - k
            val sv0 = v0 + t0 * dv
            val su1 = u0 + t1 * du - k
            val sv1 = v0 + t1 * dv
            if (skipTileClipEdges && isTileClipEdgeSegment(su0, sv0, su1, sv1)) continue
            emitOutlineSegment(su0, sv0, su1, sv1, rgba, halfWidthUv, out, featureTime)
        }
    }

    /**
     * Test hook (no Mapbox Feature dependency): triangulate a closed lon/lat ring at z=0 and return
     * fill vertex count. Used to lock antimeridian unwrap + unit-u strip slicing.
     */
    internal fun triangulateLonLatRingVertexCountForTest(lons: DoubleArray, lats: DoubleArray): Int {
        require(lons.size == lats.size && lons.size >= 3)
        val world = 1
        val z = 0
        val tx = 0
        val ty = 0
        val halfWorld = world * 0.5f
        val worldF = world.toFloat()
        val uv = ArrayList<UvPoint>(lons.size)
        var prevU = Float.NaN
        for (i in lons.indices) {
            val (rawU, v) = lonLatToTileUv(z, tx, ty, world, lons[i], lats[i])
            var u = rawU
            if (!prevU.isNaN()) {
                while (u - prevU > halfWorld) u -= worldF
                while (u - prevU < -halfWorld) u += worldF
            }
            uv.add(UvPoint(u, v))
            prevU = u
        }
        var minU = Float.POSITIVE_INFINITY
        var maxU = Float.NEGATIVE_INFINITY
        for (p in uv) {
            if (p.u < minU) minU = p.u
            if (p.u > maxU) maxU = p.u
        }
        val rgba = floatArrayOf(1f, 0f, 0f, 0.5f)
        val out = GrowableFloatArray(64)
        val kStart = kotlin.math.floor(minU.toDouble()).toInt()
        val kEnd = kotlin.math.floor(maxU.toDouble()).toInt()
        for (k in kStart..kEnd) {
            val stripMin = k.toFloat()
            val stripMax = (k + 1).toFloat()
            val piece = clipUvRingToURange(uv, stripMin, stripMax)
            if (piece.size < 3) continue
            val shifted = piece.map { UvPoint(it.u - stripMin, it.v) }
            earcutUvRingsAndEmit(listOf(shifted), rgba, out, VectorMapTime.ALWAYS_VISIBLE)
        }
        return out.toFloatArray().size / FILL_FLOATS_PER_VERTEX
    }

    private fun emitOutlineVertex(
        cx: Float,
        cy: Float,
        nx: Float,
        ny: Float,
        rgba: FloatArray,
        edgeDist: Float,
        halfWidthUv: Float,
        out: GrowableFloatArray,
        featureTime: Float = VectorMapTime.ALWAYS_VISIBLE,
    ) {
        out.add(cx); out.add(cy)
        out.add(nx); out.add(ny)
        out.add(packColorFloat(rgba))
        out.add(edgeDist)
        out.add(halfWidthUv)
        out.add(featureTime)
    }

    /**
     * Rule: coordinate-conversion-zero-alloc. Two floats packed into one `Long` (bit-reinterpreted,
     * same convention as [packColorFloat]) so per-vertex UV conversion never allocates a boxed
     * `Pair`/`Float` — [lonLatToTileUv] is called once per ring/line vertex across every polygon in
     * every tile in every phase, the single hottest loop in the whole triangulator, and this pattern
     * was measured live to be the dominant source of GC churn during active playback (200-300MB/sec
     * freed, versus single-digit-MB/sec once paused). `component1`/`component2` let every existing
     * `val (u, v) = lonLatToTileUv(...)` call site keep working unchanged.
     */
    @JvmInline
    internal value class PackedUv(private val bits: Long) {
        val u: Float get() = Float.fromBits((bits ushr 32).toInt())
        val v: Float get() = Float.fromBits(bits.toInt())
        operator fun component1(): Float = u
        operator fun component2(): Float = v
    }

    private fun packUv(u: Float, v: Float): PackedUv =
        PackedUv((u.toRawBits().toLong() shl 32) or (v.toRawBits().toLong() and 0xFFFFFFFFL))

    internal fun lonLatToTileUv(z: Int, tx: Int, ty: Int, world: Int, lon: Double, lat: Double): PackedUv {
        val xf = (lon + 180.0) / 360.0 * world
        val u = (xf - tx).toFloat()
        val latRad = Math.toRadians(lat)
        val sinLat = kotlin.math.sin(latRad)
        val yNorm = 0.5 - 0.25 * ln((1.0 + sinLat) / (1.0 - sinLat)) / PI
        val yf = yNorm * world
        val vMerc = (yf - ty).toFloat()
        return packUv(u, vMerc)
    }

    /**
     * Rule: coordinate-conversion-zero-alloc. Combines [MapboxVectorFeature.tileLocalXYToLngLat] +
     * [lonLatToTileUv] for the extremely common "ring/line vertex in tile-local pixel space needs
     * this tile's UV" pattern — inlines `tileLocalXYToLngLat`'s formula so lon/lat live only as local
     * `Double`s (identical precision/behavior to calling that function directly), never boxed into a
     * `Pair<Double, Double>` the way the two-call version required.
     */
    internal fun tileLocalXYToTileUv(
        x: Double,
        y: Double,
        coord: TileCoord,
        z: Int,
        tx: Int,
        ty: Int,
        world: Int,
        extent: Int = 4096,
    ): PackedUv {
        val lon = (x / extent + coord.x) / (1 shl coord.z) * 360.0 - 180.0
        val n = Math.PI - 2.0 * Math.PI * (y / extent + coord.y) / (1 shl coord.z)
        val lat = Math.toDegrees(Math.atan(Math.sinh(n)))
        return lonLatToTileUv(z, tx, ty, world, lon, lat)
    }

    /**
     * Triangulates [Point] and [MultiPoint] MVT features into a flat instance list using a 7-float
     * per-point layout `[cx, cy, r, g, b, a, radius_scale]` (rule: circle-gpu-instancing):
     * - `cx, cy` — circle centre in tile UV space `[0..1]`
     * - `r, g, b, a` — per-point colour.
     * - `radius_scale` — per-feature multiplier on the layer base style radius (1 when constant).
     *
     * The bounding-quad corner offset (`±1`) is a static per-vertex GPU attribute, not baked in here
     * — the vertex shader expands each instance to `pos = center + corner * (base_radius_uv *
     * radius_scale + stroke_uv)` via `glDrawArraysInstanced`, so the GPU (not the CPU) does the
     * 1-point-to-6-vertex quad expansion. Emits exactly one instance per matched [Point] or
     * [MultiPoint] coordinate.
     */
    fun triangulateCirclePoints(
        features: List<Feature>,
        coord: TileCoord,
        sourceLayerFilter: String?,
        layerFallbackCircleRgba: FloatArray? = null,
        circleColorExpression: Expression? = null,
        circleRadiusPx: Float = 6f,
        circleRadiusExpression: Expression? = null,
        clipToTileBounds: Boolean = false,
        circleRadiusUvMargin: Float = 0f,
        mapTimeRevealKey: String? = null,
    ): FloatArray =
        triangulateCirclePointsDetailed(
            features,
            coord,
            sourceLayerFilter,
            layerFallbackCircleRgba,
            circleColorExpression,
            circleRadiusPx,
            circleRadiusExpression,
            clipToTileBounds,
            circleRadiusUvMargin,
            mapTimeRevealKey,
        ).interleaved

    fun triangulateCirclePointsDetailed(
        features: List<Feature>,
        coord: TileCoord,
        sourceLayerFilter: String?,
        layerFallbackCircleRgba: FloatArray? = null,
        circleColorExpression: Expression? = null,
        circleRadiusPx: Float = 6f,
        circleRadiusExpression: Expression? = null,
        clipToTileBounds: Boolean = false,
        circleRadiusUvMargin: Float = 0f,
        mapTimeRevealKey: String? = null,
    ): CircleTriangulationResult {
        val z = coord.z; val tx = coord.x; val ty = coord.y; val world = 1 shl z
        val out = GrowableFloatArray(256)
        val times = if (mapTimeRevealKey != null) GrowableFloatArray(64) else null
        val margin = circleRadiusUvMargin.coerceAtLeast(0f)
        val baseRadiusPx = circleRadiusPx.coerceAtLeast(0.5f)

        fun radiusScaleForFeature(f: Feature): Float {
            if (circleRadiusExpression == null) return 1f
            val featurePx =
                VectorFillStyleExpressionEval.evaluateNumber(circleRadiusExpression, f, z.toDouble())?.toFloat()
                    ?: baseRadiusPx
            return (featurePx / baseRadiusPx).coerceAtLeast(0.1f)
        }

        fun emitDisc(cx: Float, cy: Float, rgba: FloatArray, radiusScale: Float, feature: Feature) {
            if (clipToTileBounds) {
                if (cx < -margin || cx > 1f + margin || cy < -margin || cy > 1f + margin) return
            }
            emitCircleInstance(cx, cy, rgba, radiusScale, out)
            times?.add(VectorMapTime.featureTimeFromProperty(feature, mapTimeRevealKey))
        }

        fun accumulate(filter: String?) {
            for (f in features) {
                if (!layerMatches(f, filter)) continue
                try {
                    val rgba = parseFillColor(
                        f,
                        layerFallbackCircleRgba,
                        circleColorExpression,
                        false,
                        z.toDouble(),
                    )
                    val radiusScale = radiusScaleForFeature(f)
                    when (val g = f.geometry()) {
                        is Point -> {
                            val (u, v) = lonLatToTileUv(z, tx, ty, world, g.longitude(), g.latitude())
                            emitDisc(u, v, rgba, radiusScale, f)
                        }
                        is MultiPoint -> {
                            for (p in g.coordinates()) {
                                val (u, v) = lonLatToTileUv(z, tx, ty, world, p.longitude(), p.latitude())
                                emitDisc(u, v, rgba, radiusScale, f)
                            }
                        }
                        else -> {}
                    }
                } catch (t: Throwable) {
                    Log.w(TAG, "triangulateCirclePoints(): skipping malformed feature", t)
                }
            }
        }

        accumulate(sourceLayerFilter)
        if (out.isEmpty() && sourceLayerFilter != null) {
            out.clear()
            times?.clear()
            accumulate(null)
        }
        return CircleTriangulationResult(out.toFloatArray(), times?.toFloatArray())
    }

    /**
     * Circle-only fast path: builds the same interleaved output as [triangulateCirclePoints] directly
     * from raw MVT-decoded features, skipping Feature/JsonObject/JTS-to-Mapbox-geometry construction
     * entirely — that construction measured as the dominant per-feature cost for point-heavy tiles.
     * Caller (rule: raw-circle-fast-path) is responsible for proving this is safe via
     * [VectorCircleRawStyleEval.isSupportedColorExpression] / `isSupportedNumberExpression` and by
     * confirming the layer's effective filter is null (visibility is still checked here directly).
     */
    internal fun triangulateCirclePointsRaw(
        rawFeatures: List<VectorTileDecoder.Feature>,
        coord: TileCoord,
        layerFallbackCircleRgba: FloatArray?,
        circleColorExpression: Expression?,
        circleRadiusPx: Float,
        circleRadiusExpression: Expression?,
    ): FloatArray {
        val z = coord.z; val tx = coord.x; val ty = coord.y; val world = 1 shl z
        // Primitive growable buffer, not ArrayList<Float>: lightning tiles can carry tens of
        // thousands of points, and boxing every float multiplies memory several-fold. Now that
        // parse is fast (rule: raw-circle-fast-path), many tiles finish parsing in the same window
        // and get triangulated concurrently — enough concurrent boxed-Float ArrayLists pushed this
        // over the heap ceiling under a full 25-interval timeline prime (observed OOM). Mirrors the
        // JS reference's own approach of writing straight into pre-sized primitive typed arrays.
        val out = GrowableFloatArray(256)
        val baseRadiusPx = circleRadiusPx.coerceAtLeast(0.5f)

        fun emitDisc(cx: Float, cy: Float, rgba: FloatArray, radiusScale: Float) {
            emitCircleInstance(cx, cy, rgba, radiusScale, out)
        }

        for (feature in rawFeatures) {
            try {
                @Suppress("UNCHECKED_CAST")
                val attrs = nestedDictionary(feature.attributes as Map<String, Any>)
                if (!rawFeatureVisible(attrs)) continue
                val rgba = circleColorExpression?.let { VectorCircleRawStyleEval.evaluateFillRgba(it, attrs) }
                    ?: layerFallbackCircleRgba?.copyOf()
                    ?: floatArrayOf(0.55f, 0.55f, 0.55f, 0.75f)
                val radiusScale = if (circleRadiusExpression == null) {
                    1f
                } else {
                    val px = VectorCircleRawStyleEval.evaluateNumber(circleRadiusExpression, attrs)?.toFloat()
                        ?: baseRadiusPx
                    (px / baseRadiusPx).coerceAtLeast(0.1f)
                }
                when (val geometry = feature.geometry) {
                    is JtsPoint -> {
                        val (u, v) = tileLocalXYToTileUv(geometry.x, geometry.y, coord, z, tx, ty, world)
                        emitDisc(u, v, rgba, radiusScale)
                    }
                    is JtsMultiPoint -> {
                        for (p in geometry.coordinates) {
                            val (u, v) = tileLocalXYToTileUv(p.x, p.y, coord, z, tx, ty, world)
                            emitDisc(u, v, rgba, radiusScale)
                        }
                    }
                    else -> Unit
                }
            } catch (t: Throwable) {
                Log.w(TAG, "triangulateCirclePointsRaw(): skipping malformed feature", t)
            }
        }
        return out.toFloatArray()
    }

    /** Mirrors [com.xweather.mapsgl.map.mapbox.VectorFeatureDrawFilter]'s MVT `visible` property check. */
    internal fun rawFeatureVisible(attrs: Map<String, Any?>): Boolean {
        (attrs["visible"] as? Number)?.let { if (it.toDouble() == 0.0) return false }
        (attrs["visible"] as? Boolean)?.let { if (!it) return false }
        return true
    }

    /**
     * [triangulateFeatures]'s raw counterpart (rule: raw-vector-fast-path). Builds the same
     * interleaved [x,y,r,g,b,a] output directly from raw MVT-decoded features, skipping
     * Feature/JsonObject/JTS-to-Mapbox-geometry construction entirely. [VectorTileDecoder.Feature]'s
     * JTS geometry coordinates are in tile-local pixel space (0..[extent]); each ring coordinate is
     * converted via [MapboxVectorFeature.tileLocalXYToLngLat] then [lonLatToTileUv], mirroring
     * [triangulateCirclePointsRaw]'s per-point conversion. Caller (each of
     * [com.xweather.mapsgl.renderers.VectorFillLayerRenderer] /
     * [com.xweather.mapsgl.renderers.VectorLineLayerRenderer]) is responsible for proving this is
     * safe via [VectorCircleRawStyleEval.isSupportedColorExpression] and declaring eligibility on
     * [com.xweather.mapsgl.sources.VectorTileSource] — despite the "Circle" name,
     * [VectorCircleRawStyleEval] evaluates purely against a `Map<String, Any?>` attrs, no
     * circle-specific logic, so it's reused here rather than duplicated.
     */
    internal fun triangulateFeaturesRaw(
        rawFeatures: List<VectorTileDecoder.Feature>,
        coord: TileCoord,
        layerFallbackFillRgba: FloatArray?,
        fillColorExpression: Expression?,
        allowLineRibbonFallback: Boolean,
        expressionColorExclusive: Boolean,
        useNativeTriangulation: Boolean = false,
        /** Rule: native-triangulation-zero-copy-write. When both are non-null and every polygon/ring
         * in this tile triangulates natively, the exact native bytes are written straight to
         * [vts]'s fill-mesh cache under [nativeCacheKey] — no FloatArray round-trip on that write.
         * Purely an optional write-side optimization; the returned [FloatArray] is unaffected. */
        vts: VectorTileSource? = null,
        nativeCacheKey: String? = null,
    ): FloatArray {
        val out = GrowableFloatArray(512)
        val nativeAccum = NativeByteAccumulator()
        for (feature in rawFeatures) {
            try {
                @Suppress("UNCHECKED_CAST")
                val attrs = nestedDictionary(feature.attributes as Map<String, Any>)
                if (!rawFeatureVisible(attrs)) continue
                val rgba = parseFillColorRaw(attrs, layerFallbackFillRgba, fillColorExpression, expressionColorExclusive)
                when (val g = feature.geometry) {
                    is JtsPolygon -> triangulatePolygonRaw(coord, g, out, rgba, useNativeTriangulation, nativeAccum)
                    is JtsMultiPolygon -> {
                        for (i in 0 until g.numGeometries) {
                            triangulatePolygonRaw(
                                coord, g.getGeometryN(i) as JtsPolygon, out, rgba, useNativeTriangulation, nativeAccum,
                            )
                        }
                    }
                    is JtsLineString -> if (allowLineRibbonFallback) {
                        nativeAccum.poison()
                        triangulateLineRibbonRaw(coord, g, lineRibbonHalfWidthUv, out, rgba)
                    }
                    is JtsMultiLineString -> if (allowLineRibbonFallback) {
                        nativeAccum.poison()
                        for (i in 0 until g.numGeometries) {
                            triangulateLineRibbonRaw(coord, g.getGeometryN(i) as JtsLineString, lineRibbonHalfWidthUv, out, rgba)
                        }
                    }
                    else -> Unit
                }
            } catch (t: Throwable) {
                Log.w(TAG, "triangulateFeaturesRaw(): skipping malformed feature", t)
                nativeAccum.poison()
            }
        }
        val floats = out.toFloatArray()
        if (vts != null && nativeCacheKey != null) {
            val pureNativeBytes = nativeAccum.pureNativeBytesOrNull()
            if (pureNativeBytes != null) {
                if (pureNativeBytes.isNotEmpty()) vts.putFillTriangulationNativeBytes(nativeCacheKey, pureNativeBytes)
            } else if (floats.isNotEmpty()) {
                vts.putFillTriangulationNative(nativeCacheKey, floats)
            }
        }
        return floats
    }

    /** [parseFillColor]'s raw counterpart, evaluated against an attrs map instead of a [Feature]. */
    private fun parseFillColorRaw(
        attrs: Map<String, Any?>,
        layerFallbackFillRgba: FloatArray?,
        fillColorExpression: Expression?,
        expressionColorExclusive: Boolean,
    ): FloatArray {
        if (expressionColorExclusive) {
            fillColorExpression?.let { expr ->
                return VectorCircleRawStyleEval.evaluateFillRgba(expr, attrs)
                    ?: layerFallbackFillRgba?.copyOf()
                    ?: floatArrayOf(0.55f, 0.55f, 0.55f, 0.75f)
            }
        }
        val raw = attrs["COLOR"] as? String
        if (!raw.isNullOrBlank()) {
            try {
                val s = raw.trim()
                val parseInput = when {
                    s.startsWith("#") || s.startsWith("rgb(", ignoreCase = true) || s.startsWith("rgba(", ignoreCase = true) -> s
                    else -> "#$s"
                }
                val argb = Color.parseColor(parseInput)
                return floatArrayOf(
                    Color.red(argb) / 255f,
                    Color.green(argb) / 255f,
                    Color.blue(argb) / 255f,
                    Color.alpha(argb) / 255f,
                )
            } catch (_: Exception) {
                // Invalid hex: try data-driven fill / layer paint like Mapbox would.
            }
        }
        fillColorExpression?.let { expr ->
            VectorCircleRawStyleEval.evaluateFillRgba(expr, attrs)?.let { return it }
        }
        return layerFallbackFillRgba?.copyOf() ?: floatArrayOf(0.55f, 0.55f, 0.55f, 0.75f)
    }

    /** Converts one JTS ring's tile-local-pixel coordinates to a flat lon/lat-derived UV array for earcut. */
    private fun ringToUvFlatRaw(coord: TileCoord, ring: JtsLineString, flat: GrowableDoubleArray) {
        val z = coord.z
        val tx = coord.x
        val ty = coord.y
        val world = 1 shl z
        val coords = ring.coordinates
        val n = if (coords.size > 1 && coords.first() == coords.last()) coords.size - 1 else coords.size
        for (i in 0 until n) {
            val c = coords[i]
            val (u, v) = tileLocalXYToTileUv(c.x, c.y, coord, z, tx, ty, world)
            flat.add(u.toDouble())
            flat.add(v.toDouble())
        }
    }

    private fun triangulatePolygonRaw(
        coord: TileCoord,
        poly: JtsPolygon,
        out: GrowableFloatArray,
        rgba: FloatArray,
        useNativeTriangulation: Boolean = false,
        nativeAccum: NativeByteAccumulator? = null,
    ) {
        val flat = GrowableDoubleArray(64)
        val holeIndices = ArrayList<Int>()
        ringToUvFlatRaw(coord, poly.exteriorRing, flat)
        for (i in 0 until poly.numInteriorRing) {
            holeIndices.add(flat.size / 2)
            ringToUvFlatRaw(coord, poly.getInteriorRingN(i), flat)
        }
        if (flat.size < 6) return
        val holes = if (holeIndices.isEmpty()) null else holeIndices.toIntArray()
        // Rule: native-fill-triangulation. flat/holes here are already in the EXACT format
        // Earcut.earcut(flat.toDoubleArray(), holes, 2) consumes today — nativeTriangulateFillPolygon
        // does the same earcut+clip+emit computation off the JVM heap. Any null/exception (malformed
        // input, JNI failure) falls back to the existing JVM path for this one polygon rather than
        // dropping it — never an all-or-nothing gate.
        if (useNativeTriangulation) {
            val nativeBytes = try {
                nativeTriHandle.nativeTriangulateFillPolygon(
                    flat.toDoubleArray(),
                    holeIndices.toIntArray(),
                    rgba,
                )
            } catch (t: Throwable) {
                Log.w(TAG, "nativeTriangulateFillPolygon failed, falling back to JVM path", t)
                null
            }
            if (nativeBytes != null && nativeBytes.size % 4 == 0) {
                if (nativeBytes.isNotEmpty()) {
                    val floats = FloatArray(nativeBytes.size / 4)
                    java.nio.ByteBuffer.wrap(nativeBytes).order(java.nio.ByteOrder.nativeOrder())
                        .asFloatBuffer().get(floats)
                    out.addAll(floats)
                    // Rule: native-triangulation-zero-copy-write. nativeBytes is already the tile-mesh's
                    // exact on-cache byte format — shadow it verbatim, no extra decode beyond the one
                    // already needed for `floats` above.
                    nativeAccum?.appendNative(nativeBytes)
                }
                // Rule: native-fill-empty-result-skip. A non-null, zero-length result means native
                // already proved (via earcut+clip) that this polygon contributes nothing to this
                // tile — confirmed empty, not a failure. Return without falling back to the JVM
                // Earcut path, which would just redundantly recompute the same empty answer. Only a
                // null return (genuine exception or malformed input) falls through to the JVM path.
                return
            }
        }
        nativeAccum?.poison()
        val triangles = Earcut.earcut(flat.toDoubleArray(), holes, 2)
        var ti = 0
        while (ti + 2 < triangles.size) {
            val a = triangles[ti++].toInt()
            val b = triangles[ti++].toInt()
            val c = triangles[ti++].toInt()
            emitTriangleClipped(
                flat[a * 2].toFloat(), flat[a * 2 + 1].toFloat(),
                flat[b * 2].toFloat(), flat[b * 2 + 1].toFloat(),
                flat[c * 2].toFloat(), flat[c * 2 + 1].toFloat(),
                rgba,
                out,
            )
        }
    }

    private fun triangulateLineRibbonRaw(
        coord: TileCoord,
        line: JtsLineString,
        halfWidthUv: Float,
        out: GrowableFloatArray,
        rgba: FloatArray,
    ) {
        val z = coord.z
        val tx = coord.x
        val ty = coord.y
        val world = 1 shl z
        val coords = line.coordinates
        if (coords.size < 2) return
        var i = 0
        while (i < coords.size - 1) {
            val (u0, v0) = tileLocalXYToTileUv(coords[i].x, coords[i].y, coord, z, tx, ty, world)
            val (u1, v1) = tileLocalXYToTileUv(coords[i + 1].x, coords[i + 1].y, coord, z, tx, ty, world)
            val dx = u1 - u0
            val dy = v1 - v0
            val len = hypot(dx.toDouble(), dy.toDouble()).toFloat()
            if (len < 1e-6f) {
                i++
                continue
            }
            val nx = (-dy / len) * halfWidthUv
            val ny = (dx / len) * halfWidthUv
            emitTriangleClipped(u0 + nx, v0 + ny, u0 - nx, v0 - ny, u1 - nx, v1 - ny, rgba, out)
            emitTriangleClipped(u0 + nx, v0 + ny, u1 - nx, v1 - ny, u1 + nx, v1 + ny, rgba, out)
            i++
        }
    }

    /**
     * [triangulateOutlines]'s raw counterpart (rule: raw-vector-fast-path). See
     * [triangulateFeaturesRaw] for the shared design notes.
     */
    internal fun triangulateOutlinesRaw(
        rawFeatures: List<VectorTileDecoder.Feature>,
        coord: TileCoord,
        strokeRgba: FloatArray?,
        layerFallbackStrokeRgba: FloatArray?,
        strokeColorExpression: Expression?,
        expressionColorExclusive: Boolean,
        layerFallbackThicknessPx: Float?,
        strokeThicknessExpression: Expression?,
        lineThicknessScale: Float,
        useNativeTriangulation: Boolean = false,
        /** See [triangulateFeaturesRaw]'s identical parameters (rule: native-triangulation-zero-copy-write). */
        vts: VectorTileSource? = null,
        nativeCacheKey: String? = null,
    ): FloatArray {
        val out = GrowableFloatArray(256)
        val nativeAccum = NativeByteAccumulator()
        for (feature in rawFeatures) {
            try {
                @Suppress("UNCHECKED_CAST")
                val attrs = nestedDictionary(feature.attributes as Map<String, Any>)
                if (!rawFeatureVisible(attrs)) continue
                val rgba = strokeRgba
                    ?: parseFillColorRaw(attrs, layerFallbackStrokeRgba, strokeColorExpression, expressionColorExclusive)
                val thicknessPx = if (strokeRgba != null) {
                    (layerFallbackThicknessPx ?: 0f) * lineThicknessScale
                } else {
                    val px = strokeThicknessExpression?.let {
                        VectorCircleRawStyleEval.evaluateNumber(it, attrs)?.toFloat()
                    } ?: layerFallbackThicknessPx ?: 0f
                    px * lineThicknessScale
                }
                if (thicknessPx <= 0f) continue
                val halfWidthUv = thicknessPx / 2f / 512f
                when (val g = feature.geometry) {
                    is JtsPolygon -> triangulatePolygonOutlineRaw(coord, g, rgba, halfWidthUv, out, useNativeTriangulation, nativeAccum)
                    is JtsMultiPolygon -> {
                        for (i in 0 until g.numGeometries) {
                            triangulatePolygonOutlineRaw(
                                coord, g.getGeometryN(i) as JtsPolygon, rgba, halfWidthUv, out, useNativeTriangulation, nativeAccum,
                            )
                        }
                    }
                    is JtsLineString -> triangulatePolylineOutlineRaw(coord, g, rgba, halfWidthUv, out, useNativeTriangulation, nativeAccum)
                    is JtsMultiLineString -> {
                        for (i in 0 until g.numGeometries) {
                            triangulatePolylineOutlineRaw(
                                coord, g.getGeometryN(i) as JtsLineString, rgba, halfWidthUv, out, useNativeTriangulation, nativeAccum,
                            )
                        }
                    }
                    else -> Unit
                }
            } catch (t: Throwable) {
                Log.w(TAG, "triangulateOutlinesRaw(): skipping malformed feature", t)
                nativeAccum.poison()
            }
        }
        val floats = out.toFloatArray()
        if (vts != null && nativeCacheKey != null) {
            val pureNativeBytes = nativeAccum.pureNativeBytesOrNull()
            if (pureNativeBytes != null) {
                if (pureNativeBytes.isNotEmpty()) vts.putOutlineTriangulationNativeBytes(nativeCacheKey, pureNativeBytes)
            } else if (floats.isNotEmpty()) {
                vts.putOutlineTriangulationNative(nativeCacheKey, floats)
            }
        }
        return floats
    }

    /** Converts one JTS ring/line's tile-local-pixel coordinates to a flat UV array for the native
     * outline path — mirrors [ringToUvFlatRaw] but keeps the ring's own duplicate-closing-vertex
     * dropped the same way the existing JVM outline loop already does. */
    private fun ringToUvFlatRawOutline(coord: TileCoord, coords: Array<org.locationtech.jts.geom.Coordinate>, flat: GrowableDoubleArray): Int {
        val z = coord.z
        val tx = coord.x
        val ty = coord.y
        val world = 1 shl z
        val n = if (coords.size > 1 && coords.first() == coords.last()) coords.size - 1 else coords.size
        for (i in 0 until n) {
            val c = coords[i]
            val (u, v) = tileLocalXYToTileUv(c.x, c.y, coord, z, tx, ty, world)
            flat.add(u.toDouble())
            flat.add(v.toDouble())
        }
        return n
    }

    private fun triangulatePolylineOutlineRaw(
        coord: TileCoord,
        line: JtsLineString,
        rgba: FloatArray,
        halfWidthUv: Float,
        out: GrowableFloatArray,
        useNativeTriangulation: Boolean = false,
        nativeAccum: NativeByteAccumulator? = null,
    ) {
        val coords = line.coordinates
        if (coords.size < 2) return
        if (useNativeTriangulation) {
            val flat = GrowableDoubleArray(coords.size * 2)
            val n = ringToUvFlatRawOutline(coord, coords, flat)
            if (n >= 2 &&
                tryNativeOutlineTriangulation(flat, intArrayOf(n), closed = false, rgba, halfWidthUv, out, nativeAccum)
            ) {
                return
            }
        }
        nativeAccum?.poison()
        val z = coord.z
        val tx = coord.x
        val ty = coord.y
        val world = 1 shl z
        var i = 0
        while (i < coords.size - 1) {
            val (u0, v0) = tileLocalXYToTileUv(coords[i].x, coords[i].y, coord, z, tx, ty, world)
            val (u1, v1) = tileLocalXYToTileUv(coords[i + 1].x, coords[i + 1].y, coord, z, tx, ty, world)
            emitOutlineSegment(u0, v0, u1, v1, rgba, halfWidthUv, out)
            i++
        }
    }

    private fun triangulatePolygonOutlineRaw(
        coord: TileCoord,
        poly: JtsPolygon,
        rgba: FloatArray,
        halfWidthUv: Float,
        out: GrowableFloatArray,
        useNativeTriangulation: Boolean = false,
        nativeAccum: NativeByteAccumulator? = null,
    ) {
        val rings = ArrayList<JtsLineString>(poly.numInteriorRing + 1)
        rings.add(poly.exteriorRing)
        for (i in 0 until poly.numInteriorRing) rings.add(poly.getInteriorRingN(i))
        if (useNativeTriangulation) {
            val flat = GrowableDoubleArray(64)
            val ringLengths = ArrayList<Int>(rings.size)
            for (ring in rings) {
                // Rule: native-outline-triangulation. Must skip a degenerate ring (n < 2) BEFORE
                // appending anything to flat — appending its points while omitting its length from
                // ringLengths would desync every subsequent ring's offset on the native side
                // (native tracks position purely by summing ringLengths), silently corrupting every
                // ring after the degenerate one in this same call.
                val coords = ring.coordinates
                val n = if (coords.size > 1 && coords.first() == coords.last()) coords.size - 1 else coords.size
                if (n < 2) continue
                ringToUvFlatRawOutline(coord, coords, flat)
                ringLengths.add(n)
            }
            if (ringLengths.isNotEmpty() &&
                tryNativeOutlineTriangulation(flat, ringLengths.toIntArray(), closed = true, rgba, halfWidthUv, out, nativeAccum)
            ) {
                return
            }
        }
        nativeAccum?.poison()
        val z = coord.z
        val tx = coord.x
        val ty = coord.y
        val world = 1 shl z
        for (ring in rings) {
            val coords = ring.coordinates
            val n = if (coords.size > 1 && coords.first() == coords.last()) coords.size - 1 else coords.size
            if (n < 2) continue
            for (i in 0 until n) {
                val c0 = coords[i]
                val c1 = coords[(i + 1) % n]
                val (u0, v0) = tileLocalXYToTileUv(c0.x, c0.y, coord, z, tx, ty, world)
                val (u1, v1) = tileLocalXYToTileUv(c1.x, c1.y, coord, z, tx, ty, world)
                val dx = u1 - u0
                val dy = v1 - v0
                val len = hypot(dx.toDouble(), dy.toDouble()).toFloat()
                if (len < 1e-6f) continue
                // Rule: outline-tile-clip-edge-skip. Raw features are MVT-only, so the test is
                // unconditional here (unlike the heavy-Feature path, which also serves GeoJSON).
                if (isTileClipEdgeSegment(u0, v0, u1, v1)) continue
                emitOutlineSegment(u0, v0, u1, v1, rgba, halfWidthUv, out)
            }
        }
    }

    /**
     * Rule: native-outline-triangulation. A null return (malformed input, JNI exception) returns
     * false so the caller falls back to the existing JVM per-segment loop for this one ring/line —
     * never an all-or-nothing gate, mirroring [triangulatePolygonRaw]'s identical fallback contract.
     * A non-null but zero-length return (rule: native-fill-empty-result-skip) is a *confirmed empty*
     * success, not a failure — returns true with nothing added, no JVM fallback.
     */
    private fun tryNativeOutlineTriangulation(
        flat: GrowableDoubleArray,
        ringLengths: IntArray,
        closed: Boolean,
        rgba: FloatArray,
        halfWidthUv: Float,
        out: GrowableFloatArray,
        nativeAccum: NativeByteAccumulator? = null,
    ): Boolean {
        val nativeBytes = try {
            nativeTriHandle.nativeTriangulateOutlineRings(flat.toDoubleArray(), ringLengths, closed, rgba, halfWidthUv)
        } catch (t: Throwable) {
            Log.w(TAG, "nativeTriangulateOutlineRings failed, falling back to JVM path", t)
            null
        }
        if (nativeBytes == null || nativeBytes.size % 4 != 0) return false
        // Rule: native-fill-empty-result-skip. A non-null, zero-length result is a confirmed-empty
        // success (this ring/line legitimately contributes nothing to this tile), not a failure —
        // return true (handled by native, no JVM fallback needed) with nothing added to `out`.
        if (nativeBytes.isEmpty()) return true
        val floats = FloatArray(nativeBytes.size / 4)
        java.nio.ByteBuffer.wrap(nativeBytes).order(java.nio.ByteOrder.nativeOrder()).asFloatBuffer().get(floats)
        out.addAll(floats)
        // Rule: native-triangulation-zero-copy-write. See triangulatePolygonRaw's identical note.
        nativeAccum?.appendNative(nativeBytes)
        return true
    }

    /** Emits one circle instance record `[cx, cy, r, g, b, a, radius_scale]` (rule: circle-gpu-instancing). */
    private fun emitCircleInstance(
        cx: Float,
        cy: Float,
        rgba: FloatArray,
        radiusScale: Float,
        out: GrowableFloatArray,
    ) {
        out.add(cx); out.add(cy)
        out.add(rgba[0]); out.add(rgba[1]); out.add(rgba[2]); out.add(rgba[3])
        out.add(radiusScale)
    }

    /**
     * Primitive-backed growable float buffer (rule: raw-circle-fast-path) — avoids the per-element
     * boxing an `ArrayList<Float>` incurs, which matters when a single tile can emit hundreds of
     * thousands of floats (lightning tiles: up to ~38k points). Also the fix for rule:
     * native-triangulation-write-path-double-copy — [addAll] lets the native-triangulation callers
     * bulk-copy an already-decoded `FloatArray` in one array copy instead of boxing every float into
     * an `ArrayList<Float>` one at a time.
     */
    private class GrowableFloatArray(initialCapacity: Int) {
        private var data = FloatArray(initialCapacity)
        private var size = 0

        fun add(value: Float) {
            if (size >= data.size) {
                data = data.copyOf(maxOf(data.size * 2, 16))
            }
            data[size++] = value
        }

        fun addAll(values: FloatArray) {
            if (size + values.size > data.size) {
                data = data.copyOf(maxOf(data.size * 2, size + values.size))
            }
            System.arraycopy(values, 0, data, size, values.size)
            size += values.size
        }

        fun isEmpty(): Boolean = size == 0

        fun clear() {
            size = 0
        }

        fun toFloatArray(): FloatArray = data.copyOf(size)
    }

    /** [GrowableFloatArray]'s byte counterpart (rule: native-triangulation-zero-copy-write). */
    private class GrowableByteArray(initialCapacity: Int) {
        private var data = ByteArray(initialCapacity)
        private var size = 0

        fun addAll(values: ByteArray) {
            if (size + values.size > data.size) {
                data = data.copyOf(maxOf(data.size * 2, size + values.size))
            }
            System.arraycopy(values, 0, data, size, values.size)
            size += values.size
        }

        fun isEmpty(): Boolean = size == 0

        fun toByteArray(): ByteArray = data.copyOf(size)
    }

    /**
     * [GrowableFloatArray]'s double-precision counterpart (rule: coordinate-conversion-zero-alloc) —
     * replaces `ArrayList<Double>` for ring/line coordinate accumulation (the values fed into
     * `Earcut.earcut`/the native triangulation JNI calls), avoiding a boxed `Double` per coordinate
     * on top of [tileLocalXYToTileUv]'s own fix. Matches `ArrayList<Double>`'s exact API surface used
     * at these call sites (`add`, `size`, indexed `get`, `toDoubleArray`) so it's a drop-in swap.
     */
    private class GrowableDoubleArray(initialCapacity: Int) {
        private var data = DoubleArray(initialCapacity)
        private var count = 0

        fun add(value: Double) {
            if (count >= data.size) {
                data = data.copyOf(maxOf(data.size * 2, 16))
            }
            data[count++] = value
        }

        val size: Int get() = count

        operator fun get(index: Int): Double = data[index]

        fun toDoubleArray(): DoubleArray = data.copyOf(count)
    }

    /**
     * Rule: native-triangulation-zero-copy-write. Shadows a tile's native-triangulation output as raw
     * bytes, in parallel with (never instead of) the existing per-vertex float accumulation that
     * [triangulateFeaturesRaw]/[triangulateOutlinesRaw] already do for their `FloatArray` return
     * value — this class changes nothing about what gets returned or how it's computed. It exists
     * purely so the caller's native-cache WRITE can skip the FloatArray-materialization step when
     * every polygon/ring in the tile triangulated natively: [appendNative] mirrors bytes the JNI call
     * already handed back (no extra decode), and the instant any polygon/ring needs the JVM fallback
     * (native disabled, JNI failure, or a geometry type — e.g. line-ribbon fallback — with no native
     * path at all), [poison] discards the shadow copy so the caller falls back to the existing
     * float-array encode-to-bytes path for that tile, unchanged from before this rule existed.
     */
    private class NativeByteAccumulator {
        private var bytes: GrowableByteArray? = GrowableByteArray(512)

        fun appendNative(nativeBytes: ByteArray) {
            bytes?.addAll(nativeBytes)
        }

        fun poison() {
            bytes = null
        }

        /** Non-null (and possibly empty, e.g. an all-invisible tile) only if every contribution to
         * this tile's mesh came from a successful native call — never poisoned. */
        fun pureNativeBytesOrNull(): ByteArray? = bytes?.toByteArray()
    }
}
