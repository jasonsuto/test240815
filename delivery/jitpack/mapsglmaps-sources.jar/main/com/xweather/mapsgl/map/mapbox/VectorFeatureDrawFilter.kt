package com.xweather.mapsgl.map.mapbox

import com.mapbox.geojson.Feature
import com.xweather.mapsgl.style.Expression

/**
 * MapsGL JS vector draw visibility: MVT `visible` property plus layer filter (including `mapTime`).
 */
internal object VectorFeatureDrawFilter {

    fun shouldDraw(
        feature: Feature,
        filter: Expression?,
        layerId: String? = null,
        mapTimeMs: Long = VectorDrawTime.currentMapTimeMillis(),
    ): Boolean {
        if (!isMvtFeatureMarkedVisible(feature)) return false
        if (TropicalDrawFilter.isTropicalTrackLineLayer(layerId)) {
            return TropicalDrawFilter.passesTrackLine(feature, mapTimeMs)
        }
        val flatFilter = ExpressionFilterFlatten.flatten(filter)
        val effective = VectorLayerDrawFilterDefaults.effectiveFilter(layerId, flatFilter)
        return StencilMaskFilter.matches(feature, effective, mapTimeMs)
    }

    /**
     * Mesh-prep visibility when GPU map-time reveal is active: apply only the static filter half
     * (and tropical type/geometry checks) so timed features stay resident in the VBO.
     */
    fun shouldDrawForGpuMapTimePrep(
        feature: Feature,
        filter: Expression?,
        layerId: String? = null,
    ): Boolean {
        if (!isMvtFeatureMarkedVisible(feature)) return false
        if (TropicalDrawFilter.isTropicalTrackLineLayer(layerId)) {
            return TropicalDrawFilter.passesTrackLineStatic(feature)
        }
        val flatFilter = ExpressionFilterFlatten.flatten(filter)
        val staticFilter = VectorMapTime.staticPrepFilter(layerId, flatFilter)
        // Static half has no map-time; playhead unused. Pass 0 for API completeness.
        return StencilMaskFilter.matches(feature, staticFilter, 0L)
    }

    fun referencesMapTime(layerId: String?, filter: Expression?): Boolean {
        if (TropicalDrawFilter.isTropicalTrackLineLayer(layerId)) return true
        return VectorLayerDrawFilterDefaults.referencesMapTime(layerId, filter)
    }

    /**
     * JS hides features when `properties.visible === 0`. Missing property means visible.
     */
    private fun isMvtFeatureMarkedVisible(feature: Feature): Boolean {
        feature.getNumberProperty("visible")?.let { if (it == 0.0) return false }
        feature.getBooleanProperty("visible")?.let { if (!it) return false }
        return true
    }
}
