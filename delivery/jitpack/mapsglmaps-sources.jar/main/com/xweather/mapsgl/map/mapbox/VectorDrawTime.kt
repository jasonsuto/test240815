package com.xweather.mapsgl.map.mapbox

import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.style.Expression

/**
 * Timeline instant used by MapsGL JS draw filters (`mapTime` / `time` / `$s`).
 */
internal object VectorDrawTime {

    /**
     * Epoch milliseconds for draw-time filters. [StencilMaskFilter] converts this to Unix seconds
     * for `map-time` / `timestamp` comparisons (matches MapsGL JS `setAnimationTime`).
     */
    fun currentMapTimeMillis(): Long {
        if (Timeline.timeLongs.isNotEmpty()) {
            val a = Timeline.timeLongs.getOrElse(Timeline.currentPhaseA) { Timeline.timeLongs.first() }
            val b = Timeline.timeLongs.getOrElse(Timeline.currentPhaseB) { a }
            // timeLongs entries are epoch seconds (see Timeline.generateHourlyIntervals).
            val seconds = a + ((b - a) * Timeline.dataMeld).toLong()
            return seconds * 1000L
        }
        return Timeline.drawMapTimeEpochMillis
    }

    /** Unix seconds for `map-time` / `timestamp` comparisons (matches MapsGL JS). */
    fun currentMapTimeSeconds(): Long = currentMapTimeMillis() / 1000L

    fun filterReferencesMapTime(filter: Expression?): Boolean {
        if (filter == null) return false
        return rawReferencesMapTime(filter.raw)
    }

    private fun rawReferencesMapTime(raw: Any?): Boolean {
        when (raw) {
            is Expression -> return rawReferencesMapTime(raw.raw)
            is List<*> -> {
                if (raw.isNotEmpty()) {
                    when (raw[0] as? String) {
                        "mapTime", "map-time", "time", "timeline" -> return true
                    }
                }
                return raw.any { rawReferencesMapTime(it) }
            }
            else -> return false
        }
    }
}
