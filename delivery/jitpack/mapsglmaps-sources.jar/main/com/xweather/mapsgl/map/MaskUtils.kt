package com.xweather.mapsgl.map

import androidx.compose.ui.graphics.Color
import com.mapbox.maps.LayerPosition
import com.mapbox.maps.MapboxMap
import com.mapbox.maps.Style
import com.mapbox.maps.extension.style.layers.generated.BackgroundLayer
import com.mapbox.maps.extension.style.layers.generated.FillLayer
import com.mapbox.maps.extension.style.layers.getLayer
import com.mapbox.maps.extension.style.layers.getLayerAs
import com.xweather.mapsgl.layers.spec.FillLayerDescriptor
import com.xweather.mapsgl.layers.spec.MaskLayerKind
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.map.mapbox.MapboxMapController
import com.xweather.mapsgl.style.StyleValue
import com.xweather.mapsgl.sources.VectorTileSource
import com.xweather.mapsgl.weather.LayerCode
import com.xweather.mapsgl.weather.WeatherLayerConfiguration
import com.xweather.mapsgl.weather.WeatherService
import kotlin.math.roundToInt

/**
 * Adds a mask layer of the specified type if not already present,
 * or increments its reference count if it is.
 * This function should be called from the main thread if it involves UI/map updates.
 */
// @MainActor equivalent: Ensure this is called from Dispatchers.Main

data class MaskLayer(
    val layer: TileLayer,         // Use 'val' if the layer reference itself doesn't change
    val code: LayerCode,  // Use 'val' if the code doesn't change post-creation
    var count: Int = 0                 // Use 'var' as it's mutable in Swift and likely modified
)

class MaskUtils {

    companion object {
        /**
         * Helper to get the 'background-color' from a BackgroundLayer or 'fill-color' from a FillLayer.
         */
        var _masks = HashMap<MaskLayerKind, MaskLayer>()
        var storedBeforeId: String? = null
        var lastVisibleState = false

        /**
         * Decrements the reference count for a mask layer, removing it from the map
         * if the count reaches zero.
         * This function should be called from the main thread if it involves UI/map updates.
         */
        fun removeMaskLayer(type: MaskLayerKind, controller: MapController) {
            val existingMaskData = _masks[type] ?: return // Guard

            if (existingMaskData.count > 1) {
                _masks[type] = existingMaskData.copy(count = existingMaskData.count - 1)
            } else {
                controller.removeLayer(id = existingMaskData.layer.id)
                _masks.remove(type) // Remove from the map
                //controller.setLayerVisible(existingMaskData.layer.id, false)
            }
        }

        fun getBackgroundColorFromLayer(style: Style, layerId: String): StyleValue<Color>?? {
            val backgroundLayer = style.getLayer(layerId) as BackgroundLayer

            if (backgroundLayer != null) {
                val expString = backgroundLayer.backgroundColorAsExpression.toString()
                val colorString = expString.substring(expString.indexOf("rgba,") + 5).replace("]", "")
                val valueList = parseFirstFourDoubles(colorString)
                return doublesToComposeColorStyleValue(valueList)
            }
            return null
        }

        fun getBackgroundColorRBGStringFromLayer(style: Style, layerId: String): String? {
            val backgroundLayer = style.getLayer(layerId) as BackgroundLayer
            val expString = backgroundLayer.backgroundColorAsExpression.toString()
            var colorString = expString.substring(expString.indexOf("rgba,") + 5).replace("]", "")
            val valueList = parseFirstFourDoubles(colorString)
            return rgbaDoublesToRgbHexString(valueList)

            return null
        }

        private fun parseFirstFourDoubles(dataString: String): List<Double> {
            return dataString
                .split(',') // Split by comma
                .take(4)      // Take the first 4 resulting substrings
                .map { it.trim().toDouble() } // Trim whitespace and convert to Double?
        }

        /**
         * Converts a list of 4 doubles (assumed to be R, G, B, A in the range 0.0-1.0)
         * to a StyleValue<ComposeColor>.
         *
         * @param rgbaDoubles A list of exactly 4 doubles: [red, green, blue, alpha].
         *                    Each value should ideally be between 0.0 and 1.0.
         * @return A StyleValue.Constant<ComposeColor> if conversion is successful, otherwise null.
         */
        private fun doublesToComposeColorStyleValue(rgbaDoubles: List<Double>): StyleValue<Color>? {
            if (rgbaDoubles.size != 4) {
                return null
            }
            val r = (rgbaDoubles[0] / 255.0).toFloat()
            val g = (rgbaDoubles[1] / 255.0).toFloat() ?: return null // Or handle error
            val b = (rgbaDoubles[2] / 255.0).toFloat() ?: return null // Or handle error
            val a = (rgbaDoubles[3]).toFloat() ?: return null // Or handle error

            try {
                val composeColor = Color(red = r, green = g, blue = b, alpha = a)
                return StyleValue.Constant(composeColor)
            } catch (e: IllegalArgumentException) {
                // This might happen if ComposeColor constructor has stricter validation
                // (though usually, it clamps values internally or expects them in range).
                println("Error creating ComposeColor from doubles: ${e.message}")
                return null
            }
        }

        /**
         * Converts a list of 4 doubles (R, G, B, A) to an RGB hex string (e.g., "#FF0000").
         * The Alpha component is ignored for the RGB hex string output.
         *
         * Assumes RGBA components are in the range 0.0 to 255.0.
         * If they are in the range 0.0 to 1.0, you'll need to scale them first.
         *
         * @param rgbaDoubles A list of 4 doubles: [Red, Green, Blue, Alpha].
         * @param componentsAre0to255 If true (default), assumes R,G,B doubles are 0-255.
         *                            If false, assumes R,G,B doubles are 0-1 and scales them.
         * @return An RGB hex string like "#RRGGBB", or null if the input list is invalid.
         */
        private fun rgbaDoublesToRgbHexString(
            rgbaDoubles: List<Double?>,
            componentsAre0to255: Boolean = true
        ): String? {
            if (rgbaDoubles.size != 4) {
                println("Error: List must contain exactly 4 double values for RGBA.")
                return null
            }

            val rDouble = rgbaDoubles[0]
            val gDouble = rgbaDoubles[1]
            val bDouble = rgbaDoubles[2]

            if (rDouble == null || gDouble == null || bDouble == null) {
                println("Error: R, G, or B component is null.")
                return null
            }

            try {
                val rInt: Int
                val gInt: Int
                val bInt: Int

                if (componentsAre0to255) {
                    rInt = rDouble.roundToInt().coerceIn(0, 255)
                    gInt = gDouble.roundToInt().coerceIn(0, 255)
                    bInt = bDouble.roundToInt().coerceIn(0, 255)
                } else {
                    // Scale from 0.0-1.0 to 0-255
                    rInt = (rDouble * 255.0).roundToInt().coerceIn(0, 255)
                    gInt = (gDouble * 255.0).roundToInt().coerceIn(0, 255)
                    bInt = (bDouble * 255.0).roundToInt().coerceIn(0, 255)
                }

                return String.format("#%02X%02X%02X", rInt, gInt, bInt)

            } catch (e: Exception) { // Catch potential errors during conversion (e.g., NumberFormatException if not really doubles)
                println("Error converting doubles to RGB hex string: ${e.message}")
                return null
            }
        }

        fun printAllMapboxLayers(mapboxMap: MapboxMap, message: String = "") {
            mapboxMap.getStyle { style ->
                val layers = style.styleLayers // This is a List<LayerInfo>
                if (layers.isEmpty()) {
                    return@getStyle
                }
                println("$message  ======================================================================================")
                println("MapboxLayers Current Mapbox Layers (${layers.size} total):")
                layers.forEachIndexed { index, layerInfo ->
                    val layerDetails = "  ${index + 1}. ID: '${layerInfo.id}', Type: '${layerInfo.type}'"
                    if (true || layerDetails.contains("mask") || layerDetails.contains("custom")) {
                        println("MapboxLayers: $layerDetails")
                    }

                }
                println("======================================================================================")
            }
        }

        fun changeFillLayerColor(mapboxMap: MapboxMap, layerId: String, newColorString: String) {
            mapboxMap.getStyle { style ->
                val fillLayer = style.getLayerAs<FillLayer>(layerId)
                if (fillLayer == null) {
                    return@getStyle
                } else {
                    fillLayer.fillColor(newColorString)
                }
            }
        }
    } // end companion object.

}

fun addMaskLayer(
    type: MaskLayerKind,
    service: WeatherService,
    mapController: MapController,
    map: MapboxMap,
    beforeId: String? = null
): TileLayer? {

    val layerCode: LayerCode = when (type) {
        MaskLayerKind.LAND -> LayerCode.LAND
        MaskLayerKind.WATER -> LayerCode.WATER
        else -> return null // Immediate exit if type is NONE or unsupported
    }

    var resultingLayer: TileLayer? = null

    val existingMaskData = MaskUtils._masks[type]

    println(">>> MaskUtils addMaskLayer() existingMaskData: ${existingMaskData != null}")

    if (existingMaskData != null) {

        resultingLayer = existingMaskData.layer
        MaskUtils._masks[type] = existingMaskData.copy(count = existingMaskData.count + 1)
        println(">>> MaskUtils addMaskLayer() layers before: ${map.styleLayers}")
        map.style?.moveStyleLayer(resultingLayer.id, LayerPosition(/*above*/beforeId, /*below*/null, /*at*/null))
        println(">>> MaskUtils addMaskLayer() calling: mapController.setLayerVisible(${existingMaskData.layer.id}")
        mapController.setLayerVisible(existingMaskData.layer.id, true)
        (existingMaskData.layer.source as? VectorTileSource)?.invalidate()

        //mapController.mapView.mapboxMap."mask::land"

        println(">>> MaskUtils addMaskLayer() layers after: ${map.styleLayers}")

    } else {
        try {
            val config =
                LayerCode.getConfigurationForLayerCode(layerCode, service) as WeatherLayerConfiguration<*, *>
            if (config.code != LayerCode.LAND && config.code != LayerCode.WATER) {
                return null // Exit withContext block returning null
            }

            val originalLayerDescriptor = config.layer
            if (originalLayerDescriptor is FillLayerDescriptor) {

                val defaultColor = StyleValue.Constant(Color.White)
                val foundColor: StyleValue<Color> = if (mapController is MapboxMapController) {
                    MaskUtils.getBackgroundColorFromLayer(map.style!!, "land") ?: defaultColor
                } else {
                    defaultColor
                }

                val mapboxLayerToMatch = when (type) {
                    MaskLayerKind.LAND -> "land"
                    MaskLayerKind.WATER -> "water"
                    else -> "background"
                }

                val mapboxStrokeColor: StyleValue<Color> = if (mapController is MapboxMapController) {
                    MaskUtils.getBackgroundColorFromLayer(map.style!!, mapboxLayerToMatch) ?: defaultColor
                } else {
                    defaultColor
                }

                val layerDescriptor = originalLayerDescriptor.copy(
                    id = "mask::${type.name.lowercase()}", // Use type.name for string representation
                    paint = originalLayerDescriptor.paint.copy(
                        fill = originalLayerDescriptor.paint.fill.copy(
                            color = foundColor,
                        ),
                        stroke = originalLayerDescriptor.paint.stroke?.copy(
                            color = mapboxStrokeColor,
                        ),

                        )
                )
                

                if (!mapController.hasSource(id = config.source.id)) {
                    mapController.addSource(config.source) // Assuming this returns the Source object or throws
                }
                val finalBeforeId = beforeId ?: beforeIdForMaskLayers()
                val maskMapLayer = mapController.addLayer(
                    layerDescriptor,
                    finalBeforeId
                )
                //trigger(MapControllerEvents.LAYER_ADDED, maskMapLayer.id)


                if (maskMapLayer != null) {
                    MaskUtils._masks[type] = MaskLayer(maskMapLayer, layerCode, 1)
                    resultingLayer = maskMapLayer
                    //MapControllerMaskUtils.updateMaskLayersForMap(serv) // Call to allow style updates etc.
                }
            }
        } catch (e: Exception) {
            println("Error adding mask layer $type: ${e.localizedMessage ?: e.toString()}")
        }
    }

    return resultingLayer // Return from withContext block
}

fun beforeIdForMaskLayers(): String? {
    return MaskUtils.storedBeforeId
}