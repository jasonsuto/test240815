package com.xweather.mapsgl.map.mapbox

import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.types.MapProvider
import kotlin.math.ceil
import kotlin.math.floor

/**
 * GeoJSON layers triangulate once into a z=0 world mesh (lon ∈ [-180, 180] → UV ∈ [0, 1]).
 * Mapbox can show several horizontal world copies near the antimeridian; MVT draws use
 * [TileCoord.offset], but GeoJSON historically drew only offset 0 — so Archive / tropical tracks
 * that cross the dateline vanished on the copies the camera was actually looking at.
 *
 * Offsets match [com.xweather.mapsgl.layers.tile.TileLayer.getVisibleTileCoords] at zoom 0
 * (`numTiles == 1` ⇒ `offset == xi`).
 */
internal object GeoJsonWorldCopies {

    fun visibleOffsets(map: MapProvider?): IntArray {
        if (map == null) return intArrayOf(0)
        val (westRaw, eastRaw) = map.getUnwrappedCameraLonBoundsForTiles()
        var east = eastRaw
        if (east < westRaw) east += 360.0
        val xMin = floor((westRaw + 180.0) / 360.0).toInt()
        val xMax = ceil((east + 180.0) / 360.0).toInt() - 1
        if (xMax < xMin) return intArrayOf(0)
        return IntArray(xMax - xMin + 1) { i -> xMin + i }
    }

    /** z=0 world tile for each visible copy (same mesh, different [TileCoord.offset]). */
    fun visibleWorldCoords(map: MapProvider?): List<TileCoord> =
        visibleOffsets(map).map { TileCoord(0, 0, 0, it) }
}
