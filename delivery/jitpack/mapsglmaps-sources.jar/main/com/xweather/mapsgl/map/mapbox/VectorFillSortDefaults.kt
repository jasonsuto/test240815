package com.xweather.mapsgl.map.mapbox

import com.mapbox.geojson.Feature
import com.xweather.mapsgl.style.FillLayerPaint
import com.xweather.mapsgl.style.SortDirection
import com.xweather.mapsgl.sources.nestedDictionary
import no.ecc.vectortile.VectorTileDecoder

/**
 * Fill draw-order defaults matching JS `FillStore.sortFeatures` / Apple `FillPaint.sortKey`.
 *
 * Prefer [com.xweather.mapsgl.style.FillPaint.sortKey] / [com.xweather.mapsgl.style.FillPaint.sortDirection]
 * when set on the layer paint. Otherwise hail and lightning threat polygons nest by lead time via
 * hardcoded layer-id defaults.
 */
internal object VectorFillSortDefaults {

    private const val PERIOD_MIN_TIMESTAMP = "period.range.minTimestamp"

    fun sortKeyDescending(layerId: String?): String? =
        when (layerId) {
            "severe.hail.threats.fill",
            "severe.lightning.threats.fill",
            -> PERIOD_MIN_TIMESTAMP
            else -> null
        }

    private fun propertyPath(paint: FillLayerPaint?, layerId: String?): String? {
        paint?.fill?.sortKey?.constantValue?.takeIf { it.isNotBlank() }?.let { return it }
        return sortKeyDescending(layerId)
    }

    private fun descending(paint: FillLayerPaint?, layerId: String?): Boolean {
        val fromPaint = paint?.fill?.sortKey?.constantValue
        if (fromPaint != null) {
            return paint.fill.sortDirection == SortDirection.DESCENDING
        }
        return sortKeyDescending(layerId) != null
    }

    /**
     * JS parity: drop features missing the sort property when a property-path key is active, then
     * sort ascending or descending per [com.xweather.mapsgl.style.FillPaint.sortDirection]
     * (layer-id defaults are descending).
     */
    fun sortedFeaturesForFill(
        layerId: String?,
        features: List<Feature>,
        paint: FillLayerPaint? = null,
    ): List<Feature> {
        val key = propertyPath(paint, layerId) ?: return features
        val desc = descending(paint, layerId)
        val paired = features.mapNotNull { f ->
            val v = readEpochSeconds(f, key) ?: return@mapNotNull null
            f to v
        }
        return (if (desc) paired.sortedByDescending { it.second } else paired.sortedBy { it.second })
            .map { it.first }
    }

    fun sortedRawFeaturesForFill(
        layerId: String?,
        rawFeatures: List<VectorTileDecoder.Feature>,
        paint: FillLayerPaint? = null,
    ): List<VectorTileDecoder.Feature> {
        val key = propertyPath(paint, layerId) ?: return rawFeatures
        val desc = descending(paint, layerId)
        val paired = rawFeatures.mapNotNull { rf ->
            @Suppress("UNCHECKED_CAST")
            val attrs = nestedDictionary(rf.attributes as Map<String, Any>)
            val v = readEpochSecondsFromAttrs(attrs, key) ?: return@mapNotNull null
            rf to v
        }
        return (if (desc) paired.sortedByDescending { it.second } else paired.sortedBy { it.second })
            .map { it.first }
    }

    private fun readEpochSeconds(feature: Feature, dottedKey: String): Double? {
        feature.getNumberProperty(dottedKey)?.let {
            return VectorMapTime.normalizeEpochSeconds(it.toDouble())
        }
        val el = feature.properties()?.let { root ->
            if (root.has(dottedKey)) root.get(dottedKey)
            else nestedElement(root, dottedKey.split('.'))
        } ?: return null
        if (!el.isJsonPrimitive) return null
        val p = el.asJsonPrimitive
        return when {
            p.isNumber -> VectorMapTime.normalizeEpochSeconds(p.asDouble)
            p.isString -> p.asString.toDoubleOrNull()?.let { VectorMapTime.normalizeEpochSeconds(it) }
            else -> null
        }
    }

    private fun nestedElement(
        root: com.google.gson.JsonObject,
        keys: List<String>,
    ): com.google.gson.JsonElement? {
        var cur: com.google.gson.JsonElement = root
        for (segment in keys) {
            if (!cur.isJsonObject) return null
            val obj = cur.asJsonObject
            if (!obj.has(segment)) return null
            cur = obj.get(segment)!!
        }
        return cur
    }

    private fun readEpochSecondsFromAttrs(attrs: Map<String, Any>, dottedKey: String): Double? {
        attrs[dottedKey]?.let { return coerceEpoch(it) }
        val parts = dottedKey.split('.')
        var cur: Any? = attrs
        for (part in parts) {
            cur = when (cur) {
                is Map<*, *> -> cur[part]
                else -> return null
            }
        }
        return coerceEpoch(cur)
    }

    private fun coerceEpoch(value: Any?): Double? = when (value) {
        is Number -> VectorMapTime.normalizeEpochSeconds(value.toDouble())
        is String -> value.toDoubleOrNull()?.let { VectorMapTime.normalizeEpochSeconds(it) }
        else -> null
    }
}
