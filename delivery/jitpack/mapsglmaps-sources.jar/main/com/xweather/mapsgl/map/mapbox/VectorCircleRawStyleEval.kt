package com.xweather.mapsgl.map.mapbox

import android.graphics.Color as AndroidColor
import androidx.compose.ui.graphics.Color as ComposeColor
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.StyleColor

/**
 * Deliberately narrow mirror of [VectorFillStyleExpressionEval], evaluated directly against a raw
 * (already dot-notation-nested, via [nestedDictionary]) attribute map instead of a
 * [com.mapbox.geojson.Feature]'s Gson `JsonObject`.
 *
 * Used by the circle-only fast path ([VectorPolygonFillTriangulator.triangulateCirclePointsRaw]) to
 * skip Feature/JsonObject/geometry-object construction entirely for point layers — that construction
 * measured as the dominant per-feature cost for point-heavy tiles (lightning: up to ~38k features).
 *
 * Only [get], [step], [match], [case], and basic boolean comparisons are supported. Any expression
 * outside that subset must fail [isSupportedColorExpression] / [isSupportedNumberExpression] /
 * [isSupportedBooleanExpression] so the caller falls back to the fully-general, proven-correct
 * Feature-based path ([VectorFillStyleExpressionEval] + [MapboxVectorFeature]) — this file trades
 * generality for speed and is never the only path an expression can take.
 */
internal object VectorCircleRawStyleEval {

    // "concat": alerts (and similarly-configured layers) express fill color as
    // ["concat", "#", ["get", "COLOR"]] to prepend the "#" MVT's raw hex string omits — matches the
    // heavy path's VectorFillStyleExpressionEval/VectorFeatureStyleResolver support for the same op.
    // Arithmetic ops (rule: raw-vector-fast-path, Symbol port) let icon.image expressions like
    // ["concat", "prefix-", ["to-string", ["max", 1, ["min", 5, ["floor", ...]]]]] (fires-obs-icons'
    // containment-percentage-to-sprite-index formula) evaluate off raw attrs instead of falling back
    // to the heavy Feature path — additive only, existing color/number callers are unaffected.
    private val ARITHMETIC_OPS =
        setOf("+", "-", "*", "/", "%", "floor", "ceil", "min", "max", "to-number", "coalesce")
    private val SUPPORTED_COLOR_OPS = setOf("get", "step", "match", "case", "concat")
    private val SUPPORTED_NUMBER_OPS = setOf("get", "step", "match", "case") + ARITHMETIC_OPS
    private val SUPPORTED_STRING_OPS =
        setOf("get", "step", "match", "case", "concat", "to-string") + ARITHMETIC_OPS
    private val SUPPORTED_BOOL_OPS =
        setOf("all", "any", "!", "==", "!=", "<", "<=", ">", ">=", "has", "get")

    fun isSupportedColorExpression(expr: Expression?): Boolean =
        expr == null || isSupportedTree(expr.raw, SUPPORTED_COLOR_OPS)

    fun isSupportedNumberExpression(expr: Expression?): Boolean =
        expr == null || isSupportedTree(expr.raw, SUPPORTED_NUMBER_OPS)

    fun isSupportedStringExpression(expr: Expression?): Boolean =
        expr == null || isSupportedTree(expr.raw, SUPPORTED_STRING_OPS)

    fun isSupportedBooleanExpression(expr: Expression?): Boolean =
        expr == null || isSupportedTree(expr.raw, SUPPORTED_BOOL_OPS)

    private fun isSupportedTree(node: Any?, allowedOps: Set<String>): Boolean {
        if (node is Expression) return isSupportedTree(node.raw, allowedOps)
        if (node !is List<*>) return true // literal (string/number/bool/null) — always fine
        if (node.isEmpty()) return false
        val op = node[0] as? String ?: return false
        if (op !in allowedOps) return false
        // node[1] for "get" is a plain key string, not a sub-expression; harmless to re-walk since
        // isSupportedTree treats non-List values as literals regardless.
        for (i in 1 until node.size) {
            if (!isSupportedTree(node[i], allowedOps)) return false
        }
        return true
    }

    fun evaluateFillRgba(expr: Expression, attrs: Map<String, Any?>): FloatArray? =
        evaluateColor(expr.raw, attrs)

    fun evaluateNumber(expr: Expression, attrs: Map<String, Any?>): Double? =
        evaluateNumber(expr.raw, attrs)

    fun evaluateBoolean(expr: Expression, attrs: Map<String, Any?>): Boolean? =
        evaluateBoolean(expr.raw, attrs)

    fun evaluateString(expr: Expression, attrs: Map<String, Any?>): String? =
        evaluateString(expr.raw, attrs)

    private fun evaluateColor(raw: Any?, attrs: Map<String, Any?>): FloatArray? {
        val list = raw as? List<*> ?: return null
        if (list.isEmpty()) return null
        return when (list[0] as? String) {
            "step" -> evaluateStepColor(list, attrs)
            "match" -> evaluateMatchColor(list, attrs)
            "case" -> evaluateCaseColor(list, attrs)
            "concat" -> evaluateConcatColor(list, attrs)
            else -> null
        }
    }

    /** ["concat", part1, part2, ...] built into one string, then parsed the same as a literal color token. */
    private fun evaluateConcatColor(list: List<*>, attrs: Map<String, Any?>): FloatArray? {
        val sb = StringBuilder()
        for (i in 1 until list.size) {
            sb.append(evaluateString(list[i], attrs) ?: return null)
        }
        return colorTokenToRgba(sb.toString())
    }

    private fun evaluateStepColor(list: List<*>, attrs: Map<String, Any?>): FloatArray? {
        if (list.size < 4) return null
        val input = evaluateNumber(list[1], attrs) ?: return null
        var result = colorTokenToRgba(list[2]) ?: return null
        var i = 3
        while (i + 1 < list.size) {
            val thr = (list[i] as? Number)?.toDouble() ?: return null
            if (input >= thr) result = colorTokenToRgba(list[i + 1]) ?: result
            i += 2
        }
        return result
    }

    private fun evaluateMatchColor(list: List<*>, attrs: Map<String, Any?>): FloatArray? {
        if (list.size < 5) return null
        val input = evaluateString(list[1], attrs) ?: evaluateNumber(list[1], attrs)?.toString()
        if (input == null) return colorTokenToRgba(list.last())
        var i = 2
        while (i + 1 < list.size - 1) {
            if (list[i]?.toString() == input) return colorTokenToRgba(list[i + 1])
            i += 2
        }
        return colorTokenToRgba(list.last())
    }

    private fun evaluateCaseColor(list: List<*>, attrs: Map<String, Any?>): FloatArray? {
        val token = evaluateCaseRaw(list, attrs) ?: return null
        return colorTokenToRgba(token) ?: evaluateColor(token, attrs)
    }

    private fun evaluateCaseRaw(list: List<*>, attrs: Map<String, Any?>): Any? {
        // ["case", cond1, out1, cond2, out2, ..., fallback]
        if (list.size < 4) return null
        var i = 1
        while (i + 1 < list.size - 1) {
            if (evaluateBoolean(list[i], attrs) == true) return list[i + 1]
            i += 2
        }
        return list.last()
    }

    private fun evaluateBoolean(raw: Any?, attrs: Map<String, Any?>): Boolean? {
        when (raw) {
            is Boolean -> return raw
            is Expression -> return evaluateBoolean(raw.raw, attrs)
            is List<*> -> {
                if (raw.isEmpty()) return null
                return when (raw[0] as? String) {
                    "all" -> {
                        for (i in 1 until raw.size) if (evaluateBoolean(raw[i], attrs) != true) return false
                        true
                    }
                    "any" -> {
                        for (i in 1 until raw.size) if (evaluateBoolean(raw[i], attrs) == true) return true
                        false
                    }
                    "!" -> if (raw.size < 2) null else evaluateBoolean(raw[1], attrs)?.let { !it }
                    "==" -> evaluateEquality(raw, attrs)
                    "!=" -> evaluateEquality(raw, attrs)?.let { !it }
                    "<" -> evaluateComparison(raw, attrs) { a, b -> a < b }
                    "<=" -> evaluateComparison(raw, attrs) { a, b -> a <= b }
                    ">" -> evaluateComparison(raw, attrs) { a, b -> a > b }
                    ">=" -> evaluateComparison(raw, attrs) { a, b -> a >= b }
                    "has" -> (raw.getOrNull(1) as? String)?.let { attrs.containsKey(it) }
                    "get" -> (evaluateGet(raw, attrs) as? Boolean)
                    else -> null
                }
            }
            else -> return null
        }
    }

    private fun evaluateEquality(list: List<*>, attrs: Map<String, Any?>): Boolean? {
        if (list.size < 3) return null
        val lhsNum = evaluateNumber(list[1], attrs)
        val rhsNum = evaluateNumber(list[2], attrs)
        if (lhsNum != null && rhsNum != null) return lhsNum == rhsNum
        val lhsStr = evaluateString(list[1], attrs)
        val rhsStr = when (val rhs = list[2]) {
            is String -> rhs
            is Number -> rhs.toString()
            else -> evaluateString(rhs, attrs)
        }
        if (lhsStr != null && rhsStr != null) return lhsStr == rhsStr
        return null
    }

    private fun evaluateComparison(
        list: List<*>,
        attrs: Map<String, Any?>,
        cmp: (Double, Double) -> Boolean,
    ): Boolean? {
        if (list.size < 3) return null
        val a = evaluateNumber(list[1], attrs) ?: return null
        val b = evaluateNumber(list[2], attrs) ?: return null
        return cmp(a, b)
    }

    private fun evaluateMatchNumber(list: List<*>, attrs: Map<String, Any?>): Double? {
        if (list.size < 5) return null
        val input = evaluateString(list[1], attrs) ?: evaluateNumber(list[1], attrs)?.toString()
        val fallback = evaluateNumber(list.last(), attrs) ?: (list.last() as? Number)?.toDouble()
        if (input == null) return fallback
        var i = 2
        while (i + 1 < list.size - 1) {
            if (list[i]?.toString() == input) {
                return evaluateNumber(list[i + 1], attrs) ?: (list[i + 1] as? Number)?.toDouble()
            }
            i += 2
        }
        return fallback
    }

    private fun evaluateStepNumber(list: List<*>, attrs: Map<String, Any?>): Double? {
        if (list.size < 4) return null
        val input = evaluateNumber(list[1], attrs) ?: return null
        var result = evaluateNumber(list[2], attrs) ?: (list[2] as? Number)?.toDouble() ?: return null
        var i = 3
        while (i + 1 < list.size) {
            val thr = (list[i] as? Number)?.toDouble() ?: return null
            if (input >= thr) {
                result = evaluateNumber(list[i + 1], attrs) ?: (list[i + 1] as? Number)?.toDouble() ?: result
            }
            i += 2
        }
        return result
    }

    private fun evaluateNumber(raw: Any?, attrs: Map<String, Any?>): Double? {
        when (raw) {
            is Number -> return raw.toDouble()
            is Expression -> return evaluateNumber(raw.raw, attrs)
            is List<*> -> {
                if (raw.isEmpty()) return null
                return when (raw[0] as? String) {
                    "get" -> when (val v = evaluateGet(raw, attrs)) {
                        is Number -> v.toDouble()
                        is String -> v.toDoubleOrNull()
                        else -> null
                    }
                    "step" -> evaluateStepNumber(raw, attrs)
                    "match" -> evaluateMatchNumber(raw, attrs)
                    "case" -> evaluateCaseRaw(raw, attrs)?.let { token ->
                        (token as? Number)?.toDouble() ?: evaluateNumber(token, attrs)
                    }
                    "+" -> binaryOp(raw, attrs) { a, b -> a + b }
                    "-" -> binaryOp(raw, attrs) { a, b -> a - b }
                    "*" -> binaryOp(raw, attrs) { a, b -> a * b }
                    "/" -> binaryOp(raw, attrs) { a, b -> a / b }
                    "%" -> binaryOp(raw, attrs) { a, b -> a % b }
                    "floor" -> (raw.getOrNull(1)?.let { evaluateNumber(it, attrs) })?.let { kotlin.math.floor(it) }
                    "ceil" -> (raw.getOrNull(1)?.let { evaluateNumber(it, attrs) })?.let { kotlin.math.ceil(it) }
                    "min" -> (1 until raw.size).mapNotNull { evaluateNumber(raw[it], attrs) }
                        .minOrNull()
                    "max" -> (1 until raw.size).mapNotNull { evaluateNumber(raw[it], attrs) }
                        .maxOrNull()
                    "to-number" -> raw.getOrNull(1)?.let { evaluateNumber(it, attrs) ?: evaluateString(it, attrs)?.toDoubleOrNull() }
                    "coalesce" -> (1 until raw.size).firstNotNullOfOrNull { evaluateNumber(raw[it], attrs) }
                    else -> null
                }
            }
            else -> return null
        }
    }

    private fun binaryOp(list: List<*>, attrs: Map<String, Any?>, op: (Double, Double) -> Double): Double? {
        if (list.size < 3) return null
        val a = evaluateNumber(list[1], attrs) ?: return null
        val b = evaluateNumber(list[2], attrs) ?: return null
        return op(a, b)
    }

    /** Mirrors JS `Number.prototype.toString()`: whole numbers print without a trailing `.0`. */
    private fun formatNumberForToString(d: Double): String =
        if (d == kotlin.math.floor(d) && !d.isInfinite()) d.toLong().toString() else d.toString()

    private fun evaluateString(raw: Any?, attrs: Map<String, Any?>): String? {
        when (raw) {
            is String -> return raw
            is Expression -> return evaluateString(raw.raw, attrs)
            is List<*> -> {
                if (raw.isEmpty()) return null
                return when (raw[0] as? String) {
                    "get" -> when (val v = evaluateGet(raw, attrs)) {
                        is String -> v
                        is Number -> v.toString()
                        is Boolean -> v.toString()
                        else -> null
                    }
                    "match" -> evaluateMatchString(raw, attrs)
                    "case" -> evaluateCaseRaw(raw, attrs)?.let { it as? String ?: evaluateString(it, attrs) }
                    "concat" -> {
                        val sb = StringBuilder()
                        for (i in 1 until raw.size) sb.append(evaluateString(raw[i], attrs) ?: return null)
                        sb.toString()
                    }
                    "to-string" -> raw.getOrNull(1)?.let { part ->
                        (part as? String)
                            ?: evaluateString(part, attrs)
                            ?: evaluateNumber(part, attrs)?.let(::formatNumberForToString)
                    }
                    "upcase" -> raw.getOrNull(1)?.let { evaluateString(it, attrs)?.uppercase() }
                    "downcase" -> raw.getOrNull(1)?.let { evaluateString(it, attrs)?.lowercase() }
                    else -> null
                }
            }
            else -> return null
        }
    }

    private fun evaluateMatchString(list: List<*>, attrs: Map<String, Any?>): String? {
        if (list.size < 5) return null
        val input = evaluateString(list[1], attrs) ?: evaluateNumber(list[1], attrs)?.toString()
        if (input == null) return list.last()?.toString()
        var i = 2
        while (i + 1 < list.size - 1) {
            when (val matchKey = list[i]) {
                is List<*> -> if (matchKey.any { it?.toString() == input }) return list[i + 1]?.toString()
                else -> if (matchKey?.toString() == input) return list[i + 1]?.toString()
            }
            i += 2
        }
        return list.last()?.toString()
    }

    /** Direct lookup into the nested attribute map, supporting `["get", "a.b"]` dot-paths. */
    private fun evaluateGet(list: List<*>, attrs: Map<String, Any?>): Any? {
        val key = list.getOrNull(1) as? String ?: return null
        if (attrs.containsKey(key)) return attrs[key]
        if (!key.contains('.')) return null
        var cur: Any? = attrs
        for (segment in key.split('.')) {
            val map = cur as? Map<*, *> ?: return null
            if (!map.containsKey(segment)) return null
            cur = map[segment]
        }
        return cur
    }

    /** Verbatim copy of the color-token parsing in [VectorFillStyleExpressionEval] (no Feature dependency there either). */
    private fun colorTokenToRgba(token: Any?): FloatArray? {
        when (token) {
            is String -> {
                val s = token.trim()
                if (s.startsWith("#")) {
                    return try {
                        val argb = AndroidColor.parseColor(s)
                        floatArrayOf(
                            AndroidColor.red(argb) / 255f,
                            AndroidColor.green(argb) / 255f,
                            AndroidColor.blue(argb) / 255f,
                            AndroidColor.alpha(argb) / 255f,
                        )
                    } catch (_: Exception) {
                        null
                    }
                }
                if (s.startsWith("rgba(", ignoreCase = true) && s.endsWith(")")) {
                    val inner = s.substring(5, s.length - 1).split(',')
                    if (inner.size >= 4) {
                        val r = inner[0].trim().toIntOrNull() ?: return null
                        val g = inner[1].trim().toIntOrNull() ?: return null
                        val b = inner[2].trim().toIntOrNull() ?: return null
                        val a = inner[3].trim().toFloatOrNull() ?: return null
                        return floatArrayOf(r / 255f, g / 255f, b / 255f, a.coerceIn(0f, 1f))
                    }
                }
            }
            is StyleColor -> {
                when (token) {
                    is StyleColor.Color -> {
                        val c = token.color
                        return floatArrayOf(c.red, c.green, c.blue, c.alpha)
                    }
                    is StyleColor.Hex -> return colorTokenToRgba(token.hexString)
                    is StyleColor.RGBA -> return colorTokenToRgba(token.rgbaString)
                }
            }
            is ComposeColor -> {
                return floatArrayOf(token.red, token.green, token.blue, token.alpha)
            }
        }
        return null
    }
}
