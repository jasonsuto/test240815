package com.xweather.mapsgl.map.mapbox

import android.graphics.Color as AndroidColor
import androidx.compose.ui.graphics.Color as ComposeColor
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.mapbox.geojson.Feature
import com.xweather.mapsgl.style.ColorStop
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.StyleColor
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.round

/**
 * Evaluates a small subset of Mapbox style [Expression]s used for vector **fill-color** when drawing
 * via [com.xweather.mapsgl.renderers.VectorFillLayerRenderer] (e.g. hail threat `step` by lead time).
 */
internal object VectorFillStyleExpressionEval {

    fun evaluateFillRgba(expr: Expression, feature: Feature, zoom: Double? = null): FloatArray? =
        evaluateFillRgba(expr.raw, feature, zoom)

    fun evaluateNumber(expr: Expression, feature: Feature, zoom: Double? = null): Double? =
        evaluateNumber(expr.raw, feature, zoom)

    fun evaluateString(expr: Expression, feature: Feature): String? =
        evaluateString(expr.raw, feature)

    fun evaluateString(expr: Expression, feature: Feature, zoom: Double): String? =
        evaluateString(expr.raw, feature, zoom)

    fun evaluateMatchString(expr: Expression, feature: Feature): String? =
        evaluateMatchString(expr.raw, feature)

    private fun evaluateFillRgba(raw: Any?, feature: Feature, zoom: Double? = null): FloatArray? {
        when (raw) {
            is Expression -> return evaluateFillRgba(raw.raw, feature, zoom)
            is String -> return colorTokenToRgba(raw)
            is List<*> -> {
                if (raw.isEmpty()) return null
                return when (raw[0] as? String) {
                    "step" -> evaluateStep(raw, feature)
                    "match" -> evaluateMatch(raw, feature)
                    "case" -> evaluateCaseColor(raw, feature)
                    "concat" -> evaluateString(raw, feature)?.let { colorTokenToRgba(it) }
                    "rgb", "rgba" -> evaluateRgb(raw, feature)
                    "interpolate" -> evaluateInterpolateColor(raw, feature, zoom)
                    "let" -> evaluateLetBody(raw, feature, zoom) { evaluateFillRgba(it, feature, zoom) }
                    "var" -> {
                        val v = lookupVar(raw) ?: return null
                        colorTokenToRgba(v) ?: evaluateFillRgba(v, feature, zoom)
                    }
                    else -> null
                }
            }
            else -> return colorTokenToRgba(raw)
        }
    }

    private fun evaluateRgb(raw: List<*>, feature: Feature): FloatArray? {
        val op = raw[0] as? String ?: return null
        val r = evaluateNumber(raw.getOrNull(1), feature) ?: return null
        val g = evaluateNumber(raw.getOrNull(2), feature) ?: return null
        val b = evaluateNumber(raw.getOrNull(3), feature) ?: return null
        val a =
            if (op == "rgba") {
                (evaluateNumber(raw.getOrNull(4), feature) ?: 1.0).coerceIn(0.0, 1.0)
            } else {
                1.0
            }
        return floatArrayOf(
            (r / 255.0).toFloat().coerceIn(0f, 1f),
            (g / 255.0).toFloat().coerceIn(0f, 1f),
            (b / 255.0).toFloat().coerceIn(0f, 1f),
            a.toFloat(),
        )
    }

    private fun evaluateCaseColor(list: List<*>, feature: Feature): FloatArray? {
        val result = evaluateCaseRaw(list, feature) ?: return null
        return colorTokenToRgba(result) ?: evaluateFillRgba(result, feature)
    }

    private fun evaluateCaseRaw(list: List<*>, feature: Feature): Any? {
        // ["case", cond1, out1, cond2, out2, ..., fallback]
        if (list.size < 4) return null
        var i = 1
        while (i + 1 < list.size - 1) {
            if (evaluateBoolean(raw = list[i], feature) == true) {
                return list[i + 1]
            }
            i += 2
        }
        return list.last()
    }

    private fun evaluateBoolean(raw: Any?, feature: Feature): Boolean? {
        when (raw) {
            is Boolean -> return raw
            is Expression -> return evaluateBoolean(raw.raw, feature)
            is List<*> -> {
                if (raw.isEmpty()) return null
                return when (raw[0] as? String) {
                    "all" -> {
                        for (i in 1 until raw.size) {
                            if (evaluateBoolean(raw[i], feature) != true) return false
                        }
                        true
                    }
                    "any" -> {
                        for (i in 1 until raw.size) {
                            if (evaluateBoolean(raw[i], feature) == true) return true
                        }
                        false
                    }
                    "!" -> {
                        if (raw.size < 2) null else evaluateBoolean(raw[1], feature)?.let { !it }
                    }
                    "==" -> evaluateEquality(raw, feature)
                    "!=" -> evaluateEquality(raw, feature)?.let { !it }
                    "<" -> evaluateComparison(raw, feature) { a, b -> a < b }
                    "<=" -> evaluateComparison(raw, feature) { a, b -> a <= b }
                    ">" -> evaluateComparison(raw, feature) { a, b -> a > b }
                    ">=" -> evaluateComparison(raw, feature) { a, b -> a >= b }
                    "has" -> evaluateHas(raw, feature)
                    "let" -> evaluateLetBody(raw, feature, zoom = null) { evaluateBoolean(it, feature) }
                    "var" -> {
                        when (val v = lookupVar(raw)) {
                            is Boolean -> v
                            else -> evaluateBoolean(v, feature)
                        }
                    }
                    else -> null
                }
            }
        }
        return null
    }

    private fun evaluateEquality(list: List<*>, feature: Feature): Boolean? {
        if (list.size < 3) return null
        val lhsNum = evaluateNumber(list[1], feature)
        val rhsNum = evaluateNumber(list[2], feature)
        if (lhsNum != null && rhsNum != null) return lhsNum == rhsNum
        val lhsStr = evaluateString(list[1], feature)
        val rhsStr = when (val rhs = list[2]) {
            is String -> rhs
            is Number -> rhs.toString()
            else -> evaluateString(rhs, feature)
        }
        if (lhsStr != null && rhsStr != null) return lhsStr == rhsStr
        return null
    }

    private fun evaluateComparison(
        list: List<*>,
        feature: Feature,
        cmp: (Double, Double) -> Boolean,
    ): Boolean? {
        if (list.size < 3) return null
        val a = evaluateNumber(list[1], feature) ?: return null
        val b = evaluateNumber(list[2], feature) ?: return null
        return cmp(a, b)
    }

    private fun evaluateHas(list: List<*>, feature: Feature): Boolean? {
        if (list.size < 2) return null
        val key = list[1] as? String ?: return null
        if (list.size == 2) {
            val root = feature.properties() ?: return false
            return root.has(key)
        }
        val parent = evaluateSubexpressionToJson(list[2], feature) ?: return false
        if (!parent.isJsonObject) return false
        return parent.asJsonObject.has(key)
    }

    private fun evaluateMatch(list: List<*>, feature: Feature): FloatArray? {
        // ["match", input, match1, out1, match2, out2, ..., fallback]
        if (list.size < 5) return null
        val input = evaluateString(list[1], feature) ?: evaluateNumber(list[1], feature)?.toString()
        if (input == null) return colorTokenToRgba(list.last())
        var i = 2
        while (i + 1 < list.size - 1) {
            val matchValue = list[i]?.toString()
            if (matchValue != null && input == matchValue) {
                return colorTokenToRgba(list[i + 1])
            }
            i += 2
        }
        return colorTokenToRgba(list.last())
    }

    private fun evaluateMatchNumber(list: List<*>, feature: Feature): Double? {
        if (list.size < 5) return null
        val input = evaluateString(list[1], feature) ?: evaluateNumber(list[1], feature)?.toString()
        val fallback = evaluateNumber(list.last(), feature) ?: (list.last() as? Number)?.toDouble()
        if (input == null) return fallback
        var i = 2
        while (i + 1 < list.size - 1) {
            val matchValue = list[i]?.toString()
            if (matchValue != null && input == matchValue) {
                return evaluateNumber(list[i + 1], feature) ?: (list[i + 1] as? Number)?.toDouble()
            }
            i += 2
        }
        return fallback
    }

    private fun evaluateStep(list: List<*>, feature: Feature): FloatArray? {
        if (list.size < 4) return null
        val input = evaluateNumber(list[1], feature) ?: return null
        var result = colorTokenToRgba(list[2]) ?: return null
        var i = 3
        while (i + 1 < list.size) {
            val thr = (list[i] as? Number)?.toDouble() ?: return null
            val out = list[i + 1]
            if (input >= thr) {
                result = colorTokenToRgba(out) ?: result
            }
            i += 2
        }
        return result
    }

    private fun evaluateStepNumber(list: List<*>, feature: Feature, zoom: Double?): Double? {
        if (list.size < 4) return null
        val input = resolveStepInput(list[1], feature, zoom) ?: return null
        var result = evaluateNumber(list[2], feature, zoom) ?: (list[2] as? Number)?.toDouble() ?: return null
        var i = 3
        while (i + 1 < list.size) {
            val thr = (list[i] as? Number)?.toDouble() ?: return null
            val out = list[i + 1]
            if (input >= thr) {
                result = evaluateNumber(out, feature, zoom) ?: (out as? Number)?.toDouble() ?: result
            }
            i += 2
        }
        return result
    }

    private fun resolveStepInput(raw: Any?, feature: Feature, zoom: Double?): Double? {
        if (raw is List<*> && raw.isNotEmpty() && raw[0] == "zoom") {
            return zoom
        }
        return evaluateNumber(raw, feature, zoom)
    }

    /**
     * Mapbox `["interpolate", interpolation, input, stop0, out0, stop1, out1, ...]`.
     * Linear, exponential, and cubic-bezier.
     */
    private data class InterpolateLerp(val a: Any?, val b: Any?, val t: Double)

    private fun resolveInterpolateLerp(
        list: List<*>,
        feature: Feature,
        zoom: Double?,
    ): InterpolateLerp? {
        if (list.size < 5) return null
        val interpolation = list[1]
        val input = resolveStepInput(list[2], feature, zoom) ?: return null
        val stops = collectInterpolateStops(list, feature, zoom) ?: return null
        if (stops.size < 2) return null
        if (input <= stops.first().first) {
            val out = stops.first().second
            return InterpolateLerp(out, out, 0.0)
        }
        if (input >= stops.last().first) {
            val out = stops.last().second
            return InterpolateLerp(out, out, 0.0)
        }
        for (i in 0 until stops.size - 1) {
            val lo = stops[i]
            val hi = stops[i + 1]
            if (input >= lo.first && input <= hi.first) {
                val t = interpolationFactor(interpolation, input, lo.first, hi.first) ?: return null
                return InterpolateLerp(lo.second, hi.second, t)
            }
        }
        val out = stops.last().second
        return InterpolateLerp(out, out, 0.0)
    }

    private fun collectInterpolateStops(
        list: List<*>,
        feature: Feature,
        zoom: Double?,
    ): List<Pair<Double, Any?>>? {
        val stops = ArrayList<Pair<Double, Any?>>(8)
        var i = 3
        while (i < list.size) {
            when (val item = list[i]) {
                is Pair<*, *> -> {
                    val key = evaluateNumber(item.first, feature, zoom) ?: return null
                    stops.add(key to item.second)
                    i++
                }
                is ColorStop -> {
                    stops.add(item.value to item.color)
                    i++
                }
                else -> {
                    if (i + 1 >= list.size) return null
                    val key = evaluateNumber(list[i], feature, zoom) ?: return null
                    stops.add(key to list[i + 1])
                    i += 2
                }
            }
        }
        return stops
    }

    /** Mapbox GL JS interpolation; cubic-bezier uses a unit bezier on the linear progress. */
    private fun interpolationFactor(
        interpolation: Any?,
        input: Double,
        lower: Double,
        upper: Double,
    ): Double? {
        val raw = if (interpolation is Expression) interpolation.raw else interpolation
        return when (raw) {
            is String -> if (raw == "linear") linearInterpolationFactor(input, lower, upper) else null
            is List<*> -> when (raw.getOrNull(0) as? String) {
                "linear" -> linearInterpolationFactor(input, lower, upper)
                "exponential" -> {
                    val base = (raw.getOrNull(1) as? Number)?.toDouble() ?: return null
                    exponentialInterpolationFactor(input, base, lower, upper)
                }
                "cubic-bezier" -> {
                    val x1 = (raw.getOrNull(1) as? Number)?.toDouble() ?: return null
                    val y1 = (raw.getOrNull(2) as? Number)?.toDouble() ?: return null
                    val x2 = (raw.getOrNull(3) as? Number)?.toDouble() ?: return null
                    val y2 = (raw.getOrNull(4) as? Number)?.toDouble() ?: return null
                    val t = linearInterpolationFactor(input, lower, upper).coerceIn(0.0, 1.0)
                    UnitBezier(x1, y1, x2, y2).solve(t)
                }
                else -> null
            }
            else -> null
        }
    }

    private fun linearInterpolationFactor(input: Double, lower: Double, upper: Double): Double {
        val difference = upper - lower
        if (difference == 0.0) return 0.0
        return (input - lower) / difference
    }

    private fun exponentialInterpolationFactor(
        input: Double,
        base: Double,
        lower: Double,
        upper: Double,
    ): Double {
        val difference = upper - lower
        val progress = input - lower
        if (difference == 0.0) return 0.0
        if (base == 1.0) return progress / difference
        return (base.pow(progress) - 1.0) / (base.pow(difference) - 1.0)
    }

    private fun evaluateInterpolateNumber(list: List<*>, feature: Feature, zoom: Double?): Double? {
        val lerp = resolveInterpolateLerp(list, feature, zoom) ?: return null
        val a = evaluateNumber(lerp.a, feature, zoom) ?: (lerp.a as? Number)?.toDouble() ?: return null
        val b = evaluateNumber(lerp.b, feature, zoom) ?: (lerp.b as? Number)?.toDouble() ?: return null
        return a + (b - a) * lerp.t
    }

    private fun evaluateInterpolateColor(list: List<*>, feature: Feature, zoom: Double?): FloatArray? {
        val lerp = resolveInterpolateLerp(list, feature, zoom) ?: return null
        val a = colorTokenToRgba(lerp.a) ?: evaluateFillRgba(lerp.a, feature, zoom) ?: return null
        val b = colorTokenToRgba(lerp.b) ?: evaluateFillRgba(lerp.b, feature, zoom) ?: return null
        val t = lerp.t.toFloat()
        return floatArrayOf(
            a[0] + (b[0] - a[0]) * t,
            a[1] + (b[1] - a[1]) * t,
            a[2] + (b[2] - a[2]) * t,
            a[3] + (b[3] - a[3]) * t,
        )
    }

    private fun evaluateMatchString(raw: Any?, feature: Feature, zoom: Double? = null): String? {
        val list = raw as? List<*> ?: return null
        if (list.isEmpty() || list[0] != "match") return null
        if (list.size < 5) return null
        val input = evaluateString(list[1], feature, zoom) ?: evaluateNumber(list[1], feature)?.toString()
        if (input == null) return tokenToString(list.last(), feature, zoom)
        var i = 2
        while (i + 1 < list.size - 1) {
            when (val matchKey = list[i]) {
                is List<*> -> {
                    if (matchKey.any { it?.toString() == input }) {
                        return tokenToString(list[i + 1], feature, zoom)
                    }
                }
                else -> {
                    if (matchKey?.toString() == input) {
                        return tokenToString(list[i + 1], feature, zoom)
                    }
                }
            }
            i += 2
        }
        return tokenToString(list.last(), feature, zoom)
    }

    private fun tokenToString(token: Any?, feature: Feature, zoom: Double? = null): String? {
        return when (token) {
            is String -> token
            is Expression -> evaluateString(token.raw, feature, zoom)
            is List<*> -> evaluateString(token, feature, zoom)
            else -> token?.toString()
        }
    }

    private fun evaluateNumber(raw: Any?, feature: Feature, zoom: Double? = null): Double? {
        when (raw) {
            is Number -> return raw.toDouble()
            is Expression -> return evaluateNumber(raw.raw, feature, zoom)
            is JsonElement -> return jsonElementToDouble(raw)
            is List<*> -> {
                if (raw.isEmpty()) return null
                return when (raw[0] as? String) {
                    "step" -> evaluateStepNumber(raw, feature, zoom)
                    "get" -> jsonElementToDouble(evaluateGet(raw, feature))
                    "literal" -> evaluateNumber(raw.getOrNull(1), feature, zoom)
                    "to-number" -> {
                        if (raw.size < 2) null
                        else evaluateNumber(raw[1], feature)
                            ?: evaluateString(raw[1], feature)?.toDoubleOrNull()
                    }
                    "case" -> evaluateCaseRaw(raw, feature)?.let { token ->
                        (token as? Number)?.toDouble()
                            ?: evaluateNumber(token, feature)
                            ?: evaluateString(token, feature)?.toDoubleOrNull()
                    }
                    "+" -> {
                        if (raw.size >= 3) {
                            val a = evaluateNumber(raw[1], feature)
                            val b = evaluateNumber(raw[2], feature)
                            if (a != null && b != null) return a + b
                        }
                        null
                    }
                    "-" -> {
                        if (raw.size >= 3) {
                            val a = evaluateNumber(raw[1], feature)
                            val b = evaluateNumber(raw[2], feature)
                            if (a != null && b != null) return a - b
                        }
                        null
                    }
                    "*" -> {
                        if (raw.size >= 3) {
                            val a = evaluateNumber(raw[1], feature)
                            val b = evaluateNumber(raw[2], feature)
                            if (a != null && b != null) return a * b
                        }
                        null
                    }
                    "/" -> {
                        if (raw.size >= 3) {
                            val a = evaluateNumber(raw[1], feature)
                            val b = evaluateNumber(raw[2], feature)
                            if (a != null && b != null && b != 0.0) return a / b
                        }
                        null
                    }
                    "min" -> {
                        var result: Double? = null
                        for (i in 1 until raw.size) {
                            val v = evaluateNumber(raw[i], feature) ?: continue
                            result = if (result == null) v else min(result, v)
                        }
                        result
                    }
                    "max" -> {
                        var result: Double? = null
                        for (i in 1 until raw.size) {
                            val v = evaluateNumber(raw[i], feature) ?: continue
                            result = if (result == null) v else kotlin.math.max(result, v)
                        }
                        result
                    }
                    "coalesce" -> {
                        for (i in 1 until raw.size) {
                            evaluateNumber(raw[i], feature)?.let { return it }
                        }
                        null
                    }
                    "round" -> {
                        if (raw.size >= 2) {
                            val v = evaluateNumber(raw[1], feature)
                            if (v != null) return round(v)
                        }
                        null
                    }
                    "floor" -> {
                        if (raw.size >= 2) {
                            val v = evaluateNumber(raw[1], feature, zoom)
                            if (v != null) return floor(v)
                        }
                        null
                    }
                    "ceil" -> {
                        if (raw.size >= 2) {
                            val v = evaluateNumber(raw[1], feature, zoom)
                            if (v != null) return ceil(v)
                        }
                        null
                    }
                    "abs" -> {
                        if (raw.size >= 2) {
                            val v = evaluateNumber(raw[1], feature, zoom)
                            if (v != null) return abs(v)
                        }
                        null
                    }
                    "%" -> {
                        if (raw.size >= 3) {
                            val a = evaluateNumber(raw[1], feature, zoom)
                            val b = evaluateNumber(raw[2], feature, zoom)
                            if (a != null && b != null && b != 0.0) return a % b
                        }
                        null
                    }
                    "match" -> evaluateMatchNumber(raw, feature)
                    "zoom" -> zoom
                    "interpolate" -> evaluateInterpolateNumber(raw, feature, zoom)
                    "length" -> evaluateLength(raw, feature, zoom)
                    "at" -> evaluateNumber(evaluateAt(raw, feature, zoom), feature, zoom)
                    "let" -> evaluateLetBody(raw, feature, zoom) { evaluateNumber(it, feature, zoom) }
                    "var" -> varAsNumber(raw, feature, zoom)
                    else -> null
                }
            }
            else -> return null
        }
    }

    private fun numberToExpressionString(value: Double): String {
        val rounded = round(value)
        return if (abs(value - rounded) < 1e-6) rounded.toLong().toString() else value.toString()
    }

    private fun evaluateString(raw: Any?, feature: Feature, zoom: Double? = null): String? {
        when (raw) {
            is String -> return raw
            is Expression -> return evaluateString(raw.raw, feature, zoom)
            is JsonElement -> {
                if (!raw.isJsonPrimitive || !raw.asJsonPrimitive.isString) return null
                return raw.asString
            }
            is List<*> -> {
                if (raw.isEmpty()) return null
                return when (raw[0] as? String) {
                    "get" -> evaluateGet(raw, feature)?.let { el ->
                        if (!el.isJsonPrimitive) null else {
                            val p = el.asJsonPrimitive
                            when {
                                p.isString -> p.asString
                                p.isNumber -> p.asNumber.toString()
                                p.isBoolean -> p.asBoolean.toString()
                                else -> null
                            }
                        }
                    }
                    "literal" -> {
                        val v = raw.getOrNull(1)
                        v as? String ?: evaluateString(v, feature, zoom)
                    }
                    "downcase" -> {
                        if (raw.size < 2) null else evaluateString(raw[1], feature, zoom)?.lowercase()
                    }
                    "upcase" -> {
                        if (raw.size < 2) null else evaluateString(raw[1], feature, zoom)?.uppercase()
                    }
                    "to-string" -> {
                        if (raw.size < 2) null else {
                            evaluateString(raw[1], feature, zoom)
                                ?: evaluateNumber(raw[1], feature)?.let(::numberToExpressionString)
                        }
                    }
                    "match" -> evaluateMatchString(raw, feature, zoom)
                    "concat" -> {
                        val sb = StringBuilder()
                        for (i in 1 until raw.size) {
                            val part = evaluateString(raw[i], feature, zoom)
                                ?: evaluateNumber(raw[i], feature)?.let(::numberToExpressionString)
                                ?: return null
                            sb.append(part)
                        }
                        sb.toString()
                    }
                    "step" -> evaluateStepString(raw, feature, zoom)
                    "coalesce" -> {
                        for (i in 1 until raw.size) {
                            evaluateString(raw[i], feature, zoom)?.let { return it }
                        }
                        null
                    }
                    "join" -> evaluateJoin(raw, feature, zoom)
                    "slice" -> evaluateSliceString(raw, feature, zoom)
                    "at" -> valueToString(evaluateAt(raw, feature, zoom), feature, zoom)
                    "let" -> evaluateLetBody(raw, feature, zoom) { evaluateString(it, feature, zoom) }
                    "var" -> varAsString(raw, feature, zoom)
                    else -> null
                }
            }
        }
        return null
    }

    /**
     * `["step", input, base, thr1, out1, thr2, out2, ...]` for string-valued results (e.g. a
     * zoom-gated label that's empty below a zoom threshold and a `match` expression above it).
     * Mirrors [evaluateStepNumber]'s shape/semantics but resolves each branch as a string.
     */
    private fun evaluateStepString(list: List<*>, feature: Feature, zoom: Double?): String? {
        if (list.size < 4) return null
        val input = resolveStepInput(list[1], feature, zoom) ?: return null
        var result = evaluateString(list[2], feature, zoom)
        var i = 3
        while (i + 1 < list.size) {
            val thr = (list[i] as? Number)?.toDouble() ?: return result
            val out = list[i + 1]
            if (input >= thr) {
                result = evaluateString(out, feature, zoom) ?: result
            }
            i += 2
        }
        return result
    }

    private fun evaluateGet(list: List<*>, feature: Feature): JsonElement? {
        val key = list[1] as? String ?: return null
        val root = feature.properties() ?: return null
        if (list.size == 2) {
            if (root.has(key)) return root.get(key)
            if (key.contains('.')) {
                return getNestedJsonElement(root, key.split('.'))
            }
            return null
        }
        if (list.size == 3) {
            val parentEl = evaluateSubexpressionToJson(list[2], feature) ?: return null
            if (!parentEl.isJsonObject) return null
            val o = parentEl.asJsonObject
            if (!o.has(key)) return null
            return o.get(key)
        }
        return null
    }

    /** Mapbox-style `["get", "report.areaAC"]` on nested MVT properties. */
    private fun getNestedJsonElement(root: com.google.gson.JsonObject, keys: List<String>): com.google.gson.JsonElement? {
        var cur: com.google.gson.JsonElement = root
        for (segment in keys) {
            if (!cur.isJsonObject) return null
            val obj = cur.asJsonObject
            if (!obj.has(segment)) return null
            cur = obj.get(segment)!!
        }
        return cur
    }

    private fun evaluateSubexpressionToJson(raw: Any?, feature: Feature): JsonElement? {
        when (raw) {
            is Expression -> return evaluateSubexpressionToJson(raw.raw, feature)
            is List<*> -> {
                if (raw.isNotEmpty() && raw[0] == "get") {
                    return evaluateGet(raw, feature)
                }
            }
        }
        return null
    }

    private fun jsonElementToDouble(el: JsonElement?): Double? {
        if (el == null || el.isJsonNull) return null
        if (!el.isJsonPrimitive) return null
        val p = el.asJsonPrimitive
        if (p.isNumber) return p.asDouble
        if (p.isString) return p.asString.toDoubleOrNull()
        return null
    }

    private fun lookupVar(raw: List<*>): Any? {
        val name = raw.getOrNull(1) as? String ?: return null
        return ExpressionLetScope.lookup(name)
    }

    private fun varAsNumber(raw: List<*>, feature: Feature, zoom: Double?): Double? {
        return when (val v = lookupVar(raw)) {
            is Number -> v.toDouble()
            is String -> v.toDoubleOrNull()
            is JsonElement -> jsonElementToDouble(v)
            else -> evaluateNumber(v, feature, zoom)
        }
    }

    private fun varAsString(raw: List<*>, feature: Feature, zoom: Double?): String? {
        return when (val v = lookupVar(raw)) {
            is String -> v
            is Number -> numberToExpressionString(v.toDouble())
            is JsonElement -> if (v.isJsonPrimitive && v.asJsonPrimitive.isString) v.asString else null
            else -> evaluateString(v, feature, zoom)
        }
    }

    private fun valueToString(value: Any?, feature: Feature, zoom: Double?): String? {
        return when (value) {
            is String -> value
            is Number -> numberToExpressionString(value.toDouble())
            is Boolean -> value.toString()
            is JsonElement -> if (value.isJsonPrimitive) {
                val p = value.asJsonPrimitive
                when {
                    p.isString -> p.asString
                    p.isNumber -> numberToExpressionString(p.asDouble)
                    p.isBoolean -> p.asBoolean.toString()
                    else -> null
                }
            } else null
            else -> evaluateString(value, feature, zoom)
        }
    }

    /**
     * `["let", name1, value1, ..., result]`. Bindings are visible to later bindings and to [body].
     */
    private fun <T> evaluateLetBody(
        list: List<*>,
        feature: Feature,
        zoom: Double?,
        body: (Any?) -> T?,
    ): T? {
        if (list.size < 4) return null
        val bindings = LinkedHashMap<String, Any?>()
        return ExpressionLetScope.withScope(bindings) {
            var i = 1
            while (i + 1 < list.size - 1) {
                val name = list[i] as? String ?: return@withScope null
                bindings[name] = evaluateBinding(list[i + 1], feature, zoom)
                i += 2
            }
            body(list.last())
        }
    }

    private fun evaluateBinding(raw: Any?, feature: Feature, zoom: Double?): Any? {
        val node = if (raw is Expression) raw.raw else raw
        evaluateArray(node, feature, zoom)?.let { return it }
        evaluateNumber(node, feature, zoom)?.let { return it }
        evaluateString(node, feature, zoom)?.let { return it }
        evaluateBoolean(node, feature)?.let { return it }
        if (node is List<*> && node.getOrNull(0) == "literal") return node.getOrNull(1)
        return node
    }

    private fun evaluateLength(list: List<*>, feature: Feature, zoom: Double?): Double? {
        val input = list.getOrNull(1) ?: return null
        evaluateArray(input, feature, zoom)?.let { return it.size.toDouble() }
        evaluateString(input, feature, zoom)?.let { return it.length.toDouble() }
        val el = if (input is List<*>) evaluateGetIfGet(input, feature) else null
        if (el != null) {
            if (el.isJsonArray) return el.asJsonArray.size().toDouble()
            if (el.isJsonPrimitive && el.asJsonPrimitive.isString) {
                return el.asJsonPrimitive.asString.length.toDouble()
            }
        }
        return null
    }

    private fun evaluateGetIfGet(list: List<*>, feature: Feature): JsonElement? {
        val op = list.getOrNull(0) as? String ?: return null
        return if (op == "get") evaluateGet(list, feature) else null
    }

    private fun evaluateAt(list: List<*>, feature: Feature, zoom: Double?): Any? {
        if (list.size < 3) return null
        val index = evaluateNumber(list[1], feature, zoom)?.toInt() ?: return null
        if (index < 0) return null
        val arr = evaluateArray(list[2], feature, zoom) ?: return null
        if (index >= arr.size) return null
        return arr[index]
    }

    private fun evaluateJoin(list: List<*>, feature: Feature, zoom: Double?): String? {
        if (list.size < 3) return null
        val asMapboxArray = evaluateArray(list[1], feature, zoom)
        if (asMapboxArray != null && list.size == 3) {
            val sep = evaluateString(list[2], feature, zoom) ?: return null
            val sb = StringBuilder()
            for (i in asMapboxArray.indices) {
                if (i > 0) sb.append(sep)
                sb.append(valueToString(asMapboxArray[i], feature, zoom) ?: return null)
            }
            return sb.toString()
        }
        val sep = evaluateString(list[1], feature, zoom) ?: return null
        val sb = StringBuilder()
        for (i in 2 until list.size) {
            if (i > 2) sb.append(sep)
            sb.append(
                evaluateString(list[i], feature, zoom)
                    ?: evaluateNumber(list[i], feature, zoom)?.let(::numberToExpressionString)
                    ?: return null,
            )
        }
        return sb.toString()
    }

    private fun evaluateSliceString(list: List<*>, feature: Feature, zoom: Double?): String? {
        val s = evaluateString(list.getOrNull(1), feature, zoom) ?: return null
        val begin = evaluateNumber(list.getOrNull(2), feature, zoom)?.toInt() ?: return null
        val end = if (list.size >= 4) {
            evaluateNumber(list[3], feature, zoom)?.toInt() ?: return null
        } else {
            s.length
        }
        val from = sliceIndex(begin, s.length)
        val to = sliceIndex(end, s.length).coerceAtLeast(from)
        if (from > s.length) return ""
        return s.substring(from, to.coerceAtMost(s.length))
    }

    private fun sliceList(
        arr: List<Any?>,
        list: List<*>,
        feature: Feature,
        zoom: Double?,
    ): List<Any?>? {
        val begin = evaluateNumber(list.getOrNull(2), feature, zoom)?.toInt() ?: return null
        val end = if (list.size >= 4) {
            evaluateNumber(list[3], feature, zoom)?.toInt() ?: return null
        } else {
            arr.size
        }
        val from = sliceIndex(begin, arr.size)
        val to = sliceIndex(end, arr.size).coerceAtLeast(from)
        return arr.subList(from, to.coerceAtMost(arr.size))
    }

    /** JS-style slice indices: negative counts from the end; out-of-range is clamped. */
    private fun sliceIndex(index: Int, size: Int): Int {
        if (index < 0) return (size + index).coerceAtLeast(0)
        return index.coerceAtMost(size)
    }

    private fun evaluateArray(raw: Any?, feature: Feature, zoom: Double?): List<Any?>? {
        when (val node = if (raw is Expression) raw.raw else raw) {
            is List<*> -> {
                if (node.isEmpty()) return null
                return when (node[0] as? String) {
                    "literal" -> {
                        val v = node.getOrNull(1)
                        @Suppress("UNCHECKED_CAST")
                        (v as? List<*>)?.map { it }
                    }
                    "get" -> {
                        val el = evaluateGet(node, feature) ?: return null
                        if (!el.isJsonArray) return null
                        jsonArrayToList(el.asJsonArray)
                    }
                    "slice" -> {
                        val arr = evaluateArray(node.getOrNull(1), feature, zoom) ?: return null
                        sliceList(arr, node, feature, zoom)
                    }
                    "at" -> {
                        val item = evaluateAt(node, feature, zoom)
                        item as? List<*> ?: (item as? JsonArray)?.let(::jsonArrayToList)
                    }
                    "var" -> {
                        when (val v = lookupVar(node)) {
                            is List<*> -> v
                            is JsonArray -> jsonArrayToList(v)
                            else -> null
                        }
                    }
                    else -> null
                }
            }
            is JsonArray -> return jsonArrayToList(node)
            else -> return null
        }
    }

    private fun jsonArrayToList(arr: JsonArray): List<Any?> {
        val out = ArrayList<Any?>(arr.size())
        for (el in arr) out.add(jsonElementToAny(el))
        return out
    }

    private fun jsonElementToAny(el: JsonElement): Any? {
        if (el.isJsonNull) return null
        if (el.isJsonPrimitive) {
            val p = el.asJsonPrimitive
            return when {
                p.isNumber -> p.asDouble
                p.isString -> p.asString
                p.isBoolean -> p.asBoolean
                else -> null
            }
        }
        if (el.isJsonArray) return jsonArrayToList(el.asJsonArray)
        if (el.isJsonObject) return el.asJsonObject
        return null
    }

    private fun colorTokenToRgba(token: Any?): FloatArray? {
        when (token) {
            is String -> {
                val s = token.trim()
                if (s.startsWith("#")) {
                    return try {
                        val argb = AndroidColor.parseColor(s)
                        floatArrayOf(
                            AndroidColor.red(argb) / 255f,
                            AndroidColor.green(argb) / 255f,
                            AndroidColor.blue(argb) / 255f,
                            AndroidColor.alpha(argb) / 255f,
                        )
                    } catch (_: Exception) {
                        null
                    }
                }
                if (s.startsWith("rgba(", ignoreCase = true) && s.endsWith(")")) {
                    val inner = s.substring(5, s.length - 1).split(',')
                    if (inner.size >= 4) {
                        val r = inner[0].trim().toIntOrNull() ?: return null
                        val g = inner[1].trim().toIntOrNull() ?: return null
                        val b = inner[2].trim().toIntOrNull() ?: return null
                        val a = inner[3].trim().toFloatOrNull() ?: return null
                        return floatArrayOf(r / 255f, g / 255f, b / 255f, a.coerceIn(0f, 1f))
                    }
                }
            }
            is StyleColor -> {
                when (token) {
                    is StyleColor.Color -> {
                        val c = token.color
                        return floatArrayOf(c.red, c.green, c.blue, c.alpha)
                    }
                    is StyleColor.Hex -> return colorTokenToRgba(token.hexString)
                    is StyleColor.RGBA -> return colorTokenToRgba(token.rgbaString)
                }
            }
            is ComposeColor -> {
                return floatArrayOf(token.red, token.green, token.blue, token.alpha)
            }
        }
        return null
    }
}

/** CSS / Mapbox unit bezier: maps x in [0,1] to y for `["cubic-bezier", x1, y1, x2, y2]`. */
private class UnitBezier(p1x: Double, p1y: Double, p2x: Double, p2y: Double) {
    private val cx = 3.0 * p1x
    private val bx = 3.0 * (p2x - p1x) - cx
    private val ax = 1.0 - cx - bx
    private val cy = 3.0 * p1y
    private val by = 3.0 * (p2y - p1y) - cy
    private val ay = 1.0 - cy - by

    fun solve(x: Double, epsilon: Double = 1e-6): Double =
        sampleCurveY(solveCurveX(x.coerceIn(0.0, 1.0), epsilon))

    private fun sampleCurveX(t: Double): Double = ((ax * t + bx) * t + cx) * t

    private fun sampleCurveY(t: Double): Double = ((ay * t + by) * t + cy) * t

    private fun sampleCurveDerivativeX(t: Double): Double = (3.0 * ax * t + 2.0 * bx) * t + cx

    private fun solveCurveX(x: Double, epsilon: Double): Double {
        var t2 = x
        for (i in 0 until 8) {
            val x2 = sampleCurveX(t2) - x
            if (abs(x2) < epsilon) return t2
            val d2 = sampleCurveDerivativeX(t2)
            if (abs(d2) < 1e-6) break
            t2 -= x2 / d2
        }
        var t0 = 0.0
        var t1 = 1.0
        t2 = x
        if (t2 < t0) return t0
        if (t2 > t1) return t1
        while (t0 < t1) {
            val x2 = sampleCurveX(t2)
            if (abs(x2 - x) < epsilon) return t2
            if (x > x2) t0 = t2 else t1 = t2
            t2 = (t1 - t0) * 0.5 + t0
        }
        return t2
    }
}
