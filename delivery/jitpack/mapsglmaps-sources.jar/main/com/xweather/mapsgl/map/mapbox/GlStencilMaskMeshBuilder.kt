package com.xweather.mapsgl.map.mapbox

import com.mapbox.geojson.Feature
import com.mapbox.geojson.LineString
import com.mapbox.geojson.MultiLineString
import com.mapbox.geojson.MultiPolygon
import com.mapbox.geojson.Point
import com.mapbox.geojson.Polygon
import com.xweather.mapsgl.gl.worldObjects.MeshInfo
import com.xweather.mapsgl.style.LineCap
import com.xweather.mapsgl.style.LineJoin
import com.xweather.mapsgl.style.LineLayerPaint
import com.xweather.mapsgl.style.StrokePaint
import com.xweather.mapsgl.style.StyleValue
import com.xweather.mapsgl.tiles.LatLonBounds
import com.xweather.mapsgl.tiles.TileCoord
import org.maplibre.earcut4j.Earcut
import java.nio.FloatBuffer
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Builds triangle vertices in **tile UV space** (0–1 per axis) so mask geometry matches
 * the encoded raster quad used by [com.xweather.mapsgl.gl.RenderPass].
 */
internal object GlStencilMaskMeshBuilder {
    /**
     * Growable float accumulator whose backing storage is a pooled direct [FloatBuffer] from
     * [DirectFloatBufferPool]. The list never holds vertex bytes on the Java heap, so even
     * the build-time scratch space sidesteps ART's Large Object Space and stops triggering
     * `Background concurrent copying GC` cycles that used to free ~10 MB of LOS objects per
     * sweep during a Demo 3 width-slider drag.
     *
     * Earlier revisions used `ArrayList<Float>` (boxed everything; ~25 MB of garbage per
     * build) and then a heap `FloatArray` (no boxing but the array itself was LOS once it
     * grew past ~3 KB). This is the third iteration: the working buffer is off-heap, and
     * for the common "build mesh and hand it to a [GlStencilMaskTileCache.CpuMesh]" path
     * the same direct buffer that the builder wrote into is the one the renderer uploads
     * via `glBufferData` — no `FloatArray -> direct buffer` copy at the boundary, and no
     * LOS allocation along the way.
     *
     * ### Lifetime
     *
     * The list owns its underlying [FloatBuffer]; one of [toFloatBuffer], [toFloatArray],
     * or [release] **must** be called exactly once to recycle the buffer back to the pool.
     * Single-thread use only — there's no synchronization on `len` or `data`.
     */
    internal class FloatArrayList(initialCapacity: Int = 16) {
        /**
         * Pool-backed direct buffer. Limit is held at `capacity()` for the duration of the
         * build (so absolute `put(int, float)` can write to any in-bounds index without
         * caring about the buffer's logical size); the actual size is tracked in [len] and
         * baked into the buffer's `limit` only at hand-off in [toFloatBuffer].
         */
        private var data: FloatBuffer = DirectFloatBufferPool
            .acquire(if (initialCapacity < 4) 4 else initialCapacity)
            .apply { limit(capacity()) }
        private var len: Int = 0
        private var consumed: Boolean = false

        val size: Int get() = len

        fun add(v: Float) {
            ensureCapacity(len + 1)
            data.put(len, v)
            len++
        }

        fun add(v0: Float, v1: Float) {
            ensureCapacity(len + 2)
            data.put(len, v0)
            data.put(len + 1, v1)
            len += 2
        }

        fun add(v0: Float, v1: Float, v2: Float, v3: Float, v4: Float, v5: Float) {
            ensureCapacity(len + 6)
            data.put(len, v0)
            data.put(len + 1, v1)
            data.put(len + 2, v2)
            data.put(len + 3, v3)
            data.put(len + 4, v4)
            data.put(len + 5, v5)
            len += 6
        }

        /**
         * Copies the accumulated floats into a fresh heap `FloatArray` and recycles the
         * direct working buffer to [DirectFloatBufferPool]. Used by call sites that have to
         * keep the data alive in a `FloatArray`-typed field (`LinePath.pointsUv`, which is
         * small enough that a heap array is fine and would be a wider refactor to change).
         */
        fun toFloatArray(): FloatArray {
            check(!consumed) { "FloatArrayList already consumed" }
            consumed = true
            val arr = FloatArray(len)
            if (len > 0) {
                val src = data.duplicate()
                src.position(0)
                src.limit(len)
                src.get(arr)
            }
            DirectFloatBufferPool.release(data)
            return arr
        }

        /**
         * Hands off the underlying direct buffer with `position=0, limit=size`. Ownership
         * transfers to the caller (typically a [GlStencilMaskTileCache.CpuMesh] that takes
         * over deferred-release responsibility). Returns `null` for an empty list and
         * recycles the buffer immediately; callers consistently distinguish "missing mesh"
         * from "zero-vertex mesh", and the pool would refuse a zero-capacity buffer anyway.
         */
        fun toFloatBuffer(): FloatBuffer? {
            check(!consumed) { "FloatArrayList already consumed" }
            consumed = true
            if (len == 0) {
                DirectFloatBufferPool.release(data)
                return null
            }
            data.position(0)
            data.limit(len)
            return data
        }

        /**
         * Recycles the underlying direct buffer without producing a result. Used by paths
         * that abandon the build (e.g. [extractPathPieces] dropping a piece shorter than 4
         * floats) so the buffer doesn't leak to GC while waiting for the Cleaner to fire.
         */
        fun release() {
            if (consumed) return
            consumed = true
            DirectFloatBufferPool.release(data)
        }

        private fun ensureCapacity(min: Int) {
            val cap = data.capacity()
            if (cap >= min) return
            // Grow by doubling, clamped to `min`, so one huge add doesn't bounce through
            // several intermediate pool round-trips.
            var newCap = cap shl 1
            if (newCap < min) newCap = min
            val newBuf = DirectFloatBufferPool.acquire(newCap).apply { limit(capacity()) }
            if (len > 0) {
                val srcDup = data.duplicate()
                srcDup.position(0)
                srcDup.limit(len)
                newBuf.position(0)
                newBuf.put(srcDup)
            }
            // Old buffer was only ever touched by this single-threaded builder, so an
            // immediate release is safe (no concurrent renderer can be staring at it). The
            // deferred-release path is reserved for buffers the cache published and might
            // still be reading.
            DirectFloatBufferPool.release(data)
            data = newBuf
        }
    }

    private const val UV_EPS = 1e-5f
    /**
     * Max tile-UV length for one ribbon segment. MVT lines sometimes chain unrelated vertices; values near
     * 1.0 still span most of a tile and produce globe-spanning stencil artifacts. Keep well under √2.
     */
    private const val MAX_LINE_SEGMENT_UV_LEN = 0.48f
    /** Break [LineString]s when consecutive points are farther apart (bad topology / clipped tile seams). */
    private const val MAX_LINE_VERTEX_HOP_METERS = 200_000.0
    /**
     * Round-join fans dominate the stencil mesh size for long highways: every interior vertex
     * emits `ROUND_JOIN_SEGMENTS × 6` floats. Highway widths in this stencil sit well under 1 % of
     * a tile, so the visual difference between an 6-triangle and 12-triangle fan is below one
     * texel. Six segments is a middle ground between the original 8 and the earlier 4-segment
     * cut that saved mesh size at the cost of visible corner faceting on round styles.
     */
    private const val ROUND_JOIN_SEGMENTS = 6
    private const val ROUND_CAP_SEGMENTS = 6
    /** Douglas–Peucker tolerance scales with ribbon width and zoom (tile-UV units). */
    private const val SIMPLIFY_HALF_WIDTH_MULT = 1.25f
    private const val SIMPLIFY_MIN_TILE_UV = 0.0008f
    /** Skip path simplification at and above this zoom so motorways keep curvature when zoomed in. */
    private const val SIMPLIFY_MAX_ZOOM = 12
    /**
     * Cosine-similarity threshold above which a [LineJoin.ROUND] interior join is skipped: at
     * this angle the fan would be sub-pixel for any realistic stencil ribbon width, and the
     * adjacent segment quads already overlap enough to hide the seam. Real-world MVT motorway
     * geometry tends to chain many near-collinear segments (often 1°–3° turns), and emitting a
     * full round fan for each one is what produced the 240 k-vertex meshes that froze the
     * width-slider commit.
     */
    private const val ROUND_JOIN_SKIP_COS = 0.9962f

    // Floats per round-fan / square-cap emit — kept here so the buffer-size estimate in
    // [estimateLineRibbonFloatCount] stays in lock-step with what the emit functions actually
    // produce. A round fan is `ROUND_JOIN_SEGMENTS` triangles × 6 floats per triangle.
    private const val ROUND_FAN_VERTEX_FLOATS = ROUND_JOIN_SEGMENTS * 6
    private const val ROUND_CAP_VERTEX_FLOATS = ROUND_CAP_SEGMENTS * 6
    private const val SQUARE_CAP_VERTEX_FLOATS = 12

    /**
     * Upper-bound the number of `Float`s that [buildLineRibbonTileUvTrianglesFromPaths] will emit
     * so the destination [FloatArrayList] can be allocated once at its final size. Hitting the
     * exact final length lets [FloatArrayList.toFloatArray] hand back the backing array directly,
     * which collapses the ~10× redundant LOS allocations a wide ribbon previously generated as
     * the underlying buffer doubled from 1 KB up to a few MB.
     *
     * The estimate is loose by design — it ignores tile-edge clipping (which only ever produces
     * fewer triangles) and the segment-length skip in `emitLineRibbonFromPath`, so the buffer
     * never has to grow once allocated.
     */
    private fun estimateLineRibbonFloatCount(paths: List<LinePath>, style: LineRibbonStyle): Int {
        var total = 0
        for (path in paths) {
            val pts = path.pointsUv
            val closed = path.closed || isClosedRingPath(pts)
            val workPts = if (closed) closedRingWithoutDuplicate(pts) else pts
            val nPts = workPts.size / 2
            if (nPts < 2) continue
            val nSeg = if (closed) maxOf(nPts, 3) else nPts - 1
            total += nSeg * 12
            if (nSeg > 1 && style.lineJoin == LineJoin.ROUND) {
                val joinCount = if (closed) nPts else nPts - 2
                var emittedJoins = 0
                var i = if (closed) 0 else 1
                val end = if (closed) nPts else nPts - 1
                while (i < end) {
                    val prev = if (closed) (i + nPts - 1) % nPts else i - 1
                    val ax = workPts[prev * 2]; val ay = workPts[prev * 2 + 1]
                    val bx = workPts[i * 2]; val by = workPts[i * 2 + 1]
                    val next = if (closed) (i + 1) % nPts else i + 1
                    val cx = workPts[next * 2]; val cy = workPts[next * 2 + 1]
                    val d0x = bx - ax; val d0y = by - ay
                    val d1x = cx - bx; val d1y = cy - by
                    val l0 = hypot(d0x.toDouble(), d0y.toDouble()).toFloat()
                    val l1 = hypot(d1x.toDouble(), d1y.toDouble()).toFloat()
                    if (l0 > 1e-6f && l1 > 1e-6f) {
                        val cos = (d0x * d1x + d0y * d1y) / (l0 * l1)
                        if (cos < ROUND_JOIN_SKIP_COS) emittedJoins++
                    }
                    i++
                }
                total += emittedJoins * ROUND_FAN_VERTEX_FLOATS
            }
            if (!closed) {
                when (style.lineCap) {
                    LineCap.ROUND -> total += 2 * ROUND_CAP_VERTEX_FLOATS
                    LineCap.SQUARE -> total += 2 * SQUARE_CAP_VERTEX_FLOATS
                    LineCap.BUTT -> {}
                }
            }
        }
        return total
    }
    data class LinePath(val pointsUv: FloatArray, val closed: Boolean = false)

    /**
     * Line join / cap for CPU-built stencil ribbons (aligned with MapsGL JS line mesh options).
     */
    data class LineRibbonStyle(
        val lineJoin: LineJoin = LineJoin.ROUND,
        val lineCap: LineCap = LineCap.ROUND,
        /** Mapbox-style miter limit ratio (max miter length / stroke half-width). */
        val miterLimit: Float = 2f,
    ) {
        companion object {
            val Default = LineRibbonStyle()
        }
    }

    fun lineRibbonStyleFromLineLayerPaint(paint: LineLayerPaint?): LineRibbonStyle {
        if (paint == null) return LineRibbonStyle.Default
        return lineRibbonStyleFromStrokePaint(paint.stroke)
    }

    fun lineRibbonStyleFromStrokePaint(stroke: StrokePaint): LineRibbonStyle {
        val join = (stroke.lineJoin as? StyleValue.Constant)?.value ?: LineJoin.ROUND
        val cap = (stroke.lineCap as? StyleValue.Constant)?.value ?: LineCap.ROUND
        val ml = ((stroke.miterLimit as? StyleValue.Constant)?.value ?: 2.0).toFloat().coerceAtLeast(1f)
        return LineRibbonStyle(join, cap, ml)
    }

    /**
     * Line ribbons along polygon exterior rings for fill-layer outlines (tile UV space).
     */
    fun extractFillOutlinePaths(
        coord: TileCoord,
        polygonFeatures: List<Feature>,
    ): List<LinePath> {
        if (polygonFeatures.isEmpty()) return emptyList()
        val rings = extractPolygonExteriorRingsTileUv(coord, polygonFeatures)
        if (rings.isEmpty()) return emptyList()
        val paths = ArrayList<LinePath>(rings.size)
        for (ring in rings) {
            val closed = closeOpenRingUv(ring) ?: continue
            paths.add(LinePath(closed, closed = true))
        }
        return paths
    }

    fun buildFillOutlineTileUvTriangles(
        coord: TileCoord,
        polygonFeatures: List<Feature>,
        halfWidthUv: Float,
        style: LineRibbonStyle = LineRibbonStyle.Default,
    ): FloatBuffer? {
        if (polygonFeatures.isEmpty() || halfWidthUv <= 0f) return null
        val paths = extractFillOutlinePaths(coord, polygonFeatures)
        if (paths.isEmpty()) return null
        return buildLineRibbonTileUvTrianglesFromPaths(paths, halfWidthUv, style, coord)
    }

    private fun closeOpenRingUv(ring: FloatArray): FloatArray? {
        if (ring.size < 6) return null
        if (ring.size >= 4 &&
            ring[0] == ring[ring.size - 2] &&
            ring[1] == ring[ring.size - 1]
        ) {
            return ring
        }
        val closed = FloatArray(ring.size + 2)
        System.arraycopy(ring, 0, closed, 0, ring.size)
        closed[ring.size] = ring[0]
        closed[ring.size + 1] = ring[1]
        return closed
    }

    /**
     * Triangle soup in **the same local space as weather [MeshInfo] quads** (`a_position`: x,y in [0,1],
     * y=0 south / y=1 north) for the intersection of the drawn tile with [clip] (WGS84 axis-aligned bounds).
     *
     * Uses [MeshInfo.x]/[MeshInfo.y] as the float tile origin (matches [RenderPass] model-view translate),
     * not an integer tile id from a cache key.
     *
     * [lonLatToTileUv] gives v_merc with 0=north edge of the tile row; weather vertices use the opposite
     * vertical convention, so we use **y_stencil = 1 - v_merc** so mask triangles land on the same pixels
     * as the encoded raster quad (otherwise stencil writes miss the quad and the whole layer tests out).
     */
    fun buildLatLonBoundsClipTileUv(meshInfo: MeshInfo, clip: LatLonBounds): FloatBuffer? {
        val z = meshInfo.z.toInt()
        if (z !in 0..30) return null
        val world = 1 shl z
        if (world <= 0) return null
        val ox = meshInfo.x
        val oy = meshInfo.y
        val n = world.toDouble()
        val tw = ox.toDouble() / n * 360.0 - 180.0
        val te = (ox + 1f).toDouble() / n * 360.0 - 180.0
        val northLat = latDegreesFromMercatorYNorm(oy.toDouble() / n)
        val southLat = latDegreesFromMercatorYNorm((oy + 1f).toDouble() / n)
        val ts = minOf(southLat, northLat)
        val tn = maxOf(southLat, northLat)
        val ix0 = maxOf(tw, clip.westExtent)
        val ix1 = minOf(te, clip.eastExtent)
        val iy0 = maxOf(ts, clip.southExtent)
        val iy1 = minOf(tn, clip.northExtent)
        if (ix0 >= ix1 || iy0 >= iy1) return null
        fun stencilPos(lon: Double, lat: Double): Pair<Float, Float> {
            val (u, vMerc) = lonLatToTileUvFloatOrigin(z, ox, oy, world, lon, lat)
            return Pair(u, 1f - vMerc)
        }
        val (u0, v0) = stencilPos(ix0, iy0)
        val (u1, v1) = stencilPos(ix1, iy0)
        val (u2, v2) = stencilPos(ix1, iy1)
        val (u3, v3) = stencilPos(ix0, iy1)
        val out = FloatArrayList(18)
        emitTriangleClippedToUnitSquare(u0, v0, u1, v1, u2, v2, out)
        emitTriangleClippedToUnitSquare(u0, v0, u2, v2, u3, v3, out)
        return out.toFloatBuffer()
    }

    /** Same as [lonLatToTileUv] but tile origin may be fractional (matches weather MV translate). */
    private fun lonLatToTileUvFloatOrigin(z: Int, ox: Float, oy: Float, world: Int, lon: Double, lat: Double): Pair<Float, Float> {
        val xf = (lon + 180.0) / 360.0 * world
        val u = (xf - ox).toFloat()
        val latRad = Math.toRadians(lat)
        val sinLat = kotlin.math.sin(latRad)
        val yNorm = 0.5 - 0.25 * ln((1.0 + sinLat) / (1.0 - sinLat)) / PI
        val yf = yNorm * world
        val vMerc = (yf - oy).toFloat()
        return Pair(u, vMerc)
    }

    /** Inverse of the yNorm used in [lonLatToTileUv] (0 = north, 1 = south along Web Mercator). */
    private fun latDegreesFromMercatorYNorm(yNorm: Double): Double {
        val yn = yNorm.coerceIn(1e-9, 1.0 - 1e-9)
        val r = exp((0.5 - yn) * PI / 0.25)
        val sinLat = ((r - 1.0) / (r + 1.0)).coerceIn(-1.0, 1.0)
        return Math.toDegrees(asin(sinLat))
    }

    fun buildTileUvTriangles(coord: TileCoord, maskFeatures: List<Feature>): FloatBuffer? {
        if (maskFeatures.isEmpty()) return null
        val z = coord.z
        val tx = coord.x
        val ty = coord.y
        val world = 1 shl z
        val out = FloatArrayList(256)
        for (f in maskFeatures) {
            when (val g = f.geometry()) {
                is Polygon -> triangulatePolygon(z, tx, ty, world, g, out)
                is MultiPolygon -> {
                    for (rings in g.coordinates()) {
                        val poly = Polygon.fromLngLats(rings)
                        triangulatePolygon(z, tx, ty, world, poly, out)
                    }
                }
                else -> {}
            }
        }
        return out.toFloatBuffer()
    }

    /**
     * Expands line features into a triangle ribbon in tile UV space for stencil masks (approximate stroke).
     */
    fun buildLineRibbonTileUvTriangles(
        coord: TileCoord,
        lineFeatures: List<Feature>,
        halfWidthUv: Float,
        style: LineRibbonStyle = LineRibbonStyle.Default,
    ): FloatBuffer? {
        if (lineFeatures.isEmpty() || halfWidthUv <= 0f) return null
        val paths = extractLinePathsTileUv(coord, lineFeatures)
        return buildLineRibbonTileUvTrianglesFromPaths(paths, halfWidthUv, style)
    }

    fun buildLineRibbonTileUvTrianglesFromPaths(
        paths: List<LinePath>,
        halfWidthUv: Float,
        style: LineRibbonStyle = LineRibbonStyle.Default,
        coord: TileCoord? = null,
        clipBounds: LatLonBounds? = null,
        clipPolygonRings: List<FloatArray> = emptyList(),
    ): FloatBuffer? {
        if (paths.isEmpty() || halfWidthUv <= 0f) return null
        var work = paths
        if (coord != null && coord.z < SIMPLIFY_MAX_ZOOM) {
            work = simplifyLinePaths(work, coord.z, halfWidthUv)
            if (clipBounds != null) {
                work = clipLinePathsToLatLonBounds(work, coord, clipBounds)
            }
            if (clipPolygonRings.isNotEmpty()) {
                work = clipLinePathsToPolygons(work, clipPolygonRings)
            }
        }
        if (work.isEmpty()) return null
        // Pre-size the buffer so we don't double through 10+ ever-larger `FloatArray`
        // allocations (each one a Large Object in ART, which is the LOS GC pressure that was
        // freezing Demo 3 width changes — see [estimateLineRibbonFloatCount]).
        val out = FloatArrayList(estimateLineRibbonFloatCount(work, style).coerceAtLeast(32))
        for (path in work) {
            val pathStyle =
                if (path.closed) {
                    style.copy(lineJoin = LineJoin.BEVEL, lineCap = LineCap.BUTT)
                } else {
                    style
                }
            if (path.closed || isClosedRingPath(path.pointsUv)) {
                emitClosedLineRibbonFromPath(path.pointsUv, halfWidthUv, pathStyle, out)
            } else {
                emitLineRibbonFromPath(path.pointsUv, halfWidthUv, pathStyle, out)
            }
        }
        return out.toFloatBuffer()
    }

    fun extractLinePathsTileUv(coord: TileCoord, lineFeatures: List<Feature>): List<LinePath> {
        if (lineFeatures.isEmpty()) return emptyList()
        val z = coord.z
        val tx = coord.x
        val ty = coord.y
        val world = 1 shl z
        val paths = ArrayList<LinePath>(64)
        for (f in lineFeatures) {
            when (val g = f.geometry()) {
                is LineString -> {
                    for (piece in extractPathPieces(z, tx, ty, world, g)) {
                        paths.add(LinePath(piece))
                    }
                }
                is MultiLineString -> {
                    for (ls in g.coordinates()) {
                        for (piece in extractPathPieces(z, tx, ty, world, LineString.fromLngLats(ls))) {
                            paths.add(LinePath(piece))
                        }
                    }
                }
                is Polygon, is MultiPolygon -> {
                    for (ring in extractPolygonExteriorRingsTileUv(coord, listOf(f))) {
                        val closed = closeOpenRingUv(ring) ?: continue
                        paths.add(LinePath(closed, closed = true))
                    }
                }
                else -> {}
            }
        }
        return paths
    }

    /** Haversine distance on WGS84 sphere (meters). */
    private fun greatCircleMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6_371_000.0
        val p1 = Math.toRadians(lat1)
        val p2 = Math.toRadians(lat2)
        val dLat = p2 - p1
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
            cos(p1) * cos(p2) * sin(dLon / 2) * sin(dLon / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1.0 - a))
        return r * c
    }

    /**
     * Tile-UV polylines for [line], split so we never connect vertices that are absurdly far apart in WGS84
     * (common source of long spurious ribbons in vector tiles).
     */
    private fun extractPathPieces(z: Int, tx: Int, ty: Int, world: Int, line: LineString): List<FloatArray> {
        val coords = line.coordinates()
        if (coords.size < 2) return emptyList()
        val pieces = ArrayList<FloatArray>(2)
        var flat = FloatArrayList(coords.size * 2)
        var lastU = Float.NaN
        var lastV = Float.NaN
        var prevRawU = 0f
        var unwrapOffset = 0
        var prevLat = 0.0
        var prevLon = 0.0
        fun flushPiece() {
            // Either consume the buffer (`toFloatArray` recycles) or release it explicitly.
            // Dropping the FloatArrayList on the floor would leak its pool buffer until the
            // JVM Cleaner ran — for a busy tile that's dozens of short-lived buckets that
            // never make it back to [DirectFloatBufferPool] for reuse.
            if (flat.size >= 4) pieces.add(flat.toFloatArray()) else flat.release()
            flat = FloatArrayList(32)
            lastU = Float.NaN
            lastV = Float.NaN
            unwrapOffset = 0
        }
        for ((i, p) in coords.withIndex()) {
            val lat = p.latitude()
            val lon = p.longitude()
            if (i > 0 && greatCircleMeters(prevLat, prevLon, lat, lon) > MAX_LINE_VERTEX_HOP_METERS) {
                flushPiece()
            }
            val (rawU, v) = lonLatToTileUv(z, tx, ty, world, lon, lat)
            if (flat.size > 0) {
                val du = rawU - prevRawU
                when {
                    du > 0.5f -> unwrapOffset--
                    du < -0.5f -> unwrapOffset++
                }
            }
            prevRawU = rawU
            val u = rawU + unwrapOffset
            if (flat.size == 0 || hypot((u - lastU).toDouble(), (v - lastV).toDouble()) > 1e-6) {
                flat.add(u, v)
                lastU = u
                lastV = v
            }
            prevLat = lat
            prevLon = lon
        }
        if (flat.size >= 4) pieces.add(flat.toFloatArray()) else flat.release()
        return pieces
    }

    /**
     * Fills a circular sector (triangle fan from [p] along arc [a0]→[a1]) after clipping the whole
     * convex polygon once. Per-triangle clipping of each wedge reproduces the same corner-pinning
     * artifacts as square caps when arcs cross tile edges.
     *
     * Fast path emits the fan directly from primitives when the bounding circle fits in the unit
     * tile; otherwise we fall back to the Sutherland-Hodgman convex-polygon clip. The fast path is
     * the only one that runs for the vast majority of joins/caps on a populated motorway tile, so
     * it has to be allocation-free.
     */
    private fun emitCircularSectorClippedToUnitSquare(
        pu: Float,
        pv: Float,
        halfW: Float,
        a0: Float,
        a1: Float,
        segments: Int,
        out: FloatArrayList,
    ) {
        if (segments < 1 || abs(a1 - a0) < 1e-6f) return
        // Fast path: bounding box of the sector fits inside the tile. No vertex is going to be
        // produced by the clipper, so emit the fan directly and skip the ArrayList<P2> + per-step
        // `P2` allocations that the slow path needs.
        if (pu - halfW >= -UV_EPS && pu + halfW <= 1f + UV_EPS &&
            pv - halfW >= -UV_EPS && pv + halfW <= 1f + UV_EPS
        ) {
            val cu = pu.coerceIn(0f, 1f)
            val cv = pv.coerceIn(0f, 1f)
            var prevU = (pu + halfW * cos(a0)).coerceIn(0f, 1f)
            var prevV = (pv + halfW * sin(a0)).coerceIn(0f, 1f)
            val invSeg = 1f / segments
            for (s in 1..segments) {
                val ang = a0 + (a1 - a0) * (s * invSeg)
                val curU = (pu + halfW * cos(ang)).coerceIn(0f, 1f)
                val curV = (pv + halfW * sin(ang)).coerceIn(0f, 1f)
                emitTriangleFastNoClip(cu, cv, prevU, prevV, curU, curV, out)
                prevU = curU
                prevV = curV
            }
            return
        }
        // Slow path: sector crosses a tile edge.
        //
        // We DELIBERATELY do *not* build one big sector polygon and run a single Sutherland-
        // Hodgman + fan-triangulation pass on it. That approach is correct in isolation, but at
        // large [halfW] (Demo 3 slider at max width is `halfW = 0.5`, i.e. a half-tile-radius cap)
        // the clipped sliver — e.g. a sector centered just inside `u = 1` whose arc bulges past
        // the edge — is a thin tall convex polygon. Fan-triangulating from the center then emits
        // one near-full-tile-height triangle like `(center, intersect_top, intersect_bottom)`.
        // That triangle is fine for the original parent tile (it stays inside the half-disk), but
        // [GlStencilMaskTileCache.remapParentMeshToChildUvs] later slices the parent into child
        // sub-regions, and the slice of a giant fan triangle is a stray wedge that shows up far
        // from the actual road — exactly the artifacts seen in Demo 3 at max width.
        //
        // Emitting each wedge `(center, arc[s], arc[s+1])` as its own clipped triangle bounds
        // each output triangle to the wedge (~`halfW` extent), so the ancestor remap can only
        // ever clip wedge-sized triangles, not tile-spanning ones.
        var prevU = pu + halfW * cos(a0)
        var prevV = pv + halfW * sin(a0)
        val invSeg = 1f / segments
        for (s in 1..segments) {
            val ang = a0 + (a1 - a0) * (s * invSeg)
            val curU = pu + halfW * cos(ang)
            val curV = pv + halfW * sin(ang)
            emitTriangleClippedToUnitSquare(pu, pv, prevU, prevV, curU, curV, out)
            prevU = curU
            prevV = curV
        }
    }

    private fun emitSquareEndCap(
        pu: Float, pv: Float,
        tFwdU: Float, tFwdV: Float,
        nu: Float, nv: Float,
        halfW: Float,
        out: FloatArrayList,
    ) {
        val extU = pu + tFwdU * halfW
        val extV = pv + tFwdV * halfW
        val pLu = pu - nu * halfW
        val pLv = pv - nv * halfW
        val pRu = pu + nu * halfW
        val pRv = pv + nv * halfW
        val eLu = extU - nu * halfW
        val eLv = extV - nv * halfW
        val eRu = extU + nu * halfW
        val eRv = extV + nv * halfW
        // Clip the cap as one convex quad. Clipping two triangles separately can pin far-out
        // vertices to tile corners via coerceIn() and produce huge spurious triangles (square-cap artifacts).
        emitQuadClippedToUnitSquare(pLu, pLv, pRu, pRv, eRu, eRv, eLu, eLv, out)
    }

    private fun emitSquareStartCap(
        pu: Float, pv: Float,
        tFwdU: Float, tFwdV: Float,
        nu: Float, nv: Float,
        halfW: Float,
        out: FloatArrayList,
    ) {
        val extU = pu - tFwdU * halfW
        val extV = pv - tFwdV * halfW
        val pLu = pu - nu * halfW
        val pLv = pv - nv * halfW
        val pRu = pu + nu * halfW
        val pRv = pv + nv * halfW
        val eLu = extU - nu * halfW
        val eLv = extV - nv * halfW
        val eRu = extU + nu * halfW
        val eRv = extV + nv * halfW
        emitQuadClippedToUnitSquare(eLu, eLv, eRu, eRv, pRu, pRv, pLu, pLv, out)
    }

    private fun emitRoundCap(
        pu: Float, pv: Float,
        tFwdU: Float, tFwdV: Float,
        halfW: Float,
        atStart: Boolean,
        out: FloatArrayList,
    ) {
        val back = if (atStart) atan2(-tFwdV, -tFwdU) else atan2(tFwdV, tFwdU)
        val a0 = back - PI.toFloat() / 2f
        val a1 = back + PI.toFloat() / 2f
        emitCircularSectorClippedToUnitSquare(pu, pv, halfW, a0, a1, ROUND_CAP_SEGMENTS, out)
    }

    private fun emitRoundJoinFan(
        pu: Float, pv: Float,
        n0u: Float, n0v: Float,
        n1u: Float, n1v: Float,
        t0u: Float, t0v: Float,
        t1u: Float, t1v: Float,
        halfW: Float,
        out: FloatArrayList,
    ) {
        val c = t0u * t1v - t0v * t1u
        if (abs(c) < 1e-6f) return
        val a0 = atan2(if (c > 0) -n0v else n0v, if (c > 0) -n0u else n0u)
        val a1 = atan2(if (c > 0) -n1v else n1v, if (c > 0) -n1u else n1u)
        var da = a1 - a0
        if (c > 0) {
            while (da <= 0f) da += 2f * PI.toFloat()
            if (da > PI.toFloat()) da = 2f * PI.toFloat() - da
        } else {
            while (da >= 0f) da -= 2f * PI.toFloat()
            if (da < -PI.toFloat()) da = -2f * PI.toFloat() - da
        }
        if (abs(da) < 1e-4f) return
        emitCircularSectorClippedToUnitSquare(pu, pv, halfW, a0, a0 + da, ROUND_JOIN_SEGMENTS, out)
    }

    private fun isClosedRingPath(pathUv: FloatArray): Boolean {
        if (pathUv.size < 6) return false
        val du = pathUv[0] - pathUv[pathUv.size - 2]
        val dv = pathUv[1] - pathUv[pathUv.size - 1]
        return hypot(du.toDouble(), dv.toDouble()) < 1e-5
    }

    private fun closedRingWithoutDuplicate(pathUv: FloatArray): FloatArray {
        if (!isClosedRingPath(pathUv) || pathUv.size <= 6) return pathUv
        return pathUv.copyOf(pathUv.size - 2)
    }

    /**
     * Ribbon mesh for a closed ring (polygon outline). Skips end caps and uses cyclic segment joins
     * so round caps are not stacked at the duplicated closing vertex.
     */
    private fun emitClosedLineRibbonFromPath(
        pathUv: FloatArray,
        halfW: Float,
        style: LineRibbonStyle,
        out: FloatArrayList,
    ) {
        val path = closedRingWithoutDuplicate(pathUv)
        val nPts = path.size ushr 1
        if (nPts < 3) return
        val nSeg = nPts
        val segDir = FloatArray(nSeg * 2)
        val segNorm = FloatArray(nSeg * 2)
        for (i in 0 until nSeg) {
            val ia = i shl 1
            val ib = ((i + 1) % nPts) shl 1
            val au = path[ia]
            val av = path[ia + 1]
            val bu = path[ib]
            val bv = path[ib + 1]
            val du0 = bu - au
            val dv0 = bv - av
            val len = hypot(du0.toDouble(), dv0.toDouble()).toFloat()
            val two = i shl 1
            if (len < 1e-6f) {
                segDir[two] = 1f
                segDir[two + 1] = 0f
                segNorm[two] = 0f
                segNorm[two + 1] = 1f
            } else {
                val du = du0 / len
                val dv = dv0 / len
                segDir[two] = du
                segDir[two + 1] = dv
                segNorm[two] = -dv
                segNorm[two + 1] = du
            }
        }
        val left = FloatArray(nPts * 2)
        val right = FloatArray(nPts * 2)
        val isMiter = style.lineJoin == LineJoin.MITER
        val miterMaxExtrusion = halfW * style.miterLimit
        for (i in 0 until nPts) {
            val pu = path[i shl 1]
            val pv = path[(i shl 1) + 1]
            val prevSeg = (i + nPts - 1) % nPts
            val curSeg = i % nPts
            val km1 = prevSeg shl 1
            val k = curSeg shl 1
            val n0u = segNorm[km1]
            val n0v = segNorm[km1 + 1]
            val n1u = segNorm[k]
            val n1v = segNorm[k + 1]
            val offU: Float
            val offV: Float
            if (!isMiter) {
                offU = n1u * halfW
                offV = n1v * halfW
            } else {
                val t0u = segDir[km1]
                val t0v = segDir[km1 + 1]
                val t1u = segDir[k]
                val t1v = segDir[k + 1]
                val mx = n0u + n1u
                val my = n0v + n1v
                val mLen = hypot(mx.toDouble(), my.toDouble()).toFloat()
                if (mLen < 1e-5f || (t0u * t1u + t0v * t1v) < -0.95f) {
                    offU = n1u * halfW
                    offV = n1v * halfW
                } else {
                    val mu = mx / mLen
                    val mv = my / mLen
                    val denom = mu * n1u + mv * n1v
                    if (abs(denom) < 1e-4f) {
                        offU = n1u * halfW
                        offV = n1v * halfW
                    } else {
                        val scale = halfW / denom
                        val clamped = scale.coerceIn(-miterMaxExtrusion, miterMaxExtrusion)
                        offU = mu * clamped
                        offV = mv * clamped
                    }
                }
            }
            val twoI = i shl 1
            left[twoI] = pu - offU
            left[twoI + 1] = pv - offV
            right[twoI] = pu + offU
            right[twoI + 1] = pv + offV
        }
        for (i in 0 until nSeg) {
            val ia = i shl 1
            val ib = ((i + 1) % nPts) shl 1
            val au = path[ia]
            val av = path[ia + 1]
            val bu = path[ib]
            val bv = path[ib + 1]
            val dx = bu - au
            val dy = bv - av
            if (hypot(dx.toDouble(), dy.toDouble()) <= MAX_LINE_SEGMENT_UV_LEN) {
                val l0u = left[ia]
                val l0v = left[ia + 1]
                val r0u = right[ia]
                val r0v = right[ia + 1]
                val l1u = left[ib]
                val l1v = left[ib + 1]
                val r1u = right[ib]
                val r1v = right[ib + 1]
                emitTriangleClippedToUnitSquare(l0u, l0v, r0u, r0v, r1u, r1v, out)
                emitTriangleClippedToUnitSquare(l0u, l0v, r1u, r1v, l1u, l1v, out)
            }
        }
        if (style.lineJoin == LineJoin.ROUND) {
            for (i in 0 until nPts) {
                val prevSeg = (i + nPts - 1) % nPts
                val curSeg = i % nPts
                val km1 = prevSeg shl 1
                val k = curSeg shl 1
                val t0u = segDir[km1]
                val t0v = segDir[km1 + 1]
                val t1u = segDir[k]
                val t1v = segDir[k + 1]
                val cos = t0u * t1u + t0v * t1v
                if (cos < ROUND_JOIN_SKIP_COS) {
                    val pu = path[k]
                    val pv = path[k + 1]
                    emitRoundJoinFan(
                        pu, pv,
                        segNorm[km1], segNorm[km1 + 1],
                        segNorm[k], segNorm[k + 1],
                        t0u, t0v,
                        t1u, t1v,
                        halfW,
                        out,
                    )
                }
            }
        }
    }

    private fun emitLineRibbonFromPath(pathUv: FloatArray, halfW: Float, style: LineRibbonStyle, out: FloatArrayList) {
        if (isClosedRingPath(pathUv)) {
            emitClosedLineRibbonFromPath(pathUv, halfW, style, out)
            return
        }
        if (pathUv.size < 4) return
        val nPts = pathUv.size ushr 1
        if (nPts < 2) return
        val nSeg = nPts - 1
        // segDir[i*2..i*2+1] = unit tangent of segment i; segNorm = perpendicular. Storing as
        // interleaved `FloatArray` keeps the per-path allocation to two primitive buffers and
        // lets the JIT scalar-replace the indexed loads. The previous `ArrayList<V2>` produced
        // a `V2` per point × five lists per path × thousands of points per motorway tile —
        // the visible chunk of Demo 3's per-build LOS GC after the float-accumulator switch.
        val segDir = FloatArray(nSeg * 2)
        val segNorm = FloatArray(nSeg * 2)
        run {
            var i = 0
            var idx = 0
            while (i < nSeg) {
                val au = pathUv[idx]
                val av = pathUv[idx + 1]
                val bu = pathUv[idx + 2]
                val bv = pathUv[idx + 3]
                val du0 = bu - au
                val dv0 = bv - av
                val len = hypot(du0.toDouble(), dv0.toDouble()).toFloat()
                val two = i shl 1
                if (len < 1e-6f) {
                    segDir[two] = 1f
                    segDir[two + 1] = 0f
                    segNorm[two] = 0f
                    segNorm[two + 1] = 1f
                } else {
                    val du = du0 / len
                    val dv = dv0 / len
                    segDir[two] = du
                    segDir[two + 1] = dv
                    segNorm[two] = -dv
                    segNorm[two + 1] = du
                }
                i++
                idx += 2
            }
        }
        // Start cap: first point + first segment direction/normal.
        val p0u = pathUv[0]
        val p0v = pathUv[1]
        val sd0u = segDir[0]
        val sd0v = segDir[1]
        val sn0u = segNorm[0]
        val sn0v = segNorm[1]
        when (style.lineCap) {
            LineCap.SQUARE -> emitSquareStartCap(p0u, p0v, sd0u, sd0v, sn0u, sn0v, halfW, out)
            LineCap.ROUND -> emitRoundCap(p0u, p0v, sd0u, sd0v, halfW, atStart = true, out)
            LineCap.BUTT -> {}
        }
        // Per-point ribbon offsets. `left[i*2..i*2+1]` and `right[i*2..i*2+1]` mirror the previous
        // `ArrayList<V2>` layout one-to-one.
        val left = FloatArray(nPts * 2)
        val right = FloatArray(nPts * 2)
        val miterMaxExtrusion = halfW * style.miterLimit
        val isMiter = style.lineJoin == LineJoin.MITER
        val lastIdx = nPts - 1
        run {
            var i = 0
            while (i < nPts) {
                val pu = pathUv[i shl 1]
                val pv = pathUv[(i shl 1) + 1]
                val offU: Float
                val offV: Float
                when (i) {
                    0 -> {
                        offU = segNorm[0] * halfW
                        offV = segNorm[1] * halfW
                    }
                    lastIdx -> {
                        val k = (nSeg - 1) shl 1
                        offU = segNorm[k] * halfW
                        offV = segNorm[k + 1] * halfW
                    }
                    else -> {
                        val km1 = (i - 1) shl 1
                        val k = i shl 1
                        val n0u = segNorm[km1]
                        val n0v = segNorm[km1 + 1]
                        val n1u = segNorm[k]
                        val n1v = segNorm[k + 1]
                        if (!isMiter) {
                            offU = n1u * halfW
                            offV = n1v * halfW
                        } else {
                            val t0u = segDir[km1]
                            val t0v = segDir[km1 + 1]
                            val t1u = segDir[k]
                            val t1v = segDir[k + 1]
                            val mx = n0u + n1u
                            val my = n0v + n1v
                            val mLen = hypot(mx.toDouble(), my.toDouble()).toFloat()
                            if (mLen < 1e-5f || (t0u * t1u + t0v * t1v) < -0.95f) {
                                offU = n1u * halfW
                                offV = n1v * halfW
                            } else {
                                val mu = mx / mLen
                                val mv = my / mLen
                                val denom = mu * n1u + mv * n1v
                                if (abs(denom) < 1e-4f) {
                                    offU = n1u * halfW
                                    offV = n1v * halfW
                                } else {
                                    val scale = halfW / denom
                                    val clamped = scale.coerceIn(-miterMaxExtrusion, miterMaxExtrusion)
                                    offU = mu * clamped
                                    offV = mv * clamped
                                }
                            }
                        }
                    }
                }
                val twoI = i shl 1
                left[twoI] = pu - offU
                left[twoI + 1] = pv - offV
                right[twoI] = pu + offU
                right[twoI + 1] = pv + offV
                i++
            }
        }
        // Segment quads.
        run {
            var i = 0
            var idx = 0
            while (i < nSeg) {
                val au = pathUv[idx]
                val av = pathUv[idx + 1]
                val bu = pathUv[idx + 2]
                val bv = pathUv[idx + 3]
                val dx = bu - au
                val dy = bv - av
                if (hypot(dx.toDouble(), dy.toDouble()) <= MAX_LINE_SEGMENT_UV_LEN) {
                    val l0u = left[idx]
                    val l0v = left[idx + 1]
                    val r0u = right[idx]
                    val r0v = right[idx + 1]
                    val l1u = left[idx + 2]
                    val l1v = left[idx + 3]
                    val r1u = right[idx + 2]
                    val r1v = right[idx + 3]
                    emitTriangleClippedToUnitSquare(l0u, l0v, r0u, r0v, r1u, r1v, out)
                    emitTriangleClippedToUnitSquare(l0u, l0v, r1u, r1v, l1u, l1v, out)
                }
                i++
                idx += 2
            }
        }
        if (style.lineJoin == LineJoin.ROUND) {
            // Skip the fan whenever consecutive segments are near-collinear. The fan would
            // collapse into a sub-pixel sliver, the adjacent segment quads already overlap, and
            // emitting it is the dominant cost on long highways (see [ROUND_JOIN_SKIP_COS]).
            var i = 1
            while (i < lastIdx) {
                val km1 = (i - 1) shl 1
                val k = i shl 1
                val t0u = segDir[km1]
                val t0v = segDir[km1 + 1]
                val t1u = segDir[k]
                val t1v = segDir[k + 1]
                val cos = t0u * t1u + t0v * t1v
                if (cos < ROUND_JOIN_SKIP_COS) {
                    val pu = pathUv[k]
                    val pv = pathUv[k + 1]
                    emitRoundJoinFan(
                        pu, pv,
                        segNorm[km1], segNorm[km1 + 1],
                        segNorm[k], segNorm[k + 1],
                        t0u, t0v,
                        t1u, t1v,
                        halfW,
                        out,
                    )
                }
                i++
            }
        }
        // End cap: last point + last segment direction/normal.
        val pLu = pathUv[lastIdx shl 1]
        val pLv = pathUv[(lastIdx shl 1) + 1]
        val lastSeg = (nSeg - 1) shl 1
        val sdLu = segDir[lastSeg]
        val sdLv = segDir[lastSeg + 1]
        val snLu = segNorm[lastSeg]
        val snLv = segNorm[lastSeg + 1]
        when (style.lineCap) {
            LineCap.SQUARE -> emitSquareEndCap(pLu, pLv, sdLu, sdLv, snLu, snLv, halfW, out)
            LineCap.ROUND -> emitRoundCap(pLu, pLv, sdLu, sdLv, halfW, atStart = false, out)
            LineCap.BUTT -> {}
        }
    }

    private fun triangulatePolygon(
        z: Int,
        tx: Int,
        ty: Int,
        world: Int,
        poly: Polygon,
        out: FloatArrayList,
    ) {
        val rings = poly.coordinates()
        if (rings.isEmpty()) return
        val flat = ArrayList<Double>(64)
        val holeIndices = ArrayList<Int>()
        for ((idx, ring) in rings.withIndex()) {
            if (idx > 0) {
                holeIndices.add(flat.size / 2)
            }
            if (ring.size < 3) continue
            val n = ring.size - if (ring.first() == ring.last()) 1 else 0
            for (i in 0 until n) {
                val p = ring[i]
                val (u, v) = lonLatToTileUv(z, tx, ty, world, p.longitude(), p.latitude())
                flat.add(u.toDouble())
                flat.add(v.toDouble())
            }
        }
        if (flat.size < 6) return
        val holes = if (holeIndices.isEmpty()) null else holeIndices.toIntArray()
        val triangles = Earcut.earcut(flat.toDoubleArray(), holes, 2)
        var ti = 0
        while (ti + 2 < triangles.size) {
            val a = triangles[ti++].toInt()
            val b = triangles[ti++].toInt()
            val c = triangles[ti++].toInt()
            val ax = flat[a * 2].toFloat()
            val ay = flat[a * 2 + 1].toFloat()
            val bx = flat[b * 2].toFloat()
            val by = flat[b * 2 + 1].toFloat()
            val cx = flat[c * 2].toFloat()
            val cy = flat[c * 2 + 1].toFloat()
            emitTriangleClippedToUnitSquare(ax, ay, bx, by, cx, cy, out)
        }
    }

    private data class P2(val u: Float, val v: Float)

    private fun clipPolygonToUnitSquare(poly: List<P2>): List<P2> {
        if (poly.size < 3) return emptyList()
        // Single-pass min/max keeps this allocation-free; the lambda overloads were each walking
        // the list and the helper objects show up in heap profiles for wide ribbons with many
        // round joins (one polygon per join, hundreds of joins per tile).
        var minU = Float.MAX_VALUE
        var maxU = -Float.MAX_VALUE
        var minV = Float.MAX_VALUE
        var maxV = -Float.MAX_VALUE
        for (p in poly) {
            if (p.u < minU) minU = p.u
            if (p.u > maxU) maxU = p.u
            if (p.v < minV) minV = p.v
            if (p.v > maxV) maxV = p.v
        }
        if (maxU < -UV_EPS || minU > 1f + UV_EPS || maxV < -UV_EPS || minV > 1f + UV_EPS) return emptyList()
        // Fast path: polygon already fits inside the unit tile, so no edge produces a new vertex.
        // Sutherland-Hodgman would otherwise allocate four new ArrayList<P2>s (one per edge) plus
        // intermediate `P2` intersection objects for every join/cap, which is the dominant
        // remaining GC source after switching the float accumulator to a primitive buffer.
        if (minU >= -UV_EPS && maxU <= 1f + UV_EPS && minV >= -UV_EPS && maxV <= 1f + UV_EPS) {
            return poly
        }

        fun clipAgainst(p: List<P2>, inside: (P2) -> Boolean, intersect: (P2, P2) -> P2): List<P2> {
            if (p.isEmpty()) return emptyList()
            val res = ArrayList<P2>(p.size + 2)
            var prev = p.last()
            var prevInside = inside(prev)
            for (cur in p) {
                val curInside = inside(cur)
                if (curInside) {
                    if (!prevInside) res.add(intersect(prev, cur))
                    res.add(cur)
                } else if (prevInside) {
                    res.add(intersect(prev, cur))
                }
                prev = cur
                prevInside = curInside
            }
            return res
        }

        fun intersectVertical(a: P2, b: P2, xEdge: Float): P2 {
            val du = b.u - a.u
            if (abs(du) < 1e-8f) return P2(xEdge, a.v)
            val t = (xEdge - a.u) / du
            return P2(xEdge, a.v + t * (b.v - a.v))
        }

        fun intersectHorizontal(a: P2, b: P2, yEdge: Float): P2 {
            val dv = b.v - a.v
            if (abs(dv) < 1e-8f) return P2(a.u, yEdge)
            val t = (yEdge - a.v) / dv
            return P2(a.u + t * (b.u - a.u), yEdge)
        }

        var p = poly
        p = clipAgainst(p, { it.u >= -UV_EPS }, { p0, p1 -> intersectVertical(p0, p1, 0f) })
        p = clipAgainst(p, { it.u <= 1f + UV_EPS }, { p0, p1 -> intersectVertical(p0, p1, 1f) })
        p = clipAgainst(p, { it.v >= -UV_EPS }, { p0, p1 -> intersectHorizontal(p0, p1, 0f) })
        p = clipAgainst(p, { it.v <= 1f + UV_EPS }, { p0, p1 -> intersectHorizontal(p0, p1, 1f) })
        return p
    }

    /**
     * Fan-triangulates a **convex** polygon after clipping to the unit tile (same space as line ribbons).
     * Vertices must be ordered consistently (CCW or CW).
     */
    private fun emitConvexPolygonClippedToUnitSquare(poly: List<P2>, out: FloatArrayList) {
        val clipped = clipPolygonToUnitSquare(poly)
        if (clipped.size < 3) return

        val root = clipped[0]
        var i = 1
        while (i + 1 < clipped.size) {
            val p1 = clipped[i]
            val p2 = clipped[i + 1]
            val area2 = (p1.u - root.u) * (p2.v - root.v) - (p2.u - root.u) * (p1.v - root.v)
            if (abs(area2) > 1e-8f) {
                // Clipping already constrained to [0,1]; clamp only fixes FP noise (avoids pinning huge coords to corners).
                out.add(
                    root.u.coerceIn(0f, 1f),
                    root.v.coerceIn(0f, 1f),
                    p1.u.coerceIn(0f, 1f),
                    p1.v.coerceIn(0f, 1f),
                    p2.u.coerceIn(0f, 1f),
                    p2.v.coerceIn(0f, 1f),
                )
            }
            i++
        }
    }

    private fun emitTriangleClippedToUnitSquare(
        ax: Float,
        ay: Float,
        bx: Float,
        by: Float,
        cx: Float,
        cy: Float,
        out: FloatArrayList,
    ) {
        // Bounding box reject: triangle entirely outside the tile.
        val minU = if (ax < bx) (if (ax < cx) ax else cx) else (if (bx < cx) bx else cx)
        val maxU = if (ax > bx) (if (ax > cx) ax else cx) else (if (bx > cx) bx else cx)
        val minV = if (ay < by) (if (ay < cy) ay else cy) else (if (by < cy) by else cy)
        val maxV = if (ay > by) (if (ay > cy) ay else cy) else (if (by > cy) by else cy)
        if (maxU < -UV_EPS || minU > 1f + UV_EPS || maxV < -UV_EPS || minV > 1f + UV_EPS) return
        // Fast path: entirely inside. Allocation-free, just two area checks + a six-float write.
        // This covers the overwhelming majority of segment triangles (~10⁵ per tile for the demo
        // motorway path), so it has to stay tight — going through the convex-polygon clipper to
        // build a `listOf(P2, P2, P2)` is what was generating the 25 MB/build of garbage.
        if (minU >= -UV_EPS && maxU <= 1f + UV_EPS && minV >= -UV_EPS && maxV <= 1f + UV_EPS) {
            emitTriangleFastNoClip(ax, ay, bx, by, cx, cy, out)
            return
        }
        // Slow path: triangle crosses a tile edge. This is rare relative to the total triangle
        // count, so the allocation here is OK.
        emitConvexPolygonClippedToUnitSquare(listOf(P2(ax, ay), P2(bx, by), P2(cx, cy)), out)
    }

    /**
     * Emit a triangle that is already known to fit inside the unit tile. Skips the bbox + clip
     * machinery; only clamps to `[0,1]` to absorb floating-point noise (mirroring the legacy
     * convex-polygon emit), and drops degenerate triangles via the standard signed-area test.
     */
    private fun emitTriangleFastNoClip(
        ax: Float,
        ay: Float,
        bx: Float,
        by: Float,
        cx: Float,
        cy: Float,
        out: FloatArrayList,
    ) {
        val area2 = (bx - ax) * (cy - ay) - (cx - ax) * (by - ay)
        if (abs(area2) <= 1e-8f) return
        out.add(
            ax.coerceIn(0f, 1f),
            ay.coerceIn(0f, 1f),
            bx.coerceIn(0f, 1f),
            by.coerceIn(0f, 1f),
            cx.coerceIn(0f, 1f),
            cy.coerceIn(0f, 1f),
        )
    }

    /**
     * Allocation-free fast path for convex quads (the square cap shape). Falls back to the slow
     * polygon clipper only when the quad straddles a tile edge.
     */
    private fun emitQuadClippedToUnitSquare(
        u0: Float, v0: Float,
        u1: Float, v1: Float,
        u2: Float, v2: Float,
        u3: Float, v3: Float,
        out: FloatArrayList,
    ) {
        val minU = minOf(minOf(u0, u1), minOf(u2, u3))
        val maxU = maxOf(maxOf(u0, u1), maxOf(u2, u3))
        val minV = minOf(minOf(v0, v1), minOf(v2, v3))
        val maxV = maxOf(maxOf(v0, v1), maxOf(v2, v3))
        if (maxU < -UV_EPS || minU > 1f + UV_EPS || maxV < -UV_EPS || minV > 1f + UV_EPS) return
        if (minU >= -UV_EPS && maxU <= 1f + UV_EPS && minV >= -UV_EPS && maxV <= 1f + UV_EPS) {
            emitTriangleFastNoClip(u0, v0, u1, v1, u2, v2, out)
            emitTriangleFastNoClip(u0, v0, u2, v2, u3, v3, out)
            return
        }
        emitConvexPolygonClippedToUnitSquare(listOf(P2(u0, v0), P2(u1, v1), P2(u2, v2), P2(u3, v3)), out)
    }

    /**
     * Web Mercator tile UV: u/v in [0,1] over the tile.
     * In this render path tile-local Y is already north->south aligned with Mercator row space,
     * so use v_mercator directly (no extra flip) to avoid per-tile vertical inversion.
     */
    fun lonLatToTileUv(z: Int, tx: Int, ty: Int, world: Int, lon: Double, lat: Double): Pair<Float, Float> {
        val xf = (lon + 180.0) / 360.0 * world
        val u = (xf - tx).toFloat()
        val latRad = Math.toRadians(lat)
        val sinLat = kotlin.math.sin(latRad)
        val yNorm = 0.5 - 0.25 * ln((1.0 + sinLat) / (1.0 - sinLat)) / PI
        val yf = yNorm * world
        val vMerc = (yf - ty).toFloat()
        return Pair(u, vMerc)
    }

    // region Path simplification (A) and clip-to-mask-region (D)

    fun simplifyToleranceTileUv(zoom: Int, halfWidthUv: Float): Float {
        val z = zoom.coerceIn(0, 24)
        val tileScale = 1f / (1 shl z).toFloat().coerceAtLeast(1f)
        return maxOf(halfWidthUv * SIMPLIFY_HALF_WIDTH_MULT, tileScale * SIMPLIFY_MIN_TILE_UV * 4f)
    }

    fun simplifyLinePaths(paths: List<LinePath>, zoom: Int, halfWidthUv: Float): List<LinePath> {
        if (paths.isEmpty()) return paths
        val tol = simplifyToleranceTileUv(zoom, halfWidthUv)
        val out = ArrayList<LinePath>(paths.size)
        for (path in paths) {
            val simplified = simplifyPathTileUv(path.pointsUv, tol)
            if (simplified.size >= 4) {
                out.add(LinePath(simplified, closed = path.closed))
            }
        }
        return out
    }

    private fun simplifyPathTileUv(points: FloatArray, tolerance: Float): FloatArray {
        val n = points.size ushr 1
        if (n < 3 || tolerance <= 0f) return points
        val keep = BooleanArray(n)
        keep[0] = true
        keep[n - 1] = true
        douglasPeuckerRange(points, 0, n - 1, tolerance * tolerance, keep)
        val count = keep.count { it }
        if (count == n) return points
        val out = FloatArray(count * 2)
        var o = 0
        for (i in 0 until n) {
            if (!keep[i]) continue
            out[o++] = points[i * 2]
            out[o++] = points[i * 2 + 1]
        }
        return out
    }

    private fun douglasPeuckerRange(
        points: FloatArray,
        start: Int,
        end: Int,
        toleranceSq: Float,
        keep: BooleanArray,
    ) {
        if (end <= start + 1) return
        val ax = points[start * 2]
        val ay = points[start * 2 + 1]
        val bx = points[end * 2]
        val by = points[end * 2 + 1]
        var maxDistSq = 0f
        var maxIdx = start
        for (i in start + 1 until end) {
            val px = points[i * 2]
            val py = points[i * 2 + 1]
            val d = perpendicularDistSq(px, py, ax, ay, bx, by)
            if (d > maxDistSq) {
                maxDistSq = d
                maxIdx = i
            }
        }
        if (maxDistSq > toleranceSq) {
            keep[maxIdx] = true
            douglasPeuckerRange(points, start, maxIdx, toleranceSq, keep)
            douglasPeuckerRange(points, maxIdx, end, toleranceSq, keep)
        }
    }

    private fun perpendicularDistSq(px: Float, py: Float, ax: Float, ay: Float, bx: Float, by: Float): Float {
        val dx = bx - ax
        val dy = by - ay
        val lenSq = dx * dx + dy * dy
        if (lenSq < 1e-12f) {
            val ex = px - ax
            val ey = py - ay
            return ex * ex + ey * ey
        }
        val t = ((px - ax) * dx + (py - ay) * dy) / lenSq
        val tc = t.coerceIn(0f, 1f)
        val cx = ax + tc * dx
        val cy = ay + tc * dy
        val ex = px - cx
        val ey = py - cy
        return ex * ex + ey * ey
    }

    /** Exterior rings of polygon features in the same tile-UV space as [extractLinePathsTileUv]. */
    fun extractPolygonExteriorRingsTileUv(coord: TileCoord, features: List<Feature>): List<FloatArray> {
        if (features.isEmpty()) return emptyList()
        val z = coord.z
        val tx = coord.x
        val ty = coord.y
        val world = 1 shl z
        val rings = ArrayList<FloatArray>(4)
        for (f in features) {
            when (val g = f.geometry()) {
                is Polygon -> {
                    val ring = g.coordinates().firstOrNull() ?: continue
                    ringToTileUvOpenPath(z, tx, ty, world, ring)?.let { rings.add(it) }
                }
                is MultiPolygon -> {
                    for (poly in g.coordinates()) {
                        val ring = poly.firstOrNull() ?: continue
                        ringToTileUvOpenPath(z, tx, ty, world, ring)?.let { rings.add(it) }
                    }
                }
                else -> {}
            }
        }
        return rings
    }

    private fun ringToTileUvOpenPath(z: Int, tx: Int, ty: Int, world: Int, ring: List<Point>): FloatArray? {
        if (ring.size < 3) return null
        val n = ring.size - if (ring.first() == ring.last()) 1 else 0
        if (n < 3) return null
        val flat = FloatArrayList(n * 2)
        for (i in 0 until n) {
            val p = ring[i]
            val (u, v) = lonLatToTileUv(z, tx, ty, world, p.longitude(), p.latitude())
            flat.add(u, v)
        }
        return if (flat.size >= 6) flat.toFloatArray() else null
    }

    fun clipLinePathsToPolygons(paths: List<LinePath>, polygonRings: List<FloatArray>): List<LinePath> {
        if (paths.isEmpty() || polygonRings.isEmpty()) return paths
        val out = ArrayList<LinePath>(paths.size)
        for (path in paths) {
            for (piece in clipPathToPolygons(path.pointsUv, polygonRings)) {
                if (piece.size >= 4) out.add(LinePath(piece))
            }
        }
        return out
    }

    fun clipLinePathsToLatLonBounds(
        paths: List<LinePath>,
        coord: TileCoord,
        bounds: LatLonBounds,
    ): List<LinePath> {
        val rect = latLonBoundsUvRect(coord, bounds) ?: return emptyList()
        val out = ArrayList<LinePath>(paths.size)
        for (path in paths) {
            for (piece in clipPathToUvRect(path.pointsUv, rect)) {
                if (piece.size >= 4) out.add(LinePath(piece))
            }
        }
        return out
    }

    /** `[minU, minV, maxU, maxV]` in tile-UV space, or null if the tile does not intersect [bounds]. */
    private fun latLonBoundsUvRect(coord: TileCoord, bounds: LatLonBounds): FloatArray? {
        val z = coord.z
        if (z !in 0..30) return null
        val world = 1 shl z
        val ox = coord.x.toFloat()
        val oy = coord.y.toFloat()
        val n = world.toDouble()
        val tw = ox / n * 360.0 - 180.0
        val te = (ox + 1f) / n * 360.0 - 180.0
        val northLat = latDegreesFromMercatorYNorm(oy.toDouble() / n)
        val southLat = latDegreesFromMercatorYNorm((oy + 1f).toDouble() / n)
        val ts = minOf(southLat, northLat)
        val tn = maxOf(southLat, northLat)
        val ix0 = maxOf(tw, bounds.westExtent)
        val ix1 = minOf(te, bounds.eastExtent)
        val iy0 = maxOf(ts, bounds.southExtent)
        val iy1 = minOf(tn, bounds.northExtent)
        if (ix0 >= ix1 || iy0 >= iy1) return null
        val (u0, v0) = lonLatToTileUv(z, coord.x, coord.y, world, ix0, iy0)
        val (u1, v1) = lonLatToTileUv(z, coord.x, coord.y, world, ix1, iy0)
        val (u2, v2) = lonLatToTileUv(z, coord.x, coord.y, world, ix1, iy1)
        val (u3, v3) = lonLatToTileUv(z, coord.x, coord.y, world, ix0, iy1)
        val minU = minOf(u0, u1, u2, u3)
        val maxU = maxOf(u0, u1, u2, u3)
        val minV = minOf(v0, v1, v2, v3)
        val maxV = maxOf(v0, v1, v2, v3)
        return floatArrayOf(minU, minV, maxU, maxV)
    }

    private fun clipPathToUvRect(points: FloatArray, rect: FloatArray): List<FloatArray> {
        val minU = rect[0]
        val minV = rect[1]
        val maxU = rect[2]
        val maxV = rect[3]
        val n = points.size ushr 1
        if (n < 2) return emptyList()
        val pieces = ArrayList<FloatArray>(2)
        var current = FloatArrayList(16)
        fun flush() {
            if (current.size >= 4) pieces.add(current.toFloatArray())
            current = FloatArrayList(16)
        }
        var lastU = Float.NaN
        var lastV = Float.NaN
        var i = 0
        while (i < n - 1) {
            val seg = clipSegmentToUvRect(
                points[i * 2],
                points[i * 2 + 1],
                points[(i + 1) * 2],
                points[(i + 1) * 2 + 1],
                minU,
                minV,
                maxU,
                maxV,
            )
            if (seg.hit) {
                if (current.size == 0) {
                    current.add(seg.au, seg.av)
                    lastU = seg.au
                    lastV = seg.av
                } else if (hypot((seg.au - lastU).toDouble(), (seg.av - lastV).toDouble()) > 1e-5) {
                    flush()
                    current.add(seg.au, seg.av)
                    lastU = seg.au
                    lastV = seg.av
                }
                current.add(seg.bu, seg.bv)
                lastU = seg.bu
                lastV = seg.bv
            } else {
                flush()
                lastU = Float.NaN
                lastV = Float.NaN
            }
            i++
        }
        flush()
        return pieces
    }

    private fun clipSegmentToUvRect(
        au: Float,
        av: Float,
        bu: Float,
        bv: Float,
        minU: Float,
        minV: Float,
        maxU: Float,
        maxV: Float,
    ): SegmentClipHit {
        var t0 = 0f
        var t1 = 1f
        val du = bu - au
        val dv = bv - av
        fun clip(p: Float, q: Float): Boolean {
            if (abs(p) < 1e-9f) return q >= 0f
            val r = q / p
            if (p < 0f) {
                if (r > t1) return false
                if (r > t0) t0 = r
            } else {
                if (r < t0) return false
                if (r < t1) t1 = r
            }
            return true
        }
        if (!clip(-du, au - minU)) return SegmentClipHit.MISS
        if (!clip(du, maxU - au)) return SegmentClipHit.MISS
        if (!clip(-dv, av - minV)) return SegmentClipHit.MISS
        if (!clip(dv, maxV - av)) return SegmentClipHit.MISS
        if (t1 < t0) return SegmentClipHit.MISS
        val outAu = au + du * t0
        val outAv = av + dv * t0
        val outBu = au + du * t1
        val outBv = av + dv * t1
        return SegmentClipHit(outAu, outAv, outBu, outBv, true)
    }

    private data class SegmentClipHit(
        val au: Float,
        val av: Float,
        val bu: Float,
        val bv: Float,
        val hit: Boolean,
    ) {
        companion object {
            val MISS = SegmentClipHit(0f, 0f, 0f, 0f, false)
        }
    }

    private fun clipPathToPolygons(points: FloatArray, polygonRings: List<FloatArray>): List<FloatArray> {
        val n = points.size ushr 1
        if (n < 2) return emptyList()
        val pieces = ArrayList<FloatArray>(4)
        var current = FloatArrayList(16)
        fun flush() {
            if (current.size >= 4) pieces.add(current.toFloatArray())
            current = FloatArrayList(16)
        }
        var i = 0
        while (i < n - 1) {
            val ax = points[i * 2]
            val ay = points[i * 2 + 1]
            val bx = points[(i + 1) * 2]
            val by = points[(i + 1) * 2 + 1]
            val aIn = pointInAnyPolygon(ax, ay, polygonRings)
            val bIn = pointInAnyPolygon(bx, by, polygonRings)
            when {
                aIn && bIn -> {
                    if (current.size == 0) current.add(ax, ay)
                    current.add(bx, by)
                }
                aIn && !bIn -> {
                    val hit = firstPolygonExit(ax, ay, bx, by, polygonRings)
                    if (current.size == 0) current.add(ax, ay)
                    if (hit != null) current.add(hit.first, hit.second)
                    flush()
                }
                !aIn && bIn -> {
                    val hit = firstPolygonEntry(ax, ay, bx, by, polygonRings)
                    if (hit != null) {
                        current.add(hit.first, hit.second)
                    }
                    current.add(bx, by)
                }
                else -> {
                    val entry = firstPolygonEntry(ax, ay, bx, by, polygonRings)
                    val exit = firstPolygonExit(ax, ay, bx, by, polygonRings)
                    if (entry != null && exit != null) {
                        current.add(entry.first, entry.second)
                        current.add(exit.first, exit.second)
                        flush()
                    } else {
                        flush()
                    }
                }
            }
            i++
        }
        flush()
        return pieces
    }

    private fun pointInAnyPolygon(u: Float, v: Float, rings: List<FloatArray>): Boolean {
        for (ring in rings) {
            if (pointInPolygonUv(u, v, ring)) return true
        }
        return false
    }

    private fun pointInPolygonUv(u: Float, v: Float, ring: FloatArray): Boolean {
        val n = ring.size ushr 1
        if (n < 3) return false
        var inside = false
        var j = n - 1
        for (i in 0 until n) {
            val xi = ring[i * 2]
            val yi = ring[i * 2 + 1]
            val xj = ring[j * 2]
            val yj = ring[j * 2 + 1]
            val intersect = ((yi > v) != (yj > v)) &&
                (u < (xj - xi) * (v - yi) / (yj - yi + 1e-12f) + xi)
            if (intersect) inside = !inside
            j = i
        }
        return inside
    }

    private fun firstPolygonEntry(
        ax: Float,
        ay: Float,
        bx: Float,
        by: Float,
        rings: List<FloatArray>,
    ): Pair<Float, Float>? {
        var bestT = 2f
        var best: Pair<Float, Float>? = null
        for (ring in rings) {
            val hit = segmentPolygonIntersection(ax, ay, bx, by, ring, wantEntry = true) ?: continue
            if (hit.third < bestT) {
                bestT = hit.third
                best = Pair(hit.first, hit.second)
            }
        }
        return best
    }

    private fun firstPolygonExit(
        ax: Float,
        ay: Float,
        bx: Float,
        by: Float,
        rings: List<FloatArray>,
    ): Pair<Float, Float>? {
        var bestT = -1f
        var best: Pair<Float, Float>? = null
        for (ring in rings) {
            val hit = segmentPolygonIntersection(ax, ay, bx, by, ring, wantEntry = false) ?: continue
            if (hit.third > bestT) {
                bestT = hit.third
                best = Pair(hit.first, hit.second)
            }
        }
        return best
    }

    /** Returns (u, v, t along AB) for the boundary crossing nearest A (entry) or farthest from A inside (exit). */
    private fun segmentPolygonIntersection(
        ax: Float,
        ay: Float,
        bx: Float,
        by: Float,
        ring: FloatArray,
        wantEntry: Boolean,
    ): Triple<Float, Float, Float>? {
        val n = ring.size ushr 1
        if (n < 2) return null
        var chosen: Triple<Float, Float, Float>? = null
        var i = 0
        while (i < n) {
            val j = (i + 1) % n
            val cx = ring[i * 2]
            val cy = ring[i * 2 + 1]
            val dx = ring[j * 2]
            val dy = ring[j * 2 + 1]
            val hit = segmentSegmentIntersection(ax, ay, bx, by, cx, cy, dx, dy)
            if (hit != null) {
                val t = hit.third
                if (chosen == null) {
                    chosen = hit
                } else if (wantEntry) {
                    if (t < chosen.third) chosen = hit
                } else {
                    if (t > chosen.third) chosen = hit
                }
            }
            i++
        }
        return chosen
    }

    private fun segmentSegmentIntersection(
        ax: Float,
        ay: Float,
        bx: Float,
        by: Float,
        cx: Float,
        cy: Float,
        dx: Float,
        dy: Float,
    ): Triple<Float, Float, Float>? {
        val rX = bx - ax
        val rY = by - ay
        val sX = dx - cx
        val sY = dy - cy
        val denom = rX * sY - rY * sX
        if (abs(denom) < 1e-9f) return null
        val qpx = cx - ax
        val qpy = cy - ay
        val t = (qpx * sY - qpy * sX) / denom
        val u = (qpx * rY - qpy * rX) / denom
        if (t < 0f || t > 1f || u < 0f || u > 1f) return null
        return Triple(ax + t * rX, ay + t * rY, t)
    }

    // endregion
}
