package com.xweather.mapsgl.map.mapbox

/**
 * Per-thread `let` / `var` bindings for GLES expression eval. Nested [withScope] calls search
 * innermost-first. Unbound names return null (fail closed).
 */
internal object ExpressionLetScope {
    private val scopes = ThreadLocal<ArrayDeque<MutableMap<String, Any?>>>()

    fun lookup(name: String): Any? {
        val stack = scopes.get() ?: return null
        for (i in stack.indices.reversed()) {
            if (stack[i].containsKey(name)) return stack[i][name]
        }
        return null
    }

    fun <T> withScope(bindings: MutableMap<String, Any?>, block: () -> T): T {
        val stack = scopes.get() ?: ArrayDeque<MutableMap<String, Any?>>().also { scopes.set(it) }
        stack.addLast(bindings)
        try {
            return block()
        } finally {
            stack.removeLast()
            if (stack.isEmpty()) scopes.remove()
        }
    }
}
