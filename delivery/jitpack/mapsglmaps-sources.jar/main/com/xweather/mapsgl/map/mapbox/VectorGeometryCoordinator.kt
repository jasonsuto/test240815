package com.xweather.mapsgl.map.mapbox

import androidx.compose.ui.graphics.Color
import com.mapbox.geojson.Feature
import com.xweather.mapsgl.layers.tile.VectorTileLayer
import com.xweather.mapsgl.map.MapController
import com.xweather.mapsgl.sources.VectorTileSource
import com.xweather.mapsgl.sources.VectorData
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.FillLayerPaint
import com.xweather.mapsgl.style.LineLayerPaint
import com.xweather.mapsgl.style.StyleValue
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.map.mapbox.GlStencilOsm
import com.xweather.mapsgl.utils.formatDateArrayToString
import com.xweather.mapsgl.util.MapsGLDebug
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.launch
import java.nio.FloatBuffer
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/**
 * Registers MVT tile listeners and builds per-tile geometry for fill/line layers that draw
 * via [com.xweather.mapsgl.renderers.VectorGeometryRenderer] instead of Mapbox style layers.
 *
 * Fill polygons are cached as triangle meshes. Line work is cached as centerline [LineTilePathCache]
 * and expanded to screen-pixel ribbons at draw time ([prepareLineMeshesForDraw]) so width stays
 * constant across zoom (Mapbox `line-width` behavior).
 */
internal object VectorGeometryCoordinator {

    private const val TAG = "VectorGeometry"

    private val meshBuildDispatcher = Executors.newFixedThreadPool(2) { r ->
        Thread(r, "mapsgl-vector-geom").apply { isDaemon = true }
    }.asCoroutineDispatcher()
    private val meshBuildScope = CoroutineScope(SupervisorJob() + meshBuildDispatcher)

    private data class Registration(val undo: List<() -> Unit>)

    private data class LineTilePathCache(
        val paths: List<GlStencilMaskMeshBuilder.LinePath>,
        val style: GlStencilMaskMeshBuilder.LineRibbonStyle,
        val coord: TileCoord,
        val thicknessPx: Double,
    )

    private val registrations = ConcurrentHashMap<String, Registration>()
    private val layerGeneration = ConcurrentHashMap<String, Int>()
    private val pendingBuildKeys = ConcurrentHashMap.newKeySet<String>()
    private val cachedLinePaths = ConcurrentHashMap<String, LineTilePathCache>()
    /** Overscale used when the current line ribbon mesh was built for `(meshLayerId, tile)`. */
    private val lineMeshOverscale = ConcurrentHashMap<String, Float>()

    fun register(controller: MapController, layer: VectorTileLayer) {
        if (!layer.glRenderingActive()) return
        unregister(controller, layer.id)
        val sl = layer.sourceLayer
        val vts = layer.source as? VectorTileSource ?: return

        val undo = mutableListOf<() -> Unit>()
        if (!sl.isNullOrEmpty()) {
            undo.add(vts.addStencilParseLayerDependency(sl))
        }
        val listenerId = "vector_geom_${layer.id}"
        undo.add(
            vts.addCustomStencilTileListener(
                listenerId,
                buildTileListener(controller, layer, sl),
            ),
        )
        registrations[layer.id] = Registration(undo)
        vts.replayCustomStencilFeedsFromCachedVectorTiles()
        vts.invalidate()
    }

    fun refreshPaint(controller: MapController, layer: VectorTileLayer) {
        if (!layer.glRenderingActive()) return
        if (registrations[layer.id] == null) {
            register(controller, layer)
            return
        }
        bumpGenerationAndClearPaths(layer.id, controller)
        val vts = layer.source as? VectorTileSource ?: return
        vts.replayCustomStencilFeedsFromCachedVectorTiles()
        (controller as? MapboxMapController)?.requestRepaintCoalesced()
    }

    fun unregister(controller: MapController?, layerId: String) {
        val reg = registrations.remove(layerId) ?: return
        reg.undo.forEach { it() }
        controller?.glStencilMaskTileCache?.clearCustomMaskKind(layerId)
        controller?.glStencilMaskTileCache?.clearCustomMaskKind(FillLayerPaint.strokeOutlineLayerId(layerId))
        GlStencilMaskRendererHolder.renderer.releaseGpuForMaskLayerId(layerId)
        GlStencilMaskRendererHolder.renderer.releaseGpuForMaskLayerId(FillLayerPaint.strokeOutlineLayerId(layerId))
        VectorGeometryColorBuckets.clearLayer(controller, layerId)
        bumpGenerationAndClearPaths(layerId, controller)
    }

    /**
     * Expands cached line paths into ribbon meshes using the current map zoom / tile overscale so
     * stroke width stays constant in screen pixels (Mapbox `line-width`).
     */
    fun prepareLineMeshesForDraw(
        controller: MapController,
        layer: VectorTileLayer,
        coord: TileCoord,
        coordHash: String,
        mapZoom: Double,
    ) {
        when (val paint = layer.paint) {
            is LineLayerPaint -> {
                val tileKey = tileCacheKey(coordHash)
                val bucketIds = VectorGeometryColorBuckets.bucketIdsForTile(layer.id, coordHash)
                val requestedMeshLayerIds =
                    if (bucketIds.isEmpty()) listOf(layer.id) else bucketIds

                val missingAny =
                    requestedMeshLayerIds.any { meshLayerId ->
                        cachedLinePaths[linePathCacheKey(meshLayerId, coordHash)] == null
                    }

                if (missingAny) {
                    // GL draw should not "blink" if the async mesh build lags behind pan/zoom:
                    // build line paths synchronously from the already-decoded vector-tile cache.
                    buildLinePathsForTileSynchronously(controller, layer, coord, coordHash, tileKey, paint)
                }

                if (bucketIds.isEmpty()) {
                    expandLineMeshForDraw(controller, layer.id, coordHash, coord, mapZoom)
                } else {
                    for (bucketId in bucketIds) {
                        expandLineMeshForDraw(controller, bucketId, coordHash, coord, mapZoom)
                    }
                }
            }

            is FillLayerPaint -> {
                val strokeLayerId = FillLayerPaint.strokeOutlineLayerId(layer.id)
                expandLineMeshForDraw(controller, strokeLayerId, coordHash, coord, mapZoom)
            }

            else -> {}
        }
    }

    private fun expandLineMeshForDraw(
        controller: MapController,
        meshLayerId: String,
        coordHash: String,
        coord: TileCoord,
        mapZoom: Double,
    ) {
        val pathCache = cachedLinePaths[linePathCacheKey(meshLayerId, coordHash)] ?: return
        val overscale = CameraSync.tileRasterOverscale(mapZoom, coord.z)
        val overscaleKey = "$meshLayerId\u0000${tileCacheKey(coordHash)}"
        if (lineMeshOverscale[overscaleKey] == overscale) return

        val halfW = strokeHalfWidthUvTileSpace(pathCache.thicknessPx, coord.z, mapZoom)
        val tri =
            GlStencilMaskMeshBuilder.buildLineRibbonTileUvTrianglesFromPaths(
                pathCache.paths,
                halfW,
                pathCache.style,
                pathCache.coord,
            )
        putMesh(controller, meshLayerId, coordHash, tri)
        lineMeshOverscale[overscaleKey] = overscale
    }

    /**
     * Sync fallback for zoom/pan: when async [buildTileListener] hasn't filled
     * [cachedLinePaths] yet, derive them from the already-decoded [VectorTileSource] cache.
     */
    private fun buildLinePathsForTileSynchronously(
        controller: MapController,
        layer: VectorTileLayer,
        coord: TileCoord,
        coordHash: String,
        tileKey: String,
        paint: LineLayerPaint,
    ) {
        val vts = layer.source as? VectorTileSource ?: return
        val generation = layerGeneration[layer.id] ?: 0

        // Avoid spending time if tiles aren't ready yet.
        val coordTime = if (vts.id == GlStencilOsm.SOURCE_ID) "" else formatDateArrayToString(listOf(vts.validTime))
        val coordForLookup = TileCoord(coord.x, coord.y, coord.z, 0, coordTime)
        val tileData = vts.getTileData(coordForLookup) as? VectorData ?: return

        val tagged = filterFeaturesForLayer(tileData.features, layer.sourceLayer, layer.filter)

        // If a paint refresh happened while we were building, do not overwrite caches.
        if (layerGeneration[layer.id] != generation) return

        VectorGeometryColorBuckets.clearTileBuckets(controller, layer.id, tileKey)
        controller.glStencilMaskTileCache.removeCustomMaskTile(layer.id, tileKey)

        val lineStyle = GlStencilMaskMeshBuilder.lineRibbonStyleFromLineLayerPaint(paint)
        val thicknessPx = lineThicknessPx(paint.stroke.thickness)

        if (VectorFeatureStyleResolver.isConstantColor(paint.stroke.color)) {
            val paths = GlStencilMaskMeshBuilder.extractLinePathsTileUv(coord, tagged)
            if (layerGeneration[layer.id] == generation) {
                cacheLinePaths(layer.id, tileKey, paths, lineStyle, coord, thicknessPx)
            }
            return
        }

        val groups = groupFeaturesByColor(tagged, paint.stroke.color, Color.White)
        for ((colorKey, groupFeats) in groups) {
            if (groupFeats.isEmpty()) continue
            if (layerGeneration[layer.id] != generation) return

            val bucketId = VectorGeometryColorBuckets.bucketId(layer.id, colorKey)
            val color = VectorFeatureStyleResolver.colorFromKey(colorKey)
            val paths = GlStencilMaskMeshBuilder.extractLinePathsTileUv(coord, groupFeats)
            cacheLinePaths(bucketId, tileKey, paths, lineStyle, coord, thicknessPx)
            VectorGeometryColorBuckets.registerBucket(layer.id, bucketId, color)
            VectorGeometryColorBuckets.rememberTileBucket(layer.id, tileKey, bucketId)
        }
    }

    private fun bumpGenerationAndClearPaths(layerId: String, controller: MapController? = null) {
        layerGeneration.merge(layerId, 1) { old, _ -> old + 1 }
        val strokeId = FillLayerPaint.strokeOutlineLayerId(layerId)
        cachedLinePaths.keys.removeIf { it.startsWith("$layerId\u0000") || it.startsWith("$strokeId\u0000") }
        lineMeshOverscale.keys.removeIf {
            it.startsWith("$layerId\u0000") || it.startsWith("$strokeId\u0000") ||
                it.contains("\u0000${layerId}::c")
        }
        val dedupInfixLayer = "\u0000$layerId\u0000"
        val dedupInfixStroke = "\u0000$strokeId\u0000"
        pendingBuildKeys.removeIf { it.contains(dedupInfixLayer) || it.contains(dedupInfixStroke) }
        VectorGeometryColorBuckets.clearLayer(controller, layerId)
    }

    private fun pendingBuildKey(generation: Int, layerId: String, coordHash: String): String =
        "$generation\u0000$layerId\u0000$coordHash"

    /** Half stroke width in tile UV for a target screen thickness at [mapZoom]. */
    private fun strokeHalfWidthUvTileSpace(
        thicknessPx: Double,
        tileZ: Int,
        mapZoom: Double,
    ): Float {
        val overscale = CameraSync.tileRasterOverscale(mapZoom, tileZ).coerceAtLeast(1f)
        return ((thicknessPx / 2.0) / (512.0 * overscale)).toFloat().coerceIn(0.00025f, 0.05f)
    }

    private fun lineThicknessPx(thickness: StyleValue<Double>): Double =
        when (thickness) {
            is StyleValue.Constant -> thickness.value
            else -> 2.0
        }

    private fun tileCacheKey(coordHash: String): String = normalizeStencilTileKey(coordHash)

    private fun linePathCacheKey(meshLayerId: String, coordHash: String): String =
        "$meshLayerId\u0000${tileCacheKey(coordHash)}"

    private fun cacheLinePaths(
        meshLayerId: String,
        coordHash: String,
        paths: List<GlStencilMaskMeshBuilder.LinePath>,
        style: GlStencilMaskMeshBuilder.LineRibbonStyle,
        coord: TileCoord,
        thicknessPx: Double,
    ) {
        cachedLinePaths[linePathCacheKey(meshLayerId, coordHash)] =
            LineTilePathCache(paths, style, coord, thicknessPx)
        lineMeshOverscale.remove("$meshLayerId\u0000${tileCacheKey(coordHash)}")
    }

    private fun putMesh(
        controller: MapController,
        meshLayerId: String,
        coordHash: String,
        tri: FloatBuffer?,
    ) {
        val normHash = normalizeStencilTileKey(coordHash)
        if (tri != null) {
            controller.glStencilMaskTileCache.putCustomMaskMesh(
                meshLayerId,
                coordHash,
                GlStencilMaskTileCache.CpuMesh(tri, tri.limit() / 2),
            )
        } else {
            controller.glStencilMaskTileCache.removeCustomMaskTile(meshLayerId, normHash)
        }
    }

    private fun filterFeaturesForLayer(
        feats: List<Feature>,
        sourceLayer: String?,
        filter: Expression?,
    ): List<Feature> {
        return feats.asSequence()
            .filter { feature ->
                if (sourceLayer.isNullOrEmpty()) {
                    true
                } else {
                    val tag = featureLayerTag(feature)
                    tag == sourceLayer || tag == "${sourceLayer}::inverted"
                }
            }
            .filter { StencilMaskFilter.matches(it, filter) }
            .toList()
    }

    private fun groupFeaturesByColor(
        features: List<Feature>,
        styleValue: StyleValue<*>,
        default: Color,
    ): Map<Int, List<Feature>> {
        if (VectorFeatureStyleResolver.isConstantColor(styleValue)) {
            val key = VectorFeatureStyleResolver.colorKey(VectorFeatureStyleResolver.constantColor(styleValue, default))
            return mapOf(key to features)
        }
        val groups = LinkedHashMap<Int, MutableList<Feature>>()
        for (feature in features) {
            val color = VectorFeatureStyleResolver.resolveComposeColor(styleValue, feature, default)
            val key = VectorFeatureStyleResolver.colorKey(color)
            groups.getOrPut(key) { mutableListOf() }.add(feature)
        }
        return groups
    }

    private fun buildTileListener(
        controller: MapController,
        layer: VectorTileLayer,
        sourceLayer: String?,
    ): (TileCoord, String, List<Feature>) -> Unit {
        val layerId = layer.id
        return listener@{ coord, coordHash, feats ->
            // Normalize keys up-front so wrap/time suffixes can't cause cache misses.
            val tileKey = tileCacheKey(coordHash)
            val builtForGeneration = layerGeneration[layerId] ?: 0
            val key = pendingBuildKey(builtForGeneration, layerId, tileKey)
            if (!pendingBuildKeys.add(key)) return@listener

            meshBuildScope.launch {
                try {
                    if (registrations[layerId] == null) return@launch
                    if (layerGeneration[layerId] != builtForGeneration) return@launch

                    val paint = layer.paint
                    val tagged = filterFeaturesForLayer(feats, sourceLayer, layer.filter)

                    when (paint) {
                        is LineLayerPaint -> {
                            VectorGeometryColorBuckets.clearTileBuckets(controller, layerId, tileKey)
                            controller.glStencilMaskTileCache.removeCustomMaskTile(layerId, tileKey)

                            val lineStyle =
                                GlStencilMaskMeshBuilder.lineRibbonStyleFromLineLayerPaint(paint)
                            val thicknessPx = lineThicknessPx(paint.stroke.thickness)

                            if (VectorFeatureStyleResolver.isConstantColor(paint.stroke.color)) {
                                val paths = GlStencilMaskMeshBuilder.extractLinePathsTileUv(coord, tagged)
                                if (layerGeneration[layerId] != builtForGeneration) return@launch
                                cacheLinePaths(layerId, tileKey, paths, lineStyle, coord, thicknessPx)
                            } else {
                                val groups =
                                    groupFeaturesByColor(tagged, paint.stroke.color, Color.White)
                                for ((colorKey, groupFeats) in groups) {
                                    if (groupFeats.isEmpty()) continue

                                    val bucketId =
                                        VectorGeometryColorBuckets.bucketId(layerId, colorKey)
                                    val color = VectorFeatureStyleResolver.colorFromKey(colorKey)

                                    val paths =
                                        GlStencilMaskMeshBuilder.extractLinePathsTileUv(coord, groupFeats)
                                    if (layerGeneration[layerId] != builtForGeneration) return@launch

                                    cacheLinePaths(bucketId, tileKey, paths, lineStyle, coord, thicknessPx)
                                    VectorGeometryColorBuckets.registerBucket(layerId, bucketId, color)
                                    VectorGeometryColorBuckets.rememberTileBucket(layerId, tileKey, bucketId)
                                }
                            }
                        }

                        is FillLayerPaint -> {
                            VectorGeometryColorBuckets.clearTileBuckets(controller, layerId, tileKey)
                            val strokeLayerId = FillLayerPaint.strokeOutlineLayerId(layerId)
                            controller.glStencilMaskTileCache.removeCustomMaskTile(
                                strokeLayerId,
                                tileKey,
                            )

                            val strokePaint = paint.stroke
                            if (strokePaint != null) {
                                val outlineStyle =
                                    GlStencilMaskMeshBuilder.lineRibbonStyleFromStrokePaint(strokePaint)
                                val outlinePaths =
                                    GlStencilMaskMeshBuilder.extractFillOutlinePaths(coord, tagged)

                                val outlineThicknessPx =
                                    FillLayerPaint.scaleOutlineThickness(strokePaint.thickness)
                                        .constantValue ?: 0.5

                                if (layerGeneration[layerId] == builtForGeneration) {
                                    cacheLinePaths(
                                        strokeLayerId,
                                        tileKey,
                                        outlinePaths,
                                        outlineStyle,
                                        coord,
                                        outlineThicknessPx,
                                    )
                                }
                            }

                            if (VectorFeatureStyleResolver.isConstantColor(paint.fill.color)) {
                                val fillTri = GlStencilMaskMeshBuilder.buildTileUvTriangles(coord, tagged)
                                if (layerGeneration[layerId] != builtForGeneration) {
                                    fillTri?.let { DirectFloatBufferPool.releaseDeferred(it) }
                                    return@launch
                                }
                                putMesh(controller, layerId, tileKey, fillTri)
                            } else {
                                val groups =
                                    groupFeaturesByColor(tagged, paint.fill.color, Color.White)
                                for ((colorKey, groupFeats) in groups) {
                                    if (groupFeats.isEmpty()) continue

                                    val bucketId =
                                        VectorGeometryColorBuckets.bucketId(layerId, colorKey)
                                    val color = VectorFeatureStyleResolver.colorFromKey(colorKey)

                                    val fillTri =
                                        GlStencilMaskMeshBuilder.buildTileUvTriangles(coord, groupFeats)
                                    if (layerGeneration[layerId] != builtForGeneration) {
                                        fillTri?.let { DirectFloatBufferPool.releaseDeferred(it) }
                                        continue
                                    }

                                    putMesh(controller, bucketId, tileKey, fillTri)
                                    VectorGeometryColorBuckets.registerBucket(layerId, bucketId, color)
                                    VectorGeometryColorBuckets.rememberTileBucket(layerId, tileKey, bucketId)
                                }
                            }
                        }

                        else -> return@launch
                    }

                    // Tile mesh completion can change legend content for GL-rendered vector products.
                    controller.updateLegendsForMap()
                    (controller as? MapboxMapController)?.requestRepaintCoalesced()
                } catch (t: Throwable) {
                    pendingBuildKeys.remove(key)
                    MapsGLDebug.logW(TAG, "mesh build failed for $layerId/$coordHash", t)
                }
            }
        }
    }
}
