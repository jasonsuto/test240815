package com.xweather.mapsgl.map.mapbox

import android.opengl.EGL14
import android.opengl.EGLContext
import android.opengl.GLES31
import android.opengl.Matrix
import com.xweather.mapsgl.gl.programs.RasterTileProgram
import com.xweather.mapsgl.gl.worldObjects.MeshInfo
import com.xweather.mapsgl.layers.spec.MaskLayerKind
import com.xweather.mapsgl.layers.spec.StencilMaskCombineMode
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor

/**
 * Minimal GLES3.1 program to write the stencil buffer from tile-UV triangles (color writes off).
 */
internal class GlStencilMaskRenderer {

    private companion object {
        private const val TEMP_DISABLE_MASK_FOR_SCREENSHOT = false
        private const val TEMP_TEST_CENTER_TRIANGLE_MASK = false
        private const val STENCIL_MASK_REF = 2
        /** After [drawCustomLineMaskOnLand], land pixels under line geometry hold this ref. */
        private const val STENCIL_HIGHWAY_ON_LAND_REF = 1
        private const val TRANSPORTATION_STENCIL_HALF_WIDTH_PX = 1.0f
        /**
         * Cap for **new** `glGenBuffers` stencil uploads in [STENCIL_VBO_UPLOAD_WINDOW_MS]. Was `1`,
         * which meant only one tile could get a fresh custom-mask VBO per window while every other
         * visible tile hit [failOpenNoStencil] on first visit to a zoom level (mask visibly blinked
         * off until later repaints drained the backlog). Custom masks also skip this budget when
         * reusing an existing handle and only calling `glBufferData` ([ensureCustomVbo]).
         * `12` covers ~two custom-mask slots × several new tiles per 16 ms without returning to
         * the old `1`-upload starvation; raise if large viewports still miss a frame.
         */
        private const val MAX_NEW_STENCIL_VBO_UPLOADS_PER_WINDOW = 12
        private const val STENCIL_VBO_UPLOAD_WINDOW_MS = 16L
    }

    private var program = 0
    private var uMvpLoc = -1
    private var aPosLoc = -1
    private var maskColorProgram = 0
    private var maskColorUMvpLoc = -1
    private var maskColorAPosLoc = -1
    private var testTriangleVbo = 0
    private var fullTileQuadVbo = 0
    private var transportProgram = 0
    private var transportSegLoc = -1
    private var transportUMvpLoc = -1
    private var transportUViewportLoc = -1
    private var transportUHalfWidthPxLoc = -1
    private val transportViewportScratch = IntArray(4)
    private val transportSegmentVbo = ConcurrentHashMap<String, Int>()
    private val transportSegmentCount = ConcurrentHashMap<String, Int>()
    private val mvp = FloatArray(16)
    /** CPU-only scratch for [clearStencilForWeatherTileScreenBounds]; never share with [mvp] on the GL thread. */
    private val mvpStencilClearScratch = FloatArray(16)
    private val gpuVbo = ConcurrentHashMap<String, Int>()
    private val gpuCounts = ConcurrentHashMap<String, Int>()
    /**
     * The exact [GlStencilMaskTileCache.CpuMesh] instance that the GPU VBO for `fullKey` was
     * uploaded from. Identity-compared (`===`) on every [ensureCustomVbo] call so that when
     * [GlStencilMaskTileCache.putCustomMaskMesh] swaps in a freshly-built mesh (e.g. after a
     * paint change via [GlStencilCustomMaskCoordinator.refreshPaint]), the renderer can detect
     * the swap and re-`glBufferData` the existing VBO instead of returning the stale handle.
     */
    private val gpuMeshRef = ConcurrentHashMap<String, GlStencilMaskTileCache.CpuMesh>()

    /**
     * GL handles that other threads asked us to free but couldn't (no current EGL context). The
     * next render frame on the GL thread drains this through [drainPendingDeletes] before doing
     * anything else, so VBOs really do get released to the driver.
     *
     * Without this, every [refreshCustomStencilMask] from the main thread (slider commits,
     * spinner changes) was dropping the Java-side handle and silently leaking the GPU buffer —
     * the `libEGL E call to OpenGL ES API with no current context` log lines are this code
     * path. Over many slider moves the leak grew into the hundreds of MB and contributed to the
     * OOM that ended the freeze.
     */
    private val pendingVboDeletes = java.util.concurrent.ConcurrentLinkedQueue<Int>()

    /**
     * EGL context the cached [program], [transportProgram], and per-mesh VBO handles belong to.
     * This singleton renderer is shared process-wide (see [GlStencilMaskRendererHolder]) so two
     * `MapView`s in two activities will both call into it with different EGL contexts. Mapbox v11
     * preserves contexts across activity pause, so [onContextLost] is not guaranteed to fire before
     * the second `MapView` starts rendering — checking the EGL context object identity at use time
     * is the only reliable detector.
     */
    private var resourcesContext: EGLContext? = null

    /** -1 = unknown, 0 = no stencil buffer on current FBO, >0 = bits available */
    private var cachedStencilBits: Int = -1
    private var weatherPassRestoreDepth: Boolean? = null
    private var weatherPassRestoreCull: Boolean? = null
    private var lastStencilWriteKind: MaskLayerKind? = null
    private var uploadWindowStartMs: Long = 0L
    private var uploadsInWindow: Int = 0
    @Volatile
    private var hasPendingUploadAfterThrottle: Boolean = false

    private fun currentStencilBits(): Int {
        if (cachedStencilBits < 0) {
            val a = IntArray(1)
            GLES31.glGetIntegerv(GLES31.GL_STENCIL_BITS, a, 0)
            cachedStencilBits = a[0]
        }
        return cachedStencilBits
    }

    /**
     * Gates **new** `glGenBuffers` stencil uploads (see [MAX_NEW_STENCIL_VBO_UPLOADS_PER_WINDOW]).
     * Re-uploading into an existing buffer handle is not gated here — see [ensureCustomVbo].
     */
    private fun reserveStencilUploadSlot(): Boolean {
        val nowMs = System.nanoTime() / 1_000_000L
        if (uploadWindowStartMs == 0L || nowMs - uploadWindowStartMs >= STENCIL_VBO_UPLOAD_WINDOW_MS) {
            uploadWindowStartMs = nowMs
            uploadsInWindow = 0
        }
        if (uploadsInWindow >= MAX_NEW_STENCIL_VBO_UPLOADS_PER_WINDOW) {
            hasPendingUploadAfterThrottle = true
            onUploadThrottled?.invoke()
            return false
        }
        uploadsInWindow++
        return true
    }

    /**
     * True when a stencil VBO upload was deferred by the per-window throttle and a follow-up frame
     * should be requested so deferred meshes can continue uploading without camera interaction.
     */
    fun consumePendingUploadRepaintRequest(): Boolean {
        if (!hasPendingUploadAfterThrottle) return false
        hasPendingUploadAfterThrottle = false
        return true
    }

    /**
     * Invoked when [reserveStencilUploadSlot] denies an upload because we're over budget for the
     * current 16 ms window. The owning controller hooks this up to a coalesced repaint request
     * (see [MapboxMapController.requestRepaintCoalesced]), which guarantees Mapbox will render
     * again on the next frame — that's how the renderer drains the rest of the queued uploads
     * even after the slider commit's single explicit repaint has been consumed. The lambda is
     * called on whichever thread tripped the throttle (typically Mapbox's GL thread); it must do
     * no GL work itself.
     */
    @Volatile
    var onUploadThrottled: (() -> Unit)? = null

    /**
     * Self-heal across EGL context switches before touching any cached GL handle. The first call
     * from a new context drops every stale resource so the subsequent `ensureProgram` /
     * `ensureTransportProgram` / `ensureVbo` calls recreate them against the live context. This
     * must be called at the top of every public render entry point (anywhere a stale `program`,
     * `transportProgram`, or VBO name from a previous activity's `MapView` could be used).
     */
    private fun ensureCurrentContext() {
        val currentContext = EGL14.eglGetCurrentContext()
        if (currentContext == EGL14.EGL_NO_CONTEXT) return
        // Free anything `releaseGpuForMaskLayerId` couldn't delete from the main thread before we
        // touch any GL state. Has to happen on a context we control (this one), not the foreign
        // one that triggered the release request.
        drainPendingDeletes()
        // Recycle direct vertex buffers that workers queued for release while the previous
        // frame was rendering. Doing this on the GL thread, between frames, guarantees no
        // concurrent render is still reading from them — see the "two-phase release"
        // comment in [DirectFloatBufferPool] for the full argument.
        DirectFloatBufferPool.drainDeferredReleases()
        if (resourcesContext == currentContext) return
        program = 0
        uMvpLoc = -1
        aPosLoc = -1
        maskColorProgram = 0
        maskColorUMvpLoc = -1
        maskColorAPosLoc = -1
        testTriangleVbo = 0
        transportProgram = 0
        transportSegLoc = -1
        transportUMvpLoc = -1
        transportUViewportLoc = -1
        transportUHalfWidthPxLoc = -1
        transportSegmentVbo.clear()
        transportSegmentCount.clear()
        gpuVbo.clear()
        gpuCounts.clear()
        gpuMeshRef.clear()
        cachedStencilBits = -1
        weatherPassRestoreDepth = null
        weatherPassRestoreCull = null
        lastStencilWriteKind = null
        resourcesContext = currentContext
    }

    private fun ensureProgram() {
        ensureCurrentContext()
        if (program != 0) return
        val vs = """
            #version 310 es
            uniform mat4 uMvp;
            layout(location = 0) in vec2 a_pos;
            void main() {
                gl_Position = uMvp * vec4(a_pos, 0.0, 1.0);
            }
        """.trimIndent()
        // Color writes are disabled while drawing the mask, but a real color output keeps some GLES
        // drivers from eliding the fragment stage entirely (which can skip stencil writes).
        val fs = """
            #version 310 es
            precision mediump float;
            layout(location = 0) out mediump vec4 o_frag;
            void main() { o_frag = vec4(0.0); }
        """.trimIndent()
        program = GLES31.glCreateProgram()
        val vShader = loadShader(GLES31.GL_VERTEX_SHADER, vs)
        val fShader = loadShader(GLES31.GL_FRAGMENT_SHADER, fs)
        GLES31.glAttachShader(program, vShader)
        GLES31.glAttachShader(program, fShader)
        GLES31.glLinkProgram(program)
        GLES31.glDeleteShader(vShader)
        GLES31.glDeleteShader(fShader)
        uMvpLoc = GLES31.glGetUniformLocation(program, "uMvp")
        aPosLoc = 0
    }

    private var maskFboDrawPassActive = false

    /** Call once before a batch of mask-FBO draws; pairs with [endMaskFboDrawPass]. */
    fun beginMaskFboDrawPass() {
        ensureCurrentContext()
        ensureMaskColorProgram()
        GLES31.glUseProgram(maskColorProgram)
        maskFboDrawPassActive = true
    }

    /** Restores the weather [RasterTileProgram] after [beginMaskFboDrawPass]. */
    fun endMaskFboDrawPass(rasterProgram: RasterTileProgram) {
        if (!maskFboDrawPassActive) return
        GLES31.glUseProgram(0)
        rasterProgram.bind()
        rasterProgram.use()
        maskFboDrawPassActive = false
    }

    private fun ensureMaskColorProgram() {
        if (maskColorProgram != 0) return
        ensureCurrentContext()
        val vs = """
            #version 310 es
            uniform mat4 uMvp;
            layout(location = 0) in vec2 a_pos;
            void main() {
                gl_Position = uMvp * vec4(a_pos, 0.0, 1.0);
            }
        """.trimIndent()
        val fs = """
            #version 310 es
            precision mediump float;
            layout(location = 0) out mediump vec4 o_frag;
            void main() { o_frag = vec4(1.0); }
        """.trimIndent()
        maskColorProgram = GLES31.glCreateProgram()
        val vShader = loadShader(GLES31.GL_VERTEX_SHADER, vs)
        val fShader = loadShader(GLES31.GL_FRAGMENT_SHADER, fs)
        GLES31.glAttachShader(maskColorProgram, vShader)
        GLES31.glAttachShader(maskColorProgram, fShader)
        GLES31.glLinkProgram(maskColorProgram)
        GLES31.glDeleteShader(vShader)
        GLES31.glDeleteShader(fShader)
        maskColorUMvpLoc = GLES31.glGetUniformLocation(maskColorProgram, "uMvp")
        maskColorAPosLoc = 0
    }

    /**
     * Writes white into the bound mask FBO color attachment (no stencil test).
     */
    fun drawMeshWhiteToMaskFbo(
        mesh: GlStencilMaskTileCache.CpuMesh,
        vboFullKey: String,
        projection: FloatArray,
        modelView: FloatArray,
        rasterProgram: RasterTileProgram,
    ): Boolean {
        if (mesh.vertexCount < 3) return false
        if (!maskFboDrawPassActive) ensureMaskColorProgram()
        val vbo = ensureCustomVbo(vboFullKey, mesh) ?: return false
        val count = gpuCounts[vboFullKey] ?: return false
        Matrix.multiplyMM(mvp, 0, projection, 0, modelView, 0)
        if (!maskFboDrawPassActive) GLES31.glUseProgram(maskColorProgram)
        GLES31.glUniformMatrix4fv(maskColorUMvpLoc, 1, false, mvp, 0)
        GLES31.glDisable(GLES31.GL_STENCIL_TEST)
        GLES31.glColorMask(true, true, true, true)
        val cullWas = GLES31.glIsEnabled(GLES31.GL_CULL_FACE)
        val depthWas = GLES31.glIsEnabled(GLES31.GL_DEPTH_TEST)
        try {
            GLES31.glDisable(GLES31.GL_CULL_FACE)
            GLES31.glDisable(GLES31.GL_DEPTH_TEST)
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, vbo)
            GLES31.glEnableVertexAttribArray(maskColorAPosLoc)
            GLES31.glVertexAttribPointer(maskColorAPosLoc, 2, GLES31.GL_FLOAT, false, 0, 0)
            GLES31.glDrawArrays(GLES31.GL_TRIANGLES, 0, count)
            GLES31.glDisableVertexAttribArray(maskColorAPosLoc)
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, 0)
        } finally {
            if (cullWas) GLES31.glEnable(GLES31.GL_CULL_FACE) else GLES31.glDisable(GLES31.GL_CULL_FACE)
            if (depthWas) GLES31.glEnable(GLES31.GL_DEPTH_TEST) else GLES31.glDisable(GLES31.GL_DEPTH_TEST)
        }
        if (!maskFboDrawPassActive) {
            GLES31.glUseProgram(0)
            rasterProgram.bind()
            rasterProgram.use()
        }
        return true
    }

    /**
     * One step of sequential ALL into the mask FBO: white color where the stencil counter matches.
     */
    fun drawSequentialAllMaskPassToMaskFbo(
        mesh: GlStencilMaskTileCache.CpuMesh,
        vboFullKey: String,
        passIndex: Int,
        projection: FloatArray,
        modelView: FloatArray,
        rasterProgram: RasterTileProgram,
    ): Boolean {
        if (mesh.vertexCount < 3 || passIndex < 0) return false
        if (!maskFboDrawPassActive) ensureMaskColorProgram()
        val vbo = ensureCustomVbo(vboFullKey, mesh) ?: return false
        val count = gpuCounts[vboFullKey] ?: return false
        Matrix.multiplyMM(mvp, 0, projection, 0, modelView, 0)
        if (!maskFboDrawPassActive) GLES31.glUseProgram(maskColorProgram)
        GLES31.glUniformMatrix4fv(maskColorUMvpLoc, 1, false, mvp, 0)
        GLES31.glEnable(GLES31.GL_STENCIL_TEST)
        GLES31.glStencilMask(0xFF)
        GLES31.glColorMask(true, true, true, true)
        if (passIndex == 0) {
            GLES31.glStencilFunc(GLES31.GL_ALWAYS, 1, 0xFF)
            GLES31.glStencilOp(GLES31.GL_KEEP, GLES31.GL_KEEP, GLES31.GL_REPLACE)
        } else {
            GLES31.glStencilFunc(GLES31.GL_EQUAL, passIndex, 0xFF)
            GLES31.glStencilOp(GLES31.GL_KEEP, GLES31.GL_KEEP, GLES31.GL_INCR)
        }
        val cullWas = GLES31.glIsEnabled(GLES31.GL_CULL_FACE)
        val depthWas = GLES31.glIsEnabled(GLES31.GL_DEPTH_TEST)
        try {
            GLES31.glDisable(GLES31.GL_CULL_FACE)
            GLES31.glDisable(GLES31.GL_DEPTH_TEST)
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, vbo)
            GLES31.glEnableVertexAttribArray(maskColorAPosLoc)
            GLES31.glVertexAttribPointer(maskColorAPosLoc, 2, GLES31.GL_FLOAT, false, 0, 0)
            GLES31.glDrawArrays(GLES31.GL_TRIANGLES, 0, count)
            GLES31.glDisableVertexAttribArray(maskColorAPosLoc)
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, 0)
        } finally {
            if (cullWas) GLES31.glEnable(GLES31.GL_CULL_FACE) else GLES31.glDisable(GLES31.GL_CULL_FACE)
            if (depthWas) GLES31.glEnable(GLES31.GL_DEPTH_TEST) else GLES31.glDisable(GLES31.GL_DEPTH_TEST)
        }
        GLES31.glDisable(GLES31.GL_STENCIL_TEST)
        if (!maskFboDrawPassActive) {
            GLES31.glUseProgram(0)
            rasterProgram.bind()
            rasterProgram.use()
        }
        return true
    }

    private fun ensureTransportProgram() {
        ensureCurrentContext()
        if (transportProgram != 0) return
        val vs = """
            #version 310 es
            uniform mat4 uMvp;
            uniform vec2 uViewport;
            uniform float uHalfWidthPx;
            layout(location = 0) in vec4 a_seg;
            void main() {
                vec4 c0 = uMvp * vec4(a_seg.xy, 0.0, 1.0);
                vec4 c1 = uMvp * vec4(a_seg.zw, 0.0, 1.0);
                vec2 n0 = c0.xy / max(abs(c0.w), 1e-6);
                vec2 n1 = c1.xy / max(abs(c1.w), 1e-6);
                vec2 s0 = (n0 * 0.5 + 0.5) * uViewport;
                vec2 s1 = (n1 * 0.5 + 0.5) * uViewport;
                vec2 dir = s1 - s0;
                float len = length(dir);
                if (len < 1e-4) dir = vec2(1.0, 0.0);
                else dir /= len;
                vec2 norm = vec2(-dir.y, dir.x);
                int vid = gl_VertexID % 6;
                float t = (vid == 2 || vid == 4 || vid == 5) ? 1.0 : 0.0;
                float side = (vid == 1 || vid == 2 || vid == 4) ? 1.0 : -1.0;
                vec2 s = mix(s0, s1, t) + norm * side * uHalfWidthPx;
                vec2 clip = s / uViewport * 2.0 - 1.0;
                gl_Position = vec4(clip, 0.0, 1.0);
            }
        """.trimIndent()
        val fs = """
            #version 310 es
            precision mediump float;
            layout(location = 0) out mediump vec4 o_frag;
            void main() { o_frag = vec4(0.0); }
        """.trimIndent()
        transportProgram = GLES31.glCreateProgram()
        val vShader = loadShader(GLES31.GL_VERTEX_SHADER, vs)
        val fShader = loadShader(GLES31.GL_FRAGMENT_SHADER, fs)
        GLES31.glAttachShader(transportProgram, vShader)
        GLES31.glAttachShader(transportProgram, fShader)
        GLES31.glLinkProgram(transportProgram)
        GLES31.glDeleteShader(vShader)
        GLES31.glDeleteShader(fShader)
        transportSegLoc = 0
        transportUMvpLoc = GLES31.glGetUniformLocation(transportProgram, "uMvp")
        transportUViewportLoc = GLES31.glGetUniformLocation(transportProgram, "uViewport")
        transportUHalfWidthPxLoc = GLES31.glGetUniformLocation(transportProgram, "uHalfWidthPx")
    }

    private fun drawCenterTriangleTestMask(
        projection: FloatArray,
        modelView: FloatArray,
        rasterProgram: RasterTileProgram?,
        maskKind: MaskLayerKind,
    ): Boolean {
        ensureProgram()
        Matrix.multiplyMM(mvp, 0, projection, 0, modelView, 0)
        // GLES3 core profile requires VBO-backed attributes (no client-side arrays).
        if (testTriangleVbo == 0) {
            val tri = floatArrayOf(
                0.3f, 0.3f,
                0.7f, 0.3f,
                0.5f, 0.7f,
            )
            val bb = ByteBuffer.allocateDirect(tri.size * 4).order(ByteOrder.nativeOrder())
            val fb: FloatBuffer = bb.asFloatBuffer()
            fb.put(tri)
            fb.position(0)
            val ids = IntArray(1)
            GLES31.glGenBuffers(1, ids, 0)
            testTriangleVbo = ids[0]
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, testTriangleVbo)
            GLES31.glBufferData(GLES31.GL_ARRAY_BUFFER, tri.size * 4, fb, GLES31.GL_STATIC_DRAW)
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, 0)
        }

        GLES31.glUseProgram(program)
        GLES31.glUniformMatrix4fv(uMvpLoc, 1, false, mvp, 0)
        GLES31.glEnable(GLES31.GL_STENCIL_TEST)
        GLES31.glStencilMask(0xFF)
        GLES31.glColorMask(false, false, false, false)
        GLES31.glStencilFunc(GLES31.GL_ALWAYS, STENCIL_MASK_REF, 0xFF)
        GLES31.glStencilOp(GLES31.GL_KEEP, GLES31.GL_KEEP, GLES31.GL_REPLACE)

        val cullWas = GLES31.glIsEnabled(GLES31.GL_CULL_FACE)
        val depthWas = GLES31.glIsEnabled(GLES31.GL_DEPTH_TEST)
        try {
            GLES31.glDisable(GLES31.GL_CULL_FACE)
            GLES31.glDisable(GLES31.GL_DEPTH_TEST)
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, testTriangleVbo)
            GLES31.glEnableVertexAttribArray(aPosLoc)
            GLES31.glVertexAttribPointer(aPosLoc, 2, GLES31.GL_FLOAT, false, 0, 0)
            GLES31.glDrawArrays(GLES31.GL_TRIANGLES, 0, 3)
            // LAND mode normally tests stencil==0, but for this debug we want visible triangle clip.
            // Mark write kind as WATER so configureStencilForWeatherDraw(LAND) switches to stencil==1.
            lastStencilWriteKind = if (maskKind == MaskLayerKind.LAND) MaskLayerKind.WATER else maskKind
        } finally {
            GLES31.glDisableVertexAttribArray(aPosLoc)
            // Must unbind: RenderPass weather quads use client/direct buffers for a_position; leaving
            // this VBO bound makes the strip read triangle verts + garbage → no rasterization → "invisible tile".
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, 0)
            if (cullWas) GLES31.glEnable(GLES31.GL_CULL_FACE) else GLES31.glDisable(GLES31.GL_CULL_FACE)
            if (depthWas) GLES31.glEnable(GLES31.GL_DEPTH_TEST) else GLES31.glDisable(GLES31.GL_DEPTH_TEST)
        }
        GLES31.glUseProgram(0)
        rasterProgram?.bind()
        rasterProgram?.use()
        return true
    }

    private fun loadShader(type: Int, code: String): Int {
        val s = GLES31.glCreateShader(type)
        GLES31.glShaderSource(s, code)
        GLES31.glCompileShader(s)
        return s
    }

    private fun buildTransportSegmentBuffer(paths: List<GlStencilMaskMeshBuilder.LinePath>): FloatArray {
        var out = FloatArray(1024)
        var outSize = 0
        fun ensure(extra: Int) {
            if (outSize + extra <= out.size) return
            var n = out.size
            while (outSize + extra > n) n *= 2
            out = out.copyOf(n)
        }
        for (path in paths) {
            val p = path.pointsUv
            if (p.size < 4) continue
            var i = 0
            while (i + 3 < p.size) {
                val u0 = p[i]
                val v0 = p[i + 1]
                val u1 = p[i + 2]
                val v1 = p[i + 3]
                val du = u1 - u0
                val dv = v1 - v0
                if (du * du + dv * dv > 1e-10f) {
                    ensure(4)
                    out[outSize++] = u0
                    out[outSize++] = v0
                    out[outSize++] = u1
                    out[outSize++] = v1
                }
                i += 2
            }
        }
        return if (outSize == 0) FloatArray(0) else out.copyOf(outSize)
    }

    private fun ensureTransportSegmentVbo(
        storageKey: String,
        paths: List<GlStencilMaskMeshBuilder.LinePath>,
    ): Pair<Int, Int>? {
        ensureCurrentContext()
        transportSegmentVbo[storageKey]?.let { vbo ->
            val count = transportSegmentCount[storageKey] ?: 0
            if (count > 0) return vbo to count
        }
        if (!reserveStencilUploadSlot()) return null
        val seg = buildTransportSegmentBuffer(paths)
        if (seg.isEmpty()) return null
        val bb = ByteBuffer.allocateDirect(seg.size * 4).order(ByteOrder.nativeOrder())
        val fb = bb.asFloatBuffer()
        fb.put(seg)
        fb.position(0)
        val ids = IntArray(1)
        GLES31.glGenBuffers(1, ids, 0)
        val vbo = ids[0]
        GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, vbo)
        GLES31.glBufferData(GLES31.GL_ARRAY_BUFFER, seg.size * 4, fb, GLES31.GL_STATIC_DRAW)
        GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, 0)
        val instances = seg.size / 4
        transportSegmentVbo[storageKey] = vbo
        transportSegmentCount[storageKey] = instances
        return vbo to instances
    }

    /**
     * Writes stencil ref [STENCIL_MASK_REF] for the full weather tile quad (0..1 UV). Used when a
     * MAPSGL tile has no explicit `water` polygons but [MaskLayerKind.WATER] should treat the tile
     * as all water (open ocean), and for instanced gridded layers that draw in one pass across tiles.
     */
    fun drawFullTileStencilRef(projection: FloatArray, modelView: FloatArray): Boolean {
        if (currentStencilBits() == 0) return false
        ensureProgram()
        Matrix.multiplyMM(mvp, 0, projection, 0, modelView, 0)
        if (fullTileQuadVbo == 0) {
            val quad = floatArrayOf(
                0f, 0f,
                0f, 1f,
                1f, 0f,
                1f, 0f,
                0f, 1f,
                1f, 1f,
            )
            val bb = ByteBuffer.allocateDirect(quad.size * 4).order(ByteOrder.nativeOrder())
            val fb: FloatBuffer = bb.asFloatBuffer()
            fb.put(quad)
            fb.position(0)
            val ids = IntArray(1)
            GLES31.glGenBuffers(1, ids, 0)
            fullTileQuadVbo = ids[0]
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, fullTileQuadVbo)
            GLES31.glBufferData(GLES31.GL_ARRAY_BUFFER, quad.size * 4, fb, GLES31.GL_STATIC_DRAW)
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, 0)
        }
        lastStencilWriteKind = MaskLayerKind.WATER
        GLES31.glUseProgram(program)
        GLES31.glUniformMatrix4fv(uMvpLoc, 1, false, mvp, 0)
        GLES31.glEnable(GLES31.GL_STENCIL_TEST)
        GLES31.glStencilMask(0xFF)
        GLES31.glColorMask(false, false, false, false)
        GLES31.glStencilFunc(GLES31.GL_ALWAYS, STENCIL_MASK_REF, 0xFF)
        GLES31.glStencilOp(GLES31.GL_KEEP, GLES31.GL_KEEP, GLES31.GL_REPLACE)
        val cullWas = GLES31.glIsEnabled(GLES31.GL_CULL_FACE)
        val depthWas = GLES31.glIsEnabled(GLES31.GL_DEPTH_TEST)
        try {
            GLES31.glDisable(GLES31.GL_CULL_FACE)
            GLES31.glDisable(GLES31.GL_DEPTH_TEST)
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, fullTileQuadVbo)
            GLES31.glEnableVertexAttribArray(aPosLoc)
            GLES31.glVertexAttribPointer(aPosLoc, 2, GLES31.GL_FLOAT, false, 0, 0)
            GLES31.glDrawArrays(GLES31.GL_TRIANGLES, 0, 6)
            GLES31.glDisableVertexAttribArray(aPosLoc)
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, 0)
        } finally {
            if (cullWas) GLES31.glEnable(GLES31.GL_CULL_FACE) else GLES31.glDisable(GLES31.GL_CULL_FACE)
            if (depthWas) GLES31.glEnable(GLES31.GL_DEPTH_TEST) else GLES31.glDisable(GLES31.GL_DEPTH_TEST)
        }
        GLES31.glUseProgram(0)
        return true
    }

    internal fun failOpenNoStencil() {
        // Ensure weather tile draw is not accidentally blocked when this tile has no mask mesh.
        GLES31.glDisable(GLES31.GL_STENCIL_TEST)
        GLES31.glStencilMask(0xFF)
        GLES31.glStencilFunc(GLES31.GL_ALWAYS, 0, 0xFF)
        GLES31.glStencilOp(GLES31.GL_KEEP, GLES31.GL_KEEP, GLES31.GL_KEEP)
        GLES31.glColorMask(true, true, true, true)
    }

    internal fun failClosedNoStencil() {
        // Hide weather tile when mask geometry is unavailable (used by transport mask).
        GLES31.glEnable(GLES31.GL_STENCIL_TEST)
        GLES31.glStencilMask(0x00)
        // With cleared stencil (=0), this always fails for STENCIL_MASK_REF.
        GLES31.glStencilFunc(GLES31.GL_EQUAL, STENCIL_MASK_REF, 0xFF)
        GLES31.glStencilOp(GLES31.GL_KEEP, GLES31.GL_KEEP, GLES31.GL_KEEP)
        GLES31.glColorMask(true, true, true, true)
    }

    private fun zoomFromCanonicalKey(key: String): Int? {
        // Expected "0:z/x/y" (possibly with suffixes); tolerate extra tail.
        val c = key.indexOf(':')
        if (c < 0 || c + 1 >= key.length) return null
        val path = key.substring(c + 1)
        val slash = path.indexOf('/')
        if (slash <= 0) return null
        return path.substring(0, slash).toIntOrNull()
    }

    fun releaseGpuForKey(maskKind: MaskLayerKind, cacheKey: String) {
        val key = vboKey(maskKind, normalizeStencilTileKey(cacheKey))
        val vbo = gpuVbo.remove(key) ?: return
        GLES31.glDeleteBuffers(1, intArrayOf(vbo), 0)
        gpuCounts.remove(key)
        gpuMeshRef.remove(key)
    }

    fun releaseAllGpu() {
        for (vbo in gpuVbo.values) {
            GLES31.glDeleteBuffers(1, intArrayOf(vbo), 0)
        }
        gpuVbo.clear()
        gpuCounts.clear()
        gpuMeshRef.clear()
        if (program != 0) {
            GLES31.glDeleteProgram(program)
            program = 0
        }
        if (transportProgram != 0) {
            GLES31.glDeleteProgram(transportProgram)
            transportProgram = 0
        }
        for (vbo in transportSegmentVbo.values) {
            GLES31.glDeleteBuffers(1, intArrayOf(vbo), 0)
        }
        transportSegmentVbo.clear()
        transportSegmentCount.clear()
        if (testTriangleVbo != 0) {
            GLES31.glDeleteBuffers(1, intArrayOf(testTriangleVbo), 0)
            testTriangleVbo = 0
        }
        if (fullTileQuadVbo != 0) {
            GLES31.glDeleteBuffers(1, intArrayOf(fullTileQuadVbo), 0)
            fullTileQuadVbo = 0
        }
        cachedStencilBits = -1
        weatherPassRestoreDepth = null
        weatherPassRestoreCull = null
        // Drop context association so the next render on a preserved or new EGL context recreates
        // programs/VBOs via [ensureCurrentContext] (Mapbox v11 often keeps the context across activities).
        resourcesContext = null
    }

    /**
     * Call when the map GL context is lost so the next [currentStencilBits] query runs on the new
     * drawable/attachments (custom layer FBO may differ from the old context).
     *
     * Because this renderer is shared process-wide via [GlStencilMaskRendererHolder], every cached
     * GL handle (programs, VBOs, uniform locations) belonged to the now-dead context and would be
     * rejected by any subsequent context — causing `glUseProgram -> GL_INVALID_OPERATION` crashes
     * the moment a second `MapView` (e.g. a new activity) tries to render. Drop all of them so the
     * next attach re-creates handles in the fresh context. We do *not* issue `glDelete*` here: the
     * owning context is already gone, so the driver would either ignore the call or crash; leaking
     * names in the dead context is harmless.
     */
    fun onContextLost() {
        cachedStencilBits = -1
        weatherPassRestoreDepth = null
        weatherPassRestoreCull = null
        program = 0
        uMvpLoc = -1
        aPosLoc = -1
        testTriangleVbo = 0
        transportProgram = 0
        transportSegLoc = -1
        transportUMvpLoc = -1
        transportUViewportLoc = -1
        transportUHalfWidthPxLoc = -1
        transportSegmentVbo.clear()
        transportSegmentCount.clear()
        gpuVbo.clear()
        gpuCounts.clear()
        gpuMeshRef.clear()
        lastStencilWriteKind = null
    }

    private fun vboKey(maskKind: MaskLayerKind, cacheKey: String) = "${maskKind.ordinal}_$cacheKey"

    private fun customVboKey(maskLayerId: String, storageKey: String) = "c_${maskLayerId}_$storageKey"

    /**
     * Drop GPU buffers for [maskLayerId]'s custom stencil meshes. Safe to call from any thread
     * — when invoked off the GL thread (e.g. from main during a paint refresh) the handles are
     * queued onto [pendingVboDeletes] and the next render frame frees them in a live context.
     * Java-side bookkeeping (`gpuVbo` / `gpuCounts`) is always cleared synchronously so the
     * next [ensureCustomVbo] call sees a clean slate and rebuilds against the new CPU mesh.
     */
    fun releaseGpuForMaskLayerId(maskLayerId: String) {
        val prefix = "c_${maskLayerId}_"
        val onGlThread = EGL14.eglGetCurrentContext() != EGL14.EGL_NO_CONTEXT
        for (k in gpuVbo.keys.filter { it.startsWith(prefix) }) {
            val vbo = gpuVbo.remove(k) ?: continue
            gpuCounts.remove(k)
            gpuMeshRef.remove(k)
            if (onGlThread) {
                GLES31.glDeleteBuffers(1, intArrayOf(vbo), 0)
            } else {
                pendingVboDeletes.offer(vbo)
            }
        }
    }

    /**
     * Free any VBOs that [releaseGpuForMaskLayerId] couldn't release because it was running off
     * the GL thread. Called at the top of every render entry point so we never accumulate
     * orphaned GPU buffers.
     */
    private fun drainPendingDeletes() {
        if (pendingVboDeletes.isEmpty()) return
        // Batched to one `glDeleteBuffers` per drain so we don't pay the per-call JNI overhead
        // once per leaked handle when a busy refresh flushes dozens at a time.
        val batch = IntArray(pendingVboDeletes.size)
        var n = 0
        while (n < batch.size) {
            val vbo = pendingVboDeletes.poll() ?: break
            batch[n++] = vbo
        }
        if (n > 0) GLES31.glDeleteBuffers(n, batch, 0)
    }

    /**
     * Prepares [mesh]'s direct vertex buffer for a `glBufferData` upload and returns the number
     * of bytes the upload will consume. The buffer is rewound (`position=0, limit=floatCount`)
     * via `duplicate` so we don't fight any other reader of the same direct memory (e.g. a
     * concurrent `remapParentMeshToChildUvs` doing absolute `get(int)` calls — those don't
     * touch position, but rewinding the original buffer might still race a hypothetical
     * future reader). The duplicated view shares the same native memory, just with its own
     * position/limit cursors.
     */
    private fun prepareUploadBuffer(mesh: GlStencilMaskTileCache.CpuMesh): Pair<FloatBuffer, Int> {
        val floatCount = mesh.vertices.limit()
        val view = mesh.vertices.duplicate()
        view.position(0)
        view.limit(floatCount)
        return view to (floatCount * 4)
    }

    private fun ensureVbo(maskKind: MaskLayerKind, cacheKey: String, mesh: GlStencilMaskTileCache.CpuMesh): Int? {
        ensureCurrentContext()
        val key = vboKey(maskKind, cacheKey)
        gpuVbo[key]?.let { return it }
        if (!reserveStencilUploadSlot()) return null
        val buf = IntArray(1)
        GLES31.glGenBuffers(1, buf, 0)
        val vbo = buf[0]
        GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, vbo)
        // Upload straight from the mesh's pooled direct buffer — no `FloatArray -> ByteBuffer`
        // copy any more (that copy was the redundant heap traffic that survived the
        // [DirectFloatBufferPool] migration of [GlStencilMaskTileCache.CpuMesh] storage).
        val (uploadBuf, byteSize) = prepareUploadBuffer(mesh)
        GLES31.glBufferData(GLES31.GL_ARRAY_BUFFER, byteSize, uploadBuf, GLES31.GL_STATIC_DRAW)
        GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, 0)
        gpuVbo[key] = vbo
        gpuCounts[key] = mesh.vertexCount
        return vbo
    }

    private fun ensureCustomVbo(fullKey: String, mesh: GlStencilMaskTileCache.CpuMesh): Int? {
        ensureCurrentContext()
        val existingVbo = gpuVbo[fullKey]
        if (existingVbo != null && gpuMeshRef[fullKey] === mesh) {
            return existingVbo
        }
        // Either no VBO yet, or the cache now holds a different mesh than the one we previously
        // uploaded (paint change → fresh `CpuMesh` from
        // [GlStencilCustomMaskCoordinator.buildStencilTileListener]). Only **new** buffer names
        // consume the upload budget — re-`glBufferData` on an existing handle is not throttled so
        // paint updates and mesh swaps on the same key do not starve first-zoom VBO creation for
        // other tiles.
        if (existingVbo == null && !reserveStencilUploadSlot()) return null
        val vbo = existingVbo ?: run {
            val buf = IntArray(1)
            GLES31.glGenBuffers(1, buf, 0)
            buf[0]
        }
        GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, vbo)
        val (uploadBuf, byteSize) = prepareUploadBuffer(mesh)
        GLES31.glBufferData(GLES31.GL_ARRAY_BUFFER, byteSize, uploadBuf, GLES31.GL_STATIC_DRAW)
        GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, 0)
        gpuVbo[fullKey] = vbo
        gpuCounts[fullKey] = mesh.vertexCount
        gpuMeshRef[fullKey] = mesh
        return vbo
    }

    /**
     * Picks CPU mesh + GPU VBO for a custom mask tile, preferring [GlStencilMaskTileCache.getCpuMeshForCustomMask]
     * (exact child mesh when present). If a **new** GPU key is throttled (common when exact MVT
     * replaces an ancestor remap at zoom), falls back to
     * [GlStencilMaskTileCache.getAncestorRemappedCpuMeshForCustomMask] so an existing remapped VBO
     * can draw for one more frame instead of [failOpenNoStencil].
     */
    internal fun tryResolveCustomMaskVboForDraw(
        cache: GlStencilMaskTileCache,
        maskLayerId: String,
        cacheKey: String,
    ): Triple<GlStencilMaskTileCache.CpuMesh, String, Int>? {
        val primary = cache.getCpuMeshForCustomMask(maskLayerId, cacheKey) ?: return null
        var mesh = primary.first
        var storageKey = primary.second
        if (mesh.vertexCount < 3) return null
        ensureProgram()
        var vboK = customVboKey(maskLayerId, storageKey)
        var vbo = ensureCustomVbo(vboK, mesh)
        if (vbo == null) {
            val alt = cache.getAncestorRemappedCpuMeshForCustomMask(maskLayerId, cacheKey) ?: return null
            if (alt.first.vertexCount < 3) return null
            if (alt.second != storageKey) {
                mesh = alt.first
                storageKey = alt.second
                vboK = customVboKey(maskLayerId, storageKey)
                vbo = ensureCustomVbo(vboK, mesh)
            }
        }
        if (vbo == null) return null
        return Triple(mesh, vboK, vbo)
    }

    /**
     * Writes a single stencil bit (power of two) for one mask slot; compatible with other slots in the same frame.
     */
    fun drawCustomMaskSlotIntoStencil(
        cache: GlStencilMaskTileCache,
        cacheKey: String,
        maskLayerId: String,
        slotBit: Int,
        projection: FloatArray,
        modelView: FloatArray,
        rasterProgram: RasterTileProgram,
    ): Boolean {
        if (currentStencilBits() == 0) {
            failOpenNoStencil()
            return false
        }
        if (slotBit == 0 || slotBit and (slotBit - 1) != 0) return false
        val resolved = tryResolveCustomMaskVboForDraw(cache, maskLayerId, cacheKey) ?: run {
            failOpenNoStencil()
            return false
        }
        val (_, vboK, vbo) = resolved
        val count = gpuCounts[vboK] ?: run {
            failOpenNoStencil()
            return false
        }
        Matrix.multiplyMM(mvp, 0, projection, 0, modelView, 0)
        GLES31.glUseProgram(program)
        GLES31.glUniformMatrix4fv(uMvpLoc, 1, false, mvp, 0)
        GLES31.glEnable(GLES31.GL_STENCIL_TEST)
        GLES31.glStencilMask(slotBit)
        GLES31.glColorMask(false, false, false, false)
        GLES31.glStencilFunc(GLES31.GL_ALWAYS, slotBit, slotBit)
        GLES31.glStencilOp(GLES31.GL_KEEP, GLES31.GL_KEEP, GLES31.GL_REPLACE)
        val cullWas = GLES31.glIsEnabled(GLES31.GL_CULL_FACE)
        val depthWas = GLES31.glIsEnabled(GLES31.GL_DEPTH_TEST)
        try {
            GLES31.glDisable(GLES31.GL_CULL_FACE)
            GLES31.glDisable(GLES31.GL_DEPTH_TEST)
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, vbo)
            GLES31.glEnableVertexAttribArray(aPosLoc)
            GLES31.glVertexAttribPointer(aPosLoc, 2, GLES31.GL_FLOAT, false, 0, 0)
            GLES31.glDrawArrays(GLES31.GL_TRIANGLES, 0, count)
            GLES31.glDisableVertexAttribArray(aPosLoc)
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, 0)
        } finally {
            if (cullWas) GLES31.glEnable(GLES31.GL_CULL_FACE) else GLES31.glDisable(GLES31.GL_CULL_FACE)
            if (depthWas) GLES31.glEnable(GLES31.GL_DEPTH_TEST) else GLES31.glDisable(GLES31.GL_DEPTH_TEST)
        }
        GLES31.glUseProgram(0)
        rasterProgram.bind()
        rasterProgram.use()
        return true
    }

    /**
     * Tags custom line mask geometry on **land only** (stencil **0** after the LAND water pass).
     * Increments matching fragments to [STENCIL_HIGHWAY_ON_LAND_REF]; marine pixels (ref
     * [STENCIL_MASK_REF]) are skipped.
     */
    fun drawCustomLineMaskOnLand(
        cache: GlStencilMaskTileCache,
        cacheKey: String,
        maskLayerId: String,
        projection: FloatArray,
        modelView: FloatArray,
        rasterProgram: RasterTileProgram,
    ): Boolean {
        if (currentStencilBits() == 0) {
            failClosedNoStencil()
            return false
        }
        val resolved = tryResolveCustomMaskVboForDraw(cache, maskLayerId, cacheKey) ?: run {
            failClosedNoStencil()
            return false
        }
        val (_, vboK, vbo) = resolved
        val count = gpuCounts[vboK] ?: run {
            failClosedNoStencil()
            return false
        }
        Matrix.multiplyMM(mvp, 0, projection, 0, modelView, 0)
        GLES31.glUseProgram(program)
        GLES31.glUniformMatrix4fv(uMvpLoc, 1, false, mvp, 0)
        GLES31.glEnable(GLES31.GL_STENCIL_TEST)
        GLES31.glStencilMask(0xFF)
        GLES31.glColorMask(false, false, false, false)
        GLES31.glStencilFunc(GLES31.GL_EQUAL, 0, 0xFF)
        GLES31.glStencilOp(GLES31.GL_KEEP, GLES31.GL_KEEP, GLES31.GL_INCR)
        val cullWas = GLES31.glIsEnabled(GLES31.GL_CULL_FACE)
        val depthWas = GLES31.glIsEnabled(GLES31.GL_DEPTH_TEST)
        try {
            GLES31.glDisable(GLES31.GL_CULL_FACE)
            GLES31.glDisable(GLES31.GL_DEPTH_TEST)
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, vbo)
            GLES31.glEnableVertexAttribArray(aPosLoc)
            GLES31.glVertexAttribPointer(aPosLoc, 2, GLES31.GL_FLOAT, false, 0, 0)
            GLES31.glDrawArrays(GLES31.GL_TRIANGLES, 0, count)
            GLES31.glDisableVertexAttribArray(aPosLoc)
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, 0)
        } finally {
            if (cullWas) GLES31.glEnable(GLES31.GL_CULL_FACE) else GLES31.glDisable(GLES31.GL_CULL_FACE)
            if (depthWas) GLES31.glEnable(GLES31.GL_DEPTH_TEST) else GLES31.glDisable(GLES31.GL_DEPTH_TEST)
        }
        GLES31.glUseProgram(0)
        rasterProgram.bind()
        rasterProgram.use()
        return true
    }

    /**
     * After [drawMaskIntoStencil] (LAND) and [drawCustomLineMaskOnLand], draw temperature only on
     * highway pixels that lie on land ([STENCIL_HIGHWAY_ON_LAND_REF]).
     */
    fun configureStencilForHybridLandHighwayDraw() {
        if (currentStencilBits() == 0) {
            failClosedNoStencil()
            return
        }
        if (weatherPassRestoreDepth == null) {
            weatherPassRestoreDepth = GLES31.glIsEnabled(GLES31.GL_DEPTH_TEST)
            weatherPassRestoreCull = GLES31.glIsEnabled(GLES31.GL_CULL_FACE)
        }
        GLES31.glDisable(GLES31.GL_DEPTH_TEST)
        GLES31.glDisable(GLES31.GL_CULL_FACE)
        GLES31.glEnable(GLES31.GL_STENCIL_TEST)
        GLES31.glColorMask(true, true, true, true)
        GLES31.glStencilMask(0x00)
        GLES31.glStencilFunc(GLES31.GL_EQUAL, STENCIL_HIGHWAY_ON_LAND_REF, 0xFF)
        GLES31.glStencilOp(GLES31.GL_KEEP, GLES31.GL_KEEP, GLES31.GL_KEEP)
    }

    /**
     * One step of **sequential intersection** for [StencilMaskCombineMode.ALL] (non-inverted multi-mask):
     * - Pass 0: replace stencil with **1** under this mesh (broad region).
     * - Pass *k* &gt; 0: where stencil **equals** *k*, **increment** (so covered pixels become *k+1*).
     * After *N* passes, weather should test **EQUAL** *N* via [configureStencilForSequentialAll].
     *
     * This matches boolean AND per pixel (e.g. country polygon first, transportation lines second)
     * without relying on multi-bit stencil plane packing.
     */
    fun drawSequentialAllMaskPass(
        mesh: GlStencilMaskTileCache.CpuMesh,
        vboFullKey: String,
        passIndex: Int,
        projection: FloatArray,
        modelView: FloatArray,
        rasterProgram: RasterTileProgram,
    ): Boolean {
        if (currentStencilBits() == 0) {
            failOpenNoStencil()
            return false
        }
        if (mesh.vertexCount < 3 || passIndex < 0) return false
        ensureProgram()
        val vbo = ensureCustomVbo(vboFullKey, mesh) ?: run {
            failOpenNoStencil()
            return false
        }
        val count = gpuCounts[vboFullKey] ?: run {
            failOpenNoStencil()
            return false
        }
        Matrix.multiplyMM(mvp, 0, projection, 0, modelView, 0)
        GLES31.glUseProgram(program)
        GLES31.glUniformMatrix4fv(uMvpLoc, 1, false, mvp, 0)
        GLES31.glEnable(GLES31.GL_STENCIL_TEST)
        GLES31.glStencilMask(0xFF)
        GLES31.glColorMask(false, false, false, false)
        if (passIndex == 0) {
            GLES31.glStencilFunc(GLES31.GL_ALWAYS, 1, 0xFF)
            GLES31.glStencilOp(GLES31.GL_KEEP, GLES31.GL_KEEP, GLES31.GL_REPLACE)
        } else {
            GLES31.glStencilFunc(GLES31.GL_EQUAL, passIndex, 0xFF)
            GLES31.glStencilOp(GLES31.GL_KEEP, GLES31.GL_KEEP, GLES31.GL_INCR)
        }
        val cullWas = GLES31.glIsEnabled(GLES31.GL_CULL_FACE)
        val depthWas = GLES31.glIsEnabled(GLES31.GL_DEPTH_TEST)
        try {
            GLES31.glDisable(GLES31.GL_CULL_FACE)
            GLES31.glDisable(GLES31.GL_DEPTH_TEST)
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, vbo)
            GLES31.glEnableVertexAttribArray(aPosLoc)
            GLES31.glVertexAttribPointer(aPosLoc, 2, GLES31.GL_FLOAT, false, 0, 0)
            GLES31.glDrawArrays(GLES31.GL_TRIANGLES, 0, count)
            GLES31.glDisableVertexAttribArray(aPosLoc)
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, 0)
        } finally {
            if (cullWas) GLES31.glEnable(GLES31.GL_CULL_FACE) else GLES31.glDisable(GLES31.GL_CULL_FACE)
            if (depthWas) GLES31.glEnable(GLES31.GL_DEPTH_TEST) else GLES31.glDisable(GLES31.GL_DEPTH_TEST)
        }
        GLES31.glUseProgram(0)
        rasterProgram.bind()
        rasterProgram.use()
        return true
    }

    fun configureStencilForSequentialAll(passCount: Int, invert: Boolean) {
        if (currentStencilBits() == 0) return
        if (passCount <= 0) return
        if (weatherPassRestoreDepth == null) {
            weatherPassRestoreDepth = GLES31.glIsEnabled(GLES31.GL_DEPTH_TEST)
            weatherPassRestoreCull = GLES31.glIsEnabled(GLES31.GL_CULL_FACE)
        }
        GLES31.glDisable(GLES31.GL_DEPTH_TEST)
        GLES31.glDisable(GLES31.GL_CULL_FACE)
        GLES31.glEnable(GLES31.GL_STENCIL_TEST)
        GLES31.glColorMask(true, true, true, true)
        GLES31.glStencilMask(0x00)
        if (invert) {
            GLES31.glStencilFunc(GLES31.GL_NOTEQUAL, passCount, 0xFF)
        } else {
            GLES31.glStencilFunc(GLES31.GL_EQUAL, passCount, 0xFF)
        }
        GLES31.glStencilOp(GLES31.GL_KEEP, GLES31.GL_KEEP, GLES31.GL_KEEP)
    }

    /**
     * GPU cache key for clip meshes must include [MeshInfo.x]/[MeshInfo.y] as used by the MV translate,
     * not only canonical `0:z/x/y`. Wrapping folds e.g. x=-3 and x=13 to the same tile index at zoom 4
     * but clip geometry is built in different geographic frames — sharing a VBO made masks jump by zoom/pan.
     */
    internal fun clipStencilVboKey(meshInfo: MeshInfo, clipBoundsKey: String): String {
        val z = meshInfo.z.toInt()
        val xr = meshInfo.x.toRawBits()
        val yr = meshInfo.y.toRawBits()
        return "clip_${clipBoundsKey}_z${z}_x${xr}_y${yr}"
    }

    /**
     * Like [drawCustomMaskSlotIntoStencil] but for a procedural lat/lon clip mesh.
     */
    fun drawClipBoundsMeshIntoStencil(
        meshInfo: MeshInfo,
        clipBoundsKey: String,
        mesh: GlStencilMaskTileCache.CpuMesh,
        slotBit: Int,
        projection: FloatArray,
        modelView: FloatArray,
        rasterProgram: RasterTileProgram,
    ): Boolean {
        if (currentStencilBits() == 0) {
            failOpenNoStencil()
            return false
        }
        if (slotBit == 0 || slotBit and (slotBit - 1) != 0) return false
        if (mesh.vertexCount < 3) return false
        ensureProgram()
        val vboK = clipStencilVboKey(meshInfo, clipBoundsKey)
        val vbo = ensureCustomVbo(vboK, mesh) ?: run {
            failOpenNoStencil()
            return false
        }
        val count = gpuCounts[vboK] ?: run {
            failOpenNoStencil()
            return false
        }
        Matrix.multiplyMM(mvp, 0, projection, 0, modelView, 0)
        GLES31.glUseProgram(program)
        GLES31.glUniformMatrix4fv(uMvpLoc, 1, false, mvp, 0)
        GLES31.glEnable(GLES31.GL_STENCIL_TEST)
        GLES31.glStencilMask(slotBit)
        GLES31.glColorMask(false, false, false, false)
        GLES31.glStencilFunc(GLES31.GL_ALWAYS, slotBit, slotBit)
        GLES31.glStencilOp(GLES31.GL_KEEP, GLES31.GL_KEEP, GLES31.GL_REPLACE)
        val cullWas = GLES31.glIsEnabled(GLES31.GL_CULL_FACE)
        val depthWas = GLES31.glIsEnabled(GLES31.GL_DEPTH_TEST)
        try {
            GLES31.glDisable(GLES31.GL_CULL_FACE)
            GLES31.glDisable(GLES31.GL_DEPTH_TEST)
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, vbo)
            GLES31.glEnableVertexAttribArray(aPosLoc)
            GLES31.glVertexAttribPointer(aPosLoc, 2, GLES31.GL_FLOAT, false, 0, 0)
            GLES31.glDrawArrays(GLES31.GL_TRIANGLES, 0, count)
            GLES31.glDisableVertexAttribArray(aPosLoc)
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, 0)
        } finally {
            if (cullWas) GLES31.glEnable(GLES31.GL_CULL_FACE) else GLES31.glDisable(GLES31.GL_CULL_FACE)
            if (depthWas) GLES31.glEnable(GLES31.GL_DEPTH_TEST) else GLES31.glDisable(GLES31.GL_DEPTH_TEST)
        }
        GLES31.glUseProgram(0)
        rasterProgram.bind()
        rasterProgram.use()
        return true
    }

    fun configureStencilForLayerMaskCombine(
        mode: StencilMaskCombineMode,
        combinedMask: Int,
        invert: Boolean,
    ) {
        if (currentStencilBits() == 0) return
        if (weatherPassRestoreDepth == null) {
            weatherPassRestoreDepth = GLES31.glIsEnabled(GLES31.GL_DEPTH_TEST)
            weatherPassRestoreCull = GLES31.glIsEnabled(GLES31.GL_CULL_FACE)
        }
        GLES31.glDisable(GLES31.GL_DEPTH_TEST)
        GLES31.glDisable(GLES31.GL_CULL_FACE)
        GLES31.glEnable(GLES31.GL_STENCIL_TEST)
        GLES31.glColorMask(true, true, true, true)
        GLES31.glStencilMask(0x00)
        when (mode) {
            StencilMaskCombineMode.ALL -> {
                if (invert) {
                    GLES31.glStencilFunc(GLES31.GL_NOTEQUAL, combinedMask, combinedMask)
                } else {
                    GLES31.glStencilFunc(GLES31.GL_EQUAL, combinedMask, combinedMask)
                }
            }
            StencilMaskCombineMode.ANY -> {
                if (invert) {
                    GLES31.glStencilFunc(GLES31.GL_EQUAL, 0, combinedMask)
                } else {
                    GLES31.glStencilFunc(GLES31.GL_NOTEQUAL, 0, combinedMask)
                }
            }
        }
        GLES31.glStencilOp(GLES31.GL_KEEP, GLES31.GL_KEEP, GLES31.GL_KEEP)
    }

    /**
     * Writes stencil bit **1** under mask triangles (color writes off), then restores [rasterProgram].
     *
     * @return `true` if mask geometry was drawn; caller must then call [configureStencilForWeatherDraw].
     *         `false` if there was no mesh for this tile — leave stencil test **off** so the weather
     *         quad draws normally (same as missing Mapbox mask data).
     */
    fun drawMaskIntoStencil(
        cache: GlStencilMaskTileCache,
        cacheKey: String,
        maskKind: MaskLayerKind,
        projection: FloatArray,
        modelView: FloatArray,
        rasterProgram: RasterTileProgram? = null,
        countryIso3166Alpha2: String? = null,
    ): Boolean {
        if (TEMP_DISABLE_MASK_FOR_SCREENSHOT) {
            lastStencilWriteKind = null
            failOpenNoStencil()
            return false
        }
        if (currentStencilBits() == 0) {
            lastStencilWriteKind = null
            failOpenNoStencil()
            return false
        }
        if (TEMP_TEST_CENTER_TRIANGLE_MASK) {
            return drawCenterTriangleTestMask(projection, modelView, rasterProgram, maskKind)
        }
        val tileZoom = zoomFromCanonicalKey(cacheKey)
        if (maskKind == MaskLayerKind.LAND && tileZoom != null && tileZoom < GlStencilMaskMarineLand.MIN_ZOOM_FOR_LAND_STENCIL) {
            lastStencilWriteKind = null
            failClosedNoStencil()
            return false
        }
        if (maskKind == MaskLayerKind.TRANSPORTATION) {
            val pathPair = cache.getTransportationPathsForRender(cacheKey)
            if (pathPair == null) {
                lastStencilWriteKind = null
                failClosedNoStencil()
                return false
            }
            val (paths, storageKey) = pathPair
            val segGpu = ensureTransportSegmentVbo(storageKey, paths)
            if (segGpu == null) {
                lastStencilWriteKind = null
                failClosedNoStencil()
                return false
            }
            val (segVbo, segInstances) = segGpu
            Matrix.multiplyMM(mvp, 0, projection, 0, modelView, 0)
            GLES31.glGetIntegerv(GLES31.GL_VIEWPORT, transportViewportScratch, 0)
            val viewportW = transportViewportScratch[2]
            val viewportH = transportViewportScratch[3]
            ensureTransportProgram()
            lastStencilWriteKind = maskKind
            GLES31.glUseProgram(transportProgram)
            GLES31.glUniformMatrix4fv(transportUMvpLoc, 1, false, mvp, 0)
            GLES31.glUniform2f(transportUViewportLoc, viewportW.toFloat(), viewportH.toFloat())
            GLES31.glUniform1f(transportUHalfWidthPxLoc, TRANSPORTATION_STENCIL_HALF_WIDTH_PX)
            GLES31.glEnable(GLES31.GL_STENCIL_TEST)
            GLES31.glStencilMask(0xFF)
            GLES31.glColorMask(false, false, false, false)
            GLES31.glStencilFunc(GLES31.GL_ALWAYS, STENCIL_MASK_REF, 0xFF)
            GLES31.glStencilOp(GLES31.GL_KEEP, GLES31.GL_KEEP, GLES31.GL_REPLACE)
            val cullWas = GLES31.glIsEnabled(GLES31.GL_CULL_FACE)
            val depthWas = GLES31.glIsEnabled(GLES31.GL_DEPTH_TEST)
            try {
                GLES31.glDisable(GLES31.GL_CULL_FACE)
                GLES31.glDisable(GLES31.GL_DEPTH_TEST)
                GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, segVbo)
                GLES31.glEnableVertexAttribArray(transportSegLoc)
                GLES31.glVertexAttribPointer(transportSegLoc, 4, GLES31.GL_FLOAT, false, 16, 0)
                GLES31.glVertexAttribDivisor(transportSegLoc, 1)
                GLES31.glDrawArraysInstanced(GLES31.GL_TRIANGLES, 0, 6, segInstances)
                GLES31.glVertexAttribDivisor(transportSegLoc, 0)
                GLES31.glDisableVertexAttribArray(transportSegLoc)
                GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, 0)
            } finally {
                if (cullWas) GLES31.glEnable(GLES31.GL_CULL_FACE) else GLES31.glDisable(GLES31.GL_CULL_FACE)
                if (depthWas) GLES31.glEnable(GLES31.GL_DEPTH_TEST) else GLES31.glDisable(GLES31.GL_DEPTH_TEST)
            }
            GLES31.glUseProgram(0)
            rasterProgram?.bind()
            rasterProgram?.use()
            return true
        }

        // Vector mask follows [cacheKey] / weather tile z only — not encoded raster partial z/x/y.
        fun meshForKind(kind: MaskLayerKind) = cache.getCpuMeshForRender(cacheKey, kind)

        val meshWithKey = when (maskKind) {
            // Safety policy: never use inverse land geometry for clipping. It can over-cover and
            // fully reject marine draws. Only use water geometry; otherwise fail closed.
            MaskLayerKind.LAND -> meshForKind(MaskLayerKind.WATER)
            MaskLayerKind.COUNTRY -> {
                val iso = countryIso3166Alpha2 ?: run {
                    lastStencilWriteKind = null
                    failOpenNoStencil()
                    return false
                }
                cache.getCpuMeshForCountry(iso, cacheKey)
            }
            else -> meshForKind(maskKind)
        }
        if (meshWithKey == null) {
            lastStencilWriteKind = null
            if (maskKind == MaskLayerKind.TRANSPORTATION) {
                failClosedNoStencil()
                return false
            }
            when (maskKind) {
                MaskLayerKind.LAND ->
                    // Inland MAPSGL tiles often omit `water` features — no mesh means all land.
                    failOpenNoStencil()
                MaskLayerKind.WATER ->
                    // Open-ocean MAPSGL tiles often omit `water` features — no mesh means all water.
                    failOpenNoStencil()
                else -> Unit
            }
            return false
        }
        val (mesh, storageKey) = meshWithKey
        if (maskKind == MaskLayerKind.LAND) {
            val waterArea = GlStencilMaskMarineLand.waterMeshUvArea(mesh)
            if (GlStencilMaskMarineLand.isEffectivelyEmptyWaterMask(waterArea) || mesh.vertexCount < 3) {
                lastStencilWriteKind = null
                failOpenNoStencil()
                return false
            }
            if (waterArea > GlStencilMaskMarineLand.MAX_WATER_UV_AREA_FOR_LAND_MASK) {
                lastStencilWriteKind = null
                failClosedNoStencil()
                return false
            }
        } else if (maskKind == MaskLayerKind.WATER) {
            val waterArea = GlStencilMaskMarineLand.waterMeshUvArea(mesh)
            if (GlStencilMaskMarineLand.isEffectivelyEmptyWaterMask(waterArea) || mesh.vertexCount < 3) {
                lastStencilWriteKind = null
                failOpenNoStencil()
                return false
            }
        } else if (mesh.vertexCount < 3) {
            lastStencilWriteKind = null
            failOpenNoStencil()
            return false
        }
        // LAND mode above only accepts WATER geometry (or fail closed), so mark stencil writes
        // deterministically as WATER. Avoid cache re-queries that can race and misclassify writes.
        val wroteKind = if (maskKind == MaskLayerKind.LAND) MaskLayerKind.WATER else maskKind
        lastStencilWriteKind = wroteKind
        ensureProgram()
        val vboKind = if (maskKind == MaskLayerKind.LAND) wroteKind else maskKind
        val vboK = vboKey(vboKind, storageKey)
        val vbo = ensureVbo(vboKind, storageKey, mesh) ?: run {
            lastStencilWriteKind = null
            if (maskKind == MaskLayerKind.LAND) {
                failClosedNoStencil()
                return false
            }
            failOpenNoStencil()
            return false
        }
        val count = gpuCounts[vboK] ?: run {
            lastStencilWriteKind = null
            if (maskKind == MaskLayerKind.LAND) {
                failClosedNoStencil()
                return false
            }
            failOpenNoStencil()
            return false
        }

        Matrix.multiplyMM(mvp, 0, projection, 0, modelView, 0)

        GLES31.glUseProgram(program)
        GLES31.glUniformMatrix4fv(uMvpLoc, 1, false, mvp, 0)

        GLES31.glEnable(GLES31.GL_STENCIL_TEST)
        GLES31.glStencilMask(0xFF)
        GLES31.glColorMask(false, false, false, false)
        GLES31.glStencilFunc(GLES31.GL_ALWAYS, STENCIL_MASK_REF, 0xFF)
        GLES31.glStencilOp(GLES31.GL_KEEP, GLES31.GL_KEEP, GLES31.GL_REPLACE)

        // Mapbox often leaves culling/depth on; culling can drop the entire land mesh (Earcut winding
        // vs. front face), and depth can hide fragments—both read as "mask not working."
        val cullWas = GLES31.glIsEnabled(GLES31.GL_CULL_FACE)
        val depthWas = GLES31.glIsEnabled(GLES31.GL_DEPTH_TEST)
        try {
            GLES31.glDisable(GLES31.GL_CULL_FACE)
            GLES31.glDisable(GLES31.GL_DEPTH_TEST)
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, vbo)
            GLES31.glEnableVertexAttribArray(aPosLoc)
            GLES31.glVertexAttribPointer(aPosLoc, 2, GLES31.GL_FLOAT, false, 0, 0)
            GLES31.glDrawArrays(GLES31.GL_TRIANGLES, 0, count)
            GLES31.glDisableVertexAttribArray(aPosLoc)
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, 0)
        } finally {
            if (cullWas) {
                GLES31.glEnable(GLES31.GL_CULL_FACE)
            } else {
                GLES31.glDisable(GLES31.GL_CULL_FACE)
            }
            if (depthWas) {
                GLES31.glEnable(GLES31.GL_DEPTH_TEST)
            } else {
                GLES31.glDisable(GLES31.GL_DEPTH_TEST)
            }
        }
        GLES31.glUseProgram(0)

        rasterProgram?.bind()
        rasterProgram?.use()
        return true
    }

    /**
     * Inverted land mask draw: full encoded quad on stencil **0**; explicit `water` polygons (stencil ref
     * written in [drawMaskIntoStencil]) are subtracted. Only call when [drawMaskIntoStencil] returned `true`.
     */
    fun configureStencilForInvertedLandDraw() {
        configureStencilForWeatherDraw(MaskLayerKind.LAND)
    }

    /**
     * After [drawMaskIntoStencil] returns `true`, restricts the following draws:
     * - [MaskLayerKind.LAND]: explicit `water` mesh writes stencil ref; marine clip uses stencil **0** vs ref (see [configureStencilForWeatherDraw]).
     * - [MaskLayerKind.WATER]: water pixels have stencil ref; draw only where stencil equals ref.
     * - [MaskLayerKind.TRANSPORTATION]: road ribbon mesh writes stencil ref; draw only where stencil equals ref (same test as water).
     * - [MaskLayerKind.COUNTRY]: country border ribbon; same test as water.
     */
    fun configureStencilForWeatherDraw(maskKind: MaskLayerKind) {
        if (currentStencilBits() == 0) return
        if (weatherPassRestoreDepth == null) {
            weatherPassRestoreDepth = GLES31.glIsEnabled(GLES31.GL_DEPTH_TEST)
            weatherPassRestoreCull = GLES31.glIsEnabled(GLES31.GL_CULL_FACE)
        }
        GLES31.glDisable(GLES31.GL_DEPTH_TEST)
        GLES31.glDisable(GLES31.GL_CULL_FACE)
        GLES31.glEnable(GLES31.GL_STENCIL_TEST)
        GLES31.glColorMask(true, true, true, true)
        GLES31.glStencilMask(0x00)
        // LAND uses explicit `water` MVT polygons that REPLACE marine pixels with ref
        // [STENCIL_MASK_REF]; weather is drawn where stencil stayed **0** (land). Do not remap
        // LAND → WATER here — that inverted the clip and painted oceans instead of land.
        when (maskKind) {
            MaskLayerKind.LAND ->
                GLES31.glStencilFunc(GLES31.GL_EQUAL, 0, 0xFF)
            MaskLayerKind.WATER, MaskLayerKind.TRANSPORTATION, MaskLayerKind.COUNTRY ->
                GLES31.glStencilFunc(GLES31.GL_EQUAL, STENCIL_MASK_REF, 0xFF)
            else ->
                GLES31.glStencilFunc(GLES31.GL_ALWAYS, 0, 0xFF)
        }
        GLES31.glStencilOp(GLES31.GL_KEEP, GLES31.GL_KEEP, GLES31.GL_KEEP)
    }

    fun disableStencil() {
        GLES31.glDisable(GLES31.GL_STENCIL_TEST)
        GLES31.glStencilMask(0xFF)
        GLES31.glStencilFunc(GLES31.GL_ALWAYS, 0, 0xFF)
        GLES31.glStencilOp(GLES31.GL_KEEP, GLES31.GL_KEEP, GLES31.GL_KEEP)
        weatherPassRestoreDepth?.let { wasOn ->
            if (wasOn) {
                GLES31.glEnable(GLES31.GL_DEPTH_TEST)
            } else {
                GLES31.glDisable(GLES31.GL_DEPTH_TEST)
            }
        }
        weatherPassRestoreDepth = null
        weatherPassRestoreCull?.let { wasOn ->
            if (wasOn) {
                GLES31.glEnable(GLES31.GL_CULL_FACE)
            } else {
                GLES31.glDisable(GLES31.GL_CULL_FACE)
            }
        }
        weatherPassRestoreCull = null
    }

    /**
     * Clears stencil for the entire current viewport. Prefer [clearStencilForWeatherTileScreenBounds]
     * from the per-tile weather loop: a full FBO stencil clear per tile was dominating frame cost
     * while panning (dozens of clears per frame), independent of CPU/VBO cache hits.
     */
    fun clearStencilForFrame() {
        clearStencilFullViewport()
    }

    /**
     * Clears stencil only inside the screen-space bounding box of the weather tile quad (unit
     * square 0..1 in model space after the same [projection]×[modelView] as the stencil hooks).
     * Cuts fill versus a full-viewport clear for every tile while panning with many tiles visible.
     *
     * Under perspective tilt, corners can cross the eye plane or blow up in NDC; we only use the
     * scissor path when **all four** corners have stable forward clip-space `w`, otherwise we fall
     * back to a full-viewport clear for that tile (correctness over the scissor optimization).
     *
     * **Important:** This path must not call [ensureCurrentContext] — it runs once per visible
     * tile per frame; pairing that with pool drains caused severe stalls when tilt produced many
     * fallbacks.
     */
    fun clearStencilForWeatherTileScreenBounds(
        projection: FloatArray,
        modelView: FloatArray,
        viewportW: Int,
        viewportH: Int,
    ) {
        if (currentStencilBits() == 0) return
        if (viewportW < 1 || viewportH < 1) {
            clearStencilFullViewport()
            return
        }
        Matrix.multiplyMM(mvpStencilClearScratch, 0, projection, 0, modelView, 0)
        val m = mvpStencilClearScratch
        var minPx = Float.POSITIVE_INFINITY
        var maxPx = Float.NEGATIVE_INFINITY
        var minPy = Float.POSITIVE_INFINITY
        var maxPy = Float.NEGATIVE_INFINITY
        var validCorners = 0
        // Corners of the 0..1 quad (same as UnitQuad2DGeometry.genQuad1x1 strip corners).
        val corners = arrayOf(
            0f to 0f,
            0f to 1f,
            1f to 0f,
            1f to 1f,
        )
        val minW = 1e-3f
        for ((lx, ly) in corners) {
            val cx = m[0] * lx + m[4] * ly + m[12]
            val cy = m[1] * lx + m[5] * ly + m[13]
            val cw = m[3] * lx + m[7] * ly + m[15]
            if (cw < minW) continue
            val ndcX = cx / cw
            val ndcY = cy / cw
            if (!ndcX.isFinite() || !ndcY.isFinite()) continue
            if (abs(ndcX) > 10f || abs(ndcY) > 10f) continue
            val px = (ndcX + 1f) * 0.5f * viewportW
            val py = (ndcY + 1f) * 0.5f * viewportH
            if (px < minPx) minPx = px
            if (px > maxPx) maxPx = px
            if (py < minPy) minPy = py
            if (py > maxPy) maxPy = py
            validCorners++
        }
        val padPx = 4
        if (validCorners != 4 || minPx > maxPx || minPy > maxPy) {
            clearStencilFullViewport()
            return
        }
        val sx = floor((minPx - padPx).toDouble()).toInt().coerceIn(0, viewportW - 1)
        val sy = floor((minPy - padPx).toDouble()).toInt().coerceIn(0, viewportH - 1)
        val ex = ceil((maxPx + padPx).toDouble()).toInt().coerceIn(sx + 1, viewportW)
        val ey = ceil((maxPy + padPx).toDouble()).toInt().coerceIn(sy + 1, viewportH)
        val sw = ex - sx
        val sh = ey - sy
        if (sw < 1 || sh < 1) {
            clearStencilFullViewport()
            return
        }
        GLES31.glEnable(GLES31.GL_SCISSOR_TEST)
        GLES31.glScissor(sx, sy, sw, sh)
        GLES31.glDisable(GLES31.GL_STENCIL_TEST)
        GLES31.glStencilMask(0xFF)
        GLES31.glClearStencil(0)
        GLES31.glClear(GLES31.GL_STENCIL_BUFFER_BIT)
        GLES31.glDisable(GLES31.GL_SCISSOR_TEST)
    }

    /**
     * Full-viewport stencil clear used when scissor is skipped. Intentionally does **not** call
     * [ensureCurrentContext] — this runs inside the per-tile weather loop; draining pools here
     * ran every tile and tanked frame time when perspective forced frequent fallbacks.
     */
    private fun clearStencilFullViewport() {
        if (currentStencilBits() == 0) return
        GLES31.glDisable(GLES31.GL_STENCIL_TEST)
        GLES31.glStencilMask(0xFF)
        GLES31.glClearStencil(0)
        GLES31.glClear(GLES31.GL_STENCIL_BUFFER_BIT)
    }
}
