package com.xweather.mapsgl.map.mapbox

import com.mapbox.geojson.Feature
import com.xweather.mapsgl.gl.worldObjects.MeshInfo
import com.xweather.mapsgl.layers.spec.MaskLayerKind
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.util.MapsGLDebug
import java.nio.FloatBuffer
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.min

/**
 * [TileCoord.hash] encodes [com.xweather.mapsgl.tiles.TileCoord.wrap] as the first segment, then
 * `z/x/y` and optional time: `wrap:z/x/y/…`. The same map tile can be `0:5/3/9` and `1:5/35/9` (x
 * differ by 2^z) — a common cache miss. [normalizeStencilTileKey] folds all world-wrappped copies
 * into a single `0:{z}/{(x mod)}/{(y mod)}/…` so `base.osm` fills and weather draw lookup agree.
 */
/**
 * [Feature.getStringProperty] can miss "layer" depending on how GeoJson properties were built.
 * Stencil cache filtering must match the tags set in [com.xweather.mapsgl.sources.VectorTileSource.parseVectorTile].
 */
internal fun featureLayerTag(f: Feature): String? {
    f.getStringProperty("layer")?.let { return it }
    return try {
        val p = f.properties() ?: return null
        if (!p.has("layer")) return null
        val e = p.get("layer")!!
        if (e.isJsonPrimitive) {
            val prim = e.asJsonPrimitive
            if (prim.isString) prim.asString else prim.toString()
        } else {
            e.toString()
        }
    } catch (_: Exception) {
        null
    }
}

/**
 * [putFromFeatures] fills the water map from `water` features (GLES stencil path). The land map is only
 * populated if any `water::inverted` features are present (unused for current marine LAND masking).
 * cached from an older [parseVectorTile] pass (e.g. before the mask consumer, when [neededLayerNames]
 * fell back to [VectorTileSource] `first()`) never contains that tag, so the GLES land stencil has no
 * geometry — no “First mask draw” in logs, full-tile product with no land clipping. Used to force an
 * MVT re-parse in [com.xweather.mapsgl.sources.VectorTileSource.requestTile].
 */
/** True when parsed MVT output includes explicit `water` features (GLES stencil mesh source). */
internal fun hasWaterStencilMvtTagInFeatures(features: List<Feature>): Boolean =
    features.any { featureLayerTag(it) == "water" }

/**
 * Integer tile column/row for encoded texture and stencil keys at [zChild], matching
 * [datelineAdjustment] X-wrap and the partial walk in [com.xweather.mapsgl.gl.RenderPass.determinePartial].
 * Safe to call before or after [datelineAdjustment] on X (idempotent once X is in `[0,n)`).
 */
internal fun meshTileXYForEncodedLookup(meshInfo: MeshInfo, zChild: Int): Pair<Int, Int> {
    val n = 1 shl zChild
    if (zChild !in 0..30 || n <= 0) return 0 to 0
    var xf = meshInfo.x
    while (xf < 0f) xf += n
    while (xf >= n) xf -= n
    val x = kotlin.math.floor(xf.toDouble()).toInt()
    var y = meshInfo.y.toInt()
    y = (y % n + n) % n
    return x to y
}

internal fun normalizeStencilTileKey(coordHash: String): String {
    val c = coordHash.indexOf(':')
    if (c < 0) return coordHash
    val path = coordHash.substring(c + 1)
    val segs = path.split('/').map { it.trim() }.filter { it.isNotEmpty() }
    if (segs.size < 3) return coordHash
    val z = segs[0].toIntOrNull() ?: return coordHash
    val x = segs[1].toIntOrNull() ?: return coordHash
    val y = segs[2].toIntOrNull() ?: return coordHash
    if (z !in 0..30) return coordHash
    val n = 1 shl z
    if (n <= 0) return coordHash
    val nx = ((x % n) + n) % n
    val ny = ((y % n) + n) % n
    // Prefix 0: canonical geographic tile; strip wrap and time.
    return "0:$z/$nx/$ny"
}

/**
 * Matches the canonical `0:z/x/y` identity used to key encoded tile textures in [com.xweather.mapsgl.gl.RenderPass]
 * (`meshInfoToTileHashShort` + dateline wrap), and therefore must match [normalizeStencilTileKey] for
 * [com.xweather.mapsgl.tiles.Tile] hashes from [base.osm] after wrap normalization.
 * Using [MeshInfo.inspectorHash] alone can miss the cache when float x/y or time suffixes differ from
 * the vector [TileCoord] string while denoting the same map tile.
 */
internal fun stencilCacheKeyForMeshInfo(meshInfo: MeshInfo): String {
    val zInt = meshInfo.z.toInt()
    if (zInt !in 0..30) {
        return normalizeStencilTileKey(meshInfo.inspectorHash)
    }
    val n = 1 shl zInt
    if (n <= 0) {
        return normalizeStencilTileKey(meshInfo.inspectorHash)
    }
    val (x, y) = meshTileXYForEncodedLookup(meshInfo, zInt)
    return "0:$zInt/$x/$y"
}

/** Parse "0:z/x/y" (input must come from [normalizeStencilTileKey] / [stencilCacheKeyForMeshInfo]). */
private fun parseStencilCanonical0zxy(key: String): Triple<Int, Int, Int>? {
    if (!key.startsWith("0:")) return null
    val path = key.substring(2)
    val segs = path.split('/').map { it.trim() }.filter { it.isNotEmpty() }
    if (segs.size < 3) return null
    val z = segs[0].toIntOrNull() ?: return null
    val x = segs[1].toIntOrNull() ?: return null
    val y = segs[2].toIntOrNull() ?: return null
    if (z !in 0..30) return null
    return Triple(z, x, y)
}

/**
 * CPU-side triangle soup per tile coord-hash and mask kind, fed from [VectorTileSource] MVT parses.
 * GPU buffers are created lazily by [GlStencilMaskRenderer] on the GL thread.
 */
internal class GlStencilMaskTileCache {
    private companion object {
        private const val LAND_PUT_LOG_MAX = 8
        private var landPutLogRemaining = LAND_PUT_LOG_MAX
        private val COUNTRY_STENCIL_RIBBON_HALF_WIDTH_UV =
            (2.5 / 400.0).toFloat().coerceIn(0.001f, 0.05f)
        // Comma-separated "z/x/y" tiles to trace stencil pipeline end-to-end.
        private const val MASK_DEBUG_TARGETS = "6/19/21,6/19/22,6/20/21,6/20/22,6/19/23,6/20/23"
    }

    private fun maskDebugMatchesCanonical0zxy(key: String): Boolean {
        if (MASK_DEBUG_TARGETS.isEmpty()) return false
        val normalized = key.removePrefix("0:")
        return MASK_DEBUG_TARGETS.split(',').any { it.trim() == normalized }
    }

    /**
     * Tile-UV triangle soup for one stencil mask, backed by an off-heap [FloatBuffer] from
     * [DirectFloatBufferPool]. Keeping the vertex bytes off the Java heap was the final
     * step in eliminating LOS GC during a Demo 3 width-slider drag (motorway ribbons emit
     * hundreds of KB per tile and would otherwise live as `FloatArray`s in the cache for
     * the tile's full lifetime). Identity equality is intentional: [FloatBuffer.equals] is
     * content-based and would iterate every vertex on every cache lookup, and the renderer
     * tracks meshes by reference identity anyway.
     *
     * Lifetime: a [CpuMesh] owns its [vertices] buffer. When the cache evicts or replaces a
     * mesh, [releaseDeferred] returns the buffer to the pool on the next GL frame so a
     * renderer that just sampled the mesh can finish its read first. Construct only via
     * builder paths that pull from the pool — do not pass a buffer you intend to keep
     * sharing.
     *
     * @param geoJsonStencilSequence [com.xweather.mapsgl.sources.GeoJSONSource.geoJsonStencilSequence] when this mesh
     * was built from inline GeoJSON for a custom stencil mask; `-1` for MVT / other sources.
     */
    class CpuMesh(
        val vertices: FloatBuffer,
        val vertexCount: Int,
        val geoJsonStencilSequence: Int = -1,
    ) {
        private val released = java.util.concurrent.atomic.AtomicBoolean(false)

        /**
         * Queues the underlying direct buffer for return to [DirectFloatBufferPool] at the
         * next GL-thread drain. Safe to call from any thread.
         *
         * **Idempotent.** A second call is a silent no-op rather than an exception. Two
         * sources can validly believe they own a [CpuMesh] in race conditions around rapid
         * paint changes (cache mutation thread and `clearAndReleaseAll` from a parallel
         * unregister, for example), and we'd rather not crash on the duplicate — and more
         * importantly, the duplicate must never re-enqueue the buffer, because two pool
         * release of the same direct buffer means two `acquire`s can hand it to parallel
         * workers and the resulting double-write would corrupt vertex data right under a
         * `glBufferData` upload.
         */
        fun releaseDeferred() {
            if (released.compareAndSet(false, true)) {
                DirectFloatBufferPool.releaseDeferred(vertices)
            }
        }
    }

    /**
     * Drains every [CpuMesh] from [map] and queues each one for deferred release.
     * Equivalent to `map.clear()` but doesn't leak the displaced direct buffers.
     */
    private fun clearAndReleaseAll(map: ConcurrentHashMap<String, CpuMesh>) {
        if (map.isEmpty()) return
        // `values.iterator()` on ConcurrentHashMap is weakly consistent; another thread
        // putting concurrently won't blow this up but may leave residue. `clear()` after
        // the iteration is the simplest way to ensure we don't keep any references alive,
        // and any post-clear inserts are by-definition not the displaced meshes.
        for (mesh in map.values) {
            mesh.releaseDeferred()
        }
        map.clear()
    }

    /**
     * Removes [key] from [map] and queues the displaced mesh (if any) for deferred release.
     */
    private fun removeAndRelease(map: ConcurrentHashMap<String, CpuMesh>, key: String) {
        map.remove(key)?.releaseDeferred()
    }

    /**
     * Puts [mesh] into [map] under [key], replacing any previous entry. The displaced mesh
     * (if any) is queued for deferred release so its direct buffer eventually returns to
     * the pool.
     */
    private fun putAndRelease(
        map: ConcurrentHashMap<String, CpuMesh>,
        key: String,
        mesh: CpuMesh,
    ) {
        val previous = map.put(key, mesh)
        if (previous != null && previous !== mesh) previous.releaseDeferred()
    }

    private val land = ConcurrentHashMap<String, CpuMesh>()
    private val water = ConcurrentHashMap<String, CpuMesh>()
    /** Centerline paths from MVT `transportation` (roads, paths, etc.), in tile UV space. */
    private val transportationPaths = ConcurrentHashMap<String, List<GlStencilMaskMeshBuilder.LinePath>>()
    private val transportationPathsRemapped =
        ConcurrentHashMap<String, List<GlStencilMaskMeshBuilder.LinePath>>()
    /** Per ISO alpha-2: tile key → country border ribbon mesh. */
    private val countryByIso = ConcurrentHashMap<String, ConcurrentHashMap<String, CpuMesh>>()
    private val countryRemappedFromAncestor = ConcurrentHashMap<String, CpuMesh>()
    /** Remapped tile-UV masks keyed like `0:8/1/1_a2_v2` (see [getCpuMeshForRender]). */
    private val remappedFromAncestor = ConcurrentHashMap<String, CpuMesh>()

    /** Per vector style layer id: canonical tile key → mesh (custom stencil masks). */
    private val customByLayer = ConcurrentHashMap<String, ConcurrentHashMap<String, CpuMesh>>()
    private val customRemappedFromAncestor = ConcurrentHashMap<String, CpuMesh>()

    /**
     * GeoJSON stencil builds call [StencilMaskFilter.matches] for every feature on every new tile
     * until [getExactCustomMaskMesh] hits — panning Demo 3 re-walked the full CONUS collection per
     * visible tile. Key: `maskLayerId|geoJsonStencilSequence|filterHash`.
     */
    private val geoJsonStencilFilteredFeatures = ConcurrentHashMap<String, List<Feature>>()

    private fun table(kind: MaskLayerKind): ConcurrentHashMap<String, CpuMesh>? = when (kind) {
        MaskLayerKind.LAND -> land
        MaskLayerKind.WATER -> water
        else -> null
    }

    /**
     * Remaps [parent] mesh in **parent** tile UVs into the **child** tile’s 0..1 (when swell / encoded
     * layer requests a finer zoom than [base.osm] has populated yet, `dz` is how many levels up the
     * parent is). UV convention matches [GlStencilMaskMeshBuilder]: u west→east, v=0 North v=1 South.
     * Mapbox/Slippy (XYZ) tile y: 0 = north, y increases **south**; the child with **even** y is the
     * **northern** sub-tile (2·parent_y), so bit 0 → parent V window [0,mid] (north) via `v1 = midV`.
     *
     * Quadtree splits must be applied **coarse-to-fine** (MSB of tile index first). Applying LSB-first
     * scrambles the UV window for dz>1 (wrong partial masks).
     */
    private fun remapParentMeshToChildUvs(
        parent: CpuMesh,
        xChild: Int,
        yChild: Int,
        dz: Int,
    ): CpuMesh? {
        if (dz < 1) return null
        // FloatBuffer.limit() is the count of valid floats (vertexCount * 2); the underlying
        // capacity is bucketed by `DirectFloatBufferPool` and may be larger, so .capacity()
        // would over-report.
        val nFloat = parent.vertices.limit()
        if (parent.vertexCount * 2 != nFloat || nFloat < 6) return null
        var u0 = 0f
        var u1 = 1f
        var v0 = 0f
        var v1 = 1f
        for (level in 0 until dz) {
            val shift = dz - 1 - level
            val bitX = (xChild ushr shift) and 1
            val bitY = (yChild ushr shift) and 1
            val midU = 0.5f * (u0 + u1)
            if (bitX == 0) {
                u1 = midU
            } else {
                u0 = midU
            }
            val midV = 0.5f * (v0 + v1)
            if (bitY == 0) {
                v1 = midV
            } else {
                v0 = midV
            }
        }
        val wu = (u1 - u0).coerceAtLeast(1e-6f)
        val wv = (v1 - v0).coerceAtLeast(1e-6f)
        val invWu = 1f / wu
        val invWv = 1f / wv
        // Parent-UV window [u0,u1]×[v0,v1] maps to child 0..1.
        // Important: do not snap straddling triangles by clamping each vertex independently; that can
        // expand thin coastal triangles into full child coverage (stencil=1 everywhere).
        // Clip each triangle against the child window (Sutherland-Hodgman), then map to child UV.
        //
        // Performance: this routine runs once per (mask, child-tile) but the cache invalidates
        // every paint change in Demo 3, so during a width-slider drag it runs N visible tiles
        // × 60 fps. The previous List<P2> + ArrayList<P2> implementation allocated roughly
        // `listOf` + 4×ArrayList per parent triangle plus 2 lambdas and 3-5 P2 intersections —
        // ~800 k objects per remap on a 50 k-triangle parent. Now it's a flat `FloatArray`
        // ping-pong with primitive args; the only object that escapes this scope is the
        // output `CpuMesh`.
        val eps = 1e-4f
        val src = parent.vertices
        val srcLen = nFloat
        val out = GlStencilMaskMeshBuilder.FloatArrayList(min(4096, srcLen))
        // A triangle clipped by 4 axis-aligned half-planes is at most 7 vertices (each pass adds
        // at most one intersection per outgoing edge). 16 floats = 8 verts gives one slot of
        // headroom and aligns to a friendly TLAB-sized slab.
        val bufA = FloatArray(16)
        val bufB = FloatArray(16)
        val u0Eps = u0 - eps
        val u1Eps = u1 + eps
        val v0Eps = v0 - eps
        val v1Eps = v1 + eps
        var k = 0
        while (k + 5 < srcLen) {
            // `FloatBuffer.get(int)` is an absolute read; it does not mutate the buffer's
            // position, so this is safe to call concurrently with the renderer also reading
            // the same buffer for `glBufferData` (which reads from position=0 to limit).
            val p0u = src.get(k)
            val p0v = src.get(k + 1)
            val p1u = src.get(k + 2)
            val p1v = src.get(k + 3)
            val p2u = src.get(k + 4)
            val p2v = src.get(k + 5)
            k += 6
            // Manual triple min/max — `kotlin.math.min(a, min(b, c))` boxes through `Float` on
            // some toolchains and shows up in the profile even though each call is "free" in
            // isolation; the explicit ternary form folds to two compares.
            val minPu = if (p0u < p1u) (if (p0u < p2u) p0u else p2u) else (if (p1u < p2u) p1u else p2u)
            val maxPu = if (p0u > p1u) (if (p0u > p2u) p0u else p2u) else (if (p1u > p2u) p1u else p2u)
            val minPv = if (p0v < p1v) (if (p0v < p2v) p0v else p2v) else (if (p1v < p2v) p1v else p2v)
            val maxPv = if (p0v > p1v) (if (p0v > p2v) p0v else p2v) else (if (p1v > p2v) p1v else p2v)
            if (maxPu < u0Eps || minPu > u1Eps || maxPv < v0Eps || minPv > v1Eps) continue

            bufA[0] = p0u; bufA[1] = p0v
            bufA[2] = p1u; bufA[3] = p1v
            bufA[4] = p2u; bufA[5] = p2v

            var n = clipPolyU(bufA, 6, bufB, u0, u0Eps, keepGreater = true)
            if (n < 6) continue
            n = clipPolyU(bufB, n, bufA, u1, u1Eps, keepGreater = false)
            if (n < 6) continue
            n = clipPolyV(bufA, n, bufB, v0, v0Eps, keepGreater = true)
            if (n < 6) continue
            n = clipPolyV(bufB, n, bufA, v1, v1Eps, keepGreater = false)
            if (n < 6) continue

            // Fan-triangulate from vertex 0 of `bufA` and map parent→child UV inline.
            val r0u = (bufA[0] - u0) * invWu
            val r0v = (bufA[1] - v0) * invWv
            var i = 2
            while (i + 3 < n) {
                val pAu = (bufA[i] - u0) * invWu
                val pAv = (bufA[i + 1] - v0) * invWv
                val pBu = (bufA[i + 2] - u0) * invWu
                val pBv = (bufA[i + 3] - v0) * invWv
                val cross = (pAu - r0u) * (pBv - r0v) - (pBu - r0u) * (pAv - r0v)
                if (abs(cross) >= 1e-7f) {
                    out.add(r0u, r0v, pAu, pAv, pBu, pBv)
                }
                i += 2
            }
        }
        if (k != srcLen) {
            // Recycle the pool buffer; otherwise it would leak until the JVM Cleaner ran.
            out.release()
            return null
        }
        if (out.size < 6) {
            out.release()
            return null
        }
        // `toFloatBuffer` returns a pool-backed direct buffer with `position=0, limit=out.size`.
        // It can only be null when `out.size == 0`, which the check above already rejects, so
        // the `!!` is safe.
        val verts = out.toFloatBuffer()!!
        return CpuMesh(verts, out.size / 2, parent.geoJsonStencilSequence)
    }

    /**
     * Sutherland-Hodgman clip of an interleaved (u, v) polygon in [inBuf] against a vertical
     * line `u = edge`. Returns the new polygon size **in floats** (2 per vertex) and writes the
     * result into [outBuf].
     *
     * Vertices are considered "inside" when `u >= epsThreshold` if [keepGreater] is `true`, or
     * `u <= epsThreshold` otherwise. The intersection is computed at the exact `edge` (no eps),
     * which preserves the original code's "include slightly out-of-bounds points but clip the
     * geometry precisely at the half-plane" behaviour.
     *
     * Buffers must be at least 16 floats each (a triangle grows to ≤ 7 verts through 4 clip
     * stages); callers are expected to ping-pong [inBuf] and [outBuf].
     */
    private fun clipPolyU(
        inBuf: FloatArray,
        inSize: Int,
        outBuf: FloatArray,
        edge: Float,
        epsThreshold: Float,
        keepGreater: Boolean,
    ): Int {
        if (inSize < 6) return 0
        var outSize = 0
        var prevU = inBuf[inSize - 2]
        var prevV = inBuf[inSize - 1]
        var prevInside = if (keepGreater) prevU >= epsThreshold else prevU <= epsThreshold
        var i = 0
        while (i < inSize) {
            val curU = inBuf[i]
            val curV = inBuf[i + 1]
            val curInside = if (keepGreater) curU >= epsThreshold else curU <= epsThreshold
            if (curInside != prevInside) {
                val du = curU - prevU
                val t = if (abs(du) < 1e-8f) 0f else (edge - prevU) / du
                outBuf[outSize] = edge
                outBuf[outSize + 1] = prevV + t * (curV - prevV)
                outSize += 2
            }
            if (curInside) {
                outBuf[outSize] = curU
                outBuf[outSize + 1] = curV
                outSize += 2
            }
            prevU = curU
            prevV = curV
            prevInside = curInside
            i += 2
        }
        return outSize
    }

    /** Horizontal-edge analogue of [clipPolyU]; clips against `v = edge`. */
    private fun clipPolyV(
        inBuf: FloatArray,
        inSize: Int,
        outBuf: FloatArray,
        edge: Float,
        epsThreshold: Float,
        keepGreater: Boolean,
    ): Int {
        if (inSize < 6) return 0
        var outSize = 0
        var prevU = inBuf[inSize - 2]
        var prevV = inBuf[inSize - 1]
        var prevInside = if (keepGreater) prevV >= epsThreshold else prevV <= epsThreshold
        var i = 0
        while (i < inSize) {
            val curU = inBuf[i]
            val curV = inBuf[i + 1]
            val curInside = if (keepGreater) curV >= epsThreshold else curV <= epsThreshold
            if (curInside != prevInside) {
                val dv = curV - prevV
                val t = if (abs(dv) < 1e-8f) 0f else (edge - prevV) / dv
                outBuf[outSize] = prevU + t * (curU - prevU)
                outBuf[outSize + 1] = edge
                outSize += 2
            }
            if (curInside) {
                outBuf[outSize] = curU
                outBuf[outSize + 1] = curV
                outSize += 2
            }
            prevU = curU
            prevV = curV
            prevInside = curInside
            i += 2
        }
        return outSize
    }

    private fun remapParentPathsToChildUvs(
        parentPaths: List<GlStencilMaskMeshBuilder.LinePath>,
        xChild: Int,
        yChild: Int,
        dz: Int,
    ): List<GlStencilMaskMeshBuilder.LinePath> {
        if (dz < 1 || parentPaths.isEmpty()) return emptyList()
        var u0 = 0f
        var u1 = 1f
        var v0 = 0f
        var v1 = 1f
        for (level in 0 until dz) {
            val shift = dz - 1 - level
            val bitX = (xChild ushr shift) and 1
            val bitY = (yChild ushr shift) and 1
            val midU = 0.5f * (u0 + u1)
            if (bitX == 0) u1 = midU else u0 = midU
            val midV = 0.5f * (v0 + v1)
            if (bitY == 0) v1 = midV else v0 = midV
        }
        val wu = (u1 - u0).coerceAtLeast(1e-6f)
        val wv = (v1 - v0).coerceAtLeast(1e-6f)

        fun clipSegToUnit(ax: Float, ay: Float, bx: Float, by: Float): FloatArray? {
            var t0 = 0f
            var t1 = 1f
            val dx = bx - ax
            val dy = by - ay
            fun clip(p: Float, q: Float): Boolean {
                if (abs(p) < 1e-8f) return q >= 0f
                val r = q / p
                if (p < 0f) {
                    if (r > t1) return false
                    if (r > t0) t0 = r
                } else {
                    if (r < t0) return false
                    if (r < t1) t1 = r
                }
                return true
            }
            if (!clip(-dx, ax)) return null
            if (!clip(dx, 1f - ax)) return null
            if (!clip(-dy, ay)) return null
            if (!clip(dy, 1f - ay)) return null
            val x0 = ax + t0 * dx
            val y0 = ay + t0 * dy
            val x1 = ax + t1 * dx
            val y1 = ay + t1 * dy
            return floatArrayOf(x0, y0, x1, y1)
        }

        val out = ArrayList<GlStencilMaskMeshBuilder.LinePath>(parentPaths.size)
        for (path in parentPaths) {
            val p = path.pointsUv
            if (p.size < 4) continue
            val accum = ArrayList<Float>(p.size)
            var i = 0
            while (i + 3 < p.size) {
                val aU = (p[i] - u0) / wu
                val aV = (p[i + 1] - v0) / wv
                val bU = (p[i + 2] - u0) / wu
                val bV = (p[i + 3] - v0) / wv
                val clipped = clipSegToUnit(aU, aV, bU, bV)
                if (clipped != null) {
                    if (accum.isEmpty()) {
                        accum.add(clipped[0]); accum.add(clipped[1])
                    } else {
                        val lu = accum[accum.lastIndex - 1]
                        val lv = accum[accum.lastIndex]
                        if (abs(lu - clipped[0]) > 1e-4f || abs(lv - clipped[1]) > 1e-4f) {
                            accum.add(clipped[0]); accum.add(clipped[1])
                        }
                    }
                    accum.add(clipped[2]); accum.add(clipped[3])
                }
                i += 2
            }
            if (accum.size >= 4) out.add(GlStencilMaskMeshBuilder.LinePath(accum.toFloatArray()))
        }
        return out
    }

    /**
     * Returns mesh + storage key for the GLES VBO cache. When no data exists at the same zoom as the
     * weather tile, reuses a **coarser** [base.osm] tile and remaps UVs (so swell can still be clipped
     * to land if Mapbox has not fetched a matching vector z yet).
     */
    fun getCpuMeshForRender(cacheKey: String, kind: MaskLayerKind): Pair<CpuMesh, String>? {
        if (kind != MaskLayerKind.LAND && kind != MaskLayerKind.WATER && kind != MaskLayerKind.TRANSPORTATION) {
            return null
        }
        if (kind == MaskLayerKind.TRANSPORTATION) return null
        val t = table(kind) ?: return null
        val k0 = normalizeStencilTileKey(cacheKey)
        return meshWithAncestorRemap(kind, t, k0, remappedFromAncestor, null)
    }

    fun getTransportationPathsForRender(cacheKey: String): Pair<List<GlStencilMaskMeshBuilder.LinePath>, String>? {
        val k0 = normalizeStencilTileKey(cacheKey)
        transportationPaths[k0]?.let { p -> if (p.isNotEmpty()) return p to k0 }
        val parsed = parseStencilCanonical0zxy(k0) ?: return null
        val (zChild, xChild, yChild) = parsed
        for (dz in 1..8) {
            val zp = zChild - dz
            if (zp < 0) break
            val xP = xChild ushr dz
            val yP = yChild ushr dz
            val pKey = "0:$zp/$xP/$yP"
            val parent = transportationPaths[pKey] ?: continue
            val storageKey = k0 + "_a${dz}_p1"
            transportationPathsRemapped[storageKey]?.let { cached ->
                if (cached.isNotEmpty()) return cached to storageKey
            }
            val remapped = remapParentPathsToChildUvs(parent, xChild, yChild, dz)
            if (remapped.isEmpty()) continue
            transportationPathsRemapped[storageKey] = remapped
            return remapped to storageKey
        }
        return null
    }

    fun getCpuMeshForCountry(isoAlpha2: String, cacheKey: String): Pair<CpuMesh, String>? {
        val iso = isoAlpha2.uppercase(Locale.US)
        val t = countryByIso[iso] ?: return null
        val k0 = normalizeStencilTileKey(cacheKey)
        return meshWithAncestorRemap(
            MaskLayerKind.COUNTRY,
            t,
            k0,
            countryRemappedFromAncestor,
            iso,
        )
    }

    private fun meshWithAncestorRemap(
        kind: MaskLayerKind,
        t: ConcurrentHashMap<String, CpuMesh>,
        k0: String,
        remappedTable: ConcurrentHashMap<String, CpuMesh>,
        extraRemapSegment: String?,
    ): Pair<CpuMesh, String>? {
        t[k0]?.let { m -> return m to k0 }
        val parsed = parseStencilCanonical0zxy(k0) ?: return null
        val (zChild, xChild, yChild) = parsed
        for (dz in 1..8) {
            val zp = zChild - dz
            if (zp < 0) break
            val xP = xChild ushr dz
            val yP = yChild ushr dz
            val pKey = "0:$zp/$xP/$yP"
            val parent = t[pKey] ?: continue
            val vboKey = k0 + "_a${dz}_v4"
            val remapKey = if (extraRemapSegment == null) {
                "${kind.ordinal}|$vboKey"
            } else {
                "${kind.ordinal}|$extraRemapSegment|$vboKey"
            }
            remappedTable[remapKey]?.let { cached ->
                if (cached.vertexCount >= 3) return cached to vboKey
            }
            val remapped = remapParentMeshToChildUvs(parent, xChild, yChild, dz) ?: continue
            if (remapped.vertexCount < 3) {
                remapped.releaseDeferred()
                continue
            }
            putAndRelease(remappedTable, remapKey, remapped)
            return remapped to vboKey
        }
        return null
    }

    /**
     * Like [getCpuMeshForRender], but remaps only from the encoded raster ancestor at
     * [rasterZ]/[rasterX]/[rasterY]. The GLES stencil path uses [getCpuMeshForRender] so vector
     * detail follows map zoom, not weather partials.
     */
    fun getCpuMeshForRenderMatchingRaster(
        cacheKey: String,
        kind: MaskLayerKind,
        rasterZ: Int,
        rasterX: Int,
        rasterY: Int,
    ): Pair<CpuMesh, String>? {
        if (kind != MaskLayerKind.LAND && kind != MaskLayerKind.WATER && kind != MaskLayerKind.TRANSPORTATION) {
            return null
        }
        val t = table(kind) ?: return null
        val k0 = normalizeStencilTileKey(cacheKey)
        val parsed = parseStencilCanonical0zxy(k0) ?: return getCpuMeshForRender(cacheKey, kind)
        val (zChild, xChild, yChild) = parsed

        // Native child mesh first for maximum OSM detail. No max-zoom cap on the mask (only
        // [GlStencilMaskRenderer] LAND min-z fail-open). When child is missing, remap from the same
        // z/x/y as phase-A raster so partial encoded tiles stay aligned.
        t[k0]?.let { m -> return m to k0 }

        if (rasterZ == zChild) {
            return getCpuMeshForRender(cacheKey, kind)
        }
        if (rasterZ < 0 || rasterZ > zChild) {
            return getCpuMeshForRender(cacheKey, kind)
        }
        val dz = zChild - rasterZ
        if (dz < 1) return getCpuMeshForRender(cacheKey, kind)

        val xExpect = xChild ushr dz
        val yExpect = yChild ushr dz
        if (rasterX != xExpect || rasterY != yExpect) {
            return getCpuMeshForRender(cacheKey, kind)
        }

        val pKey = "0:$rasterZ/$rasterX/$rasterY"
        val parent = t[pKey] ?: return getCpuMeshForRender(cacheKey, kind)

        val vboKey = k0 + "_a${dz}_v4"
        val remapKey = "${kind.ordinal}|$vboKey"
        remappedFromAncestor[remapKey]?.let { cached ->
            if (cached.vertexCount >= 3) return cached to vboKey
        }
        val remapped = remapParentMeshToChildUvs(parent, xChild, yChild, dz)
            ?: return getCpuMeshForRender(cacheKey, kind)
        if (remapped.vertexCount < 3) {
            remapped.releaseDeferred()
            return getCpuMeshForRender(cacheKey, kind)
        }
        putAndRelease(remappedFromAncestor, remapKey, remapped)
        return remapped to vboKey
    }

    fun hasMeshForCountry(isoAlpha2: String, cacheKey: String): Boolean {
        val iso = isoAlpha2.uppercase(Locale.US)
        val t = countryByIso[iso] ?: return false
        val k0 = normalizeStencilTileKey(cacheKey)
        if (t.containsKey(k0)) return true
        val parsed = parseStencilCanonical0zxy(k0) ?: return false
        val (zChild, xChild, yChild) = parsed
        for (dz in 1..8) {
            val zp = zChild - dz
            if (zp < 0) break
            val xP = xChild ushr dz
            val yP = yChild ushr dz
            if (t.containsKey("0:$zp/$xP/$yP")) return true
        }
        return false
    }

    /**
     * Exact-only existence check (no ancestor remap).
     * Useful when callers want to keep requesting child-z meshes even though a fallback ancestor
     * mesh is currently renderable.
     */
    fun hasExactMeshForRender(cacheKey: String, kind: MaskLayerKind): Boolean {
        if (kind != MaskLayerKind.LAND && kind != MaskLayerKind.WATER && kind != MaskLayerKind.TRANSPORTATION) {
            return false
        }
        val k0 = normalizeStencilTileKey(cacheKey)
        if (kind == MaskLayerKind.TRANSPORTATION) {
            return transportationPaths.containsKey(k0)
        }
        val t = table(kind) ?: return false
        return t.containsKey(k0)
    }

    /**
     * Fast existence check without allocating remapped child meshes.
     */
    fun hasMeshForRender(cacheKey: String, kind: MaskLayerKind): Boolean {
        if (kind != MaskLayerKind.LAND && kind != MaskLayerKind.WATER && kind != MaskLayerKind.TRANSPORTATION) {
            return false
        }
        if (kind == MaskLayerKind.TRANSPORTATION) return getTransportationPathsForRender(cacheKey) != null
        val t = table(kind) ?: return false
        val k0 = normalizeStencilTileKey(cacheKey)
        if (t.containsKey(k0)) {
            if (maskDebugMatchesCanonical0zxy(k0)) {
                MapsGLDebug.trace("[MaskDebug][Cache] hit exact key=$k0 kind=$kind")
            }
            return true
        }
        val parsed = parseStencilCanonical0zxy(k0) ?: return false
        val (zChild, xChild, yChild) = parsed
        for (dz in 1..8) {
            val zp = zChild - dz
            if (zp < 0) break
            val xP = xChild ushr dz
            val yP = yChild ushr dz
            if (t.containsKey("0:$zp/$xP/$yP")) {
                if (maskDebugMatchesCanonical0zxy(k0)) {
                    MapsGLDebug.trace("[MaskDebug][Cache] hit ancestor key=$k0 parent=0:$zp/$xP/$yP kind=$kind")
                }
                return true
            }
        }
        if (maskDebugMatchesCanonical0zxy(k0)) {
            MapsGLDebug.trace("[MaskDebug][Cache] miss key=$k0 kind=$kind")
        }
        return false
    }

    fun clearCountryIso(isoAlpha2: String) {
        val iso = isoAlpha2.uppercase(Locale.US)
        countryByIso.remove(iso)?.let { displaced ->
            for (mesh in displaced.values) mesh.releaseDeferred()
        }
        val prefix = "${MaskLayerKind.COUNTRY.ordinal}|$iso|"
        countryRemappedFromAncestor.keys.filter { it.startsWith(prefix) }
            .forEach { removeAndRelease(countryRemappedFromAncestor, it) }
    }

    fun clearKind(kind: MaskLayerKind) {
        when (kind) {
            MaskLayerKind.LAND -> clearAndReleaseAll(land)
            MaskLayerKind.WATER -> clearAndReleaseAll(water)
            MaskLayerKind.TRANSPORTATION -> {
                transportationPaths.clear()
                transportationPathsRemapped.clear()
            }
            MaskLayerKind.COUNTRY -> {
                for (inner in countryByIso.values) clearAndReleaseAll(inner)
                countryByIso.clear()
                clearAndReleaseAll(countryRemappedFromAncestor)
            }
            else -> {}
        }
        clearAndReleaseAll(remappedFromAncestor)
    }

    fun clearAll() {
        clearAndReleaseAll(land)
        clearAndReleaseAll(water)
        transportationPaths.clear()
        transportationPathsRemapped.clear()
        for (inner in countryByIso.values) clearAndReleaseAll(inner)
        countryByIso.clear()
        clearAndReleaseAll(countryRemappedFromAncestor)
        clearAndReleaseAll(remappedFromAncestor)
        for (inner in customByLayer.values) clearAndReleaseAll(inner)
        customByLayer.clear()
        clearAndReleaseAll(customRemappedFromAncestor)
        geoJsonStencilFilteredFeatures.clear()
        GlStencilGeoJsonMaskMeshCoordinator.cancelAllPendingGeoJsonStencilBuilds()
    }

    fun putCustomMaskMesh(maskLayerId: String, coordHash: String, mesh: CpuMesh) {
        val key = normalizeStencilTileKey(coordHash)
        val inner = customByLayer.computeIfAbsent(maskLayerId) { ConcurrentHashMap() }
        putAndRelease(inner, key, mesh)
    }

    /** Exact tile only (no ancestor remap); used to skip redundant GeoJSON stencil rebuilds. */
    internal fun getExactCustomMaskMesh(maskLayerId: String, coordHash: String): CpuMesh? {
        val key = normalizeStencilTileKey(coordHash)
        return customByLayer[maskLayerId]?.get(key)
    }

    /**
     * Caches the result of filtering a GeoJSON source's features for [StencilMaskFilter] once per
     * stable `(maskLayerId, geoJsonStencilSequence, filter)`; new tiles during pan only run the
     * per-tile triangle build, not a full collection scan (important for large static polygons).
     */
    fun getOrComputeGeoJsonStencilFilteredFeatures(
        maskLayerId: String,
        geoJsonStencilSequence: Int,
        filter: Expression?,
        allFeatures: () -> List<Feature>,
    ): List<Feature> {
        val cacheKey = "$maskLayerId|$geoJsonStencilSequence|${filter?.hashCode() ?: 0}"
        geoJsonStencilFilteredFeatures[cacheKey]?.let { return it }
        val all = allFeatures()
        val filtered = all.filter { StencilMaskFilter.matches(it, filter) }
        val raced = geoJsonStencilFilteredFeatures.putIfAbsent(cacheKey, filtered)
        return raced ?: filtered
    }

    fun removeCustomMaskTile(maskLayerId: String, coordHash: String) {
        val key = normalizeStencilTileKey(coordHash)
        customByLayer[maskLayerId]?.let { removeAndRelease(it, key) }
        val prefix = "$maskLayerId|"
        customRemappedFromAncestor.keys.filter { it.startsWith(prefix) && it.contains("|${key}_a") }
            .forEach { removeAndRelease(customRemappedFromAncestor, it) }
        invalidateCustomRemappedDescendantsOfParentTile(maskLayerId, key)
    }

    fun clearCustomMaskKind(maskLayerId: String) {
        customByLayer.remove(maskLayerId)?.let { displaced ->
            for (mesh in displaced.values) mesh.releaseDeferred()
        }
        val prefix = "$maskLayerId|"
        customRemappedFromAncestor.keys.filter { it.startsWith(prefix) }
            .forEach { removeAndRelease(customRemappedFromAncestor, it) }
        geoJsonStencilFilteredFeatures.keys.removeIf { it.startsWith("$maskLayerId|") }
        GlStencilGeoJsonMaskMeshCoordinator.cancelPendingForMaskLayer(maskLayerId)
    }

    /**
     * Drop *only* the ancestor-remapped meshes for [maskLayerId], leaving the directly-built
     * parent meshes in [customByLayer] untouched. Called by
     * [GlStencilCustomMaskCoordinator.refreshPaint] when a mask layer's paint changes: new builds
     * write fresh parents into [customByLayer], but every child tile that was being rendered via
     * `getCpuMeshForCustomMask`'s ancestor-walk had the *old* parent's remapped triangles cached
     * here. Without this eviction, `getCpuMeshForCustomMask` keeps returning the stale remap and
     * the renderer never picks up the new line width — that's the "doesn't change for already-loaded
     * areas" symptom in Demo 3 (where the camera is at z=4 but the cached MVT tiles are z=3).
     */
    fun invalidateCustomRemappedFor(maskLayerId: String) {
        val prefix = "$maskLayerId|"
        customRemappedFromAncestor.keys.filter { it.startsWith(prefix) }
            .forEach { removeAndRelease(customRemappedFromAncestor, it) }
    }

    /**
     * Drops only ancestor-remapped entries that were built from the parent tile [parentTileKey]
     * (canonical `0:z/x/y`) for [maskLayerId].
     *
     * Previously every successful MVT write called [invalidateCustomRemappedFor], which cleared
     * **all** remaps for the mask. During pinch-zoom, many tiles still draw via parent→child UV
     * remaps while finer `z` tiles stream in; wiping unrelated remaps caused the mask to flash
     * between levels (notably Demo 3's motorway ribbon).
     */
    fun invalidateCustomRemappedDescendantsOfParentTile(maskLayerId: String, parentTileKey: String) {
        val pNorm = normalizeStencilTileKey(parentTileKey)
        val parsedP = parseStencilCanonical0zxy(pNorm) ?: return
        val (zp, xp, yp) = parsedP
        val prefix = "$maskLayerId|"
        val toRemove = ArrayList<String>()
        for (key in customRemappedFromAncestor.keys.toList()) {
            if (!key.startsWith(prefix)) continue
            val (childKey, dz) = parseCustomRemapStorageKey(key, maskLayerId) ?: continue
            val parsedC = parseStencilCanonical0zxy(childKey) ?: continue
            val (zc, xc, yc) = parsedC
            if (zc - dz != zp) continue
            if (xc ushr dz != xp) continue
            if (yc ushr dz != yp) continue
            toRemove.add(key)
        }
        for (key in toRemove) {
            removeAndRelease(customRemappedFromAncestor, key)
        }
    }

    /** Parses keys written by [getCpuMeshForCustomMask] into `(childCanonicalKey, dz)`. */
    private fun parseCustomRemapStorageKey(key: String, maskLayerId: String): Pair<String, Int>? {
        val prefix = "$maskLayerId|"
        if (!key.startsWith(prefix) || !key.endsWith("_v4")) return null
        val mid = key.substring(prefix.length, key.length - "_v4".length) // e.g. 0:5/10/12_a3
        val idx = mid.lastIndexOf("_a")
        if (idx <= 0) return null
        val childKey = mid.substring(0, idx)
        val dz = mid.substring(idx + 2).toIntOrNull() ?: return null
        if (!childKey.startsWith("0:")) return null
        return childKey to dz
    }

    /**
     * Ancestor-remapped mesh for [cacheKey] (child tile) only — does **not** use an exact mesh
     * stored for the child.
     *
     * When a finer MVT lands, [getCpuMeshForCustomMask] prefers the exact child entry, which
     * changes the GPU cache key from `maskId|…_a{dz}_v4` to `0:z/x/y`. A brand-new key can be
     * denied by the stencil VBO upload throttle for one frame; the renderer may draw this path
     * instead so an existing remapped VBO keeps the mask stable.
     */
    fun getAncestorRemappedCpuMeshForCustomMask(maskLayerId: String, cacheKey: String): Pair<CpuMesh, String>? {
        val t = customByLayer[maskLayerId] ?: return null
        val k0 = normalizeStencilTileKey(cacheKey)
        val parsed = parseStencilCanonical0zxy(k0) ?: return null
        val (zChild, xChild, yChild) = parsed
        for (dz in 1..8) {
            val zp = zChild - dz
            if (zp < 0) break
            val xP = xChild ushr dz
            val yP = yChild ushr dz
            val pKey = "0:$zp/$xP/$yP"
            val parent = t[pKey] ?: continue
            val vboKey = "$maskLayerId|$k0" + "_a${dz}_v4"
            customRemappedFromAncestor[vboKey]?.let { cached ->
                if (cached.vertexCount >= 3) return cached to vboKey
            }
            val remapped = remapParentMeshToChildUvs(parent, xChild, yChild, dz) ?: continue
            if (remapped.vertexCount < 3) {
                remapped.releaseDeferred()
                continue
            }
            putAndRelease(customRemappedFromAncestor, vboKey, remapped)
            return remapped to vboKey
        }
        return null
    }

    /**
     * Like [getCpuMeshForRender] but for meshes stored under [maskLayerId] (vector style layer id).
     */
    fun getCpuMeshForCustomMask(maskLayerId: String, cacheKey: String): Pair<CpuMesh, String>? {
        val t = customByLayer[maskLayerId] ?: return null
        val k0 = normalizeStencilTileKey(cacheKey)
        t[k0]?.let { m -> return m to k0 }
        return getAncestorRemappedCpuMeshForCustomMask(maskLayerId, cacheKey)
    }

    fun putFromFeatures(
        coord: TileCoord,
        coordHash: String,
        features: List<Feature>,
    ) {
        val key = normalizeStencilTileKey(coordHash)
        val debugMaskTile = maskDebugMatchesCanonical0zxy(key)
        val landFeats = features.filter { featureLayerTag(it) == "water::inverted" }
        if (landFeats.isNotEmpty()) {
            val tri = GlStencilMaskMeshBuilder.buildTileUvTriangles(coord, landFeats)
            if (tri != null) {
                val mesh = CpuMesh(tri, tri.limit() / 2)
                putAndRelease(land, key, mesh)
                if (landPutLogRemaining > 0) {
                    landPutLogRemaining--
                    MapsGLDebug.trace(
                        "[GlStencilMask] land mesh stored: key=$key vertexCount=${mesh.vertexCount} " +
                            "(${landFeats.size} water::inverted features)",
                    )
                }
                if (debugMaskTile) {
                    MapsGLDebug.trace("[MaskDebug][Cache] stored land key=$key verts=${mesh.vertexCount} feats=${landFeats.size}")
                }
            } else if (landPutLogRemaining > 0) {
                landPutLogRemaining--
                MapsGLDebug.trace(
                    "[GlStencilMask] water::inverted had ${landFeats.size} features but 0 mask triangles for key=$key; check geometry",
                )
            }
        }
        val waterFeats = features.filter { featureLayerTag(it) == "water" }
        if (waterFeats.isNotEmpty()) {
            val tri = GlStencilMaskMeshBuilder.buildTileUvTriangles(coord, waterFeats)
            if (tri != null) {
                val mesh = CpuMesh(tri, tri.limit() / 2)
                putAndRelease(water, key, mesh)
                if (debugMaskTile) {
                    MapsGLDebug.trace("[MaskDebug][Cache] stored water key=$key verts=${mesh.vertexCount} feats=${waterFeats.size}")
                }
            }
        }
        val transportFeats = features.filter { featureLayerTag(it) == "transportation" }
        if (transportFeats.isNotEmpty()) {
            val paths = GlStencilMaskMeshBuilder.extractLinePathsTileUv(coord, transportFeats)
            if (paths.isNotEmpty()) {
                transportationPaths[key] = paths
                if (debugMaskTile) {
                    MapsGLDebug.trace(
                        "[MaskDebug][Cache] stored transportation key=$key paths=${paths.size} feats=${transportFeats.size}",
                    )
                }
            }
        }
        val countryIsos = GlStencilMaskCoordinator.activeCountryIsoCodes()
        if (countryIsos.isNotEmpty()) {
            val candidates = features.filter { GlStencilCountryMask.isCountryBoundaryFeature(it) }
            for (iso in countryIsos) {
                val feats = candidates.filter { GlStencilCountryMask.matchesIso(it, iso) }
                val tri = GlStencilMaskMeshBuilder.buildLineRibbonTileUvTriangles(
                    coord,
                    feats,
                    COUNTRY_STENCIL_RIBBON_HALF_WIDTH_UV,
                    GlStencilMaskMeshBuilder.LineRibbonStyle.Default,
                )
                val inner = countryByIso.computeIfAbsent(iso) { ConcurrentHashMap() }
                if (tri != null) {
                    val verts = tri.limit() / 2
                    putAndRelease(inner, key, CpuMesh(tri, verts))
                    if (debugMaskTile) {
                        MapsGLDebug.trace(
                            "[MaskDebug][Cache] stored country $iso key=$key verts=$verts feats=${feats.size}",
                        )
                    }
                } else {
                    removeAndRelease(inner, key)
                }
            }
        }
        if (debugMaskTile && landFeats.isEmpty() && waterFeats.isEmpty() && transportFeats.isEmpty()) {
            MapsGLDebug.trace("[MaskDebug][Cache] no stencil mask features key=$key")
        }
    }

    fun removeTile(coordHash: String) {
        val key = normalizeStencilTileKey(coordHash)
        removeAndRelease(land, key)
        removeAndRelease(water, key)
        transportationPaths.remove(key)
        transportationPathsRemapped.clear()
        for (inner in countryByIso.values) {
            removeAndRelease(inner, key)
        }
        countryRemappedFromAncestor.keys.filter { it.contains("|${key}_a") }
            .forEach { removeAndRelease(countryRemappedFromAncestor, it) }
        clearAndReleaseAll(remappedFromAncestor)
        for (inner in customByLayer.values) {
            removeAndRelease(inner, key)
        }
        customRemappedFromAncestor.keys
            .filter { it.contains("|${key}_a") }
            .forEach { removeAndRelease(customRemappedFromAncestor, it) }
    }

    fun getCpuMesh(coordHash: String, kind: MaskLayerKind): CpuMesh? {
        if (kind == MaskLayerKind.TRANSPORTATION) return null
        return getCpuMeshForRender(coordHash, kind)?.first
    }

    /**
     * Predicts marine [MaskLayerKind.LAND] GLES stencil behavior for [cacheKey] (e.g. from
     * [stencilCacheKeyForMeshInfo]). [MarineLandStencilPrediction.WillStencil.likelyIncompleteOceanStencil]
     * flags tiles that often show incomplete ocean clipping (sparse explicit `water` polys or ancestor UV remap).
     * [MarineLandStencilPrediction.AllLandNoWaterGeometry] covers MAPSGL inland tiles with no `water` MVT.
     */
    fun predictMarineLandStencilOutcome(cacheKey: String): MarineLandStencilPrediction {
        val k0 = normalizeStencilTileKey(cacheKey)
        val parsed = parseStencilCanonical0zxy(k0)
        val z = parsed?.first
        if (z != null && z < GlStencilMaskMarineLand.MIN_ZOOM_FOR_LAND_STENCIL) {
            return MarineLandStencilPrediction.FailClosed.ZoomBelowMinimum
        }
        val meshPair = getCpuMeshForRender(k0, MaskLayerKind.WATER)
            ?: return MarineLandStencilPrediction.AllLandNoWaterGeometry
        val (mesh, storageKey) = meshPair
        if (mesh.vertexCount < 3) {
            return MarineLandStencilPrediction.AllLandNoWaterGeometry
        }
        val area = GlStencilMaskMarineLand.waterMeshUvArea(mesh)
        if (GlStencilMaskMarineLand.isEffectivelyEmptyWaterMask(area)) {
            return MarineLandStencilPrediction.AllLandNoWaterGeometry
        }
        val usesAncestorRemap = '_' in storageKey
        val sparse = area < GlStencilMaskMarineLand.SPARSE_WATER_COVERAGE_HEURISTIC_UV_AREA
        return MarineLandStencilPrediction.WillStencil(
            normalizedKey = k0,
            storageKey = storageKey,
            waterUvArea = area,
            usesAncestorRemap = usesAncestorRemap,
            likelyIncompleteOceanStencil = sparse || usesAncestorRemap,
        )
    }
}
