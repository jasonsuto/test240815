package com.xweather.mapsgl.map.mapbox

import com.xweather.mapsgl.style.Expression

/**
 * Walks one or more [Expression] trees and collects every property key referenced via a `["get",
 * key, ...]` sub-expression (including nested-path forms like `["get", "b", ["get", "a"]]`). Lets a
 * renderer that can prove it only ever reads a fixed set of keys ask the tile source to skip
 * materializing everything else (see [com.xweather.mapsgl.sources.VectorTileSource.declareNeededPropertyKeys]).
 */
internal object ExpressionReferencedKeys {
    fun collect(vararg expressions: Expression?): Set<String> {
        val keys = mutableSetOf<String>()
        expressions.forEach { visit(it?.raw, keys) }
        return keys
    }

    private fun visit(node: Any?, keys: MutableSet<String>) {
        when (node) {
            is Expression -> visit(node.raw, keys)
            is List<*> -> {
                if (node.size >= 2 && node[0] == "get" && node[1] is String) {
                    keys.add(node[1] as String)
                }
                for (item in node) visit(item, keys)
            }
            else -> Unit
        }
    }
}
