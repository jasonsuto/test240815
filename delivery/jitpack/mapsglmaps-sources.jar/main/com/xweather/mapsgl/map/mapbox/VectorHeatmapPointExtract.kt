package com.xweather.mapsgl.map.mapbox

import com.mapbox.geojson.Feature
import com.mapbox.geojson.MultiPoint
import com.mapbox.geojson.Point
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.StyleValue
import com.xweather.mapsgl.tiles.TileCoord

/**
 * Extracts heatmap splat centres in tile UV space: `[u, v, weight, ...]` (3 floats per point).
 */
internal object VectorHeatmapPointExtract {

    internal const val FLOATS_PER_POINT = 3

    /**
     * Optional parallel featureTime channel for CPU map-time reveal. Same length as point count
     * (`points.size / FLOATS_PER_POINT`); [VectorMapTime.ALWAYS_VISIBLE] when a point has no time.
     */
    internal class ExtractResult(
        val points: FloatArray,
        val featureTimes: FloatArray? = null,
    )

    fun extract(
        features: List<Feature>,
        coord: TileCoord,
        sourceLayerFilter: String?,
        filter: Expression?,
        weight: StyleValue<Double>?,
        layerId: String? = null,
        mapTimeMs: Long = VectorDrawTime.currentMapTimeMillis(),
    ): FloatArray =
        extractDetailed(
            features,
            coord,
            sourceLayerFilter,
            filter,
            weight,
            layerId,
            mapTimeMs,
            staticPrepForMapTime = false,
        ).points

    fun extractDetailed(
        features: List<Feature>,
        coord: TileCoord,
        sourceLayerFilter: String?,
        filter: Expression?,
        weight: StyleValue<Double>?,
        layerId: String? = null,
        mapTimeMs: Long = VectorDrawTime.currentMapTimeMillis(),
        staticPrepForMapTime: Boolean = false,
    ): ExtractResult {
        val z = coord.z
        val tx = coord.x
        val ty = coord.y
        val world = 1 shl z
        val defaultWeight = (weight as? StyleValue.Constant)?.constantValue?.toFloat()?.coerceAtLeast(0f) ?: 1f
        val weightExpr = (weight as? StyleValue.Expression)?.expression
        val dynamicMapTime = staticPrepForMapTime ||
            VectorFeatureDrawFilter.referencesMapTime(layerId, filter)
        val bakeTimes = dynamicMapTime && staticPrepForMapTime
        val revealKey = if (bakeTimes) VectorMapTime.mapTimeRevealKey(layerId, filter) else null
        val out = ArrayList<Float>(features.size * FLOATS_PER_POINT)
        val times = if (bakeTimes) ArrayList<Float>(features.size) else null

        fun emit(lon: Double, lat: Double, feature: Feature) {
            val w = if (weightExpr != null) {
                VectorFillStyleExpressionEval.evaluateNumber(weightExpr, feature)?.toFloat()?.coerceAtLeast(0f)
                    ?: defaultWeight
            } else {
                defaultWeight
            }
            if (w <= 0f) return
            val (u, v) = VectorPolygonFillTriangulator.lonLatToTileUv(z, tx, ty, world, lon, lat)
            out.add(u)
            out.add(v)
            out.add(w)
            times?.add(VectorMapTime.featureTimeFromProperty(feature, revealKey))
        }

        fun accumulate(filterLayer: String?) {
            for (f in features) {
                val visible = if (staticPrepForMapTime) {
                    VectorFeatureDrawFilter.shouldDrawForGpuMapTimePrep(f, filter, layerId)
                } else {
                    VectorFeatureDrawFilter.shouldDraw(f, filter, layerId, mapTimeMs)
                }
                if (!visible) continue
                if (!layerMatchesFeature(f, filterLayer)) continue
                when (val g = f.geometry()) {
                    is Point -> emit(g.longitude(), g.latitude(), f)
                    is MultiPoint -> {
                        for (p in g.coordinates()) {
                            emit(p.longitude(), p.latitude(), f)
                        }
                    }
                    else -> {}
                }
            }
        }

        accumulate(sourceLayerFilter)
        if (out.isEmpty() && sourceLayerFilter != null) {
            accumulate(null)
        }
        return ExtractResult(out.toFloatArray(), times?.toFloatArray())
    }

    /** Drop splat points whose baked featureTime is still ahead of the playhead. */
    fun compactByMapTime(points: FloatArray, featureTimes: FloatArray?): FloatArray {
        if (featureTimes == null || featureTimes.isEmpty() || points.isEmpty()) return points
        val mapTime = VectorMapTime.currentMapTimeUniform(hasDynamicMapTime = true)
        val count = minOf(featureTimes.size, points.size / FLOATS_PER_POINT)
        var keep = 0
        for (i in 0 until count) {
            if (VectorMapTime.passesFeatureTime(featureTimes[i], mapTime)) keep++
        }
        if (keep == count) return points
        if (keep == 0) return FloatArray(0)
        val out = FloatArray(keep * FLOATS_PER_POINT)
        var o = 0
        for (i in 0 until count) {
            if (!VectorMapTime.passesFeatureTime(featureTimes[i], mapTime)) continue
            val base = i * FLOATS_PER_POINT
            System.arraycopy(points, base, out, o, FLOATS_PER_POINT)
            o += FLOATS_PER_POINT
        }
        return out
    }

    private fun layerMatchesFeature(f: Feature, sourceLayerFilter: String?): Boolean {
        if (sourceLayerFilter == null) return true
        val tag = featureLayerTag(f) ?: return false
        return tag.equals(sourceLayerFilter, ignoreCase = true) ||
            tag.startsWith("$sourceLayerFilter::", ignoreCase = true)
    }
}
