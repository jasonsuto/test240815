package com.xweather.mapsgl.map.mapbox

import com.xweather.mapsgl.style.Expression

/** Flattens nested [Expression] nodes to plain lists for [StencilMaskFilter] evaluation. */
internal object ExpressionFilterFlatten {

    fun flatten(filter: Expression?): Expression? {
        if (filter == null) return null
        val flat = flattenNode(filter.raw) ?: return filter
        return Expression(flat)
    }

    fun flattenNode(node: Any?): Any? = when (node) {
        null -> null
        is Expression -> flattenNode(node.raw)
        is List<*> -> node.map { flattenNode(it) }
        else -> node
    }
}
