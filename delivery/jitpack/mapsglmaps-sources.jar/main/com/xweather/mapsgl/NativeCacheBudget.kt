package com.xweather.mapsgl

import android.app.ActivityManager
import android.content.Context

/**
 * Rule: native-cache-budget (Phase 2 of the alerts-playback heap-pressure plan). Computes a total
 * native mesh/tile-bytes cache budget scaled off actual device RAM (not JVM heap — the whole point
 * of this cache is to hold data that doesn't compete with the much smaller Dalvik heap ceiling), and
 * splits it across [NativeLibCache]'s namespaced LRU caches.
 *
 * [getCacheInstance] in `cache.cpp` is a single process-wide singleton — this budget is shared by
 * every active [com.xweather.mapsgl.sources.VectorTileSource]/layer at once, so it must not be sized
 * as if only one layer will ever be animating. Called once from [com.xweather.mapsgl.map.MapController]
 * init (mirrors [com.xweather.mapsgl.sources.GeoJsonAssets.bind]'s one-time-per-context-available
 * pattern) — safe to call again on a later MapController construction; it just re-applies the same
 * computation idempotently.
 *
 * Rule: native-cache-dynamic-rebalance. A typical session has only 1-3 layers active at once, often
 * just one or two render kinds (e.g. only Fill+Outline for an alerts layer, or only Circle for air
 * quality) — a fixed percentage split across all 6 namespaces wastes a large fraction of the budget
 * on namespaces nothing is currently using, starving the ones that matter. [markNamespaceActive]/
 * [markNamespaceInactive] ref-count which namespaces have at least one live renderer and trigger
 * [rebalance], which gives every namespace a small floor (so a namespace that's briefly unused, or
 * just starting up, doesn't get evicted to nothing) and splits the rest of the budget across
 * currently-active namespaces only, weighted by typical per-feature payload size. [setMaxBytes] in
 * `lru_cache.hpp` is safe to call at any time — shrinking evicts down to the new ceiling, growing
 * just raises it — so this can run every time the active set changes, not just once at startup.
 */
internal object NativeCacheBudget {

    const val NAMESPACE_MVT_BYTES = "mvt"
    const val NAMESPACE_FILL_MESH = "fillmesh"
    const val NAMESPACE_OUTLINE_MESH = "outlinemesh"
    const val NAMESPACE_CIRCLE_MESH = "circlemesh"
    const val NAMESPACE_HEATMAP_MESH = "heatmapmesh"
    const val NAMESPACE_SYMBOL_MESH = "symbolmesh"

    /** Relative per-feature payload weight, used to split the active pool — fill/outline's per-vertex
     * triangle data is the heaviest, heatmap's 3-float points the lightest.
     *
     * Rule: outline-cache-underweighted. Outline was originally weighted equal to fill (3/3), but for
     * the same polygon, outline emits roughly 2x fill's vertex count (one quad = 6 vertices per ring
     * segment, vs earcut's ~3 vertices per triangle over the polygon interior) at a slightly wider
     * per-vertex format (7 floats: cx,cy,nx,ny,packedColor,edgeDist,halfWidth vs fill's 6). Live-measured
     * on a dense EU alerts scenario (real severe.alerts data, France + neighbors, 1000-interval 24h
     * timeline): with an equal split both at a 680.8MB ceiling, fill used only 196.7MB (comfortably
     * under budget) while outline was pinned at 680.8/680.8MB (100%, actively evicting/re-triangulating
     * already-built meshes every playback loop just to make room for meshes later in the same loop).
     * That's a measured floor of ~3.46x fill's footprint for the same underlying features; weighted
     * higher here to leave headroom above that floor, since a namespace sitting exactly at its cap is
     * itself evidence real demand is at least that high, possibly more. This does NOT remove
     * lru_cache.hpp's unconditional byte-cap-even-for-pinned-entries safety valve (see its class KDoc)
     * — that stays intentionally, per the OOM crash a similar "never evict protected" change caused
     * elsewhere this session (see project_zoom_during_playback_heap_and_slow_prime memory). This is a
     * bounded reallocation of a fixed pool, not an unbounded exemption. */
    private val MESH_NAMESPACE_WEIGHTS = mapOf(
        NAMESPACE_FILL_MESH to 3,
        NAMESPACE_OUTLINE_MESH to 12,
        NAMESPACE_CIRCLE_MESH to 2,
        NAMESPACE_HEATMAP_MESH to 1,
        NAMESPACE_SYMBOL_MESH to 2,
    )

    /** Every namespace keeps at least this much budget even while inactive, so a namespace that just
     * started being used (before its first [markNamespaceActive] lands) or is only briefly idle isn't
     * evicted to nothing. Small relative to a real per-layer working set. */
    private const val PER_NAMESPACE_FLOOR_BYTES = 24L * 1024L * 1024L

    private val cache = NativeLibCache("__native_cache_budget__")

    @Volatile
    private var totalBudgetBytes: Long = -1L

    /** Ref-counted: multiple layers of the same render kind (e.g. two Fill layers) keep a namespace
     * active until the last one is removed, not the first. */
    private val activeCounts = mutableMapOf<String, Int>()

    /** Rule: debug-memory-panel. Namespace -> currently configured byte budget, kept in sync by every
     * [rebalance] call; there's no native getter for a budget once set (only
     * [NativeLibCache.getNamespaceCurrentBytes] for current usage), so this is the source of truth
     * for the debug panel's "used / total" readout. */
    private val configuredBudgetBytes = mutableMapOf<String, Long>()

    /** Rule: debug-memory-panel. Current usage and configured budget for every namespace, plus a
     * `"total"` entry summing both — used by [com.example.mapsgldemo.debug.MapTileDebugPopup] to show
     * live native-cache pressure without exposing [NativeLibCache] or namespace names to the demo app. */
    fun debugUsageSnapshot(): List<Triple<String, Long, Long>> {
        if (totalBudgetBytes < 0) return emptyList()
        val perNamespace = configuredBudgetBytes.entries.map { (namespace, budget) ->
            Triple(namespace, cache.getNamespaceCurrentBytes(namespace), budget)
        }
        val totalUsed = perNamespace.sumOf { it.second }
        val totalBudget = perNamespace.sumOf { it.third }
        return perNamespace + Triple("total", totalUsed, totalBudget)
    }

    /**
     * Device total RAM -> total native cache budget. Bucket boundaries and midpoint values match the
     * plan approved for this work; deliberately generous relative to a single layer's working set
     * (measured ~72MB Java-heap-side for one alerts fill+outline layer over a 3-day timeline) since
     * this budget is shared across every active layer in the process.
     */
    private fun totalBudgetBytesFor(totalRamBytes: Long): Long {
        val totalRamGb = totalRamBytes / (1024.0 * 1024.0 * 1024.0)
        val totalMb = when {
            totalRamGb < 3.0 -> 256
            totalRamGb < 4.0 -> 512
            totalRamGb < 6.0 -> 768
            totalRamGb < 8.0 -> 1280
            else -> 1792
        }
        return totalMb.toLong() * 1024L * 1024L
    }

    /** Idempotent for the RAM query/total-budget computation; safe to call from every
     * [com.xweather.mapsgl.map.MapController] construction. Always re-applies [rebalance] against the
     * current active set (cheap — just a handful of [NativeLibCache.configureNamespaceBudget] calls),
     * so a second MapController picking up an already-active session still gets a correct split. */
    fun configure(context: Context) {
        synchronized(this) {
            if (totalBudgetBytes < 0) {
                totalBudgetBytes = totalBudgetBytesFor(queryTotalDeviceRamBytes(context))
            }
            rebalance()
        }
    }

    /** See the class KDoc's "native-cache-dynamic-rebalance" rule. Call when a layer of a given render
     * kind is added to the map and this is the first such layer (i.e. the namespace was previously
     * inactive) — a no-op before [configure] has run at least once. */
    fun markNamespaceActive(namespace: String) {
        synchronized(this) {
            val wasActive = (activeCounts[namespace] ?: 0) > 0
            activeCounts[namespace] = (activeCounts[namespace] ?: 0) + 1
            if (!wasActive && totalBudgetBytes >= 0) rebalance()
        }
    }

    /** Call when a layer of a given render kind is removed and no other layer of that kind remains
     * active. Mirrors [markNamespaceActive]'s ref-counting. */
    fun markNamespaceInactive(namespace: String) {
        synchronized(this) {
            val current = activeCounts[namespace] ?: 0
            if (current <= 0) return
            activeCounts[namespace] = current - 1
            if (current - 1 == 0 && totalBudgetBytes >= 0) rebalance()
        }
    }

    /** Recomputes every namespace's budget from the current active set and applies it immediately.
     * Must be called while holding the lock on `this` (all callers above already do). */
    private fun rebalance() {
        val totalBudget = totalBudgetBytes
        // mvt (raw compressed MVT bytes) is shared infrastructure needed by every time-series vector
        // source regardless of render kind — always a fixed share, not usage-tracked.
        val mvtBudget = totalBudget * 20 / 100
        val meshPool = totalBudget - mvtBudget

        val meshNamespaces = MESH_NAMESPACE_WEIGHTS.keys
        val floorBytes = minOf(PER_NAMESPACE_FLOOR_BYTES, meshPool / meshNamespaces.size / 2)
        val remainingPool = maxOf(0L, meshPool - floorBytes * meshNamespaces.size)

        val activeNamespaces = meshNamespaces.filter { (activeCounts[it] ?: 0) > 0 }
        val activeWeightSum = activeNamespaces.sumOf { MESH_NAMESPACE_WEIGHTS.getValue(it) }

        val budgets = mutableMapOf(NAMESPACE_MVT_BYTES to mvtBudget)
        for (namespace in meshNamespaces) {
            val activeShare = if (namespace in activeNamespaces && activeWeightSum > 0) {
                remainingPool * MESH_NAMESPACE_WEIGHTS.getValue(namespace) / activeWeightSum
            } else {
                0L
            }
            budgets[namespace] = floorBytes + activeShare
        }
        budgets.forEach { (namespace, budgetBytes) -> cache.configureNamespaceBudget(namespace, budgetBytes) }
        configuredBudgetBytes.putAll(budgets)
    }

    private fun queryTotalDeviceRamBytes(context: Context): Long {
        val am = context.applicationContext.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            ?: return DEFAULT_ASSUMED_RAM_BYTES
        val info = ActivityManager.MemoryInfo()
        return try {
            am.getMemoryInfo(info)
            if (info.totalMem > 0) info.totalMem else DEFAULT_ASSUMED_RAM_BYTES
        } catch (_: Exception) {
            DEFAULT_ASSUMED_RAM_BYTES
        }
    }

    // Mid-range assumption (4GB) if the RAM query ever fails — avoids over- or under-committing.
    private const val DEFAULT_ASSUMED_RAM_BYTES = 4L * 1024L * 1024L * 1024L
}
