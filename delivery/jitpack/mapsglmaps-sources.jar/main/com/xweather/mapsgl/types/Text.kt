package com.xweather.mapsgl.types

/**
 * Horizontal alignment of a text label (`text-justify`).
 *
 * @property value Style JSON string.
 */
enum class TextJustification(val value: String) {
    LEFT("left"),
    CENTER("center"),
    RIGHT("right")
}

/**
 * Case transform for a text label (`text-transform`).
 *
 * @property value Style JSON string.
 */
enum class TextTransform(val value: String) {
    NONE("none"),
    UPPERCASE("uppercase"),
    LOWERCASE("lowercase"),
    CAPITALIZE("capitalize"),
}