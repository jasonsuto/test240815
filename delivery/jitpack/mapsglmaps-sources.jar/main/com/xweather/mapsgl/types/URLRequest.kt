package com.xweather.mapsgl.types

import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.map.MapController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class AuthenticationException(message: String) : Exception(message)

data class URLResponse(
    val data: Any?,
    val headers: Map<String, List<String>>,
    val statusCode: Int,
    val contentType: String?
)

class URLRequest(
    val urlString: String,
    var method: String = "GET",
    var headers: MutableMap<String, String> = emptyMap<String, String>().toMutableMap(),
    var queryParams: MutableMap<String, String> = emptyMap<String, String>().toMutableMap(),
    var body: String? = null,
    var contentType: String = "application/json",
    /** Optional per-request connection timeout (ms). Applied to HttpURLConnection.connectTimeout. */
    var connectTimeoutMs: Int = 0,
    /** Optional per-request read timeout (ms). Applied to HttpURLConnection.readTimeout. */
    var readTimeoutMs: Int = 0,
) {

    fun setHeader(key: String, value: String) {
        headers[key] = value
    }

    fun setQueryParameter(key: String, value: String) {
        queryParams[key] = value
    }

    fun setAuthorization(value: String) {
        setHeader("Authorization", value)

        if(MapController.packageName != null){
            //setHeader("Referer", "com.wrongcompany.wrongproject")
            //setHeader("Referer", MapController.packageName!!)
            if(pr.ON) pr.p("URLREQUEST", pr.bundleID, "setAuthorization() Referer: ${headers["Referer"]}")
        }
    }

    /**
     * Makes a network request and returns:
     * - JSONObject or JSONArray for JSON requests
     * - String if the content is text
     * - ByteArray if the content is binary (e.g. image, .pbf)
     */
    suspend fun execute(): URLResponse = withContext(Dispatchers.IO) {
        // Fix for issue 10, where "+" was being stripped out of time
        val urlStringEncoded =  urlString.replace("+", "%2B")
        val fullUrl = buildUrlWithParams(urlStringEncoded, queryParams)
        val url = URL(fullUrl)
        val connection = url.openConnection() as HttpURLConnection
        connection.instanceFollowRedirects = true
        if (connectTimeoutMs > 0) connection.connectTimeout = connectTimeoutMs
        if (readTimeoutMs > 0) connection.readTimeout = readTimeoutMs

        try {
            connection.requestMethod = method
            connection.doInput = true
            connection.setRequestProperty("Content-Type", contentType)

            headers.forEach { (key, value) ->
                if(pr.ON) pr.p("URLREQUEST", pr.bundleID, "execute(): listing headers: $key: $value")
                connection.setRequestProperty(key, value)
            }

            if (method == "POST" || method == "PUT") {
                connection.doOutput = true
                body?.let {
                    OutputStreamWriter(connection.outputStream).use { writer ->
                        writer.write(it)
                        writer.flush()
                    }
                }
            }

            val statusCode = connection.responseCode
            val responseContentType = connection.contentType?.lowercase() ?: ""
            val responseHeaders = connection.headerFields.filterKeys { it != null }
            //println("URLRequest.execute: url=$fullUrl, status=$statusCode, contentType=$responseContentType")
            val stream = when (statusCode) {
                in 200..299 -> connection.inputStream
                401 -> throw AuthenticationException("Unauthorized request to $fullUrl")
                403 -> connection.inputStream // allow reading content after redirect
                else -> {
                    val errorText = connection.errorStream?.bufferedReader()?.use { it.readText() }
                    val errorContentType = connection.contentType?.lowercase() ?: ""
                    if (errorContentType.contains("application/json") && !errorText.isNullOrBlank()) {
                        println("URLRequest error response ($statusCode): $errorText")
                    }
                    throw Exception("HTTP $statusCode error for $fullUrl")
                }
            }
            val body: Any? = stream?.use { input ->
                when {
                    responseContentType.contains("application/json") -> {
                        val text = input.bufferedReader().use { it.readText() }
                        try {
                            if (text.trim().startsWith("[")) JSONArray(text)
                            else JSONObject(text)
                        } catch (e: Exception) {
                            text
                        }
                    }
                    responseContentType.contains("text") -> {
                        input.bufferedReader().use { it.readText() }
                    }
                    else -> {
                        input.readBytes()
                    }
                }
            }

            URLResponse(
                data = body,
                headers = responseHeaders,
                statusCode = statusCode,
                contentType = responseContentType
            )
        } finally {
            connection.disconnect()
        }
    }

    private fun buildUrlWithParams(baseUrl: String, params: Map<String, String>): String {
        if (params.isEmpty()) return baseUrl

        val queryString = params.entries.joinToString("&") { (key, value) ->
            "${URLEncoder.encode(key, "UTF-8")}=${URLEncoder.encode(value, "UTF-8")}"
        }

        val separator = if (baseUrl.contains("?")) "&" else "?"
        return "$baseUrl$separator$queryString"
    }
}