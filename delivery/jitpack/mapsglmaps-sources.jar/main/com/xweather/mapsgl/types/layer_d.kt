package com.xweather.mapsgl.types

/**
 * MapsGL layer kinds used on [com.xweather.mapsgl.layers.spec.LayerDescriptor.type].
 *
 * @property value Style/JSON discriminator string.
 */
enum class LayerType(val value: String) {
    raster("raster"),
    circle("circle"),
    symbol("symbol"),
    fill("fill"),
    line("line"),
    sample("sample"),
    grid("grid"),
    heatmap("heatmap"),
    contour("contour"),
    particles("particles"),
    voronoi("voronoi"),
    /**
     * Weather-value point labels that sample another layer (e.g. `temperatures-text`).
     * Resolved at add time into a private GeoJSON source + stock symbol layer.
     */
    query("query"),
    vector("vector") // maybe need individual for different vector types

}

/**
 * Determines the quality of the data when rendered.
 */
enum class DataQuality(val value: String) {
    /**
     * Data will be requested and rendered 1:1 with map tiles and zoom level. This setting results in the highest
     * data resolution but the lowest bandwidth and rendering optimization.
     */
    exact("exact"),

    /**
     * Data will be scaled slightly to share the same data tiles across 1 or 2 map zoom levels.
     */
    high("high"),

    /**
     * Data will be scaled to share the same data tiles across multiple map zoom levels. This setting provides a good
     * balance between data resolution and reduced request bandwidth and rendering performance.
     */
    medium("medium"),


    @Deprecated(
        message = "Normal quality is being phased out. Please use 'medium'",
        replaceWith = ReplaceWith("DataQuality.medium")
    )
    normal("normal"),

    /**
     * Data will be scaled resulting in less data resolution than `normal` at some map zoom levels.
     */
    low("low"),

    @Deprecated(
        message = "minimal quality is being phased out. Please use 'low' for better performance.",
        replaceWith = ReplaceWith("DataQuality.medium")
    )
    /**
     * Data will be scaled extensively to share the same data tiles across 3-5 map zoom levels. This results in
     * drastically reduced data resolution but the highest bandwidth and rendering optimization.
     */
    minimal("minimal")
}

