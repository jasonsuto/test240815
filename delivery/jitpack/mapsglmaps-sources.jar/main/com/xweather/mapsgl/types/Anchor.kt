package com.xweather.mapsgl.types

/**
 * Mapbox-style icon/text anchor (`icon-anchor` / `text-anchor`). Serialized by
 * [com.xweather.mapsgl.style.makeJSONObject].
 *
 * @property value Style JSON string (`"center"`, `"top-left"`, …).
 */
enum class Anchor(val value: String) {
    CENTER("center"),
    LEFT("left"),
    RIGHT("right"),
    TOP("top"),
    BOTTOM("bottom"),
    TOP_LEFT("top-left"),
    TOP_RIGHT("top-right"),
    BOTTOM_LEFT("bottom-left"),
    BOTTOM_RIGHT("bottom-right")
}

/**
 * Pixel offset from [Anchor] (`icon-offset` / `text-offset`), serialized as `[x, y]`.
 */
data class AnchorOffset(
    var x: Double = 0.0,
    var y: Double = 0.0
)