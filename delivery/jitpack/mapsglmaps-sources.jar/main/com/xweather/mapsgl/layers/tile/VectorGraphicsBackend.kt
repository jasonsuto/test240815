package com.xweather.mapsgl.layers.tile

enum class VectorGraphicsBackend {
    MAPBOX_STYLE_SPEC,
    CUSTOM_WEBGL_MESHES,
}
