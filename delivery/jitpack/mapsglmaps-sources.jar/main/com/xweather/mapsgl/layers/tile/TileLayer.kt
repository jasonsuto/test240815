/**
 * TileLayer.kt
 *
 *  Adapted from IOS version
 *
 * @author Jason Suto 12/22/23
 *
 **/

package com.xweather.mapsgl.layers.tile

import android.content.Context
import android.os.Looper
import com.xweather.mapsgl.anim.AnimationState
import com.xweather.mapsgl.anim.TileRequestOptions
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.data.series.AnyTimeSeries
import com.xweather.mapsgl.data.series.Data
import com.xweather.mapsgl.data.series.TimeSeries
import com.xweather.mapsgl.data.series.TimeSeriesAnimator
import com.xweather.mapsgl.data.series.TimeSeriesAnimatorOptions
import com.xweather.mapsgl.events.DataSourceEvents
import com.xweather.mapsgl.events.EventDispatcher
import com.xweather.mapsgl.events.TimeSeriesEvent
import com.xweather.mapsgl.geo.Viewport
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.gl.math.PowerTable.Companion.powerTableD
import com.xweather.mapsgl.gl.math.PowerTable.Companion.powerTableI
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera
import com.xweather.mapsgl.layers.spec.MaskLayerKind
import com.xweather.mapsgl.layers.spec.StencilLayerMaskSpec
import com.xweather.mapsgl.map.MapController
import com.xweather.mapsgl.map.mapbox.CameraSync
import com.xweather.mapsgl.map.mapbox.MapboxMapController
import com.xweather.mapsgl.renderers.LayerRenderContext
import com.xweather.mapsgl.renderers.LayerRenderer
import com.xweather.mapsgl.renderers.TileLayerRenderer
import com.xweather.mapsgl.sources.DataType
import com.xweather.mapsgl.sources.TileSource
import com.xweather.mapsgl.sources.VectorTileSource
import com.xweather.mapsgl.sources.XweatherEncodedTileSource
import com.xweather.mapsgl.style.LayerPaint
import com.xweather.mapsgl.tiles.LatLonBounds
import com.xweather.mapsgl.tiles.Tile
import com.xweather.mapsgl.tiles.TileBounds
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.tiles.TilePyramid
import com.xweather.mapsgl.tiles.TileRenderable
import com.xweather.mapsgl.types.DataQuality
import com.xweather.mapsgl.types.LayerType
import com.xweather.mapsgl.types.math_type.ValueRange
import com.xweather.mapsgl.util.MapsGLDebug
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.coroutines.cancellation.CancellationException
import kotlin.math.atan
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.sinh
import kotlin.time.Duration

private const val TAG = "TileLayer"

/** Rule: world-tile-first-on-add. Poll interval / attempt cap while waiting for the source
 * timeline to publish intervals (~16s total) before giving up on priming the z=0 world tile. */
private const val WORLD_TILE_PRIME_RETRY_MS = 400L
private const val WORLD_TILE_PRIME_ATTEMPTS = 40

/**
 * Per-frame render state passed to a [TileLayerRenderer]: the paint style to render with, the
 * renderables to draw, elapsed animation time, and the current zoom level.
 */
data class RenderContext<RenderableType>(
    /** The paint/style configuration to render this frame's [renderables] with. */
    override var paintStyle: LayerPaint, //PaintStyle,
    /** Time elapsed since the layer's animation began; drives time-based rendering effects. */
    override var elapsedTime: Duration = Duration.ZERO,
    /** The drawable items to render this frame, e.g. tiles resolved for the current viewport. */
    override var renderables: List<RenderableType> = listOf(), //List<TileRenderable<DataType>> = emptyList()
    //var projectionMatrix: ProjectiveTransform3D = ProjectiveTransform3D.identity,
    /** The map zoom level in effect for this frame, used for zoom-dependent rendering decisions. */
    override var zoomLevel: Double = 0.0
) : LayerRenderContext<RenderableType>

/** Configuration shared by layers that render data from a tile-based data source. */
interface TileLayerConfig /*: WebGLLayerConfig*/ {
    /** * Quality to use when rendering data.   */
    var quality: DataQuality

    /**  * Range of values to use when rendering data.  */
    var dataRange: ValueRange
    /**
     * Offset to apply to the map's zoom level when requesting data from the data source. This is useful to render data
     * at a different zoom level than the map's zoom level.
     */
    //var zoomOffset: Int
}

/** Represents a layer that renders data from a tile-based data source.
 *   This is the base class for all tile-based layers and is not intended to be used directly.
 */
open class TileLayer(
    /** Unique identifier for this layer within the map, used to look it up (e.g. via [MapController]). */
    final override var id: String,
    /** The tile data source this layer downloads and renders tiles from. */
    override var source: TileSource<TileData>,
    /** The paint/style configuration used to render this layer's data. */
    override var paint: LayerPaint,//SampleLayerPaint, //PaintStyle
    /** The GL renderer that builds and draws this layer's tile geometry each frame. */
    var tileLayerRenderer: TileLayerRenderer<TileData, LayerRenderContext<Any>>, //private?
    /** Offset applied to the map's zoom level when computing which tile z/x/y to request and draw for this layer. */
    var zoomOffset: Int,
    /** Coroutine scope used for this layer's background tile-download and prep work. */
    val externalScope: CoroutineScope,
    /** Data quality/resolution to request and render tiles at. Defaults to [DataQuality.exact]. */
    var quality: DataQuality = DataQuality.exact,

    ) : MapLayer<TileData, LayerRenderContext<Any>> {

    /**
     * Set by [TileLayerRenderer] when this layer uses the special multiband p-type radar shader
     * path (currently only for the "conditions.radar.fill" layer), selecting the radar fragment
     * shader/program variant instead of the standard sample-layer one.
     */
    var isRadar = false
    /** GLES stencil base mask kind for this layer (LAND/WATER/TRANSPORTATION/COUNTRY). */
    var glStencilMaskKind: MaskLayerKind = MaskLayerKind.NONE
    /** Optional ISO alpha-2 for COUNTRY base masks. */
    var glStencilMaskCountryIso: String? = null
    /** Optional custom multi-layer stencil mask (JS-style `mask.layerIds`). */
    var stencilLayerMask: StencilLayerMaskSpec? = null
    /**
     * When true, [glStencilMaskKind] [MaskLayerKind.LAND] runs first (marine clip), then line-only
     * [stencilLayerMask] layers are intersected on land (highways on land, not oceans).
     */
    var hybridLandWithCustomLineMask: Boolean = false

    /** Holds the internal [DataQuality]-to-scale-factor lookup used to compute [dataQualityMult]. */
    companion object {
        private val dataQualityHash = mapOf(
            DataQuality.exact to 1f,
            DataQuality.high to 0.75f,
            DataQuality.medium to 0.5f,
            DataQuality.normal to 0.5f,
            DataQuality.low to 0.25f,
            DataQuality.minimal to 0.25f
        )
    }

    /** Event types this layer can notify [TileLayerEventListener]s about via [triggerEvent]. */
    enum class TileLayerEventType {
        TILES_LOADING_STATUS_CHANGED, // Example: pass a boolean or count
        DATA_UPDATED,              // Example: pass metadata about the update
        SPECIFIC_ACTION_TRIGGERED,
        FINISHED_DRAWING,
        // Your custom event
        // Add more event types as needed
    }

    /** Listener for per-layer lifecycle/data events dispatched via [addTileLayerEventListener]. */
    interface TileLayerEventListener {
        /** Called when this layer fires [eventType] for the layer identified by [layerId], with optional [data] payload. */
        fun onTileLayerEvent(layerId: String, eventType: TileLayerEventType, data: Any? = null)
    }

    private val eventListeners = mutableListOf<TileLayerEventListener>() // Or TileLayerEventListenerV2


    /** Registers [listener] to receive this layer's [TileLayerEventType] events. No-op if already registered. */
    fun addTileLayerEventListener(listener: TileLayerEventListener) { // Or TileLayerEventListenerV2
        if (!eventListeners.contains(listener)) {
            eventListeners.add(listener)
        }
    }

    /** Unregisters a previously added [TileLayerEventListener]; no-op if not registered. */
    fun removeTileLayerEventListener(listener: TileLayerEventListener) { // Or TileLayerEventListenerV2
        eventListeners.remove(listener)
    }

    /**
     * Triggers a specific event to all registered listeners.
     * @param eventType A string identifying the type of event.
     * @param data Optional data associated with the event.
     */
    protected fun triggerEvent(eventType: TileLayerEventType, data: Any? = null) { // Or eventType: TileLayerEventType
        // Consider running on a specific thread if needed (e.g., main thread for UI updates)
        // For simplicity, this triggers on the calling thread.
        externalScope.launch { // Or another appropriate scope
            eventListeners.forEach { listener ->
                listener.onTileLayerEvent(id, eventType, data)
            }
        }
    }

    private var zoomVar = 0.0
    /**
     * The current visible geographic bounds for this layer, kept in sync with the map camera by
     * [onMove]/[onMoveEnd]. Also used by renderers (e.g. gridded sidecar sampling) as a fallback
     * source of the visible bounds when the map controller isn't directly reachable.
     */
    var bounds: LatLonBounds? = null
    private var oldBounds: LatLonBounds? = null
    private var tileBounds: TileBounds? = null
    private var oldTileBounds: TileBounds? = null
    final override var eventDispatcher = EventDispatcher()
    private var visibleTileCoords: List<TileCoord> = mutableListOf()
    /** Last tile set [TileCache.evictTilesOutsideViewport] ran against — skip the eviction scan
     * when the viewport tile set hasn't actually changed (this runs on every requestVisibleTiles
     * call, including frequent playback-refresh re-confirmations of the same viewport). */
    private var lastViewportEvictionKeySet: Set<String>? = null
    /** Manages this layer's tile download requests, tile cache, and per-source timeline/interval bookkeeping. */
    val pyramid: TilePyramid<DataType> = TilePyramid(this)
    /** Opacity multiplier applied to this layer's rendered output, from 0 (fully transparent) to 1 (fully opaque). */
    override var alpha = 1.0f
    /** Reserved tile-grid width (column count); not currently populated by this layer. */
    override var numW: Int = 0
    /** Reserved tile-grid height (row count); not currently populated by this layer. */
    override var numH: Int = 0
    /** Whether this layer is currently waiting on a tile download to complete. */
    override var waitingOnDL: Boolean = false
    /** Whether this layer was waiting on a tile download as of the previous check. */
    override var wasWaitingOnDL: Boolean = false
    private var offset = 0
    private var zoom = 0.0
    private var initialLoad = true

    /**
     * Rule: world-tile-first-on-add. One-shot guard for priming the z=0 world tile when the layer
     * is first added, so [com.xweather.mapsgl.gl.RenderPass.determinePartial]'s ancestor walk has
     * something to substitute everywhere while the exact-zoom tiles download.
     *
     * Kept separate from [initialLoad], which is consumed by whichever `getVisibleTileCoords` call
     * happens first — and since `getRenderables` runs every frame while the download path only runs
     * on move, that is almost always the *render* call, which puts the root in the renderables list
     * where nothing downloads it. Measured live: the z=0 tile was never bound at all
     * (`boundZooms=[3,4]`, `z0Bound=false`) even though the walk itself resolved fine (a z6 mesh hit
     * a z4 partial), so the world tile could never act as a partial.
     */
    private var worldTilePrimed = false

    /** In-flight [primeWorldTileWhenTimelineReady] retry, so only one poll runs per layer. */
    private var worldTilePrimeJob: kotlinx.coroutines.Job? = null
    private var oldRequestBounds: LatLonBounds? = null
    /** Tile bounds computed by the most recent [requestVisibleTiles] call, retained for later reference. */
    var persistentTileBounds: TileBounds? = null
    private var renderables: MutableList<TileRenderable<DataType>> = mutableListOf()

    // Rendering coordinates do not need to be recomputed every frame.
    // We only mark them dirty when bounds/viewport are updated via requestVisibleTiles().
    private var renderBoundsDirty: Boolean = true
    private var renderablesDirty: Boolean = true
    /**
     * [onMove] skips [requestVisibleTiles] while the timeline plays to limit download churn, but the
     * render path still recomputes meshes at the new map zoom each frame. Without a request at the new
     * Z, encoded tiles stay one or more levels behind until map idle or an extra zoom gesture.
     */
    private var lastOnMoveDisplayTileZ: Int? = null
    /** Tile coordinates already queued for download by [requestVisibleTiles] this session. */
    var alreadyRequested: MutableList<TileCoord> = mutableListOf()
    /** The time-series animator driving this layer's timeline playback, if timing is configured. */
    override var animator: TimeSeriesAnimator<Data>? = null
    /**
     * Unimplemented on [TileLayer]; the actual GL renderer used is [tileLayerRenderer], a more
     * specific [TileLayerRenderer] type.
     */
    override var renderer: LayerRenderer<Any>
        get() = TODO("Not yet implemented")
        set(value) {}

    /** Current data/render zoom level for this layer. */
    var z = 0.0
    private var maxVal = 0
    private var latRad = 0.0
    /** The per-frame render state (paint style, renderables, elapsed time, zoom) passed to [tileLayerRenderer]. */
    override var layerRenderContext: LayerRenderContext<Any> = RenderContext(paint)
    /** Android [Context] used to build this layer's GL shaders/programs; set in [onAdd]. */
    lateinit var drawContext: Context
    /** The time series associated with this layer, if any. */
    override var timeSeries: AnyTimeSeries? = null
    /** Identifies the weather product/configuration this layer was created for (e.g. a composite layer's shared code). */
    var code = ""
    /** Reserved for future status/error text alongside [code]; not currently populated. */
    var message = ""

    /** The map controller this layer is attached to; set by [onAdd] when the layer is added to the map. */
    override var mapController: MapController? = null
        get() = field
        set(value) {
            field = value
        }

    /** Whether this layer needs to be redrawn; set via [setNeedsUpdate]. */
    override var isDirty: Boolean = false
    /** Whether this layer is shown on the map. Toggle via the layer's show/hide API. */
    override var visible: Boolean = true

    /**
     * Layer ids that depend on this layer staying live while hidden (data-query consumers).
     * When non-empty, tile requests and timeline work continue even if [visible] is false.
     */
    private val dependentLayerIds: MutableSet<String> = linkedSetOf()

    fun registerDependentLayer(dependentId: String) {
        dependentLayerIds.add(dependentId)
    }

    fun unregisterDependentLayer(dependentId: String) {
        dependentLayerIds.remove(dependentId)
    }

    val hasDependentLayers: Boolean
        get() = dependentLayerIds.isNotEmpty()

    /** Whether this layer's current animation date is within its configured valid/showable range. */
    override var enabled: Boolean = false

    /** The map's current viewport, or `null` if this layer is not attached to a map controller. */
    override val viewport: Viewport?
        get() = mapController?.viewport

    /** HTTP request options (method, headers, reload/pending behavior, radar flag, etc.) used for this layer's tile downloads. */
    val tileRequestOptions: TileRequestOptions = TileRequestOptions(isRadar = com.xweather.mapsgl.weather.WeatherSource.isRadarEncodedSourceId(id))

    /** Tile bounds computed prior to the current [currentTileBounds]. */
    var lastTileBounds: TileBounds? = null
    /** The most recently computed tile bounds for this layer's viewport. */
    var currentTileBounds: TileBounds? = null
    /** Whether the tile bounds have changed since they were last checked. */
    var tileBoundsChanged = true
    /** Most recently computed visible tile coordinates. */
    var coords: List<TileCoord>? = null
    /** Visible tile coordinates prior to the current [coords]. */
    val oldCoords: List<TileCoord>? = null
    /** Scale factor derived from [quality] via the internal [DataQuality] lookup table. */
    val dataQualityMult: Float

    /** The time series associated with the layer, if any.
     * @internal
     */

    init {

        dataQualityMult = dataQualityHash.getOrDefault(quality, 1f)

        //should this just be MapboxMapController.
        zoomOffset += 1 //leave this be, passed from MapboxMapController
        tileLayerRenderer.id = id

        // TODO: only set up time series and animator if timing series mode is not NONE
        timeSeries = TimeSeries()
        setupTimeSeriesAnimator()
        if (pr.ON) pr.p(TAG, pr.radarFix2, "init{} isRadar:$isRadar")

    }

    /**
     * Marks this layer dirty so it redraws on the next frame, propagates the request to
     * [tileLayerRenderer], and asks [mapController] to redraw. Does nothing if the layer is
     * currently hidden, unless [force] is `true`.
     */
    override fun setNeedsUpdate(force: Boolean) {
        if (!visible && !force) {
            return
        }
        isDirty = true
        tileLayerRenderer.setNeedsUpdate()
        mapController?.redraw()
    }

    /**
     * Returns the current tile-index bounds (zoom/left/right/top/bottom) covering this layer's
     * visible viewport, recomputing from [bounds] only when the render bounds are dirty or the
     * zoom tier has changed since the last call.
     */
    fun getTileBounds(): TileBounds {
        if (bounds == null) {
            // Avoid blocking the caller thread (often UI/render) while waiting for Main.
            // On initial render, bounds should already be available from `onMove()`,
            // but this fallback prevents hard freezes if it's not.
            bounds = mapController?.getBounds()
                ?: LatLonBounds(westExtent = -180.0, southExtent = -85.0, eastExtent = 180.0, northExtent = 85.0)
        }

        //println(">>> TileLayer getTileBounds() bounds: W to E: ${bounds?.westExtent} to ${bounds?.eastExtent}")

        val zoomVarNext = zoomForVisibleTiles()
        val zoomIntNext = floor(zoomVarNext).toInt().coerceAtLeast(0)

        if (!renderBoundsDirty && tileBounds != null && tileBounds!!.zoom == zoomIntNext) {
            return tileBounds!!
        }

        zoom = mapZoomForVisibleTiles()
        zoomVar = zoomVarNext

        // Renderables follow map zoom (uncapped by encoded [source.maxZoom]) so land/water mask and
        // stencil can use native vector z; encoded rasters still use partial/parent textures as needed.
        tileBounds = getVisibleTileBounds(bounds!!, zoomVar, true)
        renderBoundsDirty = false
        return tileBounds!!
    }

    /**  gets a list of normalized renderables using getVisibleTileCoords()  */
    private fun getRenderables(): List<TileRenderable<DataType>> {
        if (!renderablesDirty) {
            return renderables
        }

        val tileBounds = getTileBounds()
        renderables.clear()

        //println(">>> TileLayer getRenderables() tileBounds: z ${tileBounds.zoom}   (${tileBounds.left} to ${tileBounds.right})")

        val visibleCoords = mapController?.let {
            getVisibleTileCoords(
                bounds!!,
                tileBounds,
                zoomVar,
                true,
            )
        }
        if (visibleCoords != null) {
            for (coord in visibleCoords) {
                renderables.add(TileRenderable(Tile(coord, null)))
            }
            oldTileBounds = tileBounds
        }
        renderablesDirty = false
        return renderables
    }

    /** * Recieves CoordinateBounds (Lat/Lon),
     * Calls  pyramid.requestTiles(coords, TileRequestOptions(reload = reload))
     * */
    suspend fun requestVisibleTiles(
        bounds: LatLonBounds,
        reload: Boolean = false,
        fromAnimation: Boolean = false
    ) {
        // After a completed play load, idle map-move / scrub must not open another HTTP wave.
        // While playing, still download missing intervals (hold only protects eviction / scrub).
        if (Timeline.holdFullTimelineResidency &&
            source.isEncoded &&
            !reload &&
            !Timeline.isGloballyPlaying
        ) {
            requeueVisibleBindsForScrub()
            return
        }
        mapController?.let { map ->
            if (visible || hasDependentLayers) {
                // Bounds/viewport changed; re-compute renderables for the next render.
                renderBoundsDirty = true
                renderablesDirty = true

                // Match [getTileBounds] / custom-layer zoom so requested z/x/y matches GLES renderables.
                // Scaling by [dataQualityMult] previously lowered download z vs draw z and could leave
                // visible rows (e.g. mid zoom) with no exact or partial texture.
                zoomVar = zoomForVisibleTiles()

                //println(">>> TileLayer requestVisibleTiles zoomOffset: ${zoomOffset}, zoomVar: $zoomVar, getDataZoom(): ${getDataZoom()} ${this.quality}")
                val tileBounds = getVisibleTileBounds(bounds, zoomVar)
                oldRequestBounds = bounds
                persistentTileBounds = tileBounds
                visibleTileCoords = getVisibleTileCoords(bounds, tileBounds, 0.0, false)

                val filteredVisibleTileCoords =
                    visibleTileCoords.filter { vtc -> //Ensure you don't request OOB tiles from server.
                        vtc.x >= 0 && vtc.x < powerTableI[vtc.z] && vtc.y >= 0 && vtc.y < powerTableI[vtc.z]
                    }

                if (pr.ON && pr.tileDownloadAudit.active) {
                    val nTiles = { z: Int -> powerTableI[z] }
                    for (c in visibleTileCoords) {
                        if (c.x < 0 || c.y < 0 || c.x >= nTiles(c.z) || c.y >= nTiles(c.z)) {
                            pr.p(
                                TAG,
                                pr.tileDownloadAudit,
                                "requestVisibleTiles OOB tile not sent to download: z=${c.z} x=${c.x} y=${c.y} (n=${nTiles(c.z)}) layer=$id"
                            )
                        }
                    }
                }

                val finalTileCoords: List<TileCoord> = if (source.bounds != null) {
                    val region = source.bounds!!
                    val kept = filteredVisibleTileCoords.filter { coord -> isWithinRegionBounds(coord, region) }
                    if (pr.ON && pr.tileDownloadAudit.active) {
                        for (c in filteredVisibleTileCoords.filterNot { isWithinRegionBounds(it, region) }) {
                            pr.p(
                                TAG,
                                pr.tileDownloadAudit,
                                "requestVisibleTiles outside source.region bounds (skipped): z=${c.z} x=${c.x} y=${c.y} layer=$id source=${source.id}"
                            )
                        }
                    }
                    kept
                } else {
                    filteredVisibleTileCoords
                }

                // Release cached tile×time data for viewports no longer visible. Rule 7 ("never
                // evict the current timeline") means the *current* viewport's full range, not
                // every viewport ever visited this session — without this, GPU/native memory for
                // stale viewports never comes back and grows unbounded across pans.
                if (source.isEncoded) {
                    val viewportKeySet = finalTileCoords.mapTo(HashSet()) { it.hashShort() }
                    if (viewportKeySet != lastViewportEvictionKeySet) {
                        lastViewportEvictionKeySet = viewportKeySet
                        // Protect zoom-ancestors of the new viewport: RenderPass.determinePartial
                        // falls back to exactly these coarser tiles while the new zoom's exact
                        // tiles are still downloading, so evicting them the instant the zoom
                        // changes (racing that very fallback lookup) turned "blurry parent while
                        // loading" into a hard blank instead.
                        val protectedAncestorKeySet = HashSet<String>()
                        for (coord in finalTileCoords) {
                            var az = coord.z
                            var ax = coord.x
                            var ay = coord.y
                            while (az > 0) {
                                az -= 1
                                ax = Math.floorDiv(ax, 2)
                                ay = Math.floorDiv(ay, 2)
                                protectedAncestorKeySet.add("0:$az/$ax/$ay")
                            }
                        }
                        pyramid.tileCache.evictTilesOutsideViewport(viewportKeySet, protectedAncestorKeySet)
                    }
                }

                // Rule: world-tile-first-on-add. Prime z=0 before the viewport batch goes out, so a
                // newly-added layer has coarse global coverage for the ancestor walk to fall back on
                // instead of a blank map. Delegates to the existing quiet path rather than pushing a
                // bare TileCoord(0,0,0) into [finalTileCoords]: that path fetches the world tile for
                // the intervals actually being drawn — [TilePyramid.timesForPausedOrScrubDownload]
                // returns phase A/B, which is exactly the `currentPhaseString` determinePartial
                // looks up — whereas a bare coord carries no interval of its own. It also skips
                // intervals already satisfied, and stays out of the load indicator
                // (`trackDownloadProgress = false`).
                //
                // Only while paused: playback wants the current viewport×interval tiles first, and a
                // whole-world tile per interval would just delay them. The flag is consumed only
                // when we actually prime, so a layer added mid-playback still gets its world tile on
                // the first request after playback stops.
                //
                // The prime cannot run inline here: on the first request after a layer is added
                // [Timeline.sourceTimeHash] is still empty, so timesForPausedOrScrubDownload returns
                // nothing and the quiet path no-ops — and requestVisibleTiles does not run again
                // until a camera move, so the world tile ended up being fetched only once the user
                // panned, which is precisely the moment it was supposed to already be covering.
                // Measured: z0Bound stayed false for the whole 30s load after switching the layer on
                // and only flipped true at the instant of the first pan. Hand off to a bounded
                // retry that waits for the timeline instead.
                primeWorldTileWhenTimelineReady()

                alreadyRequested.addAll(finalTileCoords)
                tileRequestOptions.reload = reload

                val result = pyramid.requestTilesForDownload(
                    finalTileCoords,
                    tileRequestOptions,
                    externalScope,
                )

                if (result.isFailure) {
                    val err = result.exceptionOrNull()
                    if (err is CancellationException) {
                        // Parent cancelled this refresh (e.g. layer teardown). Do not abort the
                        // caller with a throw — that previously cancelled follow-up pan/play waves.
                        return
                    }
                    throw err!!
                }

                val encLayer = this as? EncodedTileLayer
                if (encLayer != null && source.isEncoded) {
                    val stencilTb = getVisibleTileBounds(bounds, zoomVar, fromGetRenderables = true)
                    val stencilCoords = getVisibleTileCoords(bounds, stencilTb, 0.0, fromGetRenderables = true)
                    if (encLayer.glStencilMaskKind != MaskLayerKind.NONE) {
                        map.schedulePrefetchGlStencilMaskTilesForWeatherRender(
                            stencilCoords,
                            encLayer.glStencilMaskKind,
                            encLayer.glStencilMaskCountryIso,
                        )
                    }
                    val customStencil = encLayer.stencilLayerMask
                    if (customStencil != null &&
                        (customStencil.layers.isNotEmpty() || customStencil.clipBounds != null)
                    ) {
                        map.schedulePrefetchGlStencilOsmTilesForCustomMask(stencilCoords)
                    }
                }

                if (mapController == null) return

                mapController!!.checkDownloadStatus(id, pyramid.tileCache.pendingCount)

                if (Timeline.movedOnTileLoaded) {
                    withContext(Dispatchers.IO) {
                        for (item in (pyramid.tileSource as XweatherEncodedTileSource).threadSafeTileMap) {
                            (pyramid.tileSource as XweatherEncodedTileSource).onTileLoaded(
                                item.value,
                                (pyramid.tileSource as XweatherEncodedTileSource).threadSafeIntervalMap[item.key],
                                1
                            )
                        }
                        (pyramid.tileSource as XweatherEncodedTileSource).threadSafeTileMap.clear()
                        (pyramid.tileSource as XweatherEncodedTileSource).threadSafeIntervalMap.clear()
                        mapController!!.checkDownloadStatus(id, pyramid.tileCache.pendingCount)
                    }
                }
            }
        }
    }

    /**
     * Same viewport and coord selection as [requestVisibleTiles], but only counts how many new
     * encoded (coord×time) pairs would be queued — no HTTP, no cache or pending-list mutation.
     * Summed across layers in [MapController.refreshVisibleLayers] to set a fixed download % denominator.
     */
    suspend fun preflightEncodedDownloadPairCount(): Int {
        if (!visible || !source.isEncoded) return 0
        val mc = mapController ?: return 0
        if (bounds == null) {
            bounds = mc.getBounds()
        }
        val b = bounds ?: return 0

        zoomVar = zoomForVisibleTiles()
        val tileBounds = getVisibleTileBounds(b, zoomVar)
        visibleTileCoords = getVisibleTileCoords(b, tileBounds, 0.0, false)

        val filteredVisibleTileCoords =
            visibleTileCoords.filter { vtc ->
                vtc.x >= 0 && vtc.x < powerTableI[vtc.z] && vtc.y >= 0 && vtc.y < powerTableI[vtc.z]
            }

        val finalTileCoords: List<TileCoord> = if (source.bounds != null) {
            val region = source.bounds!!
            filteredVisibleTileCoords.filter { coord -> isWithinRegionBounds(coord, region) }
        } else {
            filteredVisibleTileCoords
        }

        return pyramid.preflightEncodedNewPairCount(finalTileCoords, tileRequestOptions)
    }

    private fun isWithinRegionBounds(coord: TileCoord, bounds: com.xweather.mapsgl.coordinates.LatLonBounds): Boolean {
        val n = powerTableD[coord.z]
        val lonDegPerTile = 360.0 / n
        val latRad = atan(sinh(Math.PI * (1 - 2 * coord.y / n)))
        val minLon = coord.x * lonDegPerTile - 180.0
        val maxLon = (coord.x + 1) * lonDegPerTile - 180.0
        val minLat = Math.toDegrees(atan(sinh(Math.PI * (1 - 2 * (coord.y + 1) / n))))
        val maxLat = Math.toDegrees(latRad)

        if (minLon < bounds.eastExtent && maxLon > bounds.westExtent) {
            if (minLat < bounds.northExtent && maxLat > bounds.southExtent) {
                return true
            }
        }
        return false
    }

    /** Not yet implemented on [TileLayer]; always returns an empty string. */
    override fun getInfoForLocation(lat: Double, lng: Double, zoom: Int): String {
        return ""
    }

    /** Not yet implemented on [TileLayer]. */
    override fun queryFeatures(
        zoomVar: Int,
        latTile: Int,
        lonTile: Int,
        latPix: Int,
        lonPix: Int,
        queryLon: Double?,
        queryLat: Double?,
    ): Any? {
        TODO("Not yet implemented")
    }

    /** * Recieves LatLonBounds
     * @return Tile number bounds. ex:(zoom=4, left=2, right=5, top=2, bottom=8))    */
    /** * Recieves LatLonBounds
     * @return Tile number bounds. ex:(zoom=4, left=2, right=5, top=2, bottom=8))    */
    internal fun getVisibleTileBounds(
        bounds: LatLonBounds,
        zoom: Double, //this zoom has offset baked in
        fromGetRenderables: Boolean = false
    ): TileBounds {
        var z = floor(zoom) //this zoom has offset baked in

        if (!fromGetRenderables) {
            if (z > source.maxZoom) z = source.maxZoom.toDouble()
        }

        var zoomInt = floor(z).toInt()
        if (zoomInt < 0) zoomInt = 0

        maxVal = (powerTableI[zoomInt] - 1)
        if (pr.ON) pr.p(TAG, pr.dateLine, "getVisibleTileBounds() using: ${bounds.westExtent} to ${bounds.eastExtent} ")

        lastTileBounds = currentTileBounds

        val yNorth = TileConversions.latToTile(bounds.northExtent, zoomInt)
        val ySouth = TileConversions.latToTile(bounds.southExtent, zoomInt)
        // Tile y grows south; northern latitudes map to smaller y. If north/south were ever inverted,
        // min/max still yields the correct inclusive span.
        var top = minOf(yNorth, ySouth).coerceAtLeast(0)
        var bottom = maxOf(yNorth, ySouth).coerceAtMost(maxVal)
        // Camera lat bounds can fall just inside a row while the viewport still shows the neighbor row.
        top = (top - 1).coerceAtLeast(0)
        bottom = (bottom + 1).coerceAtMost(maxVal)

        currentTileBounds = TileBounds(
            zoom = zoomInt,
            //swapped for the line below 250306 to fix dateline (to the left) issues on zoomOffset == -1
            // left = lonToTileNormalized(bounds.westExtent, zoomInt, fromGetRenderables),
            left = TileConversions.lonToTileNonNormalized(bounds.westExtent, zoomInt),
            right = TileConversions.lonToTileNormalized(bounds.eastExtent, zoomInt, fromGetRenderables),
            top = top,
            bottom = bottom
        )

        return currentTileBounds!!
    }

    private fun tileBoundsChanged(current: TileBounds, last: TileBounds): Boolean {
        if (current.top != last.top) return true
        if (current.bottom != last.bottom) return true
        if (current.left != last.left) return true
        if (current.right != last.right) return true
        if (current.zoom != last.zoom) return true

        return false
    }

    /**
     * Recieves LatLonBounds and zoom level
     * @return List of tile coords. Ex: (TileCoord: 4/2/2, TileCoord: 4/3/2)
     */
    override fun getVisibleTileCoords(
        latLonBounds: LatLonBounds,
        tileBounds: TileBounds,
        zoom: Double,
        fromGetRenderables: Boolean,
    ): List<TileCoord> {
        val coords: MutableList<TileCoord> = mutableListOf()

        if (fromGetRenderables) {
            // Enumerate every horizontal tile index the geographic bounds cover, across any number of
            // world copies (Mapbox can show many repeats when zoomed out). Older logic only stitched
            // one adjacent copy (-1/0/1), which capped encoded layers to ~2 worlds.
            //
            // Use [MapProvider.getUnwrappedCameraLonBoundsForTiles] (raw Mapbox unwrapped longitudes), not
            // [latLonBounds] from [getBounds] alone: [VisibleGeoBounds.fromMapboxUnwrappedCamera] can
            // collapse to a single world strip, which would limit xMin..xMax to one copy.
            val finalZoom = tileBounds.zoom.coerceAtLeast(0)
            val numTiles = powerTableI[finalZoom]
            if (numTiles <= 0) return coords

            val (westRaw, eastRaw) = mapController?.getUnwrappedCameraLonBoundsForTiles()
                ?: (latLonBounds.westExtent.toDouble() to latLonBounds.eastExtent.toDouble())
            var eastUnwrapped = eastRaw
            if (eastUnwrapped < westRaw) {
                eastUnwrapped += 360.0
            }

            val xMin = floor((westRaw + 180.0) / 360.0 * numTiles).toInt()
            val xMax = ceil((eastUnwrapped + 180.0) / 360.0 * numTiles).toInt() - 1

            for (y in tileBounds.top..tileBounds.bottom) {
                if (xMax < xMin) continue
                for (xi in xMin..xMax) {
                    val nx = ((xi % numTiles) + numTiles) % numTiles
                    // Rule: dateline-world-copy. (xi - nx) is always an exact multiple of numTiles (by
                    // construction of the modulo above) — it's the raw tile-index delta, not a world-
                    // copy COUNT. Every consumer of TileCoord.offset (VectorGeometryRenderer.
                    // meshInfoForCoord's worldX formula, and VectorFillLayerRenderer/
                    // VectorLineLayerRenderer's per-vertex translate) multiplies offset by numTiles
                    // again to get the pixel/tile-unit shift — so storing the raw delta here double-
                    // scaled it by numTiles, silently correct only at zoom 0 (numTiles=1, where
                    // dividing by 1 is a no-op) and wrong by a factor of numTiles at every other zoom,
                    // translating the extra world copy to a wildly wrong position instead of the
                    // adjacent one. Store the copy COUNT instead.
                    val offset = (xi - nx) / numTiles
                    coords.add(TileCoord(nx, y, finalZoom, offset))
                }
            }
        } else {
            // This branch handles simple tile requests (like for downloading)
            // where we only need tile coordinates normalized to a single world map.
            //
            // Use the same unwrapped camera longitudes as the renderables branch for horizontal
            // extent. [latLonBounds] / [getVisibleTileBounds] use [MapController.getBounds], which
            // passes through [VisibleGeoBounds.fromMapboxUnwrappedCamera] and can collapse the
            // viewport to a narrow longitude strip. At high pitch with many world copies, that strip
            // depends on bearing: facing E vs W yields different collapsed west/east, so tile
            // columns from [tileBounds.left]..[tileBounds.right] would miss tiles that are already
            // drawn (unwrapped) and force extra downloads after rotating.
            //
            // Several raw tile indices still map to the same normalized z/x/y; dedupe below.
            val finalZoom = tileBounds.zoom.coerceIn(
                floor(source.minZoom).toInt(),
                floor(source.maxZoom).toInt()
            )
            val numTiles = powerTableI[finalZoom]
            if (numTiles > 0) {
                val seenNorm = LinkedHashSet<String>()
                val (xMin, xMax) = mapController?.getUnwrappedCameraLonBoundsForTiles()?.let { (westRaw, eastRaw) ->
                    var eastUnwrapped = eastRaw
                    if (eastUnwrapped < westRaw) {
                        eastUnwrapped += 360.0
                    }
                    val minX = floor((westRaw + 180.0) / 360.0 * numTiles).toInt()
                    val maxX = ceil((eastUnwrapped + 180.0) / 360.0 * numTiles).toInt() - 1
                    minX to maxX
                } ?: (tileBounds.left to tileBounds.right)

                for (y in tileBounds.top..tileBounds.bottom) {
                    if (xMax < xMin) continue
                    for (xi in xMin..xMax) {
                        val nx = ((xi % numTiles) + numTiles) % numTiles
                        val key = "$finalZoom/$nx/$y"
                        if (seenNorm.add(key)) {
                            coords.add(TileCoord(nx, y, finalZoom))
                        }
                    }
                }
            }
        }

        if (initialLoad) { // Always download zoomLevel 0 first
            initialLoad = false
            if (tileBounds.zoom != 0) {
                val hasZ0Root = coords.any { it.z == 0 && it.x == 0 && it.y == 0 }
                if (!hasZ0Root) {
                    coords.add(TileCoord(0, 0, 0))
                }
            }
        }

        return coords
    }

    /**
     * [MapboxMap.getCameraState] must run on the map-owning thread; [getTileBounds] / render can run on
     * the GL thread. On main, read live zoom; otherwise use [CameraSync] (filled by custom-layer render / main).
     */
    private fun getDataZoom(): Double {
        val mc = mapController ?: return CameraSync.mapZoom
        if (Looper.myLooper() == Looper.getMainLooper()) {
            return mc.getZoom()
        }
        return CameraSync.zoomForCustomLayerInstancing()
    }

    /** Map zoom (no [zoomOffset]), matching Mapbox custom-layer render zoom. */
    private fun mapZoomForVisibleTiles(): Double =
        CameraSync.zoomForCustomLayerInstancing().coerceAtLeast(0.0)

    /**
     * Effective data tile zoom: [mapZoomForVisibleTiles] plus [zoomOffset]. Used for render and download
     * tile indices so both paths agree.
     */
    internal fun zoomForVisibleTiles(): Double =
        (mapZoomForVisibleTiles() + zoomOffset).coerceAtLeast(0.0)

    /** Used in TileTimeSeriesDataProvider. Needs testing */
    /** Used in TileTimeSeriesDataProvider. Needs testing */
    fun getVisibleTileCoords(): List<TileCoord> {
        return visibleTileCoords
    }

    /**
     * Tile coords for gridded sidecar sampling (e.g. GL wind barbs). Uses [visibleTileCoords] when
     * [requestVisibleTiles] has run; otherwise derives from current [bounds] / [getTileBounds] so
     * sampling still works when [onMove] skips downloads (timeline playing, etc.).
     */
    internal fun visibleTileCoordsForSidecarSampling(): List<TileCoord> {
        // Do not reuse [visibleTileCoords] from [requestVisibleTiles]: that path uses
        // [getVisibleTileCoords] with fromGetRenderables=false (download-style enumeration).
        // Gridded sidecar sampling must use fromGetRenderables=true (unwrapped camera, world copies)
        // and must track programmatic zoom changes even when [renderBoundsDirty] was not set yet.
        val b = bounds ?: mapController?.getBounds() ?: return emptyList()
        val tb = getTileBounds()
        val coords = getVisibleTileCoords(b, tb, zoomVar, true)
        var filtered = coords.filter { vtc ->
            vtc.x >= 0 && vtc.x < powerTableI[vtc.z] && vtc.y >= 0 && vtc.y < powerTableI[vtc.z]
        }
        filtered = if (source.bounds != null) {
            filtered.filter { coord -> isWithinRegionBounds(coord, source.bounds!!) }
        } else {
            filtered
        }
        // At world / near-world zoom, tile enumeration can be empty before the first camera sync or while
        // unwrapped longitudes are still settling — instanced wind then gathers zero instances until a pan.
        if (filtered.isEmpty() && tb.zoom <= 0) {
            val root = TileCoord(0, 0, 0)
            val inRegion = source.bounds == null || isWithinRegionBounds(root, source.bounds!!)
            if (inRegion) return listOf(root)
        }
        return filtered
    }

    /**
     * Visible tile keys at **native map zoom** (no layer [zoomOffset]). Mapbox
     * [com.mapbox.maps.extension.style.sources.CustomGeometrySource] requests MVT at
     * `CanonicalTileID.z` tied to the camera zoom, while [zoomForVisibleTiles] applies [zoomOffset]
     * for encoded layers — one level off makes [com.xweather.mapsgl.sources.VectorTileSource]
     * cache lookups miss every tile for custom vector mesh fills.
     *
     * Custom GL layers render on Mapbox's GL thread — must not call [com.xweather.mapsgl.map.MapController.getBounds],
     * which reads [com.mapbox.maps.MapboxMap.cameraState] (wrong-thread bindgen errors and empty tile lists).
     */
    internal fun visibleTileCoordsForMapboxVectorCache(): List<TileCoord> {
        val raw =
            mapZoomForVisibleTiles().coerceAtLeast(0.0).coerceAtMost(source.maxZoom.toDouble())
        return visibleTileCoordsForMapboxVectorCacheAtDataZoom(raw)
    }

    /**
     * Visible MVT tile keys at [dataZoom] for custom GL vector cache lookup / prefetch.
     */
    internal fun visibleTileCoordsForMapboxVectorCacheAtDataZoom(dataZoom: Double): List<TileCoord> {
        val b: LatLonBounds =
            bounds
                ?: (mapController as? MapboxMapController)?.getBoundsForRenderThread()
                ?: run {
                    if (Looper.myLooper() == Looper.getMainLooper()) mapController?.getBounds() else null
                }
                ?: return emptyList()
        val raw = dataZoom.coerceAtLeast(0.0).coerceAtMost(source.maxZoom.toDouble())
        val tb = getVisibleTileBounds(b, raw, true)
        val coords = getVisibleTileCoords(b, tb, raw, true)
        var filtered = coords.filter { vtc ->
            vtc.x >= 0 && vtc.x < powerTableI[vtc.z] && vtc.y >= 0 && vtc.y < powerTableI[vtc.z]
        }
        filtered = if (source.bounds != null) {
            filtered.filter { coord -> isWithinRegionBounds(coord, source.bounds!!) }
        } else {
            filtered
        }
        if (filtered.isEmpty() && tb.zoom <= 0) {
            val root = TileCoord(0, 0, 0)
            val inRegion = source.bounds == null || isWithinRegionBounds(root, source.bounds!!)
            if (inRegion) return listOf(root)
        }
        return filtered
    }

    /**
     * Rule: fallback-must-stay-in-viewport. [VectorTileSource.cachedTileCoordsWithDataAtZ] returns
     * every tile cached anywhere in the source at [z] with no geographic filter — it is meant for
     * "is there SOMETHING at this zoom we could show" checks, not "what's near the camera". Renderer
     * fallback paths (draw a coarser cached tile for one frame while the real viewport tiles at the
     * new zoom are still loading) called it directly and, after navigating through several regions,
     * ended up drawing whatever unrelated tiles happened to still be cached from anywhere in the
     * world, all at once — each individually correct-for-its-own-coordinate, but nowhere near the
     * current camera. Reported as "place-city labels invisible / a garbled cluster of world cities"
     * at low zoom after visiting multiple regions. Intersecting against the tiles [z] would actually
     * enumerate for the current viewport keeps the fallback geographically relevant.
     */
    internal fun cachedTileCoordsWithDataAtZInViewport(vts: VectorTileSource, z: Int): List<TileCoord> {
        val cached = vts.cachedTileCoordsWithDataAtZ(z)
        if (cached.isEmpty()) return cached
        val viewportAtZ = visibleTileCoordsForMapboxVectorCacheAtDataZoom(z.toDouble())
        if (viewportAtZ.isEmpty()) return emptyList()
        val viewportXY = HashSet<Long>(viewportAtZ.size * 2).apply {
            viewportAtZ.forEach { add(it.x.toLong() shl 32 or it.y.toLong()) }
        }
        return cached.filter { (it.x.toLong() shl 32 or it.y.toLong()) in viewportXY }
    }

    /**
     * Native camera zoom for GL vector timeline playback. Previously fetched one zoom below camera
     * (≈¼ tile count vs native Z) to cut playback prefetch request volume, scaling the coarser parent
     * tile back up via [com.xweather.mapsgl.map.mapbox.CameraSync.tileRasterOverscale]. Removed:
     * for products with large per-tile payloads (e.g. fires-obs), that traded request count for tile
     * weight without a clear win, and kept playback tiles a zoom level removed from what the static
     * (non-playback) draw path fetches — worth re-examining if playback prefetch volume becomes a
     * problem again.
     */
    internal fun glVectorPlaybackDataZoom(mapZoom: Double = mapZoomForVisibleTiles()): Int =
        floor(mapZoom).toInt().coerceAtLeast(0).coerceAtMost(source.maxZoom.toInt())

    /** Viewport tile coords at [glVectorPlaybackDataZoom]; falls back to camera-Z coords when empty. */
    internal fun visibleTileCoordsForGlVectorPlayback(): List<TileCoord> {
        val playbackCoords =
            visibleTileCoordsForMapboxVectorCacheAtDataZoom(glVectorPlaybackDataZoom().toDouble())
        if (playbackCoords.isNotEmpty()) return playbackCoords
        return visibleTileCoordsForMapboxVectorCache()
    }

    /** Cached-tile zoom search order for GL vector draw fallbacks during timeline playback. */
    internal fun glVectorPlaybackFallbackZoomCandidates(mapZoom: Double): List<Int> {
        val cameraZ = floor(mapZoom).toInt().coerceAtLeast(0).coerceAtMost(source.maxZoom.toInt())
        return listOf(cameraZ, cameraZ - 1, cameraZ + 1).filter { it >= 0 }
    }

    /**
     * Recomputes [visibleTileCoords] from the current viewport without issuing tile HTTP requests.
     * Custom GL vector layers skip [requestVisibleTiles] during timeline playback; the time-series
     * animator still reads [visibleTileCoords] when prefetching interval MVT data.
     */
    internal fun refreshVisibleTileCoordsForVectorGl(): Boolean {
        val b = bounds
            ?: mapController?.getBounds()
            ?: (mapController as? com.xweather.mapsgl.map.mapbox.MapboxMapController)?.getBoundsForRenderThread()
            ?: return false
        if (bounds == null) {
            bounds = b
        }
        zoomVar = zoomForVisibleTiles()
        val tileBounds = getVisibleTileBounds(b, zoomVar)
        val coords = getVisibleTileCoords(b, tileBounds, 0.0, false)
        var filtered = coords.filter { vtc ->
            vtc.x >= 0 && vtc.x < powerTableI[vtc.z] && vtc.y >= 0 && vtc.y < powerTableI[vtc.z]
        }
        filtered = if (source.bounds != null) {
            filtered.filter { coord -> isWithinRegionBounds(coord, source.bounds!!) }
        } else {
            filtered
        }
        val prevKeys = visibleTileCoords.map { "${it.z}/${it.x}/${it.y}" }.toSet()
        val nextKeys = filtered.map { "${it.z}/${it.x}/${it.y}" }.toSet()
        visibleTileCoords = filtered
        renderBoundsDirty = true
        renderablesDirty = true
        if (prevKeys != nextKeys && this is VectorTileLayer && glRenderingActive()) {
            // During playback, viewport MVT prefetch is rate-limited via prefetchVectorTilesForGlRendering;
            // marking the provider dirty here would duplicate the same coord×interval wave.
            if (!Timeline.isGloballyPlaying) {
                animator?.provider?.setNeedsUpdate()
            }
        }
        return filtered.isNotEmpty()
    }

    /**
     * Single tile at map center when [visibleTileCoordsForMapboxVectorCache] is empty (e.g. first
     * custom-layer frame before [cachedMapboxBounds] is populated). Keeps MVT prefetch alive for GL symbols.
     */
    internal fun viewportCenterTileCoordsForPrefetch(): List<TileCoord> {
        val mc = mapController ?: return emptyList()
        val mapZoomNow = CameraSync.zoomForCustomLayerInstancing()
        val z = floor(mapZoomNow).toInt()
            .coerceAtLeast(0)
            .coerceAtMost(source.maxZoom.toInt())
        val n = 1 shl z
        var x = TileConversions.lonToTileNonNormalized(mc.centerLatLng.lon, z) % n
        if (x < 0) x += n
        val y = TileConversions.latToTile(mc.centerLatLng.lat, z).coerceIn(0, n - 1)
        return listOf(TileCoord(x, y, z))
    }

    /** Refreshes [layerRenderContext]'s renderables/paint style for this frame, then delegates to [tileLayerRenderer]. */
    //** generates context.renderables can calls tileLayerRenderer.prerender(context)  */
    override fun prerender(elapsedTime: Double) {
        if (mapController == null || !visible) {
            return
        }
        layerRenderContext.renderables = getRenderables()
        layerRenderContext.paintStyle = paint
        tileLayerRenderer.prerender(layerRenderContext)
        return
    }

    /** No-op on [TileLayer]; there is no GL/listener state here that needs releasing on removal. */
    override fun onRemove() {}

    /** Called from LayerHost.render(), calls TileLayerRenderer.draw()*/
    /** Called from LayerHost.render(), calls TileLayerRenderer.draw()*/
    override fun render(texUnit: HashMap<String, Int>, camera: Camera) {
        if (visible)
            tileLayerRenderer.draw(layerRenderContext, texUnit, camera)
        triggerEvent(TileLayerEventType.FINISHED_DRAWING)
    }

    /** The kind of layer this is (raster, fill, line, symbol, contour, particles, etc.). */
    override lateinit var type: LayerType

    /** This layer's time-series animation configuration (mode, clamp, valid date range, interval count, etc.). */
    override lateinit var timing: LayerTiming

    /** Unimplemented on [TileLayer]. */
    override var invertMaskLayer: Boolean
        get() = TODO("Not yet implemented")
        set(value) {}

    /** Handlers registered via [MapLayer.addSourceEventHandler] to react to this layer's data-source events. */
    override var sourceEventHandlers: MutableList<MapLayer.SourceEventHandler> = mutableListOf()

    /** Attaches this layer to [controller], wires up its GL renderer, and starts observing the timeline's play/pause state. */
    override fun onAdd(context: Context, controller: MapController) {
        this.mapController = controller
        super.onAdd(context, controller)
        this.drawContext = context
        // need to trigger onMove to render initial tiles
        tileLayerRenderer.onAdd(this)

        (mapController)?.timeline?.playIsPressed?.observeForever { newValue ->
            // Avoid blocking the observer callback thread.
            externalScope.launch { handlePlayIsPressedChange(newValue) }
        }
    }

    /** Not yet implemented on [TileLayer]; simple no-context registration is not used by this layer. */
    override fun onAdd() {
        TODO("Not yet implemented")
    }

    /** Not yet implemented on [TileLayer]; this render-context/owning-layer overload is used by renderer classes instead. */
    override fun onAdd(context: RenderContext<Any>, tileLayer: TileLayer, controller: MapboxMapController) {
        TODO("Not yet implemented")
    }

    //triggers on play and pause
    private fun handlePlayIsPressedChange(newValue: Boolean) {
        if (newValue && bounds != null) {
            if (pr.ON) pr.p(TAG, pr.playPause, "handlePlayIsPressedChange(): Starting animation...")
            //println("TileLayer calling requestVisibleTiles with play button, looking")
            if (pr.ON) pr.p(TAG, pr.playLock, "handlePlayIsPressedChange($newValue) about to call requestVisibleTiles ")
            //requestVisibleTiles(bounds!!, fromAnimation = true) //commented this out 250320... was causing freeze when play pressed...

        } else {
            // if(pr.ON) pr.p(TAG, pr.obs_play,"TileLayer handlePlayIsPressedChange: Stopping animation...")
        }
    }

    /**
     * Rule: world-tile-first-on-add. Fetches the z=0 world tile once the source timeline has
     * intervals, so a newly-added layer has coarse global coverage for
     * [com.xweather.mapsgl.gl.RenderPass.determinePartial]'s ancestor walk to fall back on the
     * moment the camera moves somewhere new — instead of a blank map until the exact-zoom tiles
     * for that area download.
     *
     * Polled rather than inline because the timeline is not populated on the first
     * [requestVisibleTiles] after a layer is added, and that method does not run again until a
     * camera move — so an inline attempt silently deferred until the user panned, which is exactly
     * the case the world tile exists to cover.
     *
     * Skipped while playing: playback wants the viewport×interval tiles first. The one-shot flag is
     * only consumed on a successful prime, so a layer added mid-playback still gets its world tile
     * once playback stops.
     */
    private fun primeWorldTileWhenTimelineReady() {
        if (worldTilePrimed || !source.isEncoded) return
        if (worldTilePrimeJob?.isActive == true) return
        worldTilePrimeJob = externalScope.launch {
            repeat(WORLD_TILE_PRIME_ATTEMPTS) {
                if (worldTilePrimed) return@launch
                // Only consume the one-shot when the prime actually scheduled. Several of its
                // preconditions (mapController/timeline wired, tileRequestOptions carrying a
                // resolved date, the source timeline publishing intervals) are still settling right
                // after a layer is added, and marking primed before the call meant the first bail
                // burned it — leaving the world tile unfetched until the user panned.
                if (!Timeline.isGloballyPlaying && scheduleQuietWorldTileIfNeededOnIdleCameraMove()) {
                    worldTilePrimed = true
                    return@launch
                }
                kotlinx.coroutines.delay(WORLD_TILE_PRIME_RETRY_MS)
            }
        }
    }

    /**
     * z=0 prefetch for ancestor partials while paused; does not drive the load indicator.
     * @return true when the world tile is handled for the current intervals (see
     * [TilePyramid.scheduleQuietIdleWorldTileDownload]); false when something was not ready yet.
     */
    private suspend fun scheduleQuietWorldTileIfNeededOnIdleCameraMove(): Boolean {
        if (!visible || !source.isEncoded) return false
        val tl = mapController?.timeline ?: animator?.animation?.timeline ?: return false
        if (tl.state == AnimationState.playing) return false
        return pyramid.scheduleQuietIdleWorldTileDownload(tileRequestOptions, externalScope)
    }

    /** Gets bounds and requests visible tiles **/
    override suspend fun onMove() {
        oldBounds = bounds
        bounds = mapController?.getBounds() ?: return //These bounds are normalized

        // Keep renderables updated during movement.
        // Without this, the cached `tileBounds`/`renderables` can lag behind the camera,
        // producing temporary blank tiles until `onMoveEnd()` runs.
        renderBoundsDirty = true
        renderablesDirty = true

        if (this is VectorTileLayer) {
            if (glRenderingActive()) {
                val displayTileZ = floor(zoomForVisibleTiles()).toInt().coerceAtLeast(0)
                val zoomTierChanged =
                    lastOnMoveDisplayTileZ == null || displayTileZ != lastOnMoveDisplayTileZ
                if (zoomTierChanged) {
                    lastOnMoveDisplayTileZ = displayTileZ
                }
                refreshVisibleTileCoordsForVectorGl()
                externalScope.launch {
                    val playing = Timeline.isGloballyPlaying
                    val gateLoadUi = Timeline.isGlVectorFillPrefetchLoadUiActive()
                    prefetchVectorTilesForGlRendering(
                        minIntervalMs = if (zoomTierChanged && playing) {
                            250L
                        } else {
                            400L
                        },
                        requestBudget = when {
                            gateLoadUi -> 0
                            playing -> 40
                            else -> Int.MAX_VALUE
                        },
                    )
                }
                if (Timeline.isGloballyPlaying) {
                    // Sliding-window interval prefetch is driven by timeline ADVANCE/INTERVAL_CHANGE.
                } else {
                    animator?.loadDataIfNeeded(debounced = true)
                }
            }
        } else { // Non-vector

            val timeline = animator?.animation?.timeline
            val playingBlocksMoveRequests = timeline != null &&
                timeline.state == AnimationState.playing &&
                !Timeline.pausedForDownload

            val displayTileZ = floor(zoomForVisibleTiles()).toInt().coerceAtLeast(0)
            val zoomTierChanged =
                lastOnMoveDisplayTileZ == null || displayTileZ != lastOnMoveDisplayTileZ
            if (zoomTierChanged) {
                lastOnMoveDisplayTileZ = displayTileZ
            }

            if (!playingBlocksMoveRequests || zoomTierChanged) {
                if (Timeline.holdFullTimelineResidency &&
                    source.isEncoded &&
                    !Timeline.isGloballyPlaying
                ) {
                    requeueVisibleBindsForScrub()
                } else {
                    if (pr.ON) pr.p(
                        TAG,
                        pr.infiniteLoad,
                        "onMove() calling requestVisibleTiles() on bounds  ${bounds?.westExtent} - ${bounds?.eastExtent}"
                    )
                    bounds?.let { requestVisibleTiles(it) }
                }
            }
        }
    }

    /**
     * Like [onMove], but always calls [requestVisibleTiles] for the new bounds, without the
     * playback/zoom-tier gating [onMove] applies to limit download churn during timeline playback.
     */
    suspend fun onMoveUnrestricted() {
        oldBounds = bounds
        bounds = mapController?.getBounds() ?: return //These bounds are normalized

        if (this is VectorTileLayer) {
            if (glRenderingActive()) {
                externalScope.launch { prefetchVectorTilesForGlRendering() }
            }
        } else { // Non-vector

            //if(pr.ON) pr.p(TAG, pr.infiniteLoad, " onMove() calling requestVisibleTiles()")
            if (pr.ON) pr.p(
                TAG,
                pr.infiniteLoad,
                "onMoveUnrestricted() calling requestVisibleTiles() on bounds  ${bounds?.westExtent} - ${bounds?.eastExtent}"
            )
            bounds?.let { requestVisibleTiles(it) }
        }
    }

    /** Calls requestVisibleTiles(), gets bounds if needed. */
    override suspend fun update() {
        //if (pr.ON) pr.p(TAG, pr.lagR, "update()")
        if (this is VectorTileLayer && glRenderingActive()) {
            if (bounds == null) {
                bounds = mapController?.getBounds()
            }
            refreshVisibleTileCoordsForVectorGl()
            if (!Timeline.isGloballyPlaying) {
                prefetchVectorTilesForGlRendering()
                animator?.loadDataIfNeeded(debounced = true)
            }
            return
        }
        if (bounds == null) {
            bounds = mapController?.getBounds()
        }
        bounds?.let { requestVisibleTiles(it) }
    }

    /**
     * Re-queues already-downloaded visible tiles for GPU bind after a scrub / playhead step,
     * without issuing another HTTP pass. Marks renderables dirty so the layer keeps animating
     * from resident intervals after the initial load session completes.
     */
    internal suspend fun requeueVisibleBindsForScrub() {
        if (!visible || !source.isEncoded) return
        if (bounds == null) {
            bounds = mapController?.getBounds()
        }
        val b = bounds ?: return
        renderBoundsDirty = true
        renderablesDirty = true
        zoomVar = zoomForVisibleTiles()
        val tileBounds = getVisibleTileBounds(b, zoomVar)
        val visibleCoords = getVisibleTileCoords(b, tileBounds, 0.0, false)
        val filtered = visibleCoords.filter { vtc ->
            vtc.x >= 0 && vtc.x < powerTableI[vtc.z] && vtc.y >= 0 && vtc.y < powerTableI[vtc.z]
        }
        val finalCoords = if (source.bounds != null) {
            filtered.filter { coord -> isWithinRegionBounds(coord, source.bounds!!) }
        } else {
            filtered
        }
        visibleTileCoords = finalCoords.toMutableList()
        pyramid.requeueLoadedVisibleTilesForBind(finalCoords, pyramid.scrubPhaseTimesArray()).also { queued ->
            if (queued) {
                val mc = mapController
                if (mc is MapboxMapController) {
                    mc.layerHosts[id]?.setTexturesToBind(true)
                    mc.mapboxMap?.executeOnRenderThread {
                        mc.layerHosts[id]?.bindTextures(source.id)
                    }
                    mc.redraw()
                }
            }
        }
    }

    /** No-op on [TileLayer]; this layer does not need to react to the start of a camera move. */
    override fun onMoveStart() {
        //println("$TAG onMoveStart()")
    }

    /**
     * Called once a camera movement settles. Re-syncs [bounds], and either re-binds already-resident
     * tiles (when a full-range playback load is held resident and the timeline isn't playing) or
     * requests visible tiles for the settled viewport, skipping the request while playback is
     * already handling a coalesced refresh.
     */
    override suspend fun onMoveEnd() {
        //println("TileLayer OnMoveEnd")
        bounds = mapController?.getBounds() ?: return //These bounds are normalized

        // Keep renderables in sync even if we skip triggering downloads.
        renderBoundsDirty = true
        renderablesDirty = true

        // Full-range play load already resident — re-bind only while idle (map idle / scrub).
        // While playing, continue HTTP for holes.
        if (Timeline.holdFullTimelineResidency &&
            source.isEncoded &&
            !Timeline.isGloballyPlaying
        ) {
            requeueVisibleBindsForScrub()
            return
        }

        val vectorGlPlaying = this is VectorTileLayer && glRenderingActive()

        // While playing, MapController.onMoveEnd already schedules a coalesced playback refresh
        // after updating bounds above. A parallel requestVisibleTiles here raced the play wave
        // (shared representative tile + JobCancellationException cascades).
        if (Timeline.isGloballyPlaying && !vectorGlPlaying) {
            return
        }

        // Do not skip because [Timeline.isDownloading] is true. Playback keeps that flag set
        // almost continuously, so skipping here left pan/zoom on a stale viewport forever
        // ("never loads the new animations" while scrolling during play). MapIdle is already
        // gated on a real camera move, so this path is not the old idle spam.

        val tl = mapController?.timeline ?: animator?.animation?.timeline
        if (tl == null || tl.state != AnimationState.playing) {
            scheduleQuietWorldTileIfNeededOnIdleCameraMove()
        }

        //if(pr.ON) pr.p(TAG, pr.infiniteLoad, " onMoveEnd() calling requestVisibleTiles() with bounds: ${bounds}")
        if (pr.ON) pr.p(
            TAG,
            pr.infiniteLoad,
            "onMoveEnd() calling requestVisibleTiles() on bounds  ${bounds?.westExtent} - ${bounds?.eastExtent}"
        )
        if (vectorGlPlaying) {
            refreshVisibleTileCoordsForVectorGl()
            prefetchVectorTilesForGlRendering(
                requestBudget = if (Timeline.isGloballyPlaying) 40 else Int.MAX_VALUE,
            )
        } else {
            bounds?.let { requestVisibleTiles(it) }
        }
    }

    /** Not yet implemented on [TileLayer]. */
    override fun onResize() {
        TODO("Not yet implemented")
    }

    /** Not yet implemented on [TileLayer]. */
    override fun onClick() {
        TODO("Not yet implemented")
    }

    /** Notifies [tileLayerRenderer] that the layer became visible and marks it dirty so it redraws. */
    override fun onVisible() {
        tileLayerRenderer.onVisible()
        setNeedsUpdate()
    }

    /** Notifies [tileLayerRenderer] that the layer was hidden and marks it dirty so it updates accordingly. */
    override fun onHidden() {
        tileLayerRenderer.onHidden()
        setNeedsUpdate()
    }

    private fun setupTimeSeriesAnimator() {
        if (pr.ON) pr.p("MapLayer", pr.layerToAnimation, "setupTimeSeriesAnimator(), entered")
        //val (clamp, range, interleaved) = this.timing

        timing = LayerTiming()
        with(timing) {
            mode = TimeSeriesMode.NONE
            clamp = TimeClampMode.NONE
            range = null
            intervals = null
            interleaved = true
            operation = null
        }

        val clamp = timing.clamp
        val range = timing.range
        val interleaved = timing.interleaved


        val provider = createTimeSeriesDataProvider()

        if (pr.ON) pr.p(
            "TileLayer",
            pr.layerToAnimation,
            "setupTimeSeriesAnimator(), provider is null? ${provider == null}"
        )

        if (provider != null) {
            //if (interleaved != null) {
            provider.interleaveRequests = interleaved
            //} else provider.interleaveRequests = true
        }

        val animator = TimeSeriesAnimator(
            timeSeries as TimeSeries<Data>,
            provider,
            TimeSeriesAnimatorOptions(clamp!!),
            // mapOf("id" to this.id, "mode" to clamp!!)
        )

        this.animator = animator

        animator.animation.timeline = mapController?.timeline

        if (pr.ON) pr.p(
            "TileLayer",
            pr.layerToAnimation,
            "setupTimeSeriesAnimator() (this.animator == null) ? ${this.animator == null}"
        )

        if (range != null) {
            animator._timeRange = range
        }

        //if (true){ //TODO: Make sure this section works
        addSourceEventHandler(
            DataSourceEvents.TileLoad().toString(),
            { animator.updateEntryState() }
        )
        //}

        // TODO: note from javascript version: move this into TimeSeriesAnimator
        listOf(
            TimeSeriesEvent.DATA_ADVANCE,
            TimeSeriesEvent.LOAD_COMPLETE
        ).forEach { event ->

            animator.on(
                event,
                callback = object : EventDispatcher.MyEventListener<Any> {
                    override fun onEvent(v1: Any) {
                        if (true) {
                            //DriverManager.println("")
                        }
                        MapsGLDebug.trace("TileLayer _setupTimeSeriesAnimator() Event received with data: $v1")

                    }

                    override val eventDispatcher: EventDispatcher
                        get() = TODO("Not yet implemented")

                },
                null,
                this
            ).apply {
                //animator.on(event,   object : EventListener<TimeSeriesEvent> {},  context = this).apply {
                /*
                if (this.visible) {
                    this.setNeedsUpdate()
                }*/
            }

        }
        /*
        animator.on(TimeSeriesEvent.ADVANCE,object : EventListener {}, null,  this).apply{
            if (this.visible) {
                this.setNeedsUpdate()
                this.enabled = this.animator.canShowForDate(e as Date) ?: false
            }


        } //{ e ->
        */
        //}

        if (this.timing.mode == TimeSeriesMode.INTERVAL) {
            /*
            animator.on(TimeSeriesEvent.ADVANCE) {
                if (animator.provider == null) {
                    this.refresh(true)
                } else if (animator.isActive) {
                    animator.loadDataIfNeeded()
                }
            }
            animator.on(TimeSeriesEvent.INTERVAL_ADVANCE) { e ->
                if(animator.isActive == false) {
                    animator.loadDataForIntervals(listOf((e as? Any) ?: error("Type mismatch, event is not of type Any")))
                }
            }
        }  else if (this.timing.mode == TimeSeriesMode.ANY) {
            animator.on(TimeSeriesEvent.ADVANCE) {
                this.refresh(true)
            } */
        }

    }


}
/*
val DATA_ZOOM_RATIO = mapOf(
    DataQuality.exact to 1f,
    DataQuality.high to 0.95f,
    DataQuality.medium to 0.8f,
    DataQuality.normal to 0.65f,
    DataQuality.low to 0.4f,
    DataQuality.minimal to 0.25f
)
val DATA_TO_ZOOM = mapOf(
    DataQuality.exact to listOf(0),
    DataQuality.high to listOf(0, 1, 2, 3, 4, 4, 5, 5, 6, 7, 7, 8, 8, 9, 9, 10, 10, 10, 10, 10, 10),
    DataQuality.medium to listOf(0, 1, 1, 2, 3, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5),
    DataQuality.normal to listOf(0, 1, 1, 2, 3, 4, 4, 5, 5, 5, 6, 6, 6, 7, 7, 7, 8, 8, 8, 9, 9),
    DataQuality.low to listOf(0, 0, 1, 1, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 6, 6, 6),
    DataQuality.minimal to listOf(0, 0, 0, 0, 0, 1, 1, 1, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3)
)
val QUALITY_PIXEL_RATIO = mapOf(
    DataQuality.exact to 1,
    DataQuality.high to 2,
    DataQuality.medium to 4,
    DataQuality.normal to 6,
    DataQuality.low to 8,
    DataQuality.minimal to 15
)
*/