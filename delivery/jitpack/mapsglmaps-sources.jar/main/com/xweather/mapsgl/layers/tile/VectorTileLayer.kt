package com.xweather.mapsgl.layers.tile

import android.content.Context
import android.os.SystemClock
import com.mapbox.maps.ScreenCoordinate
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.data.series.AnyTimeSeries
import com.xweather.mapsgl.data.series.MAX_REQUEST_INTERVALS
import com.xweather.mapsgl.data.series.TiledTimeSeriesDataProvider
import com.xweather.mapsgl.data.series.TimeSeries
import com.xweather.mapsgl.data.series.TimeSeriesDataProvider
import com.xweather.mapsgl.layers.FeatureQueryResult
import com.xweather.mapsgl.layers.QueriedFeature
import com.xweather.mapsgl.events.TimeSeriesEvent
import com.xweather.mapsgl.events.EventDispatcher
import com.xweather.mapsgl.layers.tile.TimeSeriesMode
import com.xweather.mapsgl.map.MapController
import com.xweather.mapsgl.map.mapbox.MapboxMapController
import com.xweather.mapsgl.map.mapbox.MapboxVectorFeature
import com.xweather.mapsgl.map.mapbox.GlStencilOsm
import com.xweather.mapsgl.map.mapbox.TropicalDrawFilter
import com.xweather.mapsgl.map.mapbox.VectorFeatureDrawFilter
import com.xweather.mapsgl.map.mapbox.featureLayerTag
import com.xweather.mapsgl.renderers.LayerRenderContext
import com.xweather.mapsgl.renderers.LayerRenderer
import com.xweather.mapsgl.renderers.TileLayerRenderer
import com.xweather.mapsgl.renderers.VectorSymbolPlacementDefaults
import com.xweather.mapsgl.sources.EncodedTileSource
import com.xweather.mapsgl.sources.resolveVectorTileData
import com.xweather.mapsgl.sources.VectorData
import com.xweather.mapsgl.sources.TileSource
import com.xweather.mapsgl.map.mapbox.CameraSync
import com.xweather.mapsgl.sources.VectorTileSource
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.VectorLayerPaint
import com.xweather.mapsgl.tiles.LatLonBounds
import com.xweather.mapsgl.tiles.TileBounds
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.util.MapsGLDebug
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.yield
import kotlin.math.floor
import com.xweather.mapsgl.sources.timelinePhaseEpochMillis
import com.xweather.mapsgl.sources.timelinePlaybackPrefetchEpochMillis
import com.xweather.mapsgl.utils.formatDateArrayToString

/**
 * VectorTileLayer.kt
 *
 * @author Jason Suto 5/26/25
 *
 */

// TODO: subclass TileLayer for now until all of the layer stuff can be refactored
@Suppress("Dokka")
open class VectorTileLayer(
    id: String,
    source: TileSource<TileData>,
    paint: VectorLayerPaint,
    tileLayerRenderer: TileLayerRenderer<TileData, LayerRenderContext<Any>>,
    zoomOffset: Int,
    externalScope: CoroutineScope
) : TileLayer(
    id,
    source,
    paint,
    tileLayerRenderer as TileLayerRenderer<TileData, LayerRenderContext<Any>>,
    zoomOffset,
    externalScope
) {
    private companion object {
        private const val GL_PREFETCH_MIN_INTERVAL_MS = 400L
        private const val GL_PREFETCH_ZOOM_MIN_INTERVAL_MS = 250L
        /** Cap MVT HTTP/parse work per prefetch wave so zoom-out cannot enqueue thousands at once. */
        private const val MAX_GL_PREFETCH_REQUESTS_PER_WAVE = 40
        private const val MAX_GL_PLAYBACK_PREFETCH_REQUESTS_PER_WAVE = 160
        /** While the strict playback gate load UI is active, renderer-owned prep drives MVT fetch. */
        private const val MAX_GL_GATE_LOAD_UI_PREFETCH_REQUESTS_PER_WAVE = 8
        private const val PLAYBACK_VIEWPORT_REFRESH_DEBOUNCE_MS = 600L
    }

    private var lastGlPrefetchMs = 0L
    private var playbackViewportPrefetchJob: Job? = null
    private var lastScheduledPlaybackViewportRefreshMs = 0L

    init {
        this.paint = paint
    }

    var sourceLayer: String? = null
    var filter: Expression? = null
    /**
     * When true, [com.xweather.mapsgl.map.mapbox.MapboxMapController.addToMap] does not add a Mapbox vector style layer;
     * geometry is used only for GLES stencil (custom mask coordinator, geo mask paths).
     */
    var stencilOnly: Boolean = false

    /**
     * Selects vector draw path. [VectorGraphicsBackend.CUSTOM_WEBGL_MESHES] draws via
     * [com.xweather.mapsgl.renderers.VectorFillLayerRenderer] / [com.xweather.mapsgl.renderers.VectorLineLayerRenderer]
     * in a Mapbox custom GL layer with an invisible hook layer driving tile fetches.
     * [VectorGraphicsBackend.MAPBOX_STYLE_SPEC] uses native Mapbox fill/line paint.
     */
    var graphicsBackend: VectorGraphicsBackend = VectorGraphicsBackend.MAPBOX_STYLE_SPEC

    /**
     * True when this layer draws via MapsGL custom GL meshes rather than Mapbox style layers.
     * Used by [com.xweather.mapsgl.layers.tile.TileLayer] to skip the encoded-tile prefetch path.
     */
    fun glRenderingActive(): Boolean =
        graphicsBackend == VectorGraphicsBackend.CUSTOM_WEBGL_MESHES && !stencilOnly

    /**
     * Warms MVT cache for custom GL mesh layers when [CustomGeometrySource] has not yet delivered
     * tiles for the current viewport (e.g. fire observation icons on `fires_obs`).
     */
    suspend fun prefetchVectorTilesForGlRendering(
        bypassThrottle: Boolean = false,
        requestBudget: Int = Int.MAX_VALUE,
        minIntervalMs: Long = GL_PREFETCH_MIN_INTERVAL_MS,
        priorityIntervalMs: Long? = null,
    ) {
        val vts = source as? VectorTileSource ?: return
        val now = SystemClock.elapsedRealtime()
        val globallyPlaying = Timeline.isGloballyPlaying
        val bypassThrottleEffective = bypassThrottle || globallyPlaying
        if (!bypassThrottleEffective && now - lastGlPrefetchMs < minIntervalMs) return
        lastGlPrefetchMs = now
        val gateLoadUiActive = Timeline.isGlVectorFillPrefetchLoadUiActive()
        val effectiveRequestBudget = when {
            gateLoadUiActive -> minOf(requestBudget, MAX_GL_GATE_LOAD_UI_PREFETCH_REQUESTS_PER_WAVE)
            requestBudget < Int.MAX_VALUE -> requestBudget
            globallyPlaying -> MAX_GL_PLAYBACK_PREFETCH_REQUESTS_PER_WAVE
            else -> MAX_GL_PREFETCH_REQUESTS_PER_WAVE
        }
        refreshVisibleTileCoordsForVectorGl()
        val mapZoomNow = CameraSync.zoomForCustomLayerInstancing()
        val drawIntervalMs = if (vts.isTimeSeriesSource) {
            timelinePhaseEpochMillis(Timeline.currentPhaseA)
        } else {
            null
        }
        val drawIntervalDate = drawIntervalMs?.let { java.util.Date(it) }
        val timeSeriesPlayback = vts.isTimeSeriesSource && globallyPlaying
        var coords = when {
            gateLoadUiActive -> visibleTileCoordsForGlVectorPlayback()
            timeSeriesPlayback -> visibleTileCoordsForGlVectorPlayback()
            else -> {
                val placeCap = VectorSymbolPlacementDefaults.placeLabelMaxDataZoom(id)
                if (placeCap != null) {
                    visibleTileCoordsForMapboxVectorCacheAtDataZoom(mapZoomNow.coerceAtMost(placeCap))
                } else {
                    visibleTileCoordsForMapboxVectorCache()
                }
            }
        }
        if (coords.isEmpty()) {
            val zCandidates = glVectorPlaybackFallbackZoomCandidates(mapZoomNow)
            for (z in zCandidates) {
                val cached = vts.cachedTileCoordsWithDataAtZ(z)
                if (cached.isNotEmpty()) {
                    coords = cached
                    break
                }
            }
        }
        if (coords.isEmpty()) {
            coords = viewportCenterTileCoordsForPrefetch()
        }
        var requested = 0
        var alreadyCached = 0

        if (vts.isTimeSeriesSource) {
            // While playing, only prefetch the sliding window around the playhead so panning into
            // new areas can load spatial tiles promptly. Full-range prefetch is for paused preload.
            val globallyPlaying = Timeline.isGloballyPlaying
            val snappedPriorityMs = priorityIntervalMs?.let { vts.snappedTimeSeriesIntervalMs(it) }
            val phaseEpochMs = when {
                globallyPlaying && Timeline.isPlaybackFullTimelinePrimingActive() && !gateLoadUiActive -> {
                    Timeline.timeDates.indices.mapNotNull { timelinePhaseEpochMillis(it) }
                }
                globallyPlaying -> timelinePlaybackPrefetchEpochMillis()
                else -> Timeline.timeDates.indices.mapNotNull { timelinePhaseEpochMillis(it) }
            }
            val currentIntervalMs = when {
                globallyPlaying -> {
                    snappedPriorityMs
                        ?: timelinePhaseEpochMillis(Timeline.currentPhaseA)?.let { vts.snappedTimeSeriesIntervalMs(it) }
                }
                else -> {
                    timelinePhaseEpochMillis(Timeline.currentPhaseA)?.let { vts.snappedTimeSeriesIntervalMs(it) }
                }
            }
            val sortedCoords = if (currentIntervalMs != null) {
                coords.sortedBy { coord ->
                    if (vts.hasTimeSeriesIntervalAt(coord.z, coord.x, coord.y, currentIntervalMs)) 1 else 0
                }
            } else {
                coords
            }
            withContext(Dispatchers.Default) {
                var budget = effectiveRequestBudget.coerceAtLeast(0)
                var queued = 0
                // Count the *visible* interval's MVT downloads toward the load indicator whether
                // or not the play-press prefetch flag is up. Gating on that flag meant a vector
                // layer switched on while idle - or a pan into fresh tiles - never moved
                // Timeline's vector counters, so the load UI saw a completely idle app and showed
                // no percent at all. The lookahead loop below still passes false, so background
                // interval prefetch never drives the indicator; and triggerLoadStart still
                // suppresses the spinner during streaming playback.
                val trackLoads = true
                suspend fun requestInterval(
                    coord: TileCoord,
                    intervalMs: Long,
                    countsForLoadIndicator: Boolean,
                ): Boolean {
                    if (budget <= 0) return false
                    if (vts.hasTimeSeriesIntervalAt(coord.z, coord.x, coord.y, intervalMs)) {
                        alreadyCached++
                        return true
                    }
                    requested++
                    budget--
                    vts.requestTile(
                        coord.x,
                        coord.y,
                        coord.z,
                        intervalTime = java.util.Date(intervalMs),
                        countsForGlFillLoadIndicator = countsForLoadIndicator,
                    )
                    if (++queued % 12 == 0) yield()
                    return true
                }
                if (currentIntervalMs != null) {
                    for (coord in sortedCoords) {
                        if (budget <= 0) break
                        requestInterval(coord, currentIntervalMs, trackLoads)
                    }
                }
                for (coord in sortedCoords) {
                    if (budget <= 0) break
                    for (intervalMs in phaseEpochMs) {
                        if (budget <= 0) break
                        if (intervalMs == currentIntervalMs) continue
                        requestInterval(coord, intervalMs, false)
                    }
                }
            }
        } else {
            for (coord in coords) {
                if (vts.findCachedVectorTileForNominalZxy(coord.z, coord.x, coord.y, true) != null) {
                    alreadyCached++
                    continue
                }
                requested++
                vts.requestTile(coord.x, coord.y, coord.z, intervalTime = drawIntervalDate)
            }
        }

        if (MapsGLDebug.enabled && glRenderingActive()) {
            MapsGLDebug.logD(
                "VectorTileLayer",
                "prefetch layer=$id source=${source.id} zoom=$mapZoomNow coords=${coords.size} " +
                    "request=$requested cached=$alreadyCached sourceLayer=$sourceLayer",
            )
        }
        if (glRenderingActive() && (requested > 0 || alreadyCached > 0)) {
            (mapController as? com.xweather.mapsgl.map.mapbox.MapboxMapController)?.requestRepaintCoalesced()
        }
    }

    /** Refreshes MVT/triangulation for the current viewport during timeline playback (pan/zoom). */
    fun schedulePlaybackViewportRefresh(priorityIntervalMs: Long? = null) {
        if (!glRenderingActive()) return
        if (Timeline.isGlVectorFillPrefetchLoadUiActive()) return
        val now = SystemClock.elapsedRealtime()
        val debounceMs = if (priorityIntervalMs != null) 200L else PLAYBACK_VIEWPORT_REFRESH_DEBOUNCE_MS
        if (now - lastScheduledPlaybackViewportRefreshMs < debounceMs) return
        lastScheduledPlaybackViewportRefreshMs = now
        playbackViewportPrefetchJob?.cancel()
        val budget = when {
            priorityIntervalMs != null -> MAX_GL_PLAYBACK_PREFETCH_REQUESTS_PER_WAVE
            Timeline.isGloballyPlaying -> MAX_GL_PLAYBACK_PREFETCH_REQUESTS_PER_WAVE
            else -> MAX_GL_PREFETCH_REQUESTS_PER_WAVE
        }
        playbackViewportPrefetchJob = externalScope.launch {
            try {
                prefetchVectorTilesForGlRendering(
                    bypassThrottle = true,
                    requestBudget = budget,
                    priorityIntervalMs = priorityIntervalMs,
                )
            } finally {
                playbackViewportPrefetchJob = null
            }
        }
    }

    fun cancelPlaybackViewportPrefetch() {
        playbackViewportPrefetchJob?.cancel()
        playbackViewportPrefetchJob = null
    }

    override lateinit var timing: LayerTiming

    override var timeSeries: AnyTimeSeries? = null

    override var invertMaskLayer: Boolean
        get() = TODO("Not yet implemented")
        set(value) {}
    override var renderer: LayerRenderer<Any>
        get() = TODO("Not yet implemented")
        set(value) {}

    /** Returns the time series data provider to use for animating the layer, if any.
     * @internal
     */
    override fun createTimeSeriesDataProvider(): TimeSeriesDataProvider<TileLayer>? {
        val provider = TiledTimeSeriesDataProvider(this)
        if (source is EncodedTileSource) {
            provider.maxIntervalsPerRequest = Math.min(
                MAX_REQUEST_INTERVALS.toInt(),
                floor(/*source.maxTextureSize*/ 2048.0 / source.tileSize.width).toInt()
            )
        }

        return provider
    }

    override var sourceEventHandlers: MutableList<MapLayer.SourceEventHandler> = mutableListOf()

    override fun getVisibleTileCoords(
        latLonBounds: LatLonBounds,
        tileBounds: TileBounds,
        zoom: Double,
        fromGetRenderables: Boolean,
    ): List<TileCoord> {
        // Must match [TileLayer] (unwrapped camera, world copies, download vs render paths). A simplified grid
        // here left GL mesh renderables / cache keys out of sync with Mapbox [CustomGeometrySource] tile fetches.
        return super.getVisibleTileCoords(latLonBounds, tileBounds, zoom, fromGetRenderables)
    }

    /**
     * Queries features for this layer within a given geometry.
     */
    override fun queryFeatures(
        zoomVar: Int,
        latTile: Int,
        lonTile: Int,
        latPix: Int,
        lonPix: Int,
        queryLon: Double?,
        queryLat: Double?,
    ): MutableList<String> {
        val returnString = mutableListOf("EMPTY STRING", "")
        return returnString
    }


    /**
     * Returns the features from this layer that intersect the current on‑screen viewport.
     */
    suspend fun getVisibleFeatures(): HashMap<String, FeatureQueryResult>? {
        val mc = mapController as? MapboxMapController ?: return null

        // For GL-only vector layers, Mapbox style layers are not present, so
        // `queryRenderedFeatures` would return nothing. Instead, derive legend features
        // from the already-decoded MVT cache (vectorTileCache).
        if (glRenderingActive()) {
            val vts = source as? VectorTileSource ?: return null
            return withContext(Dispatchers.Default) {
                val b = bounds ?: mc.getBounds()
                bounds = b

                val zoom = zoomForVisibleTiles()
                val tileBounds = getVisibleTileBounds(b, zoom)
                val coords = getVisibleTileCoords(b, tileBounds, zoom, fromGetRenderables = false)

                val coordTime = if (vts.id == GlStencilOsm.SOURCE_ID) {
                    ""
                } else {
                    formatDateArrayToString(listOf(vts.validTime))
                }

                val resultFeatures = mutableListOf<QueriedFeature>()

                val drawIntervalMs = if (vts.isTimeSeriesSource) {
                    timelinePhaseEpochMillis(Timeline.currentPhaseA)
                        ?: animator?.currentInterval?.interval?.takeIf { it > 0L }
                } else {
                    null
                }
                // Time-series data is stored under the snapped valid-time key, not the phase
                // epoch-ms, so exact lookup always returns null — use closest-interval fallback.
                val exactInterval = !Timeline.isGloballyPlaying && !vts.isTimeSeriesSource

                for (c in coords) {
                    if (!vts.isTimeSeriesSource) {
                        c.time = coordTime
                    }

                    val fetchCoord = if (vts.isTimeSeriesSource) vts.spatialTileCoord(c.x, c.y, c.z) else c
                    val tilePayload = vts.getTileData(fetchCoord)
                    val tileData = resolveVectorTileData(tilePayload, drawIntervalMs, exactInterval = exactInterval) ?: continue
                    // Rule: raw-vector-fast-path. VectorData.features is empty once a layer takes the
                    // raw JTS fast path (severe.alerts routinely does) — mirrors the same dual-dispatch
                    // already used by the render path and the data-inspector hit-test fallback.
                    val rawFeatures = tileData.rawFeatures
                    // Rule: legend-properties-only-conversion. This loop only reads properties/id/
                    // sourceLayer below, never geometry — MapboxVectorFeature.from's full coordinate
                    // conversion (the dominant per-refresh cost for polygon-dense datasets) would be
                    // pure waste here. Excludes tropical track-line layers: VectorFeatureDrawFilter.
                    // shouldDraw -> TropicalDrawFilter.passesTrackLine genuinely reads .geometry() to
                    // check for a LineString, so those still need the real conversion. See
                    // fromPropertiesOnly's KDoc.
                    val effectiveFeatures = if (rawFeatures != null) {
                        if (TropicalDrawFilter.isTropicalTrackLineLayer(id)) {
                            rawFeatures.map { MapboxVectorFeature.from(fetchCoord, it) }
                        } else {
                            rawFeatures.map { MapboxVectorFeature.fromPropertiesOnly(it) }
                        }
                    } else {
                        tileData.features
                    }
                    for (f in effectiveFeatures) {
                        if (!sourceLayer.isNullOrEmpty()) {
                            val tag = featureLayerTag(f)
                            if (tag != sourceLayer && tag != "${sourceLayer}::inverted") continue
                        }
                        if (!VectorFeatureDrawFilter.shouldDraw(f, filter, id)) continue

                        val advisory = f.getStringProperty("ADVISORY") ?: continue
                        val color = f.getStringProperty("COLOR") ?: continue

                        // Legend for alerts only needs `ADVISORY` + `COLOR`.
                        val props = mapOf(
                            "ADVISORY" to advisory,
                            "COLOR" to color,
                        )

                        resultFeatures.add(
                            QueriedFeature(
                                id = f.id(),
                                source = vts.id,
                                sourceLayer = featureLayerTag(f),
                                properties = props,
                                mapLayerId = null,
                            )
                        )
                    }
                }

                hashMapOf(
                    id to FeatureQueryResult(
                        layerId = id,
                        features = resultFeatures,
                    )
                )
            }
        }

        // Fallback: ask Mapbox for rendered features (works when a style layer exists).
        val topLeft = ScreenCoordinate(0.0, 0.0)
        val bottomRight = ScreenCoordinate(mc.mapView.width.toDouble(), mc.mapView.height.toDouble())
        return mc.queryFeaturesInBox(topLeft, bottomRight, listOf(this), onTouch = false)
    }

    override fun onAdd(context: Context, controller: MapController) {
        super.onAdd(context, controller)
        externalScope.launch {
            val vts = source as? VectorTileSource ?: return@launch
            runCatching { vts.fetchMetadata(null, null) }
            enableVectorTimeSeriesAnimatorIfNeeded()
            // For GL-rendered time-series layers, pre-warm tile data and triangulation so the layer
            // renders immediately when the user presses play for the first time. Without this, the
            // renderer stays blank until the tile round-trip completes after play is pressed.
            if (vts.isTimeSeriesSource && glRenderingActive()) {
                refreshVisibleTileCoordsForVectorGl()
                val coords = visibleTileCoordsForGlVectorPlayback()
                    .ifEmpty { visibleTileCoordsForMapboxVectorCache() }
                    .ifEmpty { viewportCenterTileCoordsForPrefetch() }
                prefetchVectorTilesForGlRendering(
                    bypassThrottle = true,
                    requestBudget = maxOf(coords.size, 1) + 8,
                )
                val mc = mapController as? MapboxMapController ?: return@launch
                timelinePhaseEpochMillis(Timeline.currentPhaseA)?.let { phase0Ms ->
                    if (coords.isNotEmpty()) {
                        val first = coords.first()
                        vts.requestTile(first.x, first.y, first.z, intervalTime = java.util.Date(phase0Ms))
                    }
                }
                mc.requestRepaintCoalesced()
            }
        }
    }

    private fun enableVectorTimeSeriesAnimatorIfNeeded() {
        val vts = source as? VectorTileSource ?: return
        if (!vts.isTimeSeriesSource) return
        syncAnimatorSeriesIntervalsFromSource(vts)
        timing.mode = TimeSeriesMode.INTERVAL
        val anim = animator ?: return
        anim.on(
            TimeSeriesEvent.ADVANCE,
            object : EventDispatcher.MyEventListener<Any> {
                override fun onEvent(v1: Any) {
                    if (Timeline.isGloballyPlaying) {
                        if (!glRenderingActive()) {
                            anim.loadDataIfNeeded(debounced = true)
                        }
                    } else {
                        setNeedsUpdate(true)
                    }
                }
                override val eventDispatcher: EventDispatcher
                    get() = anim
            },
            null,
            this,
        )
        anim.on(
            TimeSeriesEvent.INTERVAL_ADVANCE,
            object : EventDispatcher.MyEventListener<Any> {
                override fun onEvent(v1: Any) {
                    if (!anim.isActive) {
                        anim.loadDataIfNeeded()
                    }
                    if (!Timeline.isGloballyPlaying) {
                        setNeedsUpdate(true)
                    }
                }
                override val eventDispatcher: EventDispatcher
                    get() = anim
            },
            null,
            this,
        )
        if (glRenderingActive()) {
            anim.loadDataIfNeeded(useTimeRange = false)
        } else {
            anim.loadDataIfNeeded(useTimeRange = true)
        }
    }

    /**
     * Registers fetch intervals on the layer animator.
     *
     * Uses the global timeline's phase epoch-ms values (not the product's dense 3-minute valid
     * times) so the animator series matches exactly what [vectorFillDrawIntervalMs] returns and
     * the number of pre-fetch requests stays bounded. Falls back to the product's valid times
     * only when the global timeline hasn't been generated yet.
     */
    internal fun syncAnimatorSeriesIntervalsFromSource(vts: VectorTileSource) {
        val anim = animator ?: return
        @Suppress("UNCHECKED_CAST")
        val series = anim.series as? TimeSeries<com.xweather.mapsgl.tiles.TileData> ?: return
        val phaseDates = Timeline.timeDates.ifEmpty { null }
            ?: vts.vectorValidTimes.takeIf { it.isNotEmpty() }
            ?: return
        for (date in phaseDates) {
            series.setDataForInterval(date.time, null, createIfMissing = true)
        }
    }

    override fun onRemove() {}
}

