package com.xweather.mapsgl.layers.tile

import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.data.series.AnyTimeSeries
import com.xweather.mapsgl.data.series.MAX_REQUEST_INTERVALS
import com.xweather.mapsgl.data.series.TiledTimeSeriesDataProvider
import com.xweather.mapsgl.data.series.TimeSeriesDataProvider
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.map.mapbox.CameraSync
import com.xweather.mapsgl.renderers.EncodedDataRenderer
import com.xweather.mapsgl.renderers.LayerRenderContext
import com.xweather.mapsgl.renderers.LayerRenderer
import com.xweather.mapsgl.renderers.TileLayerRenderer
import com.xweather.mapsgl.sources.DataPool
import com.xweather.mapsgl.sources.EncodedGridVectorTileSource
import com.xweather.mapsgl.sources.EncodedTileSource
import com.xweather.mapsgl.sources.TileSource
import com.xweather.mapsgl.style.ContourLayerPaint
import com.xweather.mapsgl.style.GridLayerPaint
import com.xweather.mapsgl.style.LayerPaint
import com.xweather.mapsgl.style.ParticleLayerPaint
import com.xweather.mapsgl.style.SampleLayerPaint
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.types.DataQuality
import com.xweather.mapsgl.types.LayerType
import com.xweather.mapsgl.types.SampleExpression
import kotlinx.coroutines.CoroutineScope
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * EncodedTileLayer.kt
 *
 * Adapted from IOS version
 *
 * @author Jason Suto 4/8/24
 *
 */
internal class EncodedTileLayer(
    id: String,
    source: TileSource<TileData>,
    paint: LayerPaint,
    tileLayerRenderer: TileLayerRenderer<TileData, LayerRenderContext<Any>>,
    zoomOffset: Int,
    externalScope: CoroutineScope,
    quality: DataQuality = DataQuality.exact
) : TileLayer(
    id,
    source,
    paint,
    tileLayerRenderer,
    zoomOffset,
    externalScope, quality
) {
    init {
        this.paint = paint
    }

    val dataSize = DataPool.originalSize
    val paddingSize = DataPool.padding

    private val TAG = "EncodedTileLayer"

    override var type: LayerType
        get() = TODO("Not yet implemented")
        set(value) {}
    override lateinit var timing: LayerTiming

    override var timeSeries: AnyTimeSeries? = null

    override var invertMaskLayer: Boolean
        get() = TODO("Not yet implemented")
        set(value) {}
    override var renderer: LayerRenderer<Any>
        get() = TODO("Not yet implemented")
        set(value) {}

    private val localChannelCache: MutableMap<String, ByteArray> = mutableMapOf()

    //private var featureCache: HashMap<String, GriddedDataFeature> = hashMapOf()
    var hasLandMask: Boolean = false

    /** Returns the time series data provider to use for animating the layer, if any.
     * @internal
     */
    override fun createTimeSeriesDataProvider(): TimeSeriesDataProvider<TileLayer> {
        val provider = TiledTimeSeriesDataProvider(this)
        if (source is EncodedTileSource) {
            // Allow batching multiple time intervals per HTTP request (like vector tiles),
            // but keep the request size bounded by what the server/client can reasonably handle.
            provider.maxIntervalsPerRequest = Math.min(
                MAX_REQUEST_INTERVALS.toInt(),
                floor(2048.0 / source.tileSize.width).toInt()
            ).coerceAtLeast(1)
        }

        return provider
    }

    override var sourceEventHandlers: MutableList<MapLayer.SourceEventHandler> = mutableListOf()
    override var waitingOnDL: Boolean = false
    override var wasWaitingOnDL: Boolean = false


    override fun onRemove() {
        tileLayerRenderer.onRemove()
        if (tileLayerRenderer.renderpassInitialized && tileLayerRenderer.renderPass.meshes != null && tileLayerRenderer.renderPass.meshes!!.isNotEmpty()) {
            tileLayerRenderer.renderPass.meshes?.first()?.fbTex?.cleanup()
        }
        //Todo: remove this cast
        (source as EncodedTileSource).cleanup()
    }

    override fun queryFeatures(
        zoomVar: Int,
        latTile: Int,
        lonTile: Int,
        latPix: Int,
        lonPix: Int,
        queryLon: Double?,
        queryLat: Double?,
    ): Any? {

        val layerTimeline = Timeline.sourceTimeHash[source.id] ?: return null

        //val message: MutableList<String> = mutableListOf("", "")
        val channelInts: List<Int> = when (paint) {
            is SampleLayerPaint -> (paint as SampleLayerPaint).sample.channel.map { it.rawValue }
            is ParticleLayerPaint -> (paint as ParticleLayerPaint).sample.channel.map { it.rawValue }
            is ContourLayerPaint -> (paint as ContourLayerPaint).sample.channel.map { it.rawValue }
            is GridLayerPaint -> {
                val s = (paint as GridLayerPaint).sample ?: return null
                s.channel.map { it.rawValue }
            }

            else -> return null
        }

        val pixelValsAUByte: MutableList<UByte?> = mutableListOf(null, null, null)
        val pixelValsBUByte: MutableList<UByte?> = mutableListOf(null, null, null)
        val channelsToQuery = if (isRadar) listOf(3) else channelInts
        val aString =
            if (layerTimeline.phaseAString.length < 2) Timeline.timeStrings[Timeline.currentPhaseA] else layerTimeline.phaseAString
        val bString =
            if (layerTimeline.phaseBString.length < 2) Timeline.timeStrings[Timeline.currentPhaseB] else layerTimeline.phaseBString

        pixelValsAUByte.indices.forEach { i ->
            pixelValsAUByte[i] = getPixelValue(
                channelsToQuery.getOrNull(i),
                aString,
                zoomVar,
                latTile,
                lonTile,
                latPix,
                lonPix
            )

            pixelValsBUByte[i] = getPixelValue(
                channelsToQuery.getOrNull(i),
                bString,
                zoomVar,
                latTile,
                lonTile,
                latPix,
                lonPix
            )
        }

        val finalVals = pixelValsAUByte.zip(pixelValsBUByte, ::interpolate)
        if (finalVals[0] == null) {
            return null
        }
        val expression: SampleExpression = when (paint) {
            is SampleLayerPaint -> (paint as SampleLayerPaint).sample.expression
            is ParticleLayerPaint -> (paint as ParticleLayerPaint).sample.expression
            is ContourLayerPaint -> (paint as ContourLayerPaint).sample.expression
            is GridLayerPaint -> {
                val s = (paint as GridLayerPaint).sample ?: return null
                s.expression
            }

            else -> return null
        }

        val dataRangeStart = source.datasets[channelInts[0]].dataRange.start.toFloat()
        val dataRangeEnd = source.datasets[channelInts[0]].dataRange.endInclusive.toFloat()
        var finalVal: Any?
        val dx = (mapValues(finalVals[0]!!.toFloat(), dataRangeStart, dataRangeEnd))

        if (expression == SampleExpression.NUMBER) {
            if (finalVals[0] != null) {
                finalVal = mapOf("value" to dx)
                val enc = tileLayerRenderer as? EncodedDataRenderer<*, *>
                if (enc != null) {
                    val drawLow = enc.drawLow
                    val drawHigh = enc.drawHigh
                    if (finalVals[0]!! / 255f > drawHigh || finalVals[0]!! / 255f < drawLow) {
                        finalVal = null
                    }
                }
            } else {
                finalVal = null
            }
            if (isRadar && dx == 0f) {
                return null
            }
            if (suppressZeroPrecipInspector(id, dx)) {
                return null
            }

            if (finalVal == null) return null
            finalVal = mapOf("value" to dx)
        } else if (expression == SampleExpression.ANGLE) {
            val maritimeWaveDir = id.startsWith("maritime.") && id.endsWith("_dir.fill")
            val sidecarSample: Float? =
                if (maritimeWaveDir && queryLon != null && queryLat != null) {
                    val sidecar =
                        mapController?.getSource("${id}__encodedGridVectors_argb_v2") as? EncodedGridVectorTileSource
                    sidecar?.inspectorSampleMaritimeDirDeg(
                        queryLon,
                        queryLat,
                        CameraSync.zoomForCustomLayerInstancing(),
                    )
                } else {
                    null
                }
            if (sidecarSample != null) {
                finalVal = mapOf("value" to sidecarSample)
            } else {
                // Fallback: nearest tile pixel (can disagree with bilinear instanced grid + placement zoom).
                val rawA = pixelValsAUByte[0]?.toInt()?.toDouble()
                val rawB = pixelValsBUByte[0]?.toInt()?.toDouble()
                val dirA = rawA?.let { metDirDegFromAngleBlueByte(it) }
                val dirB = rawB?.let { metDirDegFromAngleBlueByte(it) }
                val fb =
                    when {
                        dirA != null && dirB != null ->
                            blendMetDirDegFromAngleUnitVectors(dirA, dirB, Timeline.dataMeld.toDouble())

                        dirA != null -> dirA
                        dirB != null -> dirB
                        else -> return null
                    }
                finalVal = mapOf("value" to fb.toFloat())
            }
        } else if (expression == SampleExpression.ENCODED_WIND_UV) {
            val gA = pixelValsAUByte[0]?.toDouble()
            val bA = pixelValsAUByte[1]?.toDouble()
            val gB = pixelValsBUByte[0]?.toDouble()
            val bB = pixelValsBUByte[1]?.toDouble()
            val rotDeg = when {
                gA != null && bA != null && gB != null && bB != null ->
                    griddedWindVertexRotDeg(gA, bA, gB, bB, Timeline.dataMeld.toDouble())

                gA != null && bA != null ->
                    griddedWindVertexRotDeg(gA, bA, null, null, 0.0)

                gB != null && bB != null ->
                    griddedWindVertexRotDeg(gB, bB, null, null, 0.0)

                else -> return null
            }
            finalVal = mapOf("value" to rotDeg)
        } else {
            if (finalVals[1] == null) {
                return null
            }
            val dataRangeStart2 = source.datasets[channelInts[1]].dataRange.start.toFloat()
            val dataRangeEnd2 = source.datasets[channelInts[1]].dataRange.endInclusive.toFloat()
            val dy = (mapValues(finalVals[1]!!.toFloat(), dataRangeStart2, dataRangeEnd2))
            when (expression) {
                SampleExpression.VECTOR -> {
                    val speed = sqrt((dx * dx + dy * dy).toDouble())
                    val angleDeg =
                        if (speed < 1e-9) {
                            0f
                        } else {
                            val radians = atan2(dx / speed, dy / speed)
                            ((radians * 180 / Math.PI + 360) % 360).toFloat()
                        }
                    finalVal = mapOf("value" to speed.toFloat(), "angle" to angleDeg)
                }

                SampleExpression.SUM -> {
                    finalVal = mapOf("value" to dx + dy)
                }

                SampleExpression.DIFFERENCE -> {
                    finalVal = mapOf("value" to dx - dy)
                }

                else -> {
                    finalVal = mapOf("value" to finalVals[0], "angle" to finalVals[1])
                }
            }
        }

        return finalVal
    }

    private fun Float.toTwoDecimalPlaceString(): String {
        return "%.2f".format(this)
    }

    private fun mapValues(input: Float, outputLow: Float, outputHigh: Float): Float {
        return outputLow + (outputHigh - outputLow) * ((input - 0f) / (255f))
    }

    /**
     * `conditions.precip.*` hourly rate: when decoded rate is zero, omit the inspector row (coordinates only),
     * matching radar no-echo behavior.
     */
    private fun suppressZeroPrecipInspector(layerId: String, decodedRate: Float): Boolean {
        if (decodedRate != 0f) return false
        return layerId.contains(".precip.") &&
            !layerId.contains("precip_rate") &&
            !layerId.contains("ptype")
    }

    /** [EncodedGridVectorTileSource.maritimeScalarDirDegFromBlueByte] / JS EXPRESSION_ANGLE. */
    private fun metDirDegFromAngleBlueByte(bRaw: Double): Double {
        val norm = bRaw / 255.0
        var deg = norm * 360.0 - 180.0
        if (deg < 0.0) deg += 360.0
        return deg
    }

    /**
     * Matches [WindArrowInstancedRenderer] maritime branch: unit vectors from met dir, mix with [t], normalize,
     * recover scalar met degrees for the data inspector (same as GPU).
     */
    private fun blendMetDirDegFromAngleUnitVectors(dirA: Double, dirB: Double, t: Double): Double {
        val tt = t.coerceIn(0.0, 1.0)
        val rA = Math.toRadians(dirA - 90.0)
        val rB = Math.toRadians(dirB - 90.0)
        var mx = (1.0 - tt) * cos(rA) + tt * cos(rB)
        var my = (1.0 - tt) * sin(rA) + tt * sin(rB)
        val len = hypot(mx, my)
        if (len < 1e-9) return dirA
        mx /= len
        my /= len
        return (Math.toDegrees(atan2(my, mx)) + 90.0 + 360.0) % 360.0
    }

    /**
     * Matches instanced wind/arrow vertex shaders ([com.xweather.mapsgl.renderers.WindArrowInstancedRenderer]):
     * per-phase G/B → met dir via atan2(u,-v), unit vectors (cos(dir−90°), sin(dir−90°)), mix with [t], normalize,
     * then rotDeg = atan2(mixed.y, mixed.x). This differs from interpolating G/B bytes then atan2 once.
     */
    private fun griddedWindVertexRotDeg(
        gA: Double,
        bA: Double,
        gB: Double?,
        bB: Double?,
        t: Double
    ): Float {
        fun metDirDegFromGb(g: Double, b: Double): Double {
            val u = (g / 255.0) * 107.28 - 53.64
            val v = (b / 255.0) * 107.28 - 53.64
            return Math.toDegrees(atan2(u, -v))
        }

        fun unitFromMetDir(dirDeg: Double): Pair<Double, Double> {
            val r = Math.toRadians(dirDeg - 90.0)
            return cos(r) to sin(r)
        }
        val (vax, vay) = unitFromMetDir(metDirDegFromGb(gA, bA))
        if (gB == null || bB == null) {
            return Math.toDegrees(atan2(vay, vax)).toFloat()
        }
        val (vbx, vby) = unitFromMetDir(metDirDegFromGb(gB, bB))
        val tt = t.coerceIn(0.0, 1.0)
        var mx = (1.0 - tt) * vax + tt * vbx
        var my = (1.0 - tt) * vay + tt * vby
        val len = hypot(mx, my)
        if (len < 1e-9) return Math.toDegrees(atan2(vay, vax)).toFloat()
        mx /= len
        my /= len
        return Math.toDegrees(atan2(my, mx)).toFloat()
    }

    /**
     * Interpolates between two nullable UByte values using the current timeline dataMeld.
     */
    private fun interpolate(valA: UByte?, valB: UByte?): Float? {
        val a = valA?.toFloat()
        val b = valB?.toFloat()

        return when {
            a != null && b != null -> a * (1f - Timeline.dataMeld) + b * Timeline.dataMeld
            a != null -> a
            b != null -> b
            else -> null
        }
    }

    private fun getPixelValue(
        channel: Int?,
        timeString: String,
        zoom: Int,
        latTile: Int,
        lonTile: Int,
        latPix: Int,
        lonPix: Int
    ): UByte? {
        if (channel == null) return null
        return getPixelValFromLocalCache(
            this,
            zoom,
            latTile,
            lonTile,
            latPix,
            lonPix,
            timeString,
            channel
        )
    }

    private fun getPixel(hash: String, x: Int, y: Int): Byte? {
        val pickedCache = localChannelCache[hash] ?: return null
        val pixelIndex = (y * dataSize) + x
        return pickedCache[pixelIndex]
    }


    private fun getPixelValFromLocalCache(
        layer: MapLayer<*, *>,
        zoom: Int,
        latTile: Int,
        lonTile: Int,
        latPix: Int,
        lonPix: Int,
        timeString: String,
        channel: Int
    ): UByte? {

        val layerTimeline = Timeline.sourceTimeHash[layer.source.id] ?: return null

        if (pr.ON) pr.p(TAG, pr.dIFix, "getPixelValFromLocalCache() timeString = $timeString")

        var pixelVal =
            getPixel(
                "${layer.source.id}0:$zoom/$lonTile/$latTile/${timeString}$channel",
                lonPix,
                latPix
            )

        if (pr.ON) pr.p(TAG, pr.dIFix, "getPixelValFromLocalCache() pixelVal = $pixelVal")

        if (pixelVal == null) {  // If not in local cache, get from native cache and store in local cache
            var byteArray: ByteArray?
            byteArray = getByteArrayFromNativeCache(layer, "0:$zoom/$lonTile/$latTile/${timeString}")
            if (byteArray == null /*  zoom > layer.source.maxZoom*/) {
                var finalLonPix = lonPix
                var finalLatPix = latPix
                var zoomCounter: Int = if (zoom > layer.source.maxZoom) {
                    layer.source.maxZoom.toInt()
                } else {
                    zoom - 1
                }
                while (byteArray == null && zoomCounter >= 0) {
                    val quint = getParentTileCoordinates(zoom, lonTile, latTile, zoomCounter, lonPix, latPix)
                    byteArray = getByteArrayFromNativeCache(
                        layer,
                        "0:${quint[0]}/${quint[1]}/${quint[2]}/${timeString}",
                    )
                    if (byteArray != null) {
                        finalLonPix = quint[3]
                        finalLatPix = quint[4]
                    }
                    zoomCounter--
                }
                if (byteArray == null) {
                    return null
                }
                val channelByteArray = nativeToLocalResized(byteArray, channel)
                val pixelIndex = (finalLatPix * dataSize) + finalLonPix
                pixelVal = channelByteArray[pixelIndex]
            } else {
                byteArray =
                    getByteArrayFromNativeCache(layer, "0:$zoom/$lonTile/$latTile/${timeString}")
                if (byteArray == null) {
                    return null
                }
                val channelByteArray = nativeToLocalResized(byteArray, channel)
                localChannelCache["${layer.source.id}0:$zoom/$lonTile/$latTile/${timeString}$channel"] =
                    channelByteArray
                pixelVal = getPixel(
                    "${layer.source.id}0:$zoom/$lonTile/$latTile/${timeString}$channel",
                    lonPix,
                    latPix
                )
            }
        }
        return pixelVal?.toUByte()
    }

    private fun getPixelValFromLocalCacheOld(
        layer: MapLayer<*, *>,
        zoom: Int,
        latTile: Int,
        lonTile: Int,
        latPix: Int,
        lonPix: Int,
        phase: Int,
        channel: Int
    ): UByte? {
        if (Timeline.timeStrings.size <= phase) return null

        if (pr.ON) pr.p(TAG, pr.dIFix, "getPixelValFromLocalCache() time used: ${Timeline.timeStrings[phase]}")

        var pixelVal =
            getPixel(
                "${layer.source.id}0:$zoom/$lonTile/$latTile/${Timeline.timeStrings[phase]}$channel",
                lonPix,
                latPix
            )

        if (pixelVal == null) {  // If not in local cache, get from native cache and store in local cache
            var byteArray: ByteArray?
            byteArray = getByteArrayFromNativeCache(layer, "0:$zoom/$lonTile/$latTile/${Timeline.timeStrings[phase]}")
            if (byteArray == null /*  zoom > layer.source.maxZoom*/) {
                var finalLonPix = lonPix
                var finalLatPix = latPix
                var zoomCounter: Int = if (zoom > layer.source.maxZoom) {
                    layer.source.maxZoom.toInt()
                } else {
                    zoom - 1
                }
                while (byteArray == null && zoomCounter >= 0) {
                    val quint = getParentTileCoordinates(zoom, lonTile, latTile, zoomCounter, lonPix, latPix)
                    byteArray = getByteArrayFromNativeCache(
                        layer,
                        "0:${quint[0]}/${quint[1]}/${quint[2]}/${Timeline.timeStrings[phase]}",
                    )
                    if (byteArray != null) {
                        finalLonPix = quint[3]
                        finalLatPix = quint[4]
                    }
                    zoomCounter--
                }
                if (byteArray == null) {
                    return null
                }
                val channelByteArray = nativeToLocalResized(byteArray, channel)
                val pixelIndex = (finalLatPix * dataSize) + finalLonPix
                pixelVal = channelByteArray[pixelIndex]
            } else {
                byteArray =
                    getByteArrayFromNativeCache(layer, "0:$zoom/$lonTile/$latTile/${Timeline.timeStrings[phase]}")
                if (byteArray == null) {
                    return null
                }
                val channelByteArray = nativeToLocalResized(byteArray, channel)
                localChannelCache["${layer.source.id}0:$zoom/$lonTile/$latTile/${Timeline.timeStrings[phase]}$channel"] =
                    channelByteArray
                pixelVal = getPixel(
                    "${layer.source.id}0:$zoom/$lonTile/$latTile/${Timeline.timeStrings[phase]}$channel",
                    lonPix,
                    latPix
                )
            }
        }
        return pixelVal?.toUByte()
    }

    private fun getParentTileCoordinates(
        currentZoom: Int,
        lonTile: Int,
        latTile: Int,
        targetZoom: Int,
        lonPix: Int,
        latPix: Int
    ): IntArray {
        val zoomDifference = currentZoom - targetZoom
        // Each level up divides the coordinates by 2. Going up N levels means dividing by 2^N.
        val divisor = 1 shl zoomDifference // Efficient way to calculate 2^zoomDifference

        // Find the parent tile coordinates
        val parentLonTile = lonTile / divisor
        val parentLatTile = latTile / divisor
        // Find the starting offset of the original tile within the parent's grid
        val lonOffsetInParent = lonTile % divisor
        val latOffsetInParent = latTile % divisor

        // Calculate the new pixel location within the parent tile
        // The original tile's pixels are scaled down and shifted by the offset
        val newLonPix = (lonPix / divisor) + (lonOffsetInParent * (dataSize / divisor))
        val newLatPix = (latPix / divisor) + (latOffsetInParent * (dataSize / divisor))

        return intArrayOf(targetZoom, parentLonTile, parentLatTile, newLonPix, newLatPix)
    }

    private fun getByteArrayFromNativeCache(layer: MapLayer<*, *>, hash: String): ByteArray? {
        if (layer is EncodedTileLayer) {
            if (layer.paint is SampleLayerPaint ||
                layer.paint is ParticleLayerPaint ||
                layer.paint is ContourLayerPaint ||
                layer.paint is GridLayerPaint
            ) {
                //val key = "0:1/1/0/[\"2025-09-17T13:00:00Z\"]"
                return (layer as TileLayer).source.tileCache.nativeCache.getData("${layer.source.id}${hash}")
            }
        }
        return null
    }

    private fun nativeToLocalResized(
        sourceRgbaArray: ByteArray,
        channel: Int
    ): ByteArray {

        val destinationArray = ByteArray(dataSize * dataSize)
        // Padded native buffers are (512+8+8)² RGBA; the 512×512 data block starts at (padding, padding),
        // same as [sample.frag.combined.glsl] / [PaddingManager] — not (2,2).
        val xPixelOffset = paddingSize
        val yPixelOffset = paddingSize

        for (destY in 0 until dataSize) {
            for (destX in 0 until dataSize) {
                // Calculate the corresponding pixel coordinates in the source image
                val sourcePixelX = destX + xPixelOffset
                val sourcePixelY = destY + yPixelOffset
                val sourcePixelStartIndex = (sourcePixelY * (dataSize + paddingSize + paddingSize) + sourcePixelX) * 4
                val greenByteIndexInSource = sourcePixelStartIndex + channel
                val destinationIndex = destY * dataSize + destX
                destinationArray[destinationIndex] = sourceRgbaArray[greenByteIndexInSource]
            }
        }
        return destinationArray
    }
}

