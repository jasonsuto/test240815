package com.xweather.mapsgl.layers.tile

import com.mapbox.geojson.Feature
import com.mapbox.geojson.FeatureCollection
import com.mapbox.geojson.Point
import com.xweather.mapsgl.anim.Timeline
import android.util.Log
import com.google.gson.JsonElement
import com.xweather.mapsgl.extensions.UnitLength
import com.xweather.mapsgl.extensions.UnitPressure
import com.xweather.mapsgl.extensions.UnitSpeed
import com.xweather.mapsgl.extensions.UnitTemperature
import com.xweather.mapsgl.layers.spec.DataQueryLayerDescriptor
import com.xweather.mapsgl.map.MapController
import com.xweather.mapsgl.map.MeasurementUnits
import com.xweather.mapsgl.map.mapbox.CameraSync
import com.xweather.mapsgl.renderers.VectorSymbolPlacementDefaults
import com.xweather.mapsgl.sources.GeoJSONSource
import com.xweather.mapsgl.sources.VectorData
import com.xweather.mapsgl.sources.VectorTileSource
import com.xweather.mapsgl.style.sampleMeldEnabled
import com.xweather.mapsgl.tiles.LatLonBounds
import com.xweather.mapsgl.tiles.Tile
import com.xweather.mapsgl.util.MapsGLDebug
import com.xweather.mapsgl.util.PlaceLabelText
import com.xweather.mapsgl.weather.LayerCode
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.roundToInt

/**
 * Owns the sampling loop and value cache for one data-query layer.
 *
 * Collects visible point geometry from a tiled vector source (via a private collector layer),
 * samples the configured weather layer at each point, formats values, and publishes features
 * into a private [GeoJSONSource] consumed by a stock symbol layer.
 */
class DataQueryCoordinator(
    private val controller: MapController,
    private val queryLayerId: String,
    private val descriptor: DataQueryLayerDescriptor,
    private val publishSource: GeoJSONSource,
    private val pointCollectorLayerId: String,
    private val sampledLayerIdProvider: () -> String?,
) {
    companion object {
        private const val TAG = "DataQueryCoordinator"
        private const val DEDUP_QUANTIZE = 100_000.0
        private const val IDENTITY_BUCKETS = 10_000.0
        private const val SUB_INTERVAL_BUCKETS = 20
        private const val MAX_HELD_MISSES = 12
        /** Coalesces per-frame timeline ticks; keep ≥ this gap between sample passes. */
        private const val REFRESH_DEBOUNCE_MS = 250L
        private const val RETRY_DELAY_MS = 250L
        private const val CONCURRENT_SAMPLES = 8
        /**
         * Cap published / sampled place points per viewport. Unbounded tile membership (no hard
         * bounds cull) can yield hundreds of city/town points; sampling + symbol collision then
         * stalls and leaves the map blank.
         */
        private const val MAX_LABEL_POINTS = 180
        /** Expand [getBounds] slightly so a lagging viewport does not drop all tile members. */
        private const val VIEWPORT_PAD_FRACTION = 0.2
    }

    private data class CollectedPoint(
        val lon: Double,
        val lat: Double,
        val name: String,
        val rankScore: Double,
        val dedupKey: String,
        val cacheKey: String,
    )

    private data class CacheEntry(
        var intervalIndex: Int,
        var progressBucket: Int,
        var zoom: Int,
        var value: Double?,
        var unit: UnitTemperature,
        var stale: Boolean,
        var dataRevision: Long,
        var missStreak: Int,
    ) {
        val isSettled: Boolean get() = value != null && !stale
        /**
         * True when we should stop retrying this point for the current playhead identity.
         * Confirmed live: points with no encoded sample (ocean / coverage holes) never get a
         * value, so [isSettled] stayed false forever and the playhead early-out never armed —
         * runPass spun every debounce tick at settled=377/777 with no further publish.
         */
        val isResolved: Boolean get() = isSettled || missStreak >= MAX_HELD_MISSES
    }

    private val valueCache = linkedMapOf<String, CacheEntry>()
    /** Last published display label per point (`null` = name-only). Gate GeoJSON writes on this. */
    private val publishedLabels = linkedMapOf<String, String?>()
    private var collectionCacheKey: String? = null
    private var collectionCache: List<CollectedPoint> = emptyList()
    private var collectionComplete = false

    @Volatile
    private var dataRevision: Long = 0L

    @Volatile
    private var generation: Long = 0L

    private var lastPassInterval: Int = Int.MIN_VALUE
    private var lastPassProgress: Int = Int.MIN_VALUE
    private var lastPassZoom: Int = Int.MIN_VALUE
    private var lastPassRevision: Long = -1L
    /** Quantized viewport — pan at fixed zoom/time must not hit the playhead early-out. */
    private var lastPassBoundsKey: String? = null

    private var refreshJob: Job? = null
    private var retryJob: Job? = null
    private var destroyed = false

    /** Set while a refresh is scheduled/running; further triggers coalesce instead of canceling. */
    @Volatile
    private var refreshPending = false

    /** When true, the next coalesced pass skips the debounce sleep (viewport / enable). */
    @Volatile
    private var refreshImmediate = false

    /**
     * Set when a pass collected zero visible points but we held the prior GeoJSON. Prevents the
     * playhead early-out from locking that hold forever without retrying collection.
     */
    @Volatile
    private var holdLabelsPendingRetry = false

    fun bumpDataRevision() {
        dataRevision++
        if (valueCache.values.any { !it.isResolved }) {
            scheduleRefresh(immediate = false)
        }
    }

    /**
     * Schedule a sample/publish pass.
     *
     * Must **await** an in-flight pass rather than cancel it: timeline playback calls this every
     * frame, and cancel-on-trigger leaves publish unreachable for the whole animation (iOS guide §7.5).
     * Extra triggers only set [refreshPending] so another pass runs after the current one finishes.
     */
    fun scheduleRefresh(immediate: Boolean = false, reformatOnly: Boolean = false) {
        if (destroyed) return
        if (reformatOnly) {
            controller.viewModelScope.launch {
                republishFromCache(reformatOnly = true)
            }
            return
        }
        refreshPending = true
        if (immediate) refreshImmediate = true
        if (refreshJob?.isActive == true) return
        refreshJob = controller.viewModelScope.launch {
            while (!destroyed && (refreshPending || refreshImmediate)) {
                val runNow = refreshImmediate
                refreshImmediate = false
                refreshPending = false
                if (!runNow) delay(REFRESH_DEBOUNCE_MS)
                if (destroyed) break
                // onMoveEnd may set refreshImmediate during the debounce sleep; absorb it so the
                // forced pan pass is not dropped when the loop already cleared refreshPending.
                val forced = runNow || refreshImmediate
                refreshImmediate = false
                refreshPending = false
                runPass(force = forced)
            }
            refreshJob = null
            // A trigger after the loop check but before job clear — rare; re-arm if needed.
            if (!destroyed && (refreshPending || refreshImmediate)) {
                scheduleRefresh(immediate = refreshImmediate)
            }
        }
    }

    fun destroy() {
        destroyed = true
        refreshJob?.cancel()
        retryJob?.cancel()
        valueCache.clear()
        publishedLabels.clear()
        collectionCache = emptyList()
    }

    private suspend fun runPass(force: Boolean) {
        if (destroyed) return
        val myGen = ++generation

        val bounds = try {
            controller.getBounds()
        } catch (_: Throwable) {
            scheduleRetry()
            return
        }
        if (!boundsAreUsable(bounds)) {
            scheduleRetry()
            return
        }

        val snapshotInterval = Timeline.currentPhaseA
        val sampledLayer = sampledLayerIdProvider()?.let { controller.getLayer(it) as? EncodedTileLayer }
        // JS EncodedTileLayer: `progress = sampleMeld() ? renderer.progress : 0`. When meld is off,
        // labels step with the interval only (no sub-interval re-sample / blend).
        val meldEnabled = sampledLayer?.paint?.sampleMeldEnabled() ?: true
        val snapshotProgress =
            if (meldEnabled) progressBucket(Timeline.dataMeld) else 0
        val dataZoom = sampledLayer?.let {
            floor(it.zoomForVisibleTilesPublic()).toInt().coerceAtLeast(0)
        } ?: controller.zoomInt
        val revisionAtStart = dataRevision
        val boundsKey = quantizedBoundsKey(bounds)

        // Per-frame playback notify is continuous; skip when playhead identity is unchanged.
        // Confirmed live: pan at fixed zoom with a settled valueCache hit this early-out and never
        // reached collectPoints — place tiles still prefetched, but GeoJSON labels stayed on the
        // old cities (new area blank). Viewport must be part of the identity.
        if (!force &&
            !holdLabelsPendingRetry &&
            snapshotInterval == lastPassInterval &&
            snapshotProgress == lastPassProgress &&
            dataZoom <= lastPassZoom &&
            revisionAtStart == lastPassRevision &&
            boundsKey == lastPassBoundsKey &&
            valueCache.values.none { !it.isResolved }
        ) {
            return
        }

        Log.i(
            TAG,
            "runPass force=$force boundsChanged=${boundsKey != lastPassBoundsKey} " +
                "holdRetry=$holdLabelsPendingRetry zoom=$dataZoom " +
                "resolved=${valueCache.values.count { it.isResolved }}/${valueCache.size}",
        )

        val points = collectPoints(bounds, myGen) ?: return
        if (myGen != generation) return

        val collectionIncomplete = !collectionComplete
        if (points.isEmpty() && (collectionIncomplete || coordsWereEmpty)) {
            Log.i(TAG, "pass waiting: coords/tiles incomplete for $queryLayerId")
            holdLabelsPendingRetry = publishedLabels.isNotEmpty()
            scheduleRetry()
            return
        }
        // Hold prior labels instead of wiping GeoJSON on a transient empty collect (confirmed live
        // after pan: publish 39 → publish 0 → skip forever with a blank map).
        if (points.isEmpty() && publishedLabels.isNotEmpty()) {
            Log.i(
                TAG,
                "hold prior labels (${publishedLabels.size}) — empty collect while complete " +
                    "for $queryLayerId; retrying",
            )
            holdLabelsPendingRetry = true
            scheduleRetry()
            return
        }
        holdLabelsPendingRetry = false

        val visibleKeys = HashSet<String>(points.size)
        val toSample = ArrayList<CollectedPoint>(points.size)
        for (point in points) {
            visibleKeys.add(point.cacheKey)
            val needs = needsQuery(
                point.cacheKey,
                snapshotInterval,
                snapshotProgress,
                dataZoom,
            )
            if (needs) toSample.add(point)
        }

        if (toSample.isNotEmpty()) {
            // Sample off the main thread (serial main-thread queries were ~15ms×N and stalled playback).
            val results = withContext(Dispatchers.Default) {
                val sampleSemaphore = Semaphore(CONCURRENT_SAMPLES)
                coroutineScope {
                    toSample.map { point ->
                        async {
                            sampleSemaphore.withPermit {
                                if (myGen != generation) return@withPermit null
                                point.cacheKey to sampleAt(point.lon, point.lat, sampledLayer)
                            }
                        }
                    }.awaitAll()
                }
            }
            if (myGen != generation) return
            for (pair in results) {
                val (key, sample) = pair ?: continue
                applySampleResult(
                    key = key,
                    sample = sample,
                    intervalIndex = snapshotInterval,
                    progressBucket = snapshotProgress,
                    dataZoom = dataZoom,
                    dataRevision = revisionAtStart,
                )
            }
        }

        // Evict off-viewport cache entries.
        val evict = valueCache.keys.filter { it !in visibleKeys }
        evict.forEach { valueCache.remove(it) }

        if (myGen != generation) return
        republishFromCache(reformatOnly = false, points = points)

        lastPassInterval = snapshotInterval
        lastPassProgress = snapshotProgress
        lastPassZoom = dataZoom
        lastPassRevision = revisionAtStart
        lastPassBoundsKey = boundsKey

        val unresolved = points.any { p ->
            val e = valueCache[p.cacheKey]
            e == null || !e.isResolved
        }
        if (unresolved || collectionIncomplete) {
            scheduleRetry()
        } else {
            retryJob?.cancel()
        }
    }

    /** Set by [collectPoints] when the collector had no viewport tile coords yet. */
    private var coordsWereEmpty = false

    private fun quantizedBoundsKey(bounds: LatLonBounds): String {
        fun q(v: Double) = (v * 200.0).roundToInt()
        return "${q(bounds.westExtent)},${q(bounds.southExtent)},${q(bounds.eastExtent)},${q(bounds.northExtent)}"
    }

    private fun scheduleRetry() {
        if (destroyed) return
        // Per-point [CacheEntry.isResolved] (value or missStreak) is the stop condition.
        // A global round cap left ~11 points forever unresolved after the successful ones
        // settled (confirmed live: resolved=84/95 then silence / no early-out arming).
        if (refreshJob?.isActive == true) {
            refreshPending = true
            return
        }
        if (retryJob?.isActive == true) return
        retryJob = controller.viewModelScope.launch {
            delay(RETRY_DELAY_MS)
            scheduleRefresh(immediate = true)
        }
    }

    private fun boundsAreUsable(bounds: LatLonBounds): Boolean {
        val w = bounds.westExtent
        val e = bounds.eastExtent
        val s = bounds.southExtent
        val n = bounds.northExtent
        if (!w.isFinite() || !e.isFinite() || !s.isFinite() || !n.isFinite()) return false
        if (abs(e - w) < 1e-9 || abs(n - s) < 1e-9) return false
        return true
    }

    private suspend fun collectPoints(bounds: LatLonBounds, myGen: Long): List<CollectedPoint>? {
        val collector = controller.getLayer(pointCollectorLayerId) as? VectorTileLayer
        val source = collector?.source as? VectorTileSource
        if (collector == null || source == null) {
            MapsGLDebug.trace("[$TAG] missing point collector for $queryLayerId")
            scheduleRetry()
            return null
        }

        collector.bounds = bounds
        val mapZoomNow = CameraSync.zoomForCustomLayerInstancing()
        val placeCap = VectorSymbolPlacementDefaults.placeLabelMaxDataZoom(collector.id)
        var coords =
            if (placeCap != null) {
                collector.visibleTileCoordsForMapboxVectorCacheAtDataZoom(
                    mapZoomNow.coerceAtMost(placeCap),
                )
            } else {
                collector.visibleTileCoordsForMapboxVectorCache()
            }
        if (coords.isEmpty()) {
            val zHint = floor(mapZoomNow).toInt().coerceAtLeast(0)
            coords = (zHint downTo (zHint - 2).coerceAtLeast(0)).flatMap { z ->
                source.cachedTileCoordsWithDataAtZ(z)
            }.distinctBy { "${it.z}/${it.x}/${it.y}" }
        }
        coordsWereEmpty = coords.isEmpty()
        val tileKey = coords.joinToString(",") { "${it.z}/${it.x}/${it.y}" }

        // Geometry is timeline-invariant — reuse during playback/scrub when the tile set matches.
        // Return the full cached set (do not re-cull with getBounds). Confirmed live: after a good
        // collect, the same tileKey + isPointVisible filter returned 0 points while complete=true,
        // which held forever and never refreshed labels for the settled viewport.
        if (collectionComplete && collectionCacheKey == tileKey && coords.isNotEmpty()) {
            return collectionCache
        }

        // Same tile zoom / prefetch path as VectorSymbolLayerRenderer — requestVisibleTiles uses
        // zoomOffset and misses the CustomGeometrySource cache (see TileLayer KDoc).
        try {
            collector.prefetchVectorTilesForGlRendering(bypassThrottle = true)
        } catch (t: Throwable) {
            MapsGLDebug.trace("[$TAG] point tile prefetch failed: ${t.message}")
        }
        if (myGen != generation) return null

        // Viewport may have shifted while prefetch ran; recompute coords once.
        coords =
            if (placeCap != null) {
                collector.visibleTileCoordsForMapboxVectorCacheAtDataZoom(
                    CameraSync.zoomForCustomLayerInstancing().coerceAtMost(placeCap),
                )
            } else {
                collector.visibleTileCoordsForMapboxVectorCache()
            }
        if (coords.isEmpty()) {
            val zHint = floor(CameraSync.zoomForCustomLayerInstancing()).toInt().coerceAtLeast(0)
            coords = (zHint downTo (zHint - 2).coerceAtLeast(0)).flatMap { z ->
                source.cachedTileCoordsWithDataAtZ(z)
            }.distinctBy { "${it.z}/${it.x}/${it.y}" }
        }
        coordsWereEmpty = coords.isEmpty()
        val tileKeyAfter = coords.joinToString(",") { "${it.z}/${it.x}/${it.y}" }
        if (collectionComplete && collectionCacheKey == tileKeyAfter && coords.isNotEmpty()) {
            return collectionCache
        }

        val byDedup = linkedMapOf<String, CollectedPoint>()
        var anyMissing = false
        var featureCount = 0
        var rejectFilter = 0
        var rejectGeom = 0
        var rejectName = 0
        for (coord in coords) {
            val tile = source.findCachedVectorTileForNominalZxy(coord.z, coord.x, coord.y)
            @Suppress("UNCHECKED_CAST")
            val vectorData = (tile as? Tile<*>)?.data as? VectorData
            if (vectorData == null) {
                anyMissing = true
                continue
            }
            for (feature in vectorData.features) {
                featureCount++
                if (!passesFilter(feature)) {
                    rejectFilter++
                    continue
                }
                val geometry = feature.geometry() as? Point
                if (geometry == null) {
                    rejectGeom++
                    continue
                }
                val lon = geometry.longitude()
                val lat = geometry.latitude()
                // Soft viewport cull with pad. Hard [isPointVisible] against getBounds() was
                // confirmed live to disagree with visible tile coords after pan (553 → kept=0).
                // Prefer a padded cull for density; if that empties a non-empty tile set, keep
                // tile members (Mapbox collision drops off-screen points).
                val name = resolveLabel(feature)
                if (name == null) {
                    rejectName++
                    continue
                }
                val rank = resolveRank(feature)
                val dedup = dedupKey(lon, lat)
                val cache = cacheKey(lon, lat, name)
                val existing = byDedup[dedup]
                if (existing == null || rank < existing.rankScore) {
                    byDedup[dedup] = CollectedPoint(lon, lat, name, rank, dedup, cache)
                }
            }
        }

        // Empty coords or missing tiles are incomplete — never treat as a settled empty ocean.
        // Confirmed live: a force pass mid-pan saw 5 tiles / 450 place features but kept=0
        // (bounds vs tile mismatch while the camera settled), marked complete, published an empty
        // FeatureCollection, and wiped the prior 39 labels — then the playhead early-out locked
        // that empty GeoJSON forever.
        val allPoints = byDedup.values.toList()
        val nearViewport = allPoints.filter { isPointNearViewport(it.lon, it.lat, bounds) }
        val scoped =
            if (nearViewport.isNotEmpty()) nearViewport
            else allPoints
        val capped =
            if (scoped.size <= MAX_LABEL_POINTS) scoped
            else scoped.sortedBy { it.rankScore }.take(MAX_LABEL_POINTS)
        val keptEmptyDespiteFeatures = capped.isEmpty() && featureCount > 0
        collectionComplete = coords.isNotEmpty() && !anyMissing && !keptEmptyDespiteFeatures
        if (collectionComplete) {
            collectionCacheKey = tileKeyAfter
            collectionCache = capped
        }
        Log.i(
            TAG,
            "collect coords=${coords.size} z=${coords.firstOrNull()?.z} features=$featureCount " +
                "kept=${capped.size} near=${nearViewport.size} all=${allPoints.size} " +
                "complete=$collectionComplete missing=$anyMissing " +
                "rej(filter=$rejectFilter geom=$rejectGeom name=$rejectName) " +
                "bounds=${"%.2f".format(bounds.westExtent)},${"%.2f".format(bounds.southExtent)}," +
                "${"%.2f".format(bounds.eastExtent)},${"%.2f".format(bounds.northExtent)}",
        )
        return capped
    }

    private fun passesFilter(feature: Feature): Boolean {
        val filter = descriptor.filter ?: return true
        val raw = filter.raw
        if (raw is List<*> && raw.isNotEmpty()) {
            val classVal =
                feature.getStringProperty("class")
                    ?: feature.properties()?.get("class")?.takeIf { it.isJsonPrimitive }?.asString
                    ?: return false
            return classVal == "city" || classVal == "town"
        }
        return true
    }

    private fun resolveLabel(feature: Feature): String? =
        PlaceLabelText.resolvePreferredName(feature, descriptor.labelKeyPath)

    private fun resolveRank(feature: Feature): Double {
        nestedProperty(feature, descriptor.rankKeyPath)?.let { v ->
            return (v as? Number)?.toDouble() ?: v.toString().toDoubleOrNull() ?: Double.MAX_VALUE
        }
        feature.getNumberProperty("rank")?.let { return it.toDouble() }
        return Double.MAX_VALUE
    }

    private fun nestedProperty(feature: Feature, keyPath: String): Any? {
        if (keyPath.isBlank()) return null
        val props = feature.properties() ?: return null
        // Flat key first (guide: try literal flat key of the same name).
        jsonValue(props.get(keyPath))?.let { return it }
        if (!keyPath.contains('.')) return null
        val leaf = keyPath.substringAfterLast('.')
        return jsonValue(props.get(leaf))
    }

    private fun jsonValue(el: JsonElement?): Any? {
        if (el == null || el.isJsonNull) return null
        if (!el.isJsonPrimitive) return null
        val p = el.asJsonPrimitive
        return when {
            p.isNumber -> p.asDouble
            p.isString -> p.asString
            p.isBoolean -> p.asBoolean
            else -> p.toString()
        }
    }

    private fun isPointVisible(lon: Double, lat: Double, bounds: LatLonBounds): Boolean {
        if (lat < bounds.southExtent || lat > bounds.northExtent) return false
        val west = bounds.westExtent
        val east = bounds.eastExtent
        // World-wrap: shift lon into [west, west+360…) span that may cross ±180.
        val shifted = lon + 360.0 * ceil((west - lon) / 360.0)
        return shifted <= east + 1e-9
    }

    /** Like [isPointVisible] but expands the viewport so lagging getBounds() still keep tile members. */
    private fun isPointNearViewport(lon: Double, lat: Double, bounds: LatLonBounds): Boolean {
        val lonSpan = abs(bounds.eastExtent - bounds.westExtent).coerceAtLeast(1e-6)
        val latSpan = abs(bounds.northExtent - bounds.southExtent).coerceAtLeast(1e-6)
        val padLon = lonSpan * VIEWPORT_PAD_FRACTION
        val padLat = latSpan * VIEWPORT_PAD_FRACTION
        val padded = LatLonBounds(
            westExtent = bounds.westExtent - padLon,
            southExtent = bounds.southExtent - padLat,
            eastExtent = bounds.eastExtent + padLon,
            northExtent = bounds.northExtent + padLat,
        )
        return isPointVisible(lon, lat, padded)
    }

    private fun dedupKey(lon: Double, lat: Double): String {
        val qLon = (lon * DEDUP_QUANTIZE).roundToInt()
        val qLat = (lat * DEDUP_QUANTIZE).roundToInt()
        return "$qLon,$qLat"
    }

    private fun cacheKey(lon: Double, lat: Double, name: String): String {
        // Mercator-ish normalized buckets (~4 km) + label — zoom-stable.
        val x = ((lon + 180.0) / 360.0).coerceIn(0.0, 1.0)
        val sinLat = kotlin.math.sin(Math.toRadians(lat)).coerceIn(-0.9999, 0.9999)
        val y = (0.5 - kotlin.math.ln((1 + sinLat) / (1 - sinLat)) / (4 * Math.PI)).coerceIn(0.0, 1.0)
        val bx = (x * IDENTITY_BUCKETS).roundToInt()
        val by = (y * IDENTITY_BUCKETS).roundToInt()
        return "$bx:$by:$name"
    }

    private fun progressBucket(meld: Float): Int =
        (meld.coerceIn(0f, 1f) * SUB_INTERVAL_BUCKETS).roundToInt().coerceIn(0, SUB_INTERVAL_BUCKETS)

    private fun needsQuery(
        key: String,
        intervalIndex: Int,
        progressBucket: Int,
        dataZoom: Int,
    ): Boolean {
        val entry = valueCache[key] ?: return true
        if (entry.intervalIndex != intervalIndex ||
            entry.progressBucket != progressBucket ||
            dataZoom > entry.zoom
        ) {
            return true
        }
        // Settled hit or terminal miss — stop.
        if (entry.isResolved) return false
        // Unresolved misses must keep sampling on every pass. Confirmed live: scheduleRetry
        // coalesces into an already-active refreshJob without bumping retryRounds, so
        // retryingUnresolved stayed false, missStreak stuck at 1, and runPass spun forever
        // at resolved=52/95 without ever arming the playhead early-out.
        return true
    }

    private fun sampleAt(lon: Double, lat: Double, layer: EncodedTileLayer?): Double? {
        if (layer == null) return null
        val zoomBase = CameraSync.customLayerRenderZoom ?: CameraSync.camera.zoom
        val zoomVar = floor(zoomBase + layer.zoomOffset).toInt().coerceAtLeast(0)
        val latTile = TileConversions.latToTile(lat, zoomVar)
        val lonTile = TileConversions.lonToTileNormalized(lon, zoomVar)
        val latPix = TileConversions.getLatPixelInTile(lat, zoomVar, 512).toInt()
        val lonPix = TileConversions.getLonPixelInTile(lon, zoomVar, 512).toInt()
        val raw = layer.queryFeatures(zoomVar, latTile, lonTile, latPix, lonPix, lon, lat) ?: return null
        @Suppress("UNCHECKED_CAST")
        val map = raw as? Map<*, *> ?: return null
        return (map["value"] as? Number)?.toDouble()
    }

    private fun applySampleResult(
        key: String,
        sample: Double?,
        intervalIndex: Int,
        progressBucket: Int,
        dataZoom: Int,
        dataRevision: Long,
    ) {
        val existing = valueCache[key]
        if (sample != null) {
            valueCache[key] = CacheEntry(
                intervalIndex = intervalIndex,
                progressBucket = progressBucket,
                zoom = dataZoom,
                value = sample,
                unit = UnitTemperature.celsius,
                stale = false,
                dataRevision = dataRevision,
                missStreak = 0,
            )
            return
        }
        if (existing?.value != null && existing.missStreak < MAX_HELD_MISSES) {
            existing.missStreak++
            existing.stale = true
            existing.dataRevision = dataRevision
            existing.intervalIndex = intervalIndex
            existing.progressBucket = progressBucket
            // Keep prior zoom / value (hold-over).
            return
        }
        valueCache[key] = CacheEntry(
            intervalIndex = intervalIndex,
            progressBucket = progressBucket,
            zoom = dataZoom,
            value = null,
            unit = UnitTemperature.celsius,
            stale = false,
            dataRevision = dataRevision,
            missStreak = (existing?.missStreak ?: 0) + 1,
        )
    }

    private fun republishFromCache(
        reformatOnly: Boolean,
        points: List<CollectedPoint>? = null,
    ) {
        val pts = points ?: collectionCache.filter {
            try {
                isPointNearViewport(it.lon, it.lat, controller.getBounds())
            } catch (_: Throwable) {
                true
            }
        }
        var changed = reformatOnly
        val nextPublished = linkedMapOf<String, String?>()
        val features = ArrayList<Feature>(pts.size)
        val units = controller.units

        for (point in pts) {
            val entry = valueCache[point.cacheKey]
            val numeric = entry?.value
            // Gate on the *displayed* label, not raw float — meld ticks often re-sample without
            // changing what the user sees, and GeoJSON writes rebuild symbols.
            val label = numeric?.let { formatValue(it, units) }
            nextPublished[point.cacheKey] = label

            if (!changed) {
                if (point.cacheKey !in publishedLabels || publishedLabels[point.cacheKey] != label) {
                    changed = true
                }
            }

            val props = HashMap<String, Any>(4)
            props["name"] = point.name
            props["rankScore"] = point.rankScore
            if (label != null) {
                props["value"] = label
            }
            val feature = Feature.fromGeometry(Point.fromLngLat(point.lon, point.lat), null, point.cacheKey)
            for ((k, v) in props) {
                when (v) {
                    is String -> feature.addStringProperty(k, v)
                    is Number -> feature.addNumberProperty(k, v)
                    else -> feature.addStringProperty(k, v.toString())
                }
            }
            features.add(feature)
        }

        if (!changed) {
            for (key in publishedLabels.keys) {
                if (key !in nextPublished) {
                    changed = true
                    break
                }
            }
        }

        if (!changed && !reformatOnly) return

        publishedLabels.clear()
        publishedLabels.putAll(nextPublished)
        publishSource.data = FeatureCollection.fromFeatures(features)
        Log.i(TAG, "publish features=${features.size} reformatOnly=$reformatOnly")
        (controller.getLayer(queryLayerId) as? TileLayer)?.setNeedsUpdate(force = true)
        controller.redraw()
    }

    /**
     * Format a raw encoded sample for display. Source units match [encodedQueryUnitForLayerId]
     * / inspector conventions (°C, %, m/s, mbar, m, mm/s). The early temperatures-text path
     * always treated samples as Celsius — that incorrectly °F-converted humidity and other
     * catalog products after the shared PlaceValueText expansion.
     */
    private fun formatValue(raw: Double, units: MeasurementUnits): String {
        return when (descriptor.sampledLayerCode) {
            LayerCode.TEMPERATURES,
            LayerCode.FEELS_LIKE,
            LayerCode.DEW_POINTS,
            LayerCode.WIND_CHILL,
            LayerCode.HEAT_INDEX,
            -> formatTemperature(raw, units.temperature)

            LayerCode.TEMPERATURES_24_HOUR_CHANGE,
            LayerCode.TEMPERATURES_1_HOUR_CHANGE,
            -> formatTemperatureDelta(raw, units.temperatureDelta)

            LayerCode.HUMIDITY,
            -> "${roundHalfUp(raw).toInt()}%"

            LayerCode.WIND_SPEEDS,
            LayerCode.WIND_GUSTS,
            -> formatSpeedMetersPerSecond(raw, units.speed)

            LayerCode.PRESSURE_MEAN_SEA_LEVEL,
            -> formatPressureMillibars(raw, units.pressure)

            LayerCode.VISIBILITY,
            -> formatDistanceMeters(raw, units.distance)

            LayerCode.PRECIPITATION,
            -> formatPrecipMmPerSec(raw, units.precipitationRate)

            LayerCode.SNOW,
            -> formatSnowMm(raw, units.snowfall)

            LayerCode.ULTRAVIOLET_INDEX,
            LayerCode.AIR_QUALITY_INDEX,
            LayerCode.AIR_QUALITY_INDEX_CAI_CATEGORIES,
            LayerCode.AIR_QUALITY_INDEX_CHINA_CATEGORIES,
            LayerCode.AIR_QUALITY_INDEX_EAQI_CATEGORIES,
            LayerCode.AIR_QUALITY_INDEX_INDIA_CATEGORIES,
            LayerCode.AIR_QUALITY_INDEX_UBA_DAQI_CATEGORIES,
            LayerCode.AIR_QUALITY_INDEX_UK_DAQI_CATEGORIES,
            -> "${roundHalfUp(raw).toInt()}"

            LayerCode.CARBON_MONOXIDE,
            LayerCode.NITRIC_OXIDE,
            LayerCode.NITROGEN_DIOXIDE,
            LayerCode.OZONE,
            LayerCode.PARTICULATE_MATTER_10_MICRON,
            LayerCode.PARTICULATE_MATTER_2P5_MICRON,
            LayerCode.SULFUR_DIOXIDE,
            -> {
                val rounded = roundHalfUp(raw * 10.0) / 10.0
                if (rounded == floor(rounded)) "${rounded.toInt()}" else rounded.toString()
            }

            else -> "${roundHalfUp(raw).toInt()}"
        }
    }

    private fun formatTemperature(celsius: Double, target: UnitTemperature): String {
        val display = when (target) {
            is UnitTemperature.Fahrenheit -> celsius * 9.0 / 5.0 + 32.0
            is UnitTemperature.Kelvin -> celsius + 273.15
            else -> celsius
        }
        return "${roundHalfUp(display).toInt()}${target.symbol}"
    }

    private fun formatTemperatureDelta(celsiusDelta: Double, target: UnitTemperature): String {
        val display = when (target) {
            is UnitTemperature.Fahrenheit -> celsiusDelta * 9.0 / 5.0
            else -> celsiusDelta
        }
        val rounded = roundHalfUp(display).toInt()
        val sign = if (rounded > 0) "+" else ""
        return "$sign$rounded${target.symbol}"
    }

    private fun formatSpeedMetersPerSecond(metersPerSecond: Double, target: UnitSpeed): String {
        val display = when (target) {
            is UnitSpeed.MilesPerHour -> metersPerSecond / 0.44704
            is UnitSpeed.KilometersPerHour -> metersPerSecond * 3.6
            is UnitSpeed.Knots -> metersPerSecond / 0.514444
            else -> metersPerSecond
        }
        return "${roundHalfUp(display).toInt()}${target.symbol.trim()}"
    }

    private fun formatPressureMillibars(mbar: Double, target: UnitPressure): String {
        return when (target) {
            is UnitPressure.InchesOfMercury -> {
                val inHg = mbar * 0.0295299830714
                String.format(java.util.Locale.US, "%.2f%s", inHg, target.symbol)
            }
            else -> "${roundHalfUp(mbar).toInt()}${target.symbol}"
        }
    }

    private fun formatDistanceMeters(meters: Double, target: UnitLength): String {
        val display = when (target) {
            is UnitLength.Miles -> meters / 1609.34
            is UnitLength.Kilometers -> meters / 1000.0
            is UnitLength.Feet -> meters / 0.3048
            else -> meters
        }
        return when (target) {
            is UnitLength.Miles, is UnitLength.Kilometers ->
                String.format(java.util.Locale.US, "%.1f%s", display, target.symbol)
            else -> "${roundHalfUp(display).toInt()}${target.symbol}"
        }
    }

    /** Encoded precip samples are mm/s; legends display as mm/h or in/h (×3600). */
    private fun formatPrecipMmPerSec(mmPerSec: Double, target: UnitLength): String {
        val perHour = mmPerSec * 3600.0
        val display = when (target) {
            is UnitLength.Inches -> perHour / 25.4
            else -> perHour
        }
        return String.format(java.util.Locale.US, "%.2f%s", display, target.symbol.trim())
    }

    /** Snow depth samples are mm liquid-equivalent depth in the encoded product. */
    private fun formatSnowMm(mm: Double, target: UnitLength): String {
        val display = when (target) {
            is UnitLength.Inches -> mm / 25.4
            is UnitLength.Centimeters -> mm / 10.0
            else -> mm
        }
        return String.format(java.util.Locale.US, "%.1f%s", display, target.symbol.trim())
    }

    private fun roundHalfUp(value: Double): Double = floor(value + 0.5)
}

/** Expose zoom helper used by the coordinator without widening TileLayer's public API further. */
internal fun EncodedTileLayer.zoomForVisibleTilesPublic(): Double = zoomForVisibleTiles()
