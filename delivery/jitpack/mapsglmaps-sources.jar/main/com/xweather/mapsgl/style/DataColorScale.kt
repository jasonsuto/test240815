package com.xweather.mapsgl.style

import com.xweather.mapsgl.data.DataRange
import com.xweather.mapsgl.types.math_type.ValueRange

fun getClosestInterval(value: Double, int: Double): Double {
    return if (value % int == 0.0) {
        value
    } else {
        Math.round((value + int / 2) / int) * int
    }
}

/**
 * [ColorScaleOptions.stops] is either a flat [List] of [ColorStop] (typical encoded layers) or,
 * for multiband radar, a list of per-band stop lists. CPU [ColorScale] and bar legends use the
 * first band (reflectivity / red), matching [TileLayerRenderer] multiband sampling.
 */
fun colorStopsFromOptionsStops(stops: List<Any>): List<ColorStop> {
    if (stops.isEmpty()) return emptyList()
    return when (val first = stops.first()) {
        is ColorStop -> stops.filterIsInstance<ColorStop>()
        is List<*> -> first.filterIsInstance<ColorStop>()
        else -> emptyList()
    }
}

/**
 * If [stops] is multiband (`listOf(band0, band1, …)` each band a list of [ColorStop]), returns those bands.
 * Otherwise null (flat single-band list).
 *
 * Used by [MapController.syncLegend] so each bar legend row keeps its own ramp when syncing from layer paint.
 */
fun colorStopBandsFromOptionsStops(stops: List<Any>): List<List<ColorStop>>? {
    if (stops.isEmpty()) return null
    return when (val first = stops.first()) {
        is ColorStop -> null
        is List<*> -> {
            val bands =
                stops.mapNotNull { entry ->
                    (entry as? List<*>)?.filterIsInstance<ColorStop>()?.takeIf { it.isNotEmpty() }
                }
            if (bands.size != stops.size) null else bands
        }
        else -> null
    }
}

/**
 * Color ramp for encoded/sample layers: [stops], optional [positions], data [range], and
 * interpolation flags. Nested [masks] select a scale from a discrete band (e.g. precip type).
 *
 * @property stops Color stops ([ColorStop] or value/color pairs).
 * @property positions Optional stop positions when not implied by [stops].
 * @property interval Quantize interval; `0` means none.
 * @property range Data domain mapped onto the ramp; inferred from [stops] when null.
 * @property normalized When true, samples are treated as 0–1.
 * @property interpolate When true, blend between stops; when false, step.
 * @property masks Optional per-code nested scales ([ColorMaskOptions]).
 * @property roundDown When true, sample values round toward the lower stop.
 */
data class ColorScaleOptions(
    var stops: List<Any> = emptyList(),
    var positions: List<Double>? = null,
    var interval: Double = 0.0,
    var range: ClosedRange<Double>? = null,
    var normalized: Boolean = false,
    var interpolate: Boolean = true,
    var masks: List<ColorMaskOptions>? = null,
    var roundDown: Boolean = false
) {

    //var unitText = "closed"

    init {
        if (range == null) {
            if (stops.isNotEmpty()) {
                val flatStops = colorStopsFromOptionsStops(stops)
                val firstValue = flatStops.firstOrNull()?.value ?: 0.0
                val lastValue = flatStops.lastOrNull()?.value ?: (firstValue + 1.0)
                range = firstValue..lastValue
            }
        }
    }

    companion object {
        /**
         * An alternate constructor that builds ColorScaleOptions from a typed List of ColorStop objects.
         * This is often cleaner and safer than using a List<Any>.
         */
        fun fromTypedRange(
            stops: List<Any> = emptyList(),
            positions: List<Double>? = null,
            interval: Double = 0.0,
            range: TypedRange<Double>? = null,
            normalized: Boolean = false,
            interpolate: Boolean = true,
            masks: List<ColorMaskOptions>? = null,
            roundDown: Boolean = false
        ): ColorScaleOptions {
            // The 'stops' list for DataColorScale expects a flattened list of [value, color, value, color...].
            // This constructor handles that conversion automatically.

            val returnOptions = ColorScaleOptions(
                stops,
                positions,
                interval,
                range,
                normalized,
                interpolate,
                masks,
                roundDown,
            )
            //returnOptions.unitText = range?.unitText ?: "closed"
            return returnOptions
        }
    }
}

class DataColorScale(config: Map<String, Any> = emptyMap()) {
    //private val options: Map<String, Any?>? = deepMerge(/*emptyMap(),*/ config)
    private var stops: List<Any> = config["stops"] as List<Any>? ?: emptyList()
    private val positions: List<Double> = config["positions"] as List<Double>? ?: emptyList()
    private var range: DataRange = DataRange(config["range"] as ValueRange)
    private var interval: Double = (config["interval"] as Double?) ?: 0.0
    private var normalized: Boolean = config["normalized"] as Boolean? ?: false
    private var interpolate: Boolean = (config["interpolate"] as Boolean?) ?: true
    private var ramp: ColorScale = ColorScale(/*emptyList()*/)
    //private val colors: List<RGB> = emptyList()

    val stopValues: List<Double>
        get() = stops.filterIndexed { index, _ -> index % 2 == 0 } as List<Double>
    val stopColors: List<String>
        get() = stops.filterIndexed { index, _ -> index % 2 != 0 } as List<String>
    val gradient: Boolean
        get() = interval == 0.0

    fun setColorStops(stops: List<Any>, normalized: Boolean = false) {
        this.stops = stops.toList()
        this.normalized = normalized
        generate(normalized)
    }

    fun setInterval(interval: Double) {
        this.interval = interval
        generate(normalized)
    }

    fun setValueRange(range: ValueRange) {
        this.range = DataRange(range)
        generate()
    }

    fun getColor(value: Double): Any {
        return ramp.getColor(value)
    }

    fun getColorNoRamp(value: Double): Any {
        return ramp.getColor(value)
    }

    fun getValue(color: Any, channel: Int = 0): Double {
        return 0.0
    }

    private fun generate(normalized: Boolean = this.normalized) { //DOES THIS EVER RUN????
        val min = range.min
        val max = range.max
        val scale = mapOf(
            "colors" to mutableListOf<String>(),
            "domain" to mutableListOf<Double>(),
            "positions" to mutableListOf<Double>()
        )

        var n = 0
        for (i in stops.indices step 2) {
            var value = stops[i] as Double
            var pos = (value - min) / (max - min)
            if (normalized) {
                pos = value
                value = min + value * Math.abs(max - min)
            } else if ((positions[n]) != null) {
                pos = positions[n]
            }
            val color = "${stops[i + 1]}"
            (scale["positions"] as MutableList<Double>).add(pos)
            (scale["colors"] as MutableList<String>).add(color.trim())
            (scale["domain"] as MutableList<Double>).add(value)
            n += 1
        }


        ramp = ColorScale(/*scale["colors"] as List<Int> ?: emptyList()*/)
        if (!interpolate) {
            ramp.breaks(scale["domain"] /*?: emptyList()*/)
            ramp.domain(mutableListOf(range.range.min, range.range.max))
        } else {
            ramp.domain((scale["domain"] as MutableList<Double>) ?: mutableListOf())
        }

        val colors = mutableListOf<Any>()
        val startVal = if (gradient) min else getClosestInterval(min, interval)
        var value = startVal
        var total = 0
        val colorValueInterval = if (gradient) (max - min) / 256 else interval
        var pos = 1

        while (value <= max) {
            var cinterval = colorValueInterval
            if (positions.isNotEmpty()) {
                val span = positions[pos] - positions[pos - 1]
                val rangeDelta =
                    ((scale["domain"]!![pos] as Double) - (scale["domain"]!![pos - 1] as Double)) / (max - min)
                cinterval *= (rangeDelta / span)
            }
            if (value > scale["domain"]!![pos] as Double) {
                pos += 1
            }
            val c = ramp.getColor(value)
            colors.add(c)
            value += cinterval
            total += 1
            if (value > max) {
                val last = ramp.getColor(max)
                colors.add(last)
                total += 1
            }
        }

        val colorBuffer = ByteArray(total * 4)
        for (i in colors.indices) {
            //val (r, g, b, a) = colors[i]
            val r = colors[0]
            val g = colors[1]
            val b = colors[2]
            val a = colors[3]

            colorBuffer[i * 4 + 0] = r as Byte
            colorBuffer[i * 4 + 1] = g as Byte
            colorBuffer[i * 4 + 2] = b as Byte
            colorBuffer[i * 4 + 3] = (a as Double * 255) as Byte
        }
    }


    private fun deepMerge(vararg objects: Any?): Map<String, Any?>? {
        if (objects.isEmpty()) return null
        if (objects.size == 1) return objects[0] as Map<String, Any>

        val result = mutableMapOf<String, Any?>()

        for (obj in objects) {
            if (obj is Map<*, *>) {
                for ((key, value) in obj) {
                    if (key is String) {
                        val existingValue = result[key]
                        result[key] = when {
                            existingValue is Map<*, *> && value is Map<*, *> -> deepMerge(existingValue, value)
                            else -> value
                        }
                    }
                }
            }
        }

        return result
    }

    class RGB(
        var red: Int,
        var green: Int,
        var blue: Int
    ) {
        init {
            require(red in 0..255) { "Red value must be between 0 and 255" }
            require(green in 0..255) { "Green value must be between 0 and 255" }
            require(blue in 0..255) { "Blue value must be between 0 and 255" }
        }

        fun toHex(): String {
            return "#%02X%02X%02X".format(red, green, blue)
        }

        fun brightness(): Double {
            return 0.2126 * red + 0.7152 * green + 0.0722 * blue
        }

        fun isDark(): Boolean {
            return brightness() < 128
        }

        fun isLight(): Boolean {
            return brightness() >= 128
        }
    }
}

open class TypedRange<T>(
    override val start: Double,
    override val endInclusive: Double
) : ClosedRange<Double> {
    open val unitText = "empty"

}

data class Celcius(
    override val start: Double,
    override val endInclusive: Double
) : TypedRange<Double>(start, endInclusive) {
    override val unitText = "C"
}

data class Fahrenheit(
    override val start: Double,
    override val endInclusive: Double
) : TypedRange<Double>(start, endInclusive) {
    override val unitText = "F"
}