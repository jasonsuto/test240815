package com.xweather.mapsgl.geojson

import com.mapbox.geojson.FeatureCollection
import com.xweather.mapsgl.sources.GeoJsonAssets

/**
 * Java-visible entry for patched [com.mapbox.geojson.FeatureCollection.fromJson] asset paths.
 */
object MapsGLGeoJsonBridge {
    @JvmStatic
    fun featureCollectionFromJson(jsonOrAssetPath: String): FeatureCollection =
        GeoJsonAssets.parse(jsonOrAssetPath)
}
