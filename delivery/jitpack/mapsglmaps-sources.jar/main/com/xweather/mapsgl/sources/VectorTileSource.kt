package com.xweather.mapsgl.sources

import VariableObserver
import android.os.SystemClock
import com.mapbox.geojson.Feature
import com.mapbox.geojson.MultiPoint
import com.mapbox.geojson.MultiPolygon
import com.mapbox.geojson.Point
import com.mapbox.geojson.Polygon
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.anim.TileRequestManager
import com.xweather.mapsgl.anim.TileRequestOptions
import com.xweather.mapsgl.NativeCacheBudget
import com.xweather.mapsgl.error.AuthenticationError
import com.xweather.mapsgl.events.DataSourceEvents
import com.xweather.mapsgl.events.trigger
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.map.mapbox.CameraSync
import com.xweather.mapsgl.map.mapbox.GlStencilOsm
import com.xweather.mapsgl.map.mapbox.MapboxVectorFeature
import com.xweather.mapsgl.map.mapbox.featureLayerTag
import com.xweather.mapsgl.network.Urls.Companion.mapsGLServer
import com.xweather.mapsgl.map.mapbox.hasWaterStencilMvtTagInFeatures
import com.xweather.mapsgl.sources.utils.FeatureCluster
import com.xweather.mapsgl.tiles.LatLonBounds
import com.xweather.mapsgl.tiles.Tile
import com.xweather.mapsgl.tiles.TileCache
import com.xweather.mapsgl.data.series.VectorTimeSeriesData
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.tiles.TileState
import com.xweather.mapsgl.types.DataSourceConsumer
import com.xweather.mapsgl.types.DataSourceKind
import com.xweather.mapsgl.types.Headers
import com.xweather.mapsgl.types.URLRequest
import com.xweather.mapsgl.util.MapsGLDebug
import com.xweather.mapsgl.utils.formatDateArrayToString
import com.xweather.mapsgl.utils.replaceVars
import com.xweather.mapsgl.weather.XweatherAuthenticator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import no.ecc.vectortile.PruningVectorTileDecoder
import no.ecc.vectortile.VectorTileDecoder
import org.json.JSONObject
import org.locationtech.jts.geom.Point as JtsPoint
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.zip.GZIPInputStream
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.logging.Logger
import kotlin.math.max
import kotlin.math.min


/** Demo/debug-only: fetch/parse pipeline stage for a tile, see [VectorTileSource.debugTileStage]. */
enum class DebugTileStage {
    NEEDED,
    DOWNLOADED_NOT_PROCESSED,
    PROCESSED,
}

/**
 * Pure decision function behind [VectorTileSource.restrictedPropertyKeysFor] (rule: pruning), split
 * out so it's testable without instantiating [VectorTileSource] (its `init` block requires Android
 * framework classes unavailable in plain JVM unit tests). A consumer with a `null` `sourceLayerId`
 * consumes whatever MVT layer this source decodes, so it matches every [tileLayerName].
 */
internal fun resolveRestrictedPropertyKeys(
    tileLayerName: String,
    consumers: List<DataSourceConsumer>,
    neededPropertyKeysByConsumerLayerId: Map<String, Set<String>>,
    alwaysNeededKeys: Set<String>,
): Set<String>? {
    val matching = consumers.filter { consumer ->
        val sid = consumer.sourceLayerId
        sid == null || sid.removeSuffix("::inverted") == tileLayerName
    }
    if (matching.isEmpty()) return null
    val perConsumer = matching.map { neededPropertyKeysByConsumerLayerId[it.layerId] }
    if (perConsumer.any { it == null }) return null
    return perConsumer.flatMap { it!! }.toSet() + alwaysNeededKeys
}

/**
 * [rawFeatures] non-null means this tile+interval was parsed in the raw fast path (rule:
 * raw-vector-fast-path — originally circle-only, generalized to Fill/Line/Circle via
 * [VectorTileSource.setRawPathEligible]) — it and [features] are never both populated. This is the
 * single flag every reader branches on; there is no separate map tracking "raw mode," which is what
 * caused prior gate-hold desync bugs.
 */
class VectorData(
    val validTime: Date,
    val features: MutableList<Feature>,
    val rawFeatures: List<VectorTileDecoder.Feature>? = null,
) : TileData {
    override fun init(byteArrayOf: ByteArray) {
        TODO("Not yet implemented")
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is VectorData) return false
        return this.hashCode() == other.hashCode()
    }

    override fun hashCode(): Int {
        // You can customize this to suit your hash requirements.
        // For now, just combine validTime and features size as an example:
        return 31 * (31 * validTime.hashCode() + features.hashCode()) + (rawFeatures?.size ?: 0)
    }
}

// TODO: move this into a source transformer
data class XweatherVectorLayerMetadata(
    var layers: List<Layer>,
    var validTimes: List<Date>
) {
    data class Layer(
        val name: String,
        val minZoom: Int,
        val maxZoom: Int,
        val fields: List<String>?
    )
}

/**
 * Runtime vector tile source created by [com.xweather.mapsgl.map.MapController.addSource] when using
 * [com.xweather.mapsgl.sources.source.spec.VectorSourceDescriptor]. Obtain via [com.xweather.mapsgl.map.MapController.getSource]
 * and cast to this type to change [TileSource.tileURL], [TileSource.minZoom] / [TileSource.maxZoom], or refresh tiles.
 */
open class VectorTileSource(override val id: String, open var authenticator: XweatherAuthenticator? = null) :
    TileSource<VectorData>() {
    companion object {
        // Comma-separated "z/x/y" tiles to trace stencil pipeline end-to-end.
        private const val MASK_DEBUG_TARGETS = "6/19/21,6/19/22,6/20/21,6/20/22,6/19/23,6/20/23"
        /** Demo/debug-only: total permits in [vectorParseSemaphore]. */
        // Was 4, set when parse (Gson reflection + per-feature JsonObject construction) was expensive
        // enough that higher concurrency risked exhausting heap under zoom-out prefetch. Direct
        // measurement (a per-request pipeline-stage timeline: REQ_START -> DL_SEM_ACQUIRED -> DL_DONE
        // -> PARSE_SEM_ACQUIRED -> PARSE_DONE) showed this permit count, not network or download
        // concurrency, was the actual pacing bottleneck for a full 25-interval lightning-strikes
        // timeline load: parse-permit queueing alone averaged 614ms/tile (p90 1744ms) even though the
        // per-tile parse work itself now only costs tens of ms post-optimization. Raised now that
        // parse is both fast and bounded (dense-tile point de-duplication caps per-tile point counts).
        const val DEBUG_PARSE_SEMAPHORE_CAPACITY = 12
        /** Limits concurrent MVT parse/Gson work so zoom-out prefetch cannot exhaust heap. */
        private val vectorParseSemaphore = Semaphore(DEBUG_PARSE_SEMAPHORE_CAPACITY)
        /** Caps concurrent time-series HTTP downloads across all vector sources. */
        private val timeSeriesDownloadSemaphore = Semaphore(20)
        const val TIME_SERIES_MAX_IN_FLIGHT_BEFORE_PREFETCH = 24
        /**
         * Always materialized regardless of a consumer's declared key restriction (rule: pruning).
         *
         * `timestamp`/`featureType` are here because
         * [com.xweather.mapsgl.map.mapbox.VectorLayerDrawFilterDefaults.effectiveFilter] injects a
         * `timestamp <= map-time` scrub into track-line/track-point layers at draw time — it is not
         * part of any layer's declared `filter`, so an [ExpressionReferencedKeys]-derived key set
         * built from `layer.filter` alone would prune the very attribute the scrub reads and the
         * features would silently all-show or all-vanish. Protecting the two keys here costs two
         * attributes per feature and closes the hole for every renderer at once, rather than
         * depending on each one remembering to add them.
         */
        private val ALWAYS_NEEDED_PROPERTY_KEYS = setOf("visible", "timestamp", "featureType")
        /** Sentinel key for [setRawPathEligible]/[rawPathEligibleForLayer] when a consumer has no `sourceLayer` restriction. */
        private const val RAW_PATH_WILDCARD_LAYER = "*"

        /**
         * Demo/debug-only: free MVT-decode slots (out of [DEBUG_PARSE_SEMAPHORE_CAPACITY]), shared
         * by every [VectorTileSource] instance. 0 means decode concurrency is currently the
         * bottleneck — tiles are downloaded but queued waiting for a free parse slot.
         */
        fun debugAvailableParseSlots(): Int = vectorParseSemaphore.availablePermits

        /**
         * Demo/debug-only: current bytes used / configured budget bytes for every native mesh/tile
         * cache namespace (`mvt`/`fillmesh`/`outlinemesh`/`circlemesh`), plus a `"total"` row summing
         * all four — see [com.xweather.mapsgl.NativeCacheBudget]. Bridged here (a public companion
         * function) because [com.xweather.mapsgl.NativeCacheBudget] itself is `internal` and not
         * reachable from a consuming app module. Returns an empty list before the first
         * [com.xweather.mapsgl.map.MapController] has configured the budget.
         */
        fun debugNativeCacheUsage(): List<Triple<String, Long, Long>> =
            com.xweather.mapsgl.NativeCacheBudget.debugUsageSnapshot()

        /**
         * Demo/debug-only: one completed [requestTile] call's timing. [networkMs] covers
         * acquiring [timeSeriesDownloadSemaphore] (if applicable) plus the HTTP fetch itself;
         * [parseMs] covers acquiring [vectorParseSemaphore] plus the actual MVT decode.
         */
        data class DebugRequestTiming(val networkMs: Long, val parseMs: Long)

        private const val DEBUG_RECENT_TIMINGS_MAX = 30
        private val debugTimingsLock = Any()
        private val debugRecentTimings = mutableListOf<DebugRequestTiming>()

        private fun recordDebugRequestTiming(networkMs: Long, parseMs: Long) {
            synchronized(debugTimingsLock) {
                debugRecentTimings.add(DebugRequestTiming(networkMs, parseMs))
                if (debugRecentTimings.size > DEBUG_RECENT_TIMINGS_MAX) debugRecentTimings.removeAt(0)
            }
        }

        /** Demo/debug-only: the most recent (up to [DEBUG_RECENT_TIMINGS_MAX]) request timings across all vector sources, oldest first. */
        fun debugRecentRequestTimings(): List<DebugRequestTiming> =
            synchronized(debugTimingsLock) { debugRecentTimings.toList() }

        /**
         * Demo/debug-only: breakdown of one [parseVectorTile] call. [decodeAllMs] is the initial
         * whole-tile [no.ecc.vectortile.VectorTileDecoder.decode] used only to discover layer names;
         * [convertMs] is the per-layer decode-plus-Feature-conversion loop (usually the expensive
         * part for point-heavy layers); [clusterMs] is only nonzero when point de-duplication
         * (>3000 point features) ran.
         */
        data class DebugParseBreakdown(
            val featureCount: Int,
            val clusteredFeatureCount: Int?,
            val decodeAllMs: Long,
            val convertMs: Long,
            val clusterMs: Long,
        )

        private val debugParseBreakdownsLock = Any()
        private val debugRecentParseBreakdowns = mutableListOf<DebugParseBreakdown>()

        private fun recordDebugParseBreakdown(breakdown: DebugParseBreakdown) {
            synchronized(debugParseBreakdownsLock) {
                debugRecentParseBreakdowns.add(breakdown)
                if (debugRecentParseBreakdowns.size > DEBUG_RECENT_TIMINGS_MAX) debugRecentParseBreakdowns.removeAt(0)
            }
        }

        /** Demo/debug-only: the most recent (up to [DEBUG_RECENT_TIMINGS_MAX]) parse breakdowns across all vector sources, oldest first. */
        fun debugRecentParseBreakdowns(): List<DebugParseBreakdown> =
            synchronized(debugParseBreakdownsLock) { debugRecentParseBreakdowns.toList() }
    }

    private val TAG = "VectorTileSource"
    private var lastSymbolMvtDebugLogMs = 0L

    //override var tileManager: /*TileRequestManager<VectorData> = TileRequestManager(this as TileSource<TileData>)
    override var timeRange: ClosedRange<Date>? = null
    var dlCount = 0
    var validTimes: List<Date>? = null
    /** Valid times from product metadata; drives interval time-series tile caching. */
    var vectorValidTimes: List<Date> = emptyList()
        private set
    /** True when metadata exposes valid times and tiles should cache multiple intervals per z/x/y.
     * Excludes [isAdminSource] — static OSM/basemap products (`open-street-map*`) reuse the same
     * `"layers"` + `"validTimes"` JSON shape as interval weather vectors (hail-threats, road-wx,
     * lightning-threat-zones) but are not per-interval-tiled. Treating those basemaps as
     * time-series pulls place labels / roads into the playback gate; their tiles are never cached
     * under a playback interval, so [resolveVectorTileData] fails forever and stalls every layer
     * via the shared readiness map. Weather products that share this metadata shape must remain
     * time-series so timeline play can swap `/vector/{code}/{time}/…` tiles. */
    val isTimeSeriesSource: Boolean
        get() = vectorValidTimes.isNotEmpty() && !useTimelessStencilMaskKeys && !isAdminSource
    var validTime: Date = Date()
    /** MVT layer `name` values from product metadata (e.g. `fires-obs` for fires observation points). */
    var parsedMetadataLayerNames: List<String> = emptyList()
        internal set
    val consumers: MutableList<DataSourceConsumer> = mutableListOf()
    private val consumedLayers: MutableMap<String, Int> = mutableMapOf()

    /**
     * Explicit opt-in per-consumer property allowlist (rule: pruning-to-referenced-keys). Absent
     * entry = "needs every attribute" (default, current behavior). Only renderers that can prove
     * they read a fixed, statically-known set of keys (e.g. [com.xweather.mapsgl.renderers.VectorCircleLayerRenderer]
     * from its filter + paint expressions) should call [declareNeededPropertyKeys]; every other
     * consumer is left unrestricted so this is purely additive and never removes data anyone needs.
     */
    private val neededPropertyKeysByConsumerLayerId: MutableMap<String, Set<String>> = ConcurrentHashMap()

    /** See [neededPropertyKeysByConsumerLayerId]. Pass `null` to clear a previously-declared restriction. */
    fun declareNeededPropertyKeys(consumerLayerId: String, keys: Set<String>?) {
        if (keys == null) {
            neededPropertyKeysByConsumerLayerId.remove(consumerLayerId)
        } else {
            neededPropertyKeysByConsumerLayerId[consumerLayerId] = keys
        }
    }

    /**
     * The attribute keys worth materializing for MVT layer [tileLayerName], or `null` if any
     * registered consumer of that layer hasn't declared a restriction (meaning: build everything,
     * exactly as before). Union across every matching consumer so a shared MVT layer with multiple
     * restricted consumers still gets the keys all of them need. A consumer with a `null`
     * [DataSourceConsumer.sourceLayerId] consumes whatever MVT layer this source decodes (the
     * common single-layer-per-source case), so it matches every [tileLayerName] rather than none.
     */
    private fun restrictedPropertyKeysFor(tileLayerName: String): Set<String>? =
        resolveRestrictedPropertyKeys(
            tileLayerName,
            consumers,
            neededPropertyKeysByConsumerLayerId,
            ALWAYS_NEEDED_PROPERTY_KEYS,
        )

    /**
     * [FeatureCluster.deduplicateClosePoints]'s counterpart for the raw circle fast path (rule:
     * raw-circle-fast-path) — same grid-based Euclidean lon/lat dedup, but keyed on raw
     * [VectorTileDecoder.Feature] point geometry (tile-local coordinates, converted via
     * [MapboxVectorFeature.tileLocalXYToLngLat]) instead of a [com.mapbox.geojson.Feature]'s already
     * lon/lat geometry, so raw mode never skips this de-dup and doesn't need to build Features first.
     */
    private fun deduplicateClosePointsRaw(
        rawFeatures: List<VectorTileDecoder.Feature>,
        coord: TileCoord,
        maxDistanceKilometers: Double,
    ): List<VectorTileDecoder.Feature> {
        if (rawFeatures.size < 2) return rawFeatures
        val retained = mutableListOf<VectorTileDecoder.Feature>()
        val grid = mutableMapOf<Pair<Int, Int>, MutableList<Pair<Double, Double>>>()
        val thresholdDegrees = (maxDistanceKilometers * 1000.0) / 111_000.0
        val cellSize = thresholdDegrees
        val thresholdSquared = cellSize * cellSize

        for (feature in rawFeatures) {
            val point = feature.geometry as? JtsPoint
            if (point == null) {
                // Non-point geometry (e.g. MultiPoint) isn't produced by this demo's point layers;
                // keep as-is rather than silently dropping it.
                retained.add(feature)
                continue
            }
            val (lon, lat) = MapboxVectorFeature.tileLocalXYToLngLat(point.x, point.y, coord)
            val col = (lon / cellSize).toInt()
            val row = (lat / cellSize).toInt()

            var isDuplicate = false
            outer@ for (dCol in -1..1) {
                for (dRow in -1..1) {
                    val neighborPoints = grid[(col + dCol) to (row + dRow)] ?: continue
                    for ((nLon, nLat) in neighborPoints) {
                        val dx = nLon - lon
                        val dy = nLat - lat
                        if (dx * dx + dy * dy < thresholdSquared) {
                            isDuplicate = true
                            break@outer
                        }
                    }
                }
            }
            if (!isDuplicate) {
                retained.add(feature)
                grid.getOrPut(col to row) { mutableListOf() }.add(lon to lat)
            }
        }
        return retained
    }

    override var tileCache: TileCache<DataType> = TileCache()

    // TODO("Temporary vectorTileCache until base TileSource can be cleaned up")
    protected val vectorTileCache: TileCache<VectorData> = TileCache()
    private val dateFormatter: SimpleDateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.getDefault())
    val metadataObserver = VariableObserver()
    private var hadLoadedMetadata = false
    private var metadataLoadingTask: Deferred<Any>? = null

    private var invalidateFunction: ((Int, Int, Int) -> Unit)? = null

    /** Keys reserved while a time-series download is queued or active: "${cacheCoord.hash()}/${snappedMs}". */
    private val inFlightTileKeys = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
    private val cancelledInFlightKeys = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
    /** Active HTTP downloads only (excludes coroutines waiting on [timeSeriesDownloadSemaphore]). */
    private val activeTimeSeriesDownloads = java.util.concurrent.atomic.AtomicInteger(0)
    private var batchInvalidateFunction: ((List<Triple<Int, Int, Int>>) -> Unit)? = null
    private var decoder: VectorTileDecoder = VectorTileDecoder()

    /**
     * When set (GL stencil mask mode), invoked on the tile decode thread after each successful MVT parse
     * with the same [TileCoord] / coord-hash key used by encoded raster meshes.
     */
    var glStencilMaskTileListener: ((coord: TileCoord, coordHash: String, features: List<Feature>) -> Unit)? = null

    /**
     * Per-consumer raw-path eligibility declarations (rule: raw-vector-fast-path — originally
     * circle-only single-consumer-only design, generalized so a shared source with multiple
     * consumers, e.g. alerts fill+outline, can still use the fast path). Each of
     * [com.xweather.mapsgl.renderers.VectorFillLayerRenderer] /
     * [com.xweather.mapsgl.renderers.VectorLineLayerRenderer] /
     * [com.xweather.mapsgl.renderers.VectorCircleLayerRenderer] calls [setRawPathEligible] every draw
     * (cheap — no per-feature cost) once its current paint is provably safe to evaluate off raw MVT
     * attributes (see [com.xweather.mapsgl.map.mapbox.VectorCircleRawStyleEval]). [parseVectorTile]
     * takes the raw path for a tile-layer only when *every* consumer currently attached to it (via
     * [consumers]) has declared itself eligible — missing or `false` for any one of them means: build
     * [Feature]s exactly as before. This is a fail-closed, purely additive fast path with no separate
     * readiness bookkeeping — [VectorData.rawFeatures] itself records which mode a given parse
     * actually used, so there is nothing that can desync.
     */
    private val rawPathEligibleByConsumer = java.util.concurrent.ConcurrentHashMap<String, Boolean>()

    /**
     * Declares whether [consumerLayerId] currently allows the raw fast path for [tileLayerName].
     * `null` means the consumer has no `sourceLayer` restriction (matches whichever tile-layer it
     * ends up needing) — stored under a wildcard key so [rawPathEligibleForLayer] can still resolve
     * it against any concrete tile-layer name.
     */
    fun setRawPathEligible(consumerLayerId: String, tileLayerName: String?, eligible: Boolean) {
        rawPathEligibleByConsumer["$consumerLayerId|${tileLayerName ?: RAW_PATH_WILDCARD_LAYER}"] = eligible
    }

    /** Clears every raw-path declaration for [consumerLayerId] (e.g. on layer removal). */
    fun clearRawPathEligibility(consumerLayerId: String) {
        rawPathEligibleByConsumer.keys.removeAll { it.startsWith("$consumerLayerId|") }
    }

    /** True only when every consumer attached to [tileLayerName] has declared itself eligible. */
    private fun rawPathEligibleForLayer(tileLayerName: String): Boolean {
        val relevantConsumerIds = consumers
            .filter { c -> val sl = c.sourceLayerId; sl == null || sl.removeSuffix("::inverted") == tileLayerName }
            .map { it.layerId }
        if (relevantConsumerIds.isEmpty()) return false
        return relevantConsumerIds.all { id ->
            rawPathEligibleByConsumer["$id|$tileLayerName"] == true ||
                rawPathEligibleByConsumer["$id|$RAW_PATH_WILDCARD_LAYER"] == true
        }
    }

    /**
     * Ensures [parseVectorTile] includes [sourceLayerTag] in decoded MVT layers (refcounted).
     * @return Undo closure; call when the dependency is removed.
     */
    fun addStencilParseLayerDependency(sourceLayerTag: String): () -> Unit {
        stencilParseExtraLayers.merge(sourceLayerTag, 1, Int::plus)
        invalidate()
        return {
            stencilParseExtraLayers.computeIfPresent(sourceLayerTag) { _, c ->
                (c - 1).takeIf { it > 0 }
            }
            invalidate()
        }
    }

    /**
     * Invoked on the tile decode thread after each successful parse, after [glStencilMaskTileListener].
     */
    fun addCustomStencilTileListener(
        listenerId: String,
        listener: (coord: TileCoord, coordHash: String, features: List<Feature>) -> Unit,
    ): () -> Unit {
        customStencilTileListeners[listenerId] = listener
        invalidate()
        return {
            customStencilTileListeners.remove(listenerId)
            invalidate()
        }
    }

    /**
     * Swap the current listener for [listenerId] without calling [invalidate]. Use when the spec a
     * weather layer cares about is unchanged but a captured value inside the listener (e.g. a line
     * mask's `lineHalfWidth` / `lineStyle`) has been updated — we want the next replay through the
     * listener to pick up the new closure without forcing Mapbox to re-fetch and re-decode every
     * cached MVT tile, which is the expensive path that [invalidate] triggers.
     *
     * The caller is responsible for replaying cached features (see
     * [replayCustomStencilFeedsFromCachedVectorTiles]) so existing cache entries get rebuilt.
     */
    internal fun replaceCustomStencilTileListenerWithoutInvalidate(
        listenerId: String,
        listener: (coord: TileCoord, coordHash: String, features: List<Feature>) -> Unit,
    ) {
        customStencilTileListeners[listenerId] = listener
    }

    /**
     * Number of vector tiles currently held in [vectorTileCache]; debug-only.
     *
     * Reads `LRUCache.size` directly (a `HashMap.size` field read, O(1)) instead of
     * `.entries().count()`. The latter walks the LRU's internal doubly-linked list lazily, which
     * deadlocks indefinitely if any other thread does a [LRUCache.get] mid-iteration: that `get`
     * calls `_bumpAge` → `_list.unshiftNode`, which moves the just-visited node to the head, so
     * the iterator's `current.next` points back into already-visited territory and the loop never
     * terminates. We saw this hang inside [GlStencilCustomMaskCoordinator.refreshPaint] between
     * its `listeners swapped` and `replay source=` log lines — the count call was wedged while
     * cached tile feeds bumped LRU nodes from the listener side. The same class of bug was
     * already patched in [replayCustomStencilFeedsFromCachedVectorTiles] /
     * [replayGlStencilFeedsFromCachedVectorTiles] by snapshotting, but the count call here was
     * missed because `.count()` on a Sequence looks like a one-shot value, not an iteration.
     */
    internal fun cachedVectorTileCount(): Int = vectorTileCache.tiles.size
    /**
     * Reparse attempts for cached tiles that still lack `water` features while stencil masking is active.
     * A single attempt is not always enough when a stale/corrupt response was cached.
     */
    private val stencilInclusionReparseAttempts = ConcurrentHashMap<String, Int>()
    private val maxStencilInclusionReparseAttempts = 3

    /**
     * Extra MVT source-layer names to parse so GLES custom stencil masks receive features even when no
     * style consumer references that layer.
     */
    private val stencilParseExtraLayers = ConcurrentHashMap<String, Int>()
    private val customStencilTileListeners =
        ConcurrentHashMap<String, (TileCoord, String, List<Feature>) -> Unit>()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var isAdminSource = false
    private val useTimelessStencilMaskKeys: Boolean
        get() = id == GlStencilOsm.SOURCE_ID

    /**
     * Only static OSM/basemap products should opt out of interval time-series. Other MapsGL
     * products (`hail-threats-nowcast`, `lightning-threat-zones`, `road-wx-*`, …) use the same
     * metadata object shape but must animate via per-interval tile URLs.
     */
    private fun isStaticBasemapProduct(productKey: String): Boolean =
        productKey == "open-street-map" || productKey.startsWith("open-street-map")

    private fun isStaticBasemapSourceId(sourceId: String): Boolean =
        sourceId == GlStencilOsm.SOURCE_ID ||
            sourceId == "base.osm" ||
            sourceId == "base_osm"

    private fun maskDebugMatches(z: Int, x: Int, y: Int): Boolean {
        if (MASK_DEBUG_TARGETS.isEmpty()) return false
        val key = "$z/$x/$y"
        return MASK_DEBUG_TARGETS.split(',').any { it.trim() == key }
    }

    private fun shouldLogSymbolMvtDebug(): Boolean =
        MapsGLDebug.enabled && consumers.any { c ->
            val lid = c.layerId
            lid.contains("fire", ignoreCase = true) ||
                lid.contains("icons", ignoreCase = true) ||
                lid.contains("symbol", ignoreCase = true)
        }

    /** Circle fire-obs styling needs `report.startTimestampMillis`; icon/name layers do not. */
    private fun consumersNeedFireStartTimestamp(): Boolean =
        consumers.any { it.layerId.contains("fire_obs.point", ignoreCase = true) }

    init {
        metadata = SourceMetadata(
            ImageTileSource.MetadataSchema(), URL(
                mapsGLServer
            )
        )

        tileManager = TileRequestManager(this as TileSource<TileData>)
    }

    override fun getMetadataURL(): URL? {
        val url = metadataURL ?: return null
        val variables = emptyMap<String, Any>().toMutableMap()
        timeRange?.let {
            variables.set("startDate", it.start)
            variables.set("endDate", it.endInclusive)
        }
        authenticator?.appendTileCredentialVariables(variables)
        val urlString = url.replaceVars(variables, true)

        return URL(urlString)
    }

    override fun appendTileUrlVariables(coord: TileCoord, vars: MutableMap<String, Any>) {
        authenticator?.appendTileCredentialVariables(vars)
    }

    override suspend fun fetchMetadata(startDate: Date?, endDate: Date?): Result<Unit> {
        val reload = false
        if (hadLoadedMetadata && !reload) return Result.success(Unit)

        authenticator?.authenticate()

        val url =
            getMetadataURL() ?: return Result.failure(IllegalStateException("Metadata URL could not be generated."))

        if (metadataLoadingTask != null) {
            try {
                metadataLoadingTask!!.join()
            } catch (e: Exception) {
                MapsGLDebug.trace("Metadata loading task failed: ${e.localizedMessage}")
                return Result.failure(IllegalStateException(e.localizedMessage))
            }
            // return
        }

        metadataLoadingTask = CoroutineScope(Dispatchers.IO).async {
            val request = URLRequest(url.toString())
            android.util.Log.d(TAG, "[$id] fetchMetadata url=$url")

            authenticator?.credentials?.let { credentials ->
                request.setAuthorization("Bearer ${credentials.accessToken}")
            }

            try {
                val response = request.execute()
                android.util.Log.d(TAG, "[$id] metadata response type=${response.data?.javaClass?.simpleName}")
                when (response.data) {
                    is JSONObject -> {
                        val json = response.data
                        if (json.keys().hasNext()) {
                            val dataKey = json.keys().next()
                            android.util.Log.d(TAG, "[$id] metadata dataKey=$dataKey hasInner=${json.optJSONObject(dataKey) != null} raw=${json.opt(dataKey)?.javaClass?.simpleName}: ${json.opt(dataKey).toString().take(300)}")
                            // Alerts-style metadata: top-level key maps to a JSONArray of file
                            // entries each with a "timestamp" (epoch seconds) field.
                            json.optJSONArray(dataKey)?.let { filesArray ->
                                val validTimes = mutableListOf<Date>()
                                for (i in 0 until filesArray.length()) {
                                    val entry = filesArray.optJSONObject(i) ?: continue
                                    val epochSec = entry.optLong("timestamp", -1L)
                                    if (epochSec > 0) validTimes.add(Date(epochSec * 1000L))
                                }
                                if (validTimes.isNotEmpty()) {
                                    vectorValidTimes = validTimes.sortedBy { it.time }
                                    val intervalMs = if (vectorValidTimes.size >= 2)
                                        vectorValidTimes[1].time - vectorValidTimes[0].time else 0L
                                    val perHour = if (intervalMs > 0) 3_600_000L / intervalMs else 0L
                                    android.util.Log.d(TAG, "[$id] files[] vectorValidTimes(${vectorValidTimes.size}) intervalMin=${intervalMs/60_000}min perHour=$perHour: ${vectorValidTimes.take(3).joinToString { it.toInstant().toString() }}${if (vectorValidTimes.size > 3) " … ${vectorValidTimes.last().toInstant()}" else ""}")
                                    hadLoadedMetadata = true
                                }
                            }
                            json.optJSONObject(dataKey)?.let {
                                val layers = emptyList<XweatherVectorLayerMetadata.Layer>().toMutableList()
                                val validTimes = emptyList<Date>().toMutableList()

                                it.optJSONArray("layers")?.let {
                                    for (i in 0 until it.length()) {
                                        val item = it.getJSONObject(i)
                                        val name = item.getString("name")

                                        val minZoom = if (item.has("minZoom")) {
                                            item.getInt("minZoom")
                                        } else {
                                            0
                                        }

                                        val maxZoom = if (item.has("maxZoom")) {
                                            item.getInt("maxZoom")
                                        } else {
                                            21
                                        }

                                        val fields = if (item.has("fields")) {
                                            val fieldsList = mutableListOf<String>()
                                            val fieldsArray = item.optJSONArray("fields")
                                            if (fieldsArray != null) {
                                                for (j in 0 until fieldsArray.length()) {
                                                    fieldsList.add(fieldsArray.optString(j))
                                                }
                                            }
                                            fieldsList
                                        } else {
                                            emptyList()
                                        }

                                        val layer = XweatherVectorLayerMetadata.Layer(
                                            name,
                                            minZoom,
                                            maxZoom,
                                            fields
                                        )
                                        layers.add(layer)
                                    }
                                }
                                // Parse validTimes array into List<Date>
                                it.optJSONArray("validTimes")?.let { validTimesArray ->
                                    val dateFormat =
                                        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US)
                                    for (i in 0 until validTimesArray.length()) {
                                        val dateStr = validTimesArray.optString(i)
                                        try {
                                            val date = dateFormat.parse(dateStr)
                                            if (date != null) validTimes.add(date)
                                        } catch (e: Exception) {
                                            // Optionally log or handle parse error
                                        }
                                    }
                                }
                                // Do NOT mark every layers+validTimes product as admin — that shape is
                                // shared by interval weather vectors. Only OSM/basemap products skip
                                // time-series (see isTimeSeriesSource).
                                isAdminSource =
                                    isStaticBasemapProduct(dataKey) || isStaticBasemapSourceId(id)
                                val metadata = XweatherVectorLayerMetadata(layers, validTimes)
                                // Rule: valid-times-sorted-invariant. Must be ascending — snapFetchTime's
                                // nearest-neighbor lookup binary-searches this list and is only correct
                                // if it's sorted (the other assignment site already sorts explicitly).
                                vectorValidTimes = validTimes.sortedBy { it.time }
                                val intervalMs2 = if (vectorValidTimes.size >= 2)
                                    vectorValidTimes[1].time - vectorValidTimes[0].time else 0L
                                val perHour2 = if (intervalMs2 > 0) 3_600_000L / intervalMs2 else 0L
                                android.util.Log.d(
                                    TAG,
                                    "[$id] vectorValidTimes(${vectorValidTimes.size}) " +
                                        "isAdminSource=$isAdminSource isTimeSeriesSource=$isTimeSeriesSource " +
                                        "productKey=$dataKey intervalMin=${intervalMs2 / 60_000}min perHour=$perHour2: " +
                                        "${vectorValidTimes.take(3).joinToString { it.toInstant().toString() }}" +
                                        if (vectorValidTimes.size > 3) " … ${vectorValidTimes.last().toInstant()}" else "",
                                )
                                parsedMetadataLayerNames = metadata.layers.map { it.name }
                                minZoom = metadata.layers.first().minZoom.toFloat()
                                maxZoom = metadata.layers.first().maxZoom.toFloat()
                            }
                        }
                        hadLoadedMetadata = true
                    }
                }
            } catch (e: AuthenticationError) {
                if (e.statusCode == 401) {
                    Logger.getGlobal().severe("Authentication error")
                    throw AuthenticationError(401, "")
                } else {
                    Logger.getGlobal().severe("Unexpected auth error: $e")
                    throw e
                }
            } catch (e: Exception) {
                Logger.getGlobal().severe("Metadata load failed: $e")
                throw e
            } finally {
                metadataLoadingTask = null
            }
        }

        metadataLoadingTask!!.await()
        return Result.success(Unit)
    }

    override fun getTileData(coord: TileCoord): Any? {
        val lookup = cacheCoordForLookup(coord)
        val tile = vectorTileCache[lookup] ?: vectorTileCache.tiles[lookup.hash()]
        return tile?.data
    }

    /** Demo/debug-only: last-fetch download size and currently-retained raw size for [coord], in bytes. */
    fun debugTileByteSizes(coord: TileCoord): Pair<Int, Int>? {
        val lookup = cacheCoordForLookup(coord)
        val tile = vectorTileCache[lookup] ?: vectorTileCache.tiles[lookup.hash()]
        return tile?.let { it.downloadedBytes to it.storedBytes }
    }

    /**
     * Demo/debug-only: epoch-ms time intervals with parsed data currently cached for the spatial
     * tile at [coord], sorted ascending. Null when this source isn't a time-series source (there's
     * only ever one interval per tile); empty when the tile hasn't been fetched yet.
     */
    fun debugLoadedIntervals(coord: TileCoord): List<Long>? {
        if (!isTimeSeriesSource) return null
        val lookup = cacheCoordForLookup(coord)
        val tile = vectorTileCache[lookup] ?: vectorTileCache.tiles[lookup.hash()]
        val series = tile?.data as? VectorTimeSeriesData ?: return emptyList()
        return series.series.intervals.filter { series.hasDataForInterval(it) }.sorted()
    }

    /**
     * Demo/debug-only: raw MVT byte size retained for one [intervalMs] of the spatial tile at
     * [coord]. Time-series sources retain raw bytes per interval in [mvtNativeCache] (see
     * [storeNativeMvtBytes]), so this is both the download and stored size for that interval.
     * Null when this source isn't time-series or that interval's bytes were trimmed/never fetched.
     */
    fun debugIntervalByteSize(coord: TileCoord, intervalMs: Long): Int? {
        if (!retainNativeMvtBytes) return null
        val lookup = cacheCoordForLookup(coord)
        val nativeKey = timeSeriesMvtNativeKey(lookup.hash(), intervalMs)
        return mvtNativeCache().getNamespaced(NativeCacheBudget.NAMESPACE_MVT_BYTES, nativeKey)?.size
    }

    /**
     * Demo/debug-only: where [coord] currently sits in the fetch/parse pipeline.
     * [DebugTileStage.DOWNLOADED_NOT_PROCESSED] is normally short-lived (parsing happens inline
     * right after a successful fetch) but can persist under load, e.g. while multiple tiles wait
     * on [vectorParseSemaphore] for a free decode slot.
     */
    fun debugTileStage(coord: TileCoord): DebugTileStage {
        val lookup = cacheCoordForLookup(coord)
        val tile = vectorTileCache[lookup] ?: vectorTileCache.tiles[lookup.hash()]
        if (tile == null || tile.downloadedBytes < 0) return DebugTileStage.NEEDED
        val hasData = if (isTimeSeriesSource) {
            debugLoadedIntervals(coord)?.isNotEmpty() == true
        } else {
            tile.data != null
        }
        return if (hasData) DebugTileStage.PROCESSED else DebugTileStage.DOWNLOADED_NOT_PROCESSED
    }

    /** Spatial cache key for time-series tiles (time is not part of the key). */
    internal fun spatialTileCoord(x: Int, y: Int, z: Int, offset: Int = 0): TileCoord {
        val timeKey = if (isTimeSeriesSource) "" else formatDateArrayToString(listOf(validTime))
        return TileCoord(x, y, z, offset, timeKey)
    }

    private fun cacheCoordForLookup(coord: TileCoord): TileCoord {
        if (!isTimeSeriesSource) return coord
        return TileCoord(coord.x, coord.y, coord.z, coord.offset, "")
    }

    override suspend fun requestTiles(
        coord: TileCoord,
        options: TileRequestOptions,
        currentDate: String,
        fromAnimation: Boolean,
        intervals: List<String>?,
        trackDownloadProgress: Boolean,
    ): Any {
        if (!isTimeSeriesSource) return 0
        val dates = options.intervals
            ?: intervals?.mapNotNull { parseBracketedIntervalDate(it) }
            ?: return 0
        // Launch all interval downloads concurrently. Sequential awaiting blocked animation because
        // each ~300ms download per interval meant the playback prefetch window (8 intervals) took
        // 2+ seconds to load, always behind the advancing phase. Concurrent launches share the same
        // VectorTimeSeriesData (guarded by synchronized(tile) in requestTile) so intervals accumulate
        // in the shared container rather than overwriting each other.
        for (date in dates) {
            scope.launch { requestTile(coord.x, coord.y, coord.z, intervalTime = date) }
        }
        return dates.size
    }

    private fun parseBracketedIntervalDate(raw: String): Date? {
        val trimmed = raw.trim()
        return try {
            when {
                trimmed.startsWith("[\"") && trimmed.endsWith("\"]") -> {
                    val inner = trimmed.substring(2, trimmed.length - 2)
                    dateFormatter.parse(inner)
                }
                trimmed.all { it.isDigit() } -> Date(trimmed.toLong())
                else -> dateFormatter.parse(trimmed)
            }
        } catch (_: Exception) {
            null
        }
    }

    open suspend fun requestTile(
        x: Int,
        y: Int,
        z: Int,
        mapZoomForDensity: Double? = null,
        visibleGeoBounds: VisibleGeoBounds? = null,
        intervalTime: Date? = null,
        countsForGlFillLoadIndicator: Boolean = false,
    ): VectorData? {
        val countsForLoadUi = countsForGlFillLoadIndicator || isTimeSeriesSource
        val debugMaskTile = useTimelessStencilMaskKeys && maskDebugMatches(z, x, y)
        // Snap the requested interval to the nearest actual valid time so the tile URL matches a
        // real data snapshot. Without this, callers that pass a round phase epoch-ms (e.g. hourly
        // timeline phases) get a URL the AMP server doesn't recognise, which returns no tile data.
        // When intervalTime is before the known valid-times range (e.g. the timeline was extended
        // further into history than the metadata covers), snap-to-nearest would wrongly pin every
        // older phase to the oldest metadata entry. Instead, round to the product's own granularity
        // so the tile URL is still valid — the AMP server stores data at that cadence regardless of
        // what the metadata listing covers.
        val fetchTime = if (isTimeSeriesSource && intervalTime != null) {
            snapFetchTime(intervalTime)
        } else {
            intervalTime ?: validTime
        }
        val cacheCoord = spatialTileCoord(x, y, z)
        val urlCoord = TileCoord(x, y, z, 0, formatDateArrayToString(listOf(fetchTime)))

        var inFlightKey: String? = null
        if (isTimeSeriesSource) {
            val series = getTileData(cacheCoord) as? VectorTimeSeriesData
            val cachedInterval = series?.getData(fetchTime.time)
            if (cachedInterval != null) {
                return cachedInterval
            }
            // Skip if another coroutine is already downloading the same (coord, snappedTime) pair.
            val key = "${cacheCoord.hash()}/${fetchTime.time}"
            if (inFlightTileKeys.size >= TIME_SERIES_MAX_IN_FLIGHT_BEFORE_PREFETCH &&
                !inFlightTileKeys.contains(key)
            ) {
                return null
            }
            if (!inFlightTileKeys.add(key)) return null
            if (cancelledInFlightKeys.contains(key)) {
                inFlightTileKeys.remove(key)
                return null
            }
            // Count every real MVT download for a time-series source, not just the ones whose
            // caller happened to pass countsForGlFillLoadIndicator. That flag is only set by one of
            // a dozen requestTile call sites (VectorTileLayer's current-interval prefetch loop), so
            // a vector-only load moved the counter for a single tile and the load UI concluded
            // there was nothing to show. The decrement below uses the same value, and it runs in a
            // finally, so the counter cannot leak and strand the indicator.
            if (countsForLoadUi) {
                Timeline.adjustGlVectorFillMvtPending(1)
            }
            inFlightKey = key
        }

        var reload = false
        val existing = if (isTimeSeriesSource) null else getTileData(urlCoord)
        val existingTile = vectorTileCache[if (isTimeSeriesSource) cacheCoord else urlCoord]
            ?: tileCache.get(if (isTimeSeriesSource) cacheCoord else urlCoord)

        if (existing != null && existing is VectorData && existingTile?.state !== TileState.Expired) {
            if (false && existing.validTime != fetchTime) {
                reload = true
            } else {
                if (glStencilMaskTileListener != null &&
                    !hasWaterStencilMvtTagInFeatures(existing.features)
                ) {
                    val key = urlCoord.hash()
                    val attempts = stencilInclusionReparseAttempts.getOrDefault(key, 0)
                    if (attempts < maxStencilInclusionReparseAttempts) {
                        stencilInclusionReparseAttempts[key] = attempts + 1
                        MapsGLDebug.trace(
                            "[GlStencilMask] base.osm cache missing water features; expiring tile for reparse " +
                                "attempt ${attempts + 1}/$maxStencilInclusionReparseAttempts: $key",
                        )
                        existingTile?.state = TileState.Expired
                        vectorTileCache[urlCoord]?.let { t ->
                            t.state = TileState.Expired
                            vectorTileCache.setStale(true, t)
                        }
                    } else {
                        feedGlStencilMaskFromVectorCache(urlCoord, existing)
                        return existing
                    }
                } else {
                    if (glStencilMaskTileListener != null && hasWaterStencilMvtTagInFeatures(existing.features)) {
                        stencilInclusionReparseAttempts.remove(urlCoord.hash())
                    }
                    feedGlStencilMaskFromVectorCache(urlCoord, existing)
                    return existing
                }
            }
        }

        val url = makeTileURL(urlCoord, mutableMapOf("time" to fetchTime))
        if (debugMaskTile) {
            MapsGLDebug.trace("[MaskDebug][Fetch] requestTile start key=${z}/${x}/${y} url=$url")
        }
        val urlRequest = URLRequest(
            url.toString(),
            // Without an explicit timeout, HttpURLConnection blocks indefinitely on a stalled
            // connection (no OS-level timeout fires for a long time). A single stuck request then
            // permanently occupies one of the bounded timeSeriesDownloadSemaphore permits and one
            // inFlightTileKeys slot, and enough of those wedge all future tile fetching for this
            // source with no crash, no error, and no recovery short of an app restart.
            connectTimeoutMs = 20_000,
            readTimeoutMs = 20_000,
        )
        authenticator?.credentials?.let { credentials ->
            urlRequest.setAuthorization("Bearer ${credentials.accessToken}")
        }

        if (vectorTileCache.pendingCount == 0) {
            trigger(DataSourceEvents.LoadStart(sourceID = id))
            _shouldTriggerLoadCompleteEvent = true
        }

        val storeCoord = if (isTimeSeriesSource) cacheCoord else urlCoord
        storeCoord.time = if (isTimeSeriesSource) "" else formatDateArrayToString(listOf(fetchTime))
        // Synchronize tile creation so concurrent interval requests for the same spatial coord
        // all share the same Tile object (prevents each coroutine creating its own orphaned tile).
        val tile = synchronized(vectorTileCache) {
            vectorTileCache[storeCoord] ?: Tile<VectorData>(storeCoord).also { newTile ->
                newTile.time = storeCoord.time
                newTile.coordHash = storeCoord.hash()
                vectorTileCache.updateTile(newTile, storeCoord)
            }
        }

        vectorTileCache.setPending(true, tile)
        tile.state = TileState.Loading

        try {
            val fetchStartNs = System.nanoTime()
            val tileResponse = try {
                if (isTimeSeriesSource) {
                    timeSeriesDownloadSemaphore.withPermit {
                        if (inFlightKey != null && cancelledInFlightKeys.contains(inFlightKey)) {
                            return@withPermit null
                        }
                        activeTimeSeriesDownloads.incrementAndGet()
                        try {
                            tileManager.loadTile(urlCoord, urlRequest)
                        } finally {
                            activeTimeSeriesDownloads.decrementAndGet()
                        }
                    }
                } else {
                    tileManager.loadTile(urlCoord, urlRequest)
                }
            } catch (e: Exception) {
                if (debugMaskTile) {
                    MapsGLDebug.trace("[MaskDebug][Fetch] requestTile error key=${z}/${x}/${y} err=${e.message}")
                }
                Logger.getGlobal().warning("Failed to load tile $storeCoord: ${e.message}")
                return null
            }
            // Demo/debug-only: includes any wait for timeSeriesDownloadSemaphore, not just the HTTP call.
            val networkMs = (System.nanoTime() - fetchStartNs) / 1_000_000

            tile.state = TileState.Ready
            val tileData = tileResponse?.data as ByteArray?

            tileData?.let {
                if (inFlightKey != null && cancelledInFlightKeys.contains(inFlightKey)) {
                    return null
                }
                tile.downloadedBytes = tileData.size
                if (isTimeSeriesSource && retainNativeMvtBytes) {
                    storeNativeMvtBytes(storeCoord, fetchTime.time, tileData)
                    tile.storedBytes = tileData.size
                } else {
                    // Raw MVT bytes are discarded after parsing; only decoded features are retained.
                    tile.storedBytes = 0
                }
                if (debugMaskTile) {
                    MapsGLDebug.trace("[MaskDebug][Fetch] response bytes key=${z}/${x}/${y} size=${tileData.size}")
                }
                val parseStartNs = System.nanoTime()
                val deferred = scope.async(Dispatchers.Default) {
                    parseVectorTile(tile, tileData, fetchTime, headers = tileResponse?.headers)
                }
                val parsed = deferred.await()
                // Demo/debug-only: includes any wait for vectorParseSemaphore, not just decode itself.
                val parseMs = (System.nanoTime() - parseStartNs) / 1_000_000
                recordDebugRequestTiming(networkMs, parseMs)
                if (isTimeSeriesSource) {
                    // Synchronize the read-modify-write on tile.data so concurrent interval downloads
                    // for the same spatial tile each add their interval into the shared VectorTimeSeriesData
                    // rather than overwriting each other's work.
                    var seriesCount = 0
                    synchronized(tile) {
                        val series = (tile.data as? VectorTimeSeriesData)
                            ?: VectorTimeSeriesData(vectorValidTimes.map { it.time })
                        series.setValidIntervals(vectorValidTimes.map { it.time })
                        series.setData(fetchTime.time, parsed)
                        tile.data = series
                        seriesCount = series.count
                    }
                    tileCache.tiles[storeCoord.hash()] = tile as Tile<DataType>
                    return parsed
                }
                tile.data = parsed
                tileCache.tiles[storeCoord.hash()] = tile as Tile<DataType>
                return parsed
            }
            if (debugMaskTile) {
                MapsGLDebug.trace("[MaskDebug][Fetch] no tileData key=${z}/${x}/${y}")
            }
            if (isTimeSeriesSource) {
                synchronized(tile) {
                    val series = (tile.data as? VectorTimeSeriesData)
                        ?: VectorTimeSeriesData(vectorValidTimes.map { it.time })
                    series.setValidIntervals(vectorValidTimes.map { it.time })
                    val empty = VectorData(fetchTime, mutableListOf())
                    series.setData(fetchTime.time, empty)
                    tile.data = series
                    tileCache.tiles[storeCoord.hash()] = tile as Tile<DataType>
                }
                return VectorData(fetchTime, mutableListOf())
            }
            return null
        } finally {
            inFlightKey?.let { key -> finishInFlightKey(key, countsForLoadUi) }
        }
    }

    private fun finishInFlightKey(key: String, countsForGlFillLoadIndicator: Boolean) {
        inFlightTileKeys.remove(key)
        cancelledInFlightKeys.remove(key)
        if (countsForGlFillLoadIndicator) {
            Timeline.adjustGlVectorFillMvtPending(-1)
        }
    }

    fun abortTile(x: Int, y: Int, z: Int) {
        val coord = spatialTileCoord(x, y, z)
        inFlightTileKeys.filter { it.startsWith("${coord.hash()}/") }.toList().forEach { key ->
            cancelledInFlightKeys.add(key)
            inFlightTileKeys.remove(key)
        }
    }

    /** Cancels in-flight MVT downloads outside [keepSpatialHashes] (rule 5). */
    fun cancelInFlightTilesOutside(keepSpatialHashes: Set<String>) {
        inFlightTileKeys.filter { key ->
            val spatial = key.substringBefore('/')
            spatial !in keepSpatialHashes
        }.toList().forEach { key ->
            cancelledInFlightKeys.add(key)
            inFlightTileKeys.remove(key)
        }
    }

    /** Cancels every queued/active time-series download (e.g. before playback gate at z−1). */
    fun cancelAllInFlightTimeSeriesTiles() {
        if (!isTimeSeriesSource) return
        inFlightTileKeys.toList().forEach { key ->
            cancelledInFlightKeys.add(key)
            inFlightTileKeys.remove(key)
        }
    }

    /** Retain raw MVT bytes in native memory for time-series tiles (rules 6 & 7). */
    val retainNativeMvtBytes: Boolean
        get() = isTimeSeriesSource

    private fun mvtNativeCache() = vectorTileCache.nativeCache

    private fun timeSeriesMvtNativeKey(spatialCoordHash: String, snappedMs: Long): String =
        "${id}$spatialCoordHash/ts/$snappedMs"

    private fun storeNativeMvtBytes(spatialCoord: TileCoord, snappedMs: Long, bytes: ByteArray) {
        if (!retainNativeMvtBytes) return
        mvtNativeCache().putNamespaced(
            NativeCacheBudget.NAMESPACE_MVT_BYTES,
            timeSeriesMvtNativeKey(spatialCoord.hash(), snappedMs),
            bytes,
        )
    }

    fun hasNativeMvtBytesAt(z: Int, x: Int, y: Int, intervalMs: Long): Boolean {
        if (!retainNativeMvtBytes) return false
        val coord = spatialTileCoord(x, y, z)
        val snappedMs = snappedTimeSeriesIntervalMs(intervalMs)
        return mvtNativeCache().containsKeyNamespaced(
            NativeCacheBudget.NAMESPACE_MVT_BYTES,
            timeSeriesMvtNativeKey(coord.hash(), snappedMs),
        )
    }

    /** Pins [z]/[x]/[y]'s MVT bytes for [intervalMs] against native-cache eviction — see
     * [pinFillTriangulationNative] for the eviction-priority semantics this declares. */
    fun pinNativeMvtBytesAt(z: Int, x: Int, y: Int, intervalMs: Long) {
        if (!retainNativeMvtBytes) return
        val coord = spatialTileCoord(x, y, z)
        val snappedMs = snappedTimeSeriesIntervalMs(intervalMs)
        mvtNativeCache().pinNamespaced(
            NativeCacheBudget.NAMESPACE_MVT_BYTES,
            timeSeriesMvtNativeKey(coord.hash(), snappedMs),
        )
    }

    fun unpinNativeMvtBytesAt(z: Int, x: Int, y: Int, intervalMs: Long) {
        if (!retainNativeMvtBytes) return
        val coord = spatialTileCoord(x, y, z)
        val snappedMs = snappedTimeSeriesIntervalMs(intervalMs)
        mvtNativeCache().unpinNamespaced(
            NativeCacheBudget.NAMESPACE_MVT_BYTES,
            timeSeriesMvtNativeKey(coord.hash(), snappedMs),
        )
    }

    private fun fillTriangulationNativeKey(triKey: String): String = "${id}ftri|$triKey"

    /** Precomputed fill mesh interleaved floats stored in the native fill-mesh cache (rule 9). */
    internal fun putFillTriangulationNative(triKey: String, interleaved: FloatArray) {
        if (interleaved.isEmpty()) return
        val bytes = java.nio.ByteBuffer.allocate(interleaved.size * 4)
            .order(java.nio.ByteOrder.nativeOrder())
            .also { it.asFloatBuffer().put(interleaved) }
            .array()
        mvtNativeCache().putNamespaced(NativeCacheBudget.NAMESPACE_FILL_MESH, fillTriangulationNativeKey(triKey), bytes)
    }

    /** Rule: native-triangulation-zero-copy-write. [putFillTriangulationNative]'s byte-passthrough
     * counterpart — for when the caller ([VectorPolygonFillTriangulator.triangulateFeaturesRaw])
     * already has the mesh in this cache's exact on-disk byte format (every polygon in the tile
     * triangulated natively), skipping the FloatArray materialization + re-encode this function's
     * `FloatArray` overload requires. */
    internal fun putFillTriangulationNativeBytes(triKey: String, bytes: ByteArray) {
        if (bytes.isEmpty()) return
        mvtNativeCache().putNamespaced(NativeCacheBudget.NAMESPACE_FILL_MESH, fillTriangulationNativeKey(triKey), bytes)
    }

    internal fun getFillTriangulationNative(triKey: String): FloatArray? {
        val bytes = mvtNativeCache().getNamespaced(NativeCacheBudget.NAMESPACE_FILL_MESH, fillTriangulationNativeKey(triKey))
            ?: return null
        if (bytes.size % 4 != 0) return null
        val floats = FloatArray(bytes.size / 4)
        java.nio.ByteBuffer.wrap(bytes).order(java.nio.ByteOrder.nativeOrder()).asFloatBuffer().get(floats)
        return floats
    }

    internal fun hasFillTriangulationNative(triKey: String): Boolean =
        mvtNativeCache().containsKeyNamespaced(NativeCacheBudget.NAMESPACE_FILL_MESH, fillTriangulationNativeKey(triKey))

    /** Rule: zero-copy-gpu-upload (Phase 5). See [NativeLibCache.getNamespacedDirect]'s KDoc — the
     * returned buffer, if non-null, MUST be paired with exactly one [releaseFillTriangulationNativeDirect]
     * call once the caller (the GL upload path) is done reading it. */
    internal fun getFillTriangulationNativeDirect(triKey: String): java.nio.ByteBuffer? =
        mvtNativeCache().getNamespacedDirect(NativeCacheBudget.NAMESPACE_FILL_MESH, fillTriangulationNativeKey(triKey))

    internal fun releaseFillTriangulationNativeDirect(triKey: String) {
        mvtNativeCache().releaseNamespacedDirect(NativeCacheBudget.NAMESPACE_FILL_MESH, fillTriangulationNativeKey(triKey))
    }

    /** Rule: native-cache-budget. Marks [triKey]'s fill mesh as part of the currently-needed
     * playback working set — preferred to survive eviction under [NativeCacheBudget]'s shared
     * budget, but not exempt from it if the pinned set alone exceeds the namespace's budget. Callers
     * must unpin once a key leaves the working set (e.g. every playback-ref rebuild), or pins would
     * accumulate across an entire session. */
    internal fun pinFillTriangulationNative(triKey: String) {
        mvtNativeCache().pinNamespaced(NativeCacheBudget.NAMESPACE_FILL_MESH, fillTriangulationNativeKey(triKey))
    }

    internal fun unpinFillTriangulationNative(triKey: String) {
        mvtNativeCache().unpinNamespaced(NativeCacheBudget.NAMESPACE_FILL_MESH, fillTriangulationNativeKey(triKey))
    }

    private fun outlineTriangulationNativeKey(triKey: String): String = "${id}otri|$triKey"

    /** Precomputed outline ribbon mesh stored in the native outline-mesh cache (rule 9). */
    internal fun putOutlineTriangulationNative(triKey: String, interleaved: FloatArray) {
        if (interleaved.isEmpty()) return
        val bytes = java.nio.ByteBuffer.allocate(interleaved.size * 4)
            .order(java.nio.ByteOrder.nativeOrder())
            .also { it.asFloatBuffer().put(interleaved) }
            .array()
        mvtNativeCache().putNamespaced(NativeCacheBudget.NAMESPACE_OUTLINE_MESH, outlineTriangulationNativeKey(triKey), bytes)
    }

    /** Rule: native-triangulation-zero-copy-write. See [putFillTriangulationNativeBytes]'s identical
     * rationale — [VectorPolygonFillTriangulator.triangulateOutlinesRaw]'s byte-passthrough counterpart. */
    internal fun putOutlineTriangulationNativeBytes(triKey: String, bytes: ByteArray) {
        if (bytes.isEmpty()) return
        mvtNativeCache().putNamespaced(NativeCacheBudget.NAMESPACE_OUTLINE_MESH, outlineTriangulationNativeKey(triKey), bytes)
    }

    internal fun getOutlineTriangulationNative(triKey: String): FloatArray? {
        val bytes = mvtNativeCache()
            .getNamespaced(NativeCacheBudget.NAMESPACE_OUTLINE_MESH, outlineTriangulationNativeKey(triKey))
            ?: return null
        if (bytes.size % 4 != 0) return null
        val floats = FloatArray(bytes.size / 4)
        java.nio.ByteBuffer.wrap(bytes).order(java.nio.ByteOrder.nativeOrder()).asFloatBuffer().get(floats)
        return floats
    }

    internal fun hasOutlineTriangulationNative(triKey: String): Boolean =
        mvtNativeCache().containsKeyNamespaced(NativeCacheBudget.NAMESPACE_OUTLINE_MESH, outlineTriangulationNativeKey(triKey))

    /** See [getFillTriangulationNativeDirect]'s KDoc. */
    internal fun getOutlineTriangulationNativeDirect(triKey: String): java.nio.ByteBuffer? =
        mvtNativeCache().getNamespacedDirect(NativeCacheBudget.NAMESPACE_OUTLINE_MESH, outlineTriangulationNativeKey(triKey))

    internal fun releaseOutlineTriangulationNativeDirect(triKey: String) {
        mvtNativeCache().releaseNamespacedDirect(NativeCacheBudget.NAMESPACE_OUTLINE_MESH, outlineTriangulationNativeKey(triKey))
    }

    /** See [pinFillTriangulationNative]. */
    internal fun pinOutlineTriangulationNative(triKey: String) {
        mvtNativeCache().pinNamespaced(NativeCacheBudget.NAMESPACE_OUTLINE_MESH, outlineTriangulationNativeKey(triKey))
    }

    internal fun unpinOutlineTriangulationNative(triKey: String) {
        mvtNativeCache().unpinNamespaced(NativeCacheBudget.NAMESPACE_OUTLINE_MESH, outlineTriangulationNativeKey(triKey))
    }

    private fun circleTriangulationNativeKey(triKey: String): String = "${id}ctri|$triKey"

    /** Precomputed circle point mesh stored in the native circle-mesh cache (rule 9). */
    internal fun putCircleTriangulationNative(triKey: String, interleaved: FloatArray) {
        if (interleaved.isEmpty()) return
        val bytes = java.nio.ByteBuffer.allocate(interleaved.size * 4)
            .order(java.nio.ByteOrder.nativeOrder())
            .also { it.asFloatBuffer().put(interleaved) }
            .array()
        mvtNativeCache().putNamespaced(NativeCacheBudget.NAMESPACE_CIRCLE_MESH, circleTriangulationNativeKey(triKey), bytes)
    }

    internal fun getCircleTriangulationNative(triKey: String): FloatArray? {
        val bytes = mvtNativeCache()
            .getNamespaced(NativeCacheBudget.NAMESPACE_CIRCLE_MESH, circleTriangulationNativeKey(triKey))
            ?: return null
        if (bytes.size % 4 != 0) return null
        val floats = FloatArray(bytes.size / 4)
        java.nio.ByteBuffer.wrap(bytes).order(java.nio.ByteOrder.nativeOrder()).asFloatBuffer().get(floats)
        return floats
    }

    internal fun hasCircleTriangulationNative(triKey: String): Boolean =
        mvtNativeCache().containsKeyNamespaced(NativeCacheBudget.NAMESPACE_CIRCLE_MESH, circleTriangulationNativeKey(triKey))

    /** See [getFillTriangulationNativeDirect]'s KDoc. */
    internal fun getCircleTriangulationNativeDirect(triKey: String): java.nio.ByteBuffer? =
        mvtNativeCache().getNamespacedDirect(NativeCacheBudget.NAMESPACE_CIRCLE_MESH, circleTriangulationNativeKey(triKey))

    internal fun releaseCircleTriangulationNativeDirect(triKey: String) {
        mvtNativeCache().releaseNamespacedDirect(NativeCacheBudget.NAMESPACE_CIRCLE_MESH, circleTriangulationNativeKey(triKey))
    }

    /** See [pinFillTriangulationNative]. */
    internal fun pinCircleTriangulationNative(triKey: String) {
        mvtNativeCache().pinNamespaced(NativeCacheBudget.NAMESPACE_CIRCLE_MESH, circleTriangulationNativeKey(triKey))
    }

    internal fun unpinCircleTriangulationNative(triKey: String) {
        mvtNativeCache().unpinNamespaced(NativeCacheBudget.NAMESPACE_CIRCLE_MESH, circleTriangulationNativeKey(triKey))
    }

    private fun heatmapPointsNativeKey(triKey: String): String = "${id}htri|$triKey"

    /** Precomputed heatmap point buffer ([x, y, weight] per point) stored in the native heatmap-mesh
     * cache (rule 9), mirroring [putCircleTriangulationNative]. */
    internal fun putHeatmapPointsNative(triKey: String, interleaved: FloatArray) {
        if (interleaved.isEmpty()) return
        val bytes = java.nio.ByteBuffer.allocate(interleaved.size * 4)
            .order(java.nio.ByteOrder.nativeOrder())
            .also { it.asFloatBuffer().put(interleaved) }
            .array()
        mvtNativeCache().putNamespaced(NativeCacheBudget.NAMESPACE_HEATMAP_MESH, heatmapPointsNativeKey(triKey), bytes)
    }

    internal fun getHeatmapPointsNative(triKey: String): FloatArray? {
        val bytes = mvtNativeCache()
            .getNamespaced(NativeCacheBudget.NAMESPACE_HEATMAP_MESH, heatmapPointsNativeKey(triKey))
            ?: return null
        if (bytes.size % 4 != 0) return null
        val floats = FloatArray(bytes.size / 4)
        java.nio.ByteBuffer.wrap(bytes).order(java.nio.ByteOrder.nativeOrder()).asFloatBuffer().get(floats)
        return floats
    }

    internal fun hasHeatmapPointsNative(triKey: String): Boolean =
        mvtNativeCache().containsKeyNamespaced(NativeCacheBudget.NAMESPACE_HEATMAP_MESH, heatmapPointsNativeKey(triKey))

    /** See [getFillTriangulationNativeDirect]'s KDoc. */
    internal fun getHeatmapPointsNativeDirect(triKey: String): java.nio.ByteBuffer? =
        mvtNativeCache().getNamespacedDirect(NativeCacheBudget.NAMESPACE_HEATMAP_MESH, heatmapPointsNativeKey(triKey))

    internal fun releaseHeatmapPointsNativeDirect(triKey: String) {
        mvtNativeCache().releaseNamespacedDirect(NativeCacheBudget.NAMESPACE_HEATMAP_MESH, heatmapPointsNativeKey(triKey))
    }

    private fun symbolInstancesNativeKey(triKey: String): String = "${id}stri|$triKey"

    /** Precomputed symbol-instance batch (sdf/raster/text float arrays + per-instance cross-tile-id
     * metadata) stored in the native symbol-mesh cache (rule 9), as a caller-serialized byte blob —
     * unlike Fill/Outline/Circle/Heatmap's uniform float layout, a symbol batch mixes float data with
     * variable-length crossTileId strings, so serialization is [VectorSymbolLayerRenderer]'s job; this
     * is just raw-byte storage. */
    internal fun putSymbolInstancesNative(triKey: String, serialized: ByteArray) {
        if (serialized.isEmpty()) return
        mvtNativeCache().putNamespaced(NativeCacheBudget.NAMESPACE_SYMBOL_MESH, symbolInstancesNativeKey(triKey), serialized)
    }

    internal fun getSymbolInstancesNative(triKey: String): ByteArray? =
        mvtNativeCache().getNamespaced(NativeCacheBudget.NAMESPACE_SYMBOL_MESH, symbolInstancesNativeKey(triKey))

    internal fun hasSymbolInstancesNative(triKey: String): Boolean =
        mvtNativeCache().containsKeyNamespaced(NativeCacheBudget.NAMESPACE_SYMBOL_MESH, symbolInstancesNativeKey(triKey))

    fun trimParsedTimeSeriesIntervalsOutside(spatialCoord: TileCoord, keepSnappedMs: Set<Long>) {
        if (!retainNativeMvtBytes || keepSnappedMs.isEmpty()) return
        val tile = vectorTileCache[spatialCoord] ?: return
        val series = tile.data as? VectorTimeSeriesData ?: return
        synchronized(tile) {
            for (interval in series.series.intervals.toList()) {
                if (interval in keepSnappedMs) continue
                if (!hasNativeMvtBytesAt(spatialCoord.z, spatialCoord.x, spatialCoord.y, interval)) continue
                series.removeData(interval)
            }
        }
    }

    fun trimParsedHeapForTimeline(keepSpatialHashes: Set<String>? = null) {
        if (!retainNativeMvtBytes) return
        val keepIntervals = parsedIntervalKeepSetForTimeline()
        if (keepIntervals.isEmpty()) return
        for (key in vectorTileCache.keys) {
            val coord = TileCoord.fromHash(key) ?: continue
            if (keepSpatialHashes != null && key !in keepSpatialHashes) {
                trimAllParsedIntervalsRetainingNative(coord)
            } else {
                trimParsedTimeSeriesIntervalsOutside(coord, keepIntervals)
            }
        }
    }

    /**
     * Rule: parsed-heap-bound. Per explicit, repeated user directive: always keep the whole
     * animation's parsed-feature data resident once fetched, regardless of play/pause state — a
     * per-region animation ([Timeline.timeStrings]'s actual frame count, tens of phases, not the
     * source metadata's much finer-grained [vectorValidTimes] count) times the visible-tile count
     * is a small, fixed, known quantity, not the kind of unbounded growth an earlier fix in this
     * area was built to guard against (a much wider/denser viewport pushing genuine, unbounded
     * memory growth). No narrow "near current phase" window, no heap-pressure fallback — a loop
     * wrap must never force re-parsing something already parsed this session.
     */
    private fun parsedIntervalKeepSetForTimeline(): Set<Long> {
        if (!isTimeSeriesSource) return emptySet()
        val phaseEpochs = Timeline.timeStrings.indices.mapNotNull { timelinePhaseEpochMillis(it) }
        return phaseEpochs.map { snappedTimeSeriesIntervalMs(it) }.toSet()
    }

    private fun trimAllParsedIntervalsRetainingNative(spatialCoord: TileCoord) {
        val tile = vectorTileCache[spatialCoord] ?: return
        val series = tile.data as? VectorTimeSeriesData ?: return
        synchronized(tile) {
            for (interval in series.series.intervals.toList()) {
                if (!hasNativeMvtBytesAt(spatialCoord.z, spatialCoord.x, spatialCoord.y, interval)) continue
                series.removeData(interval)
            }
        }
    }

    suspend fun ensureTimeSeriesParsedAt(z: Int, x: Int, y: Int, intervalMs: Long): VectorData? {
        if (!isTimeSeriesSource) return null
        val coord = spatialTileCoord(x, y, z)
        val snappedMs = snappedTimeSeriesIntervalMs(intervalMs)
        val nativeKey = timeSeriesMvtNativeKey(coord.hash(), snappedMs)
        var tile = vectorTileCache[coord]
        if (tile == null) {
            if (!retainNativeMvtBytes ||
                !mvtNativeCache().containsKeyNamespaced(NativeCacheBudget.NAMESPACE_MVT_BYTES, nativeKey)
            ) {
                return null
            }
            tile = synchronized(vectorTileCache) {
                vectorTileCache[coord] ?: Tile<VectorData>(coord).also { newTile ->
                    newTile.coordHash = coord.hash()
                    vectorTileCache.updateTile(newTile, coord)
                }
            }
        }
        synchronized(tile) {
            (tile.data as? VectorTimeSeriesData)?.getData(snappedMs)?.let { return it }
        }
        if (!retainNativeMvtBytes) return null
        val bytes = mvtNativeCache().getNamespaced(NativeCacheBudget.NAMESPACE_MVT_BYTES, nativeKey) ?: return null
        @Suppress("UNCHECKED_CAST")
        val typedTile = tile as Tile<VectorData>
        val parsed = parseVectorTile(typedTile, bytes, Date(snappedMs), headers = null)
        synchronized(tile) {
            val series = (tile.data as? VectorTimeSeriesData)
                ?: VectorTimeSeriesData(vectorValidTimes.map { it.time })
            series.setValidIntervals(vectorValidTimes.map { it.time })
            series.setData(snappedMs, parsed)
            tile.data = series
            tileCache.tiles[coord.hash()] = tile as Tile<DataType>
        }
        return parsed
    }

    open fun invalidate() {
        stencilInclusionReparseAttempts.clear()
        // Expire synchronously so a concurrent Mapbox fetch cannot return cached Ready tiles before
        // per-tile Mapbox invalidation is scheduled (remove/re-add same source id).
        val keys = (tileCache.keys + vectorTileCache.keys).distinct()
        for (key in keys) {
            val coord = TileCoord.fromHash(key) ?: continue
            vectorTileCache[coord]?.let { t ->
                t.state = TileState.Expired
                vectorTileCache.setStale(true, t)
            }
            tileCache[coord]?.let { t ->
                t.state = TileState.Expired
                tileCache.setStale(true, t)
            }
        }
        scope.launch {
            try {
                for (key in keys) {
                    val coord = TileCoord.fromHash(key) ?: continue
                    invalidateFunction?.invoke(coord.x, coord.y, coord.z)
                }
            } catch (t: Throwable) {
                MapsGLDebug.logE("VectorTileSource", "invalidate() failed", t)
            }
        }
    }

    fun setInvalidateFunction(invalidateFunction: ((Int, Int, Int) -> Unit)?) {
        this.invalidateFunction = invalidateFunction
    }

    /** True after [com.xweather.mapsgl.map.mapbox.MapboxVectorSourceAdapter] registered this source on the style. */
    internal fun isWiredToMapboxCustomGeometrySource(): Boolean = invalidateFunction != null

    fun setBatchInvalidateFunction(batchInvalidateFunction: ((List<Triple<Int, Int, Int>>) -> Unit)?) {
        this.batchInvalidateFunction = batchInvalidateFunction
    }

    /** Subclasses that do not use [tileCache] (e.g. [EncodedGridVectorTileSource]) call this for each loaded Mapbox tile. */
    protected fun notifyMapboxCustomGeometryTileInvalidation(x: Int, y: Int, z: Int) {
        invalidateFunction?.invoke(x, y, z)
    }

    /**
     * Prefer this for many tiles: one Main-thread coroutine instead of one launch per tile (avoids Mapbox stalls).
     */
    protected fun notifyMapboxCustomGeometryTilesInvalidation(coords: List<Triple<Int, Int, Int>>) {
        if (coords.isEmpty()) return
        val batch = batchInvalidateFunction
        if (batch != null) batch(coords)
        else coords.forEach { (x, y, z) -> invalidateFunction?.invoke(x, y, z) }
    }

    protected fun launchInSourceScope(block: suspend () -> Unit) {
        scope.launch { block() }
    }

    override val kind: DataSourceKind
        get() = DataSourceKind.VECTOR

    override fun addConsumer(consumer: DataSourceConsumer) {
        if (consumers.any { it.layerId == consumer.layerId }) {
            return
        }
        consumers.add(consumer)

        consumer.sourceLayerId?.let { layerName ->
            val exists = consumedLayers.containsKey(layerName)
            consumedLayers[layerName] = consumedLayers.getOrDefault(layerName, 0) + 1

            // If layerName hasn't been added yet, invalidate so new layer data is parsed next time tiles are requested
            if (!exists) {
                invalidate()
            }
        }
    }

    override fun removeConsumer(layerId: String) {
        val consumer = consumers.firstOrNull { it.layerId == layerId }
        val layerName = consumer?.sourceLayerId
        if (layerName != null) {
            val count = consumedLayers[layerName]
            if (count != null) {
                val newCount = count - 1
                if (newCount <= 0) {
                    consumedLayers.remove(layerName)
                    // We've completely eliminated the need for this layer, so invalidate the source to clear cached data
                    invalidate()
                } else {
                    consumedLayers[layerName] = newCount
                }
            }
        }
        consumers.remove(consumer)
    }

    /**
     * [parseVectorTile] only runs when bytes are loaded from the network. Mapbox can call
     * [requestTile] many times for tiles already in [vectorTileCache]; the early return path must
     * still invoke [glStencilMaskTileListener] or the GL stencil land cache never fills (marine
     * products added after the first base.osm fetch, or consumer registered after parse).
     *
     * Custom GLES stencil masks ([addCustomStencilTileListener]) must run here too: most vector
     * sources keep [glStencilMaskTileListener] null, so bailing when it is null would skip the
     * cache entirely on every tile hit.
     */
    private fun feedGlStencilMaskFromVectorCache(coord: TileCoord, data: VectorData) {
        val hash = vectorTileCache[coord]?.coordHash ?: coord.hash()
        val snapshot = data.features.toList()
        val tLand0 = System.nanoTime()
        glStencilMaskTileListener?.invoke(coord, hash, snapshot)
        val landMs = (System.nanoTime() - tLand0) / 1_000_000
        if (landMs > 30) {
            MapsGLDebug.logD(
                "VectorTileSource",
                "feed slow: glStencilMaskTileListener key=${coord.hash()} feats=${snapshot.size} ms=$landMs",
            )
        }
        if (customStencilTileListeners.isNotEmpty()) {
            for (cb in customStencilTileListeners.values) {
                cb(coord, hash, snapshot)
            }
        }
    }

    /**
     * After registering custom stencil listeners, replay already-cached MVT parses so the stencil
     * CPU mesh cache fills without waiting for a network round-trip (tiles often parsed before
     * the weather layer + coordinator run).
     */
    private fun vectorDataFromTilePayload(data: Any?): VectorData? = when (data) {
        is VectorData -> data
        is VectorTimeSeriesData ->
            data.getData(validTime.time) ?: data.getDataClosestToInterval(validTime.time)
        else -> null
    }

    internal fun replayCustomStencilFeedsFromCachedVectorTiles() {
        if (customStencilTileListeners.isEmpty()) return
        // `entries()` builds its snapshot internally under [LRUCache]'s lock, so the sequence we
        // get back doesn't touch the live linked list. That matters because
        // [feedGlStencilMaskFromVectorCache] calls `vectorTileCache[coord]`, which mutates the LRU
        // via `_bumpAge` → `_list.unshiftNode`. Previously this method snapshotted with a manual
        // `.toList()` over the lazy sequence, but the snapshot itself could be invalidated by a
        // background tile-parse `get` from another thread — the lazy walk would loop on a stale
        // `.next` pointer and `.toList()` would `add()` until the heap was exhausted (we saw a
        // 118 MB OOM from this path). The fix lives in [LRUCache.entries] now; the loop body here
        // is just a normal iteration over a list-backed sequence.
        for ((_, tile) in vectorTileCache.tiles.entries()) {
            val vd = vectorDataFromTilePayload(tile.data) ?: continue
            if (vd.features.isEmpty()) continue
            feedGlStencilMaskFromVectorCache(tile.coord, vd)
        }
    }

    /**
     * Replays cached vector tiles into [glStencilMaskTileListener] (and custom listeners) so stencil
     * meshes can be rebuilt immediately without waiting for network/parse on zoom-dependent mask updates.
     */
    internal fun replayGlStencilFeedsFromCachedVectorTiles() {
        if (glStencilMaskTileListener == null && customStencilTileListeners.isEmpty()) return
        // See [replayCustomStencilFeedsFromCachedVectorTiles] for the snapshot-safety story.
        for ((_, tile) in vectorTileCache.tiles.entries()) {
            val vd = vectorDataFromTilePayload(tile.data) ?: continue
            if (vd.features.isEmpty()) continue
            feedGlStencilMaskFromVectorCache(tile.coord, vd)
        }
    }

    private suspend fun parseVectorTile(
        tile: Tile<VectorData>,
        data: ByteArray,
        validTime: Date,
        headers: Headers?
    ): VectorData = withContext(Dispatchers.Default) {
        vectorParseSemaphore.withPermit {
        val coord = tile.coord
        if (pr.ON) pr.p(TAG, pr.invVec, "parseVectorTile():  ${coord.hash()}")
        decoder.isAutoScale = false

        val pbf = gunzipVectorTileIfNeeded(data)
        val debugDecodeAllStartNs = System.nanoTime()
        // Every decoder.decode(...) overload does a full VectorTile.Tile.parseFrom(pbf) internally
        // (protobuf parseFrom always materializes the whole message tree, layer-name/layer-set
        // filtering only affects what's returned afterward) — calling it once just for layerNames and
        // again per needed layer re-parsed the entire tile N+1 times per parseVectorTile() call. This
        // was a major contributor to the burst-OOM seen when playback start fires ~12 concurrent
        // parses (vectorParseSemaphore) at once over a wide, densely-featured viewport. Decode once
        // and group by layer name ourselves instead — identical result, a single parse.
        //
        // Rule: pruning-to-referenced-keys. Decode through PruningVectorTileDecoder so attributes
        // no consumer declared are never allocated, rather than built per feature and dropped by
        // the allowlist filter further down. The stock decoder's per-feature attribute HashMap
        // dominated the live heap inside the play burst (~1.95M HashMap$Node + ~893k
        // UnmodifiableEntry + ~1.26M String); restricting at decode time removes that work
        // entirely. Layers with an unrestricted consumer still get every attribute (null).
        val featuresByLayer = mutableMapOf<String, MutableList<VectorTileDecoder.Feature>>()
        for (feature in PruningVectorTileDecoder.decode(pbf) { layerName ->
                restrictedPropertyKeysFor(layerName)
            }) {
            featuresByLayer.getOrPut(feature.layerName) { mutableListOf() }.add(feature)
        }
        val debugDecodeAllMs = (System.nanoTime() - debugDecodeAllStartNs) / 1_000_000
        val tileLayerNames = featuresByLayer.keys.toList()
        val debugMaskTile = useTimelessStencilMaskKeys && maskDebugMatches(coord.z, coord.x, coord.y)

        if (pr.ON) pr.p(TAG, pr.invVec, "parseVectorTile() consumers count: ${consumers.count()}")

        for (consumer in consumers) {
            if (pr.ON) pr.p(
                TAG,
                pr.invVec,
                "parseVectorTile() consumer: lID ${consumer.layerId}   sLID: ${consumer.sourceLayerId}"
            )
        }

        // Build the list of needed source-layer names based on active consumers
        val neededLayerNames = mutableListOf<String>()
        consumers.forEach { consumer ->
            val sourceLayerId = consumer.sourceLayerId ?: return@forEach
            val tileLayerId = sourceLayerId.removeSuffix("::inverted")
            if (tileLayerNames.contains(tileLayerId)) {
                neededLayerNames += sourceLayerId
            }
        }
        // Weather configs often omit sourceLayer; parse every layer present in the tile.
        if (consumers.any { it.sourceLayerId == null }) {
            for (name in tileLayerNames) {
                if (!neededLayerNames.contains(name)) {
                    neededLayerNames.add(name)
                }
            }
        }

        // GLES stencil: parse raw `water` (marine LAND / WATER masks) and `transportation` (road ribbon mask).
        if (glStencilMaskTileListener != null && tileLayerNames.contains("water")) {
            if (!neededLayerNames.contains("water")) {
                neededLayerNames.add("water")
            }
        }
        if (glStencilMaskTileListener != null && tileLayerNames.contains("transportation")) {
            if (!neededLayerNames.contains("transportation")) {
                neededLayerNames.add("transportation")
            }
        }
        if (glStencilMaskTileListener != null && tileLayerNames.contains("admin")) {
            if (!neededLayerNames.contains("admin")) {
                neededLayerNames.add("admin")
            }
        }
        if (glStencilMaskTileListener != null && tileLayerNames.contains("boundary")) {
            if (!neededLayerNames.contains("boundary")) {
                neededLayerNames.add("boundary")
            }
        }

        for (tag in stencilParseExtraLayers.keys) {
            val base = tag.removeSuffix("::inverted")
            if (tileLayerNames.contains(base) && !neededLayerNames.contains(tag)) {
                neededLayerNames.add(tag)
            }
        }
        if (debugMaskTile) {
            MapsGLDebug.trace(
                "[MaskDebug][Parse] key=${coord.z}/${coord.x}/${coord.y} layers=${tileLayerNames.joinToString()} " +
                    "needed=${neededLayerNames.joinToString()}",
            )
        }

        // If no layers provided by any consumers, then default to the first to handle cases where
        // MVT only has a single layer and no `sourceLayer` is necessary
        if (neededLayerNames.isEmpty() && tileLayerNames.isNotEmpty()) {
            if (glStencilMaskTileListener != null) {
                if (tileLayerNames.contains("water")) {
                    neededLayerNames.add("water")
                }
                if (tileLayerNames.contains("transportation")) {
                    neededLayerNames.add("transportation")
                }
                if (tileLayerNames.contains("admin")) {
                    neededLayerNames.add("admin")
                }
                if (tileLayerNames.contains("boundary")) {
                    neededLayerNames.add("boundary")
                }
            } else {
                neededLayerNames += tileLayerNames.first()
            }
        }

        val features = mutableListOf<Feature>()
        val rawFeaturesAccum = mutableListOf<VectorTileDecoder.Feature>()
        var anyRawLayerParsed = false
        val needFireTimestamp = consumersNeedFireStartTimestamp()
        val debugConvertStartNs = System.nanoTime()

        for (layerName in neededLayerNames.distinct()) {
            val invertFeatures = layerName.endsWith("::inverted")
            val tileLayerName = layerName.removeSuffix("::inverted")

            // null = at least one consumer of this MVT layer hasn't declared a key restriction, so
            // materialize every attribute exactly as before (see declareNeededPropertyKeys).
            val restrictedKeys = restrictedPropertyKeysFor(tileLayerName)

            // Rule: raw-vector-fast-path. Skip Feature/JsonObject construction entirely for this
            // layer when every consumer currently attached to it has proven it only needs raw MVT
            // attributes (see VectorTileSource.rawPathEligibleForLayer). Never applies to
            // inverted-polygon layers or when a stencil listener needs real Feature objects for this
            // source. Still applies restrictedKeys so raw features retain only what's referenced,
            // same as the Feature path.
            //
            // Rule: place-layer-never-raw. OSM `place` feeds admin place-* text symbol layers
            // (VectorTextLayout needs GeoJSON Feature). A sibling raw-eligible OSM consumer, or a
            // parse before setRawPathEligible(false) runs, must not divert `place` into rawFeatures
            // alone — that left place-city building empty text batches (Ohio blank) forever.
            if (!invertFeatures &&
                tileLayerName != "place" &&
                glStencilMaskTileListener == null &&
                customStencilTileListeners.isEmpty() &&
                rawPathEligibleForLayer(tileLayerName)
            ) {
                val decoded = featuresByLayer[tileLayerName] ?: emptyList()
                if (restrictedKeys != null) {
                    for (feature in decoded) {
                        val filteredAttributes = feature.attributes.filterKeys { key ->
                            restrictedKeys.contains(key.substringBefore('.'))
                        }
                        rawFeaturesAccum += VectorTileDecoder.Feature(
                            feature.layerName,
                            feature.extent,
                            feature.geometry,
                            filteredAttributes,
                            feature.id,
                        )
                    }
                } else {
                    rawFeaturesAccum += decoded
                }
                anyRawLayerParsed = true
                continue
            }

            // Fetch features from the tile layer, convert to Mapbox Features, and tag the layer name
            var layerFeatures: List<Feature> =
                (featuresByLayer[tileLayerName] ?: emptyList()).mapNotNull { feature ->
                    val rawAttributes = if (restrictedKeys != null) {
                        feature.attributes.filterKeys { key -> restrictedKeys.contains(key.substringBefore('.')) }
                    } else {
                        feature.attributes
                    }
                    // Sometimes properties are stored as dot-notated strings in a flattened dictionary, but styling requires nested structure
                    // So convert the properties to the original nested dictionary structure
                    val properties = nestedDictionary(rawAttributes).toMutableMap()
                    // Wall-clock ms at tile decode; matches JS `Date.now()` at paint time for freshly loaded tiles.
                    properties["now"] = System.currentTimeMillis().toDouble()
                    if (needFireTimestamp) {
                        injectFireReportStartTimestampMillisForStyle(properties)
                    }
                    properties["layer"] = layerName
                    MapboxVectorFeature.from(coord, feature, properties)
                } ?: listOf()

            // Optional inversion of polygonal features into a single “inverse” polygon covering the tile
            if (invertFeatures) {
                val inverted = inverseTileFeatures(layerFeatures, coord)
                if (inverted != null) {
                    inverted.addStringProperty("layer", layerName)
                    layerFeatures = mutableListOf(inverted)
                } else {
                    // No valid land mask for this tile; do not keep raw water polys tagged water::inverted
                    // (putFromFeatures would triangulate water as "land" and invert the mask).
                    layerFeatures = emptyList()
                }
            }

            features += layerFeatures
        }
        val debugConvertMs = (System.nanoTime() - debugConvertStartNs) / 1_000_000
        val debugFeatureCountBeforeCluster = features.size

        // Optional clustering / de-duplication for dense point-only tiles
        val isAllPoints = features.all { it.geometry() is Point }

        var debugClusterMs = 0L
        var debugClusteredFeatureCount: Int? = null
        if (isAllPoints && features.size > 3000) {
            val debugClusterStartNs = System.nanoTime()
            val minDistanceKm = 1.0
            val maxDistanceKm = 10.0
            val t = ((10 - coord.z).coerceIn(0, 10)) / 10.0
            val maxDistanceKilometers = minDistanceKm + t * (maxDistanceKm - minDistanceKm)

            val pointClusterer = FeatureCluster()
            val clustered = pointClusterer.deduplicateClosePoints(features, maxDistanceKilometers)
            features.clear()
            features += clustered
            debugClusterMs = (System.nanoTime() - debugClusterStartNs) / 1_000_000
            debugClusteredFeatureCount = features.size
        }

        // Rule: raw-vector-fast-path. The raw branch above diverts eligible-layer features into
        // rawFeaturesAccum instead of `features`, which skips this same de-dup step entirely —
        // a low-zoom tile that legitimately packs tens of thousands of points into one MVT tile (e.g.
        // z=0/0/0) then gets triangulated at full, unclustered size on every cached timeline interval.
        // That's what drove a full 25-interval run to OOM even after pruning attributes down to just
        // the referenced keys. Mirror the same threshold/distance rule here. deduplicateClosePointsRaw
        // passes non-point features (fill polygons, line strings) through unchanged, so this is safe
        // even when rawFeaturesAccum mixes point and non-point geometry across consumers.
        if (anyRawLayerParsed && rawFeaturesAccum.size > 3000) {
            val minDistanceKm = 1.0
            val maxDistanceKm = 10.0
            val t = ((10 - coord.z).coerceIn(0, 10)) / 10.0
            val maxDistanceKilometers = minDistanceKm + t * (maxDistanceKm - minDistanceKm)
            val deduped = deduplicateClosePointsRaw(rawFeaturesAccum, coord, maxDistanceKilometers)
            rawFeaturesAccum.clear()
            rawFeaturesAccum += deduped
        }
        recordDebugParseBreakdown(
            DebugParseBreakdown(
                featureCount = debugFeatureCountBeforeCluster,
                clusteredFeatureCount = debugClusteredFeatureCount,
                decodeAllMs = debugDecodeAllMs,
                convertMs = debugConvertMs,
                clusterMs = debugClusterMs,
            ),
        )

        if (glStencilMaskTileListener != null || customStencilTileListeners.isNotEmpty()) {
            val featSnapshot = features.toList()
            glStencilMaskTileListener?.invoke(coord, tile.coordHash, featSnapshot)
            if (customStencilTileListeners.isNotEmpty()) {
                for (cb in customStencilTileListeners.values) {
                    cb(coord, tile.coordHash, featSnapshot)
                }
            }
        }
        if (debugMaskTile) {
            val water = features.count { it.getStringProperty("layer") == "water" }
            val inv = features.count { it.getStringProperty("layer") == "water::inverted" }
            MapsGLDebug.trace("[MaskDebug][Parse] key=${coord.z}/${coord.x}/${coord.y} features=${features.size} water=$water inv=$inv")
        }

        if (shouldLogSymbolMvtDebug()) {
            val now = SystemClock.elapsedRealtime()
            if (now - lastSymbolMvtDebugLogMs >= 2_000L) {
                lastSymbolMvtDebugLogMs = now
                val points = features.count {
                    when (val g = it.geometry()) {
                        is Point, is MultiPoint -> true
                        else -> false
                    }
                }
                val layerTags = features.mapNotNull { featureLayerTag(it) }.distinct()
                val wasGzipped = data.size != pbf.size
                MapsGLDebug.logD(
                    TAG,
                    "parse ${coord.z}/${coord.x}/${coord.y} gzip=$wasGzipped raw=${data.size} pbf=${pbf.size} " +
                        "tileLayers=$tileLayerNames needed=$neededLayerNames features=${features.size} points=$points " +
                        "layerTags=$layerTags consumers=${consumers.map { "${it.layerId}:${it.sourceLayerId}" }} " +
                        "zoom=${CameraSync.zoomForCustomLayerInstancing()}",
                )
            }
        }

        VectorData(validTime, features, rawFeatures = if (anyRawLayerParsed) rawFeaturesAccum else null)
        }
    }

    private fun inverseTileFeatures(features: List<Feature>, tileCoord: TileCoord): Feature? {
        if (features.isEmpty()) {
            // Inverting "no water" is ambiguous (all-ocean vs all-land with empty layer). The legacy
            // path used a full-tile outer ring as "land" with no holes, which stencils the entire
            // weather quad (stencil=1) so GL_EQUAL 0 rejects every fragment — the marine layer vanishes.
            // Safer: no land mask for this tile; marine still shows; rare land tiles with no water
            // layer may show marine on land.
            return null
        }
        var currentBounds = getLatLonBoundsOfTile(tileCoord)

        // Expand bounds to fully contain buffered features
        val allCoords: List<Point> = features
            .mapNotNull { feature ->
                when (val geom = feature.geometry()) {
                    is Polygon -> geom.coordinates().flatten()                  // List<List<Point>> -> List<Point>
                    is MultiPolygon -> geom.coordinates().flatten()
                        .flatten()   // List<List<List<Point>>> -> List<Point>
                    else -> null
                }
            }
            .flatten()

        if (allCoords.isNotEmpty()) {
            val minLat = allCoords.minOfOrNull { it.latitude() }?.let {
                min(currentBounds.southExtent, it)
            } ?: currentBounds.southExtent
            val maxLat = allCoords.maxOfOrNull { it.latitude() }?.let {
                max(currentBounds.northExtent, it)
            } ?: currentBounds.northExtent
            val minLon = allCoords.minOfOrNull { it.longitude() }?.let {
                min(currentBounds.westExtent, it)
            } ?: currentBounds.westExtent
            val maxLon = allCoords.maxOfOrNull { it.longitude() }?.let {
                max(currentBounds.eastExtent, it)
            } ?: currentBounds.eastExtent

            currentBounds = LatLonBounds(
                minLon,
                minLat,
                maxLon,
                maxLat
            )

            if (pr.ON) pr.p(
                TAG,
                pr.invVec2,
                "inverseTileFeatures() db bounds:lon: ${(maxLon - minLon).toInt()} ($minLon / $maxLon)  lat: ${(maxLat - minLat).toInt()}  ($minLat / $maxLat)  ",
            )

            if (pr.ON) for (coord in allCoords) {
                if (pr.ON) pr.p(TAG, pr.invVec2, "   coord:$coord  ")
            }

        }

        //outer ring is CCW
        val outerRing: List<Point> = listOf(
            Point.fromLngLat(currentBounds.westExtent, currentBounds.southExtent),
            Point.fromLngLat(currentBounds.eastExtent, currentBounds.southExtent),
            Point.fromLngLat(currentBounds.eastExtent, currentBounds.northExtent),
            Point.fromLngLat(currentBounds.westExtent, currentBounds.northExtent),
            Point.fromLngLat(currentBounds.westExtent, currentBounds.southExtent)
        ).reversedIfClockwise()

        val holeRings: MutableList<List<Point>> = mutableListOf()

        for (feature in features) {
            when (val geom = feature.geometry()) {
                is Polygon -> {
                    val rings: List<List<Point>> = geom.coordinates()
                    rings.forEachIndexed { index, ring ->
                        val corrected = if (index == 0) {
                            ring.reversedIfClockwise()           // outer -> hole, ensure CCW->CW
                        } else {
                            ring.reversedIfCounterClockwise()     // inner -> outer-of-hole, ensure CW->CCW
                        }
                        holeRings.add(corrected)
                    }
                }

                is MultiPolygon -> {
                    val polys: List<List<List<Point>>> = geom.coordinates()
                    polys.forEach { poly ->
                        poly.forEachIndexed { index, ring ->
                            val corrected = if (index == 0) {
                                ring.reversedIfClockwise()
                            } else {
                                ring.reversedIfCounterClockwise()
                            }
                            holeRings.add(corrected)
                        }
                    }
                }

                else -> {
                    // ignore non-polygonal geometry
                }
            }
        }

        if (holeRings.isEmpty()) {
            // No polygonal water to punch out: do not use outerRing alone (full-tile = all land in stencil).
            // That happens for water layer that only has points/lines, or non-polygon geometry.
            return null
        }
        val allRings = ArrayList<List<Point>>(1 + holeRings.size)
        allRings.add(outerRing)
        allRings.addAll(holeRings)
        val feature: Feature = Feature.fromGeometry(Polygon.fromLngLats(allRings))

        feature.addNumberProperty("now", System.currentTimeMillis().toDouble())
        feature.addStringProperty("featureType", "Polygon")
        feature.addStringProperty("geometry-type", "Polygon")

        return feature
    }

    /**
     * Snaps [intervalTime] to the key that [requestTile] will use: nearest metadata entry when
     * within the metadata range, or granularity-rounded otherwise. Both [requestTile] and
     * [hasTimeSeriesIntervalAt] must use this same logic so cache checks and HTTP requests always
     * refer to the same key.
     */
    private fun snapFetchTime(intervalTime: Date): Date {
        if (vectorValidTimes.isEmpty()) return intervalTime
        val granularityMs = if (vectorValidTimes.size >= 2)
            vectorValidTimes[1].time - vectorValidTimes[0].time else 0L
        return if (granularityMs > 0 && intervalTime.time < vectorValidTimes.first().time) {
            // Before the metadata range — round down to product granularity so the tile URL
            // matches what the AMP server stores (granularity-aligned, not oldest metadata entry).
            Date((intervalTime.time / granularityMs) * granularityMs)
        } else {
            nearestValidTime(intervalTime.time)
        }
    }

    /**
     * Rule: snap-fetch-time-alloc. [snapFetchTime] runs on the hot per-frame playback draw path
     * (via [snappedTimeSeriesIntervalMs]) — the previous `vectorValidTimes.minByOrNull { abs(...) }`
     * linearly scanned the whole list AND boxed a `Long` per comparison every single call. Measured
     * via an ART allocation-counter diagnostic: ~500-800KB allocated per rendered frame during
     * playback (vs. ~80KB/frame paused), matching a 1000-entry vectorValidTimes list's boxing cost
     * multiplied across the several call sites that resolve a snapped interval each frame. A binary
     * search over the (guaranteed-sorted — see the two assignment sites) list finds the same nearest
     * entry in O(log n) with zero allocation.
     */
    private fun nearestValidTime(targetMs: Long): Date {
        val list = vectorValidTimes
        var lo = 0
        var hi = list.size - 1
        while (lo < hi) {
            val mid = (lo + hi) ushr 1
            if (list[mid].time < targetMs) lo = mid + 1 else hi = mid
        }
        if (lo == 0) return list[0]
        val after = list[lo]
        val before = list[lo - 1]
        return if (targetMs - before.time <= after.time - targetMs) before else after
    }

    /** True when the spatial time-series tile already holds parsed data for [intervalMs]. */
    fun hasTimeSeriesDataLoadedAt(z: Int, x: Int, y: Int, intervalMs: Long): Boolean {
        if (!isTimeSeriesSource) return false
        val snappedMs = snappedTimeSeriesIntervalMs(intervalMs)
        val series = getTileData(spatialTileCoord(x, y, z)) as? VectorTimeSeriesData ?: return false
        return series.hasDataForInterval(snappedMs)
    }

    /** Epoch ms key used for MVT fetch and [VectorTimeSeriesData] lookup. */
    fun snappedTimeSeriesIntervalMs(intervalMs: Long): Long = snapFetchTime(Date(intervalMs)).time

    /** True when data is cached or a download is already in flight (dedupe prefetch). */
    fun hasTimeSeriesIntervalAt(z: Int, x: Int, y: Int, intervalMs: Long): Boolean {
        if (!isTimeSeriesSource) return false
        val coord = spatialTileCoord(x, y, z)
        val snappedMs = snapFetchTime(Date(intervalMs)).time
        // Already downloaded.
        val series = getTileData(coord) as? VectorTimeSeriesData
        if (series?.hasDataForInterval(snappedMs) == true) return true
        if (hasNativeMvtBytesAt(z, x, y, intervalMs)) return true
        // Download in progress — don't fire a duplicate request.
        return inFlightTileKeys.contains("${coord.hash()}/$snappedMs")
    }

    /** True when a download is in flight for (coord, interval) but parsed data is not cached yet. */
    fun isTimeSeriesIntervalDownloading(z: Int, x: Int, y: Int, intervalMs: Long): Boolean {
        if (!isTimeSeriesSource) return false
        val coord = spatialTileCoord(x, y, z)
        val snappedMs = snapFetchTime(Date(intervalMs)).time
        val series = getTileData(coord) as? VectorTimeSeriesData
        if (series?.hasDataForInterval(snappedMs) == true) return false
        return inFlightTileKeys.contains("${coord.hash()}/$snappedMs")
    }

    /** Retained MVT bytes exist but [VectorTimeSeriesData] has no parsed snapshot yet. */
    fun hasUnparsedNativeMvtAt(z: Int, x: Int, y: Int, intervalMs: Long): Boolean {
        if (!isTimeSeriesSource || !retainNativeMvtBytes) return false
        if (hasTimeSeriesDataLoadedAt(z, x, y, intervalMs)) return false
        return hasNativeMvtBytesAt(z, x, y, intervalMs)
    }

    /** Count of (spatial tile, interval) MVT HTTP requests actively downloading. */
    fun inFlightTimeSeriesTileCount(): Int =
        if (!isTimeSeriesSource) 0 else activeTimeSeriesDownloads.get()

    /** True while any time-series tile HTTP requests are still in flight. */
    fun isLoadingTimeSeriesTiles(): Boolean =
        isTimeSeriesSource && (inFlightTileKeys.isNotEmpty() || activeTimeSeriesDownloads.get() > 0)

    /**
     * Finds a cached vector tile by nominal z/x/y. Tries the [validTime] key first, then scans the
     * cache so draws still resolve tiles after subtle key drift (e.g. time format rounding).
     */
    fun findCachedVectorTileForNominalZxy(
        z: Int,
        x: Int,
        y: Int,
        allowStaleTimeFallback: Boolean = true,
    ): Tile<VectorData>? {
        if (isTimeSeriesSource) {
            spatialTileCoord(x, y, z).let { spatial ->
                vectorTileCache[spatial]?.takeIf { it.data != null }?.let { return it }
            }
        }
        val preferred = TileCoord(x, y, z, 0, formatDateArrayToString(listOf(validTime)))
        vectorTileCache[preferred]?.takeIf { it.data != null }?.let { return it }
        if (!allowStaleTimeFallback) return null
        fun pickFrom(cache: TileCache<VectorData>): Tile<VectorData>? {
            for (tile in cache.tiles.values) {
                if (tile.coord.z != z || tile.coord.x != x || tile.coord.y != y) continue
                if (tile.data == null) continue
                @Suppress("UNCHECKED_CAST")
                return tile as Tile<VectorData>
            }
            return null
        }
        pickFrom(vectorTileCache)?.let { return it }
        @Suppress("UNCHECKED_CAST")
        pickFrom(tileCache as TileCache<VectorData>)?.let { return it }
        return null
    }

    /**
     * Cached tile coords at zoom [z] that already hold parsed [VectorData].
     * Used when viewport enumeration yields no coords but MVTs have loaded (e.g. alert point legends).
     */
    fun cachedTileCoordsWithDataAtZ(z: Int): List<TileCoord> {
        val seen = HashSet<String>()
        val out = ArrayList<TileCoord>()
        fun consider(tile: Tile<VectorData>) {
            if (tile.coord.z != z || tile.data == null) return
            val key = "${tile.coord.z}/${tile.coord.x}/${tile.coord.y}"
            if (seen.add(key)) out.add(tile.coord)
        }
        for (tile in vectorTileCache.tiles.values) {
            @Suppress("UNCHECKED_CAST")
            consider(tile as Tile<VectorData>)
        }
        @Suppress("UNCHECKED_CAST")
        val secondary = tileCache as TileCache<VectorData>
        for (tile in secondary.tiles.values) consider(tile)
        return out
    }
}

/**
 * Epoch millis from [report] `startDateISO`, aligned with JavaScript `new Date(report.startDateISO).getTime()`.
 * Null when the field is absent or not parseable (Invalid Date on the web).
 */
private fun fireReportStartEpochMillisFromIso(report: Map<String, Any>): Double? {
    val iso = report["startDateISO"] as? String ?: return null
    return try {
        java.time.OffsetDateTime.parse(iso).toInstant().toEpochMilli().toDouble()
    } catch (_: Exception) {
        try {
            java.time.Instant.parse(iso).toEpochMilli().toDouble()
        } catch (_: Exception) {
            null
        }
    }
}

/**
 * Fires-obs styling uses `report.startDateISO` only for the 24h "new" rule (see web `getFireObsPointStyle`).
 * We store that instant as `report.startTimestampMillis` for Mapbox expressions.
 */
private fun injectFireReportStartTimestampMillisForStyle(properties: MutableMap<String, Any>) {
    val reportObj = properties["report"] as? Map<String, Any> ?: return
    if (reportObj.containsKey("startTimestampMillis")) return
    val report = reportObj.toMutableMap()
    val millis = fireReportStartEpochMillisFromIso(report) ?: return
    report["startTimestampMillis"] = millis
    properties["report"] = report
}

/**
 * AMP / MapsGL vector tiles are often `Content-Encoding: gzip`. [java.net.HttpURLConnection] may
 * leave the body gzip-wrapped on some devices; the MVT decoder needs raw protobuf bytes.
 */
internal fun gunzipVectorTileIfNeeded(data: ByteArray): ByteArray {
    if (data.size < 2) return data
    if (data[0] != 0x1f.toByte() || data[1] != 0x8b.toByte()) return data
    return try {
        GZIPInputStream(data.inputStream()).use { it.readBytes() }
    } catch (_: Exception) {
        data
    }
}

fun nestedDictionary(flat: Map<String, Any>): Map<String, Any> {
    fun insert(target: Any?, keys: List<String>, value: Any): Any {
        if (keys.isEmpty()) return target ?: value

        val key = keys.first()
        val remainingKeys = keys.drop(1)

        return if (key.toIntOrNull() != null) {
            val index = key.toInt()
            val array = (target as? List<Any?>)?.toMutableList() ?: mutableListOf()

            while (array.size <= index) {
                array.add(null)
            }

            array[index] = insert(array[index], remainingKeys, value)
            array
        } else {
            val dict = (target as? Map<*, *>)?.toMutableMap() ?: mutableMapOf()
            dict[key] = insert(dict[key], remainingKeys, value)
            dict
        }
    }

    var result: Any = mutableMapOf<String, Any>()

    for ((flatKey, value) in flat) {
        val keys = flatKey.split(".")
        result = insert(result, keys, value)
    }

    @Suppress("UNCHECKED_CAST")
    return result as? Map<String, Any> ?: emptyMap()
}
