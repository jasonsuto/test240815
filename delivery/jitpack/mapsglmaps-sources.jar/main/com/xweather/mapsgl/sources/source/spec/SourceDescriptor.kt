package com.xweather.mapsgl.sources.source.spec

import com.xweather.mapsgl.weather.XweatherAuthenticator
import com.xweather.mapsgl.coordinates.LatLonBounds
import com.xweather.mapsgl.types.DataSourceKind
import com.xweather.mapsgl.types.TileSize
import com.xweather.mapsgl.weather.EncodedDataset

/**
 * Declarative configuration for a data source before it is registered on a [com.xweather.mapsgl.map.MapController].
 *
 * Implementations describe tile URLs, metadata, bounds, and optional authentication. The controller’s
 * [com.xweather.mapsgl.map.MapController.addSource] turns a descriptor into a live
 * [com.xweather.mapsgl.sources.DataSource].
 *
 * @property id Stable id used as the Mapbox style source id and MapsGL registry key.
 * @property kind Discriminator matching [com.xweather.mapsgl.sources.DataSource.kind] after registration.
 *
 * @see com.xweather.mapsgl.map.MapController.addSource
 */
interface SourceDescriptor {
    val id: String
    val kind: DataSourceKind
}

/** @deprecated Use [SourceDescriptor.kind] instead. */
val SourceDescriptor.type: DataSourceKind
    @Deprecated("Use `kind` instead.")
    get() = kind

/**
 * Raster or image-tile source (PNG/JPEG tiles, satellite, etc.).
 *
 * @property url Tile URL template with `{z}`, `{x}`, `{y}` and optional time/subdomain tokens per product docs.
 * @property metadataUrl Endpoint for tile metadata / valid times when applicable.
 * @property minZoom Lowest zoom level served (optional).
 * @property maxZoom Highest zoom level served (optional).
 * @property bounds Geographic limits for the source, if any.
 * @property tileSize Logical tile size in px (often 256 or 512).
 * @property attribution Attribution string for the map.
 * @property authenticator Optional per-source signing; when null, [com.xweather.mapsgl.map.MapController] may apply
 *   the shared [com.xweather.mapsgl.weather.WeatherService.authenticator].
 */
data class ImageSourceDescriptor(
    override val id: String,
    var url: String? = null,
    var metadataUrl: String? = null,
    var minZoom: Float? = null,
    var maxZoom: Float? = null,
    var bounds: LatLonBounds? = null,
    var tileSize: TileSize? = null,
    var attribution: String? = null,
    var authenticator: XweatherAuthenticator? = null
) : SourceDescriptor {
    override val kind: DataSourceKind
        get() = DataSourceKind.RASTER
}

/**
 * MapsGL **encoded** grid source (multi-band numeric tiles consumed by sample/contour/particle layers).
 *
 * @property datasets Band definitions and decoding hints; required for encoded pipelines.
 *
 * Other fields match [ImageSourceDescriptor] semantics for URLs, zoom, bounds, and auth.
 *
 * @see com.xweather.mapsgl.sources.EncodedTileSource
 */
data class EncodedSourceDescriptor(
    override val id: String,
    var url: String? = null,
    var metadataUrl: String? = null,
    var minZoom: Float? = null,
    var maxZoom: Float? = null,
    var bounds: LatLonBounds? = null,
    var tileSize: TileSize? = null,
    var attribution: String? = null,
    var authenticator: XweatherAuthenticator? = null,
    var datasets: List<EncodedDataset>? = null
) : SourceDescriptor {
    override val kind: DataSourceKind
        get() = DataSourceKind.ENCODED
}

/**
 * Legacy Aeris-style encoded source kind; same shape as [EncodedSourceDescriptor] with nullable fields.
 *
 * Prefer [EncodedSourceDescriptor] for new code unless a product still reports [DataSourceKind.AERIS_ENCODED].
 */
data class XweatherEncodedSourceDescriptor(
    override val id: String,
    var url: String?,
    var metadataUrl: String?,
    var minZoom: Float?,
    var maxZoom: Float?,
    var bounds: LatLonBounds?,
    var tileSize: TileSize?,
    var attribution: String?,
    var authenticator: XweatherAuthenticator?,
    var datasets: List<EncodedDataset>?
) : SourceDescriptor {
    override val kind: DataSourceKind
        get() = DataSourceKind.AERIS_ENCODED
}

/**
 * @param url Tile URL template. Always includes `{z}`, `{x}`, `{y}`; `{s}` is a subdomain index (1–4), see [com.xweather.mapsgl.sources.TileSource.makeTileURL].
 * If [authenticator] is an [com.xweather.mapsgl.weather.XweatherAuthenticator] (for example [com.xweather.mapsgl.weather.WeatherService.authenticator]),
 * these placeholders are also merged each request: `{accessKey}` (client id + `_` + secret), `{clientId}`, `{clientSecret}`,
 * and the documentation segment `[CLIENT_ID]_[CLIENT_SECRET]`.
 * When [authenticator] is null, [com.xweather.mapsgl.map.MapController.addSource] uses the controller's
 * [com.xweather.mapsgl.weather.WeatherService.authenticator] automatically.
 *
 * **Time in the path (Aeris / AMP-style vector tiles):** use a `{time::…}` token so each tile request uses
 * [com.xweather.mapsgl.sources.VectorTileSource.validTime] (driven by the map timeline), the same pattern as
 * `WeatherService.vectorTileURLPathTemplate` (`/{accessKey}/{code}/{z}/{x}/{y}/{time::utc:format[yyyyMMddhhmm00]}.pbf`).
 * That expands to a **14-digit** UTC offset (`yyyyMMddHHmm` plus a literal `00` suffix from the format string).
 * A hand-written **12-digit** segment (e.g. `202603061110`) is usually not the same offset the API expects and often yields
 * `missing_resource_error`. Use `…/0.pbf` only when the product docs say that offset selects the correct tiles.
 */
data class VectorSourceDescriptor(
    override val id: String,
    var url: String? = null,
    var metadataUrl: String? = null,
    var minZoom: Float? = null,
    var maxZoom: Float? = null,
    var bounds: LatLonBounds? = null,
    var tileSize: TileSize? = null,
    var attribution: String? = null,
    var authenticator: XweatherAuthenticator? = null,
) : SourceDescriptor {
    override val kind: DataSourceKind
        get() = DataSourceKind.VECTOR
}

/**
 * Configuration for a GeoJSON-backed source. At runtime, [com.xweather.mapsgl.map.MapController.addSource]
 * creates a [com.xweather.mapsgl.sources.GeoJSONSource]; use [com.xweather.mapsgl.map.MapController.getSource] and cast
 * to that type to set [com.xweather.mapsgl.sources.GeoJSONSource.data] or adjust [com.xweather.mapsgl.sources.GeoJSONSource.url]
 * after registration.
 *
 * **Provide GeoJSON in one of three ways:**
 * 1. [bundledAssetPath] — path under the host app's `src/main/assets/` (loaded on [com.xweather.mapsgl.map.MapController.addSource]).
 * 2. Assign [com.xweather.mapsgl.sources.GeoJSONSource.data] after addSource (inline JSON via [com.mapbox.geojson.FeatureCollection.fromJson],
 *    or an asset path via [com.xweather.mapsgl.sources.GeoJSONSource.parseJsonOrAsset]).
 * 3. [url] — remote GeoJSON endpoint template.
 */
data class GeoJSONSourceDescriptor(
    override val id: String,
    var url: String? = null,
    var metadataUrl: String? = null,
    var minZoom: Float? = null,
    var maxZoom: Float? = null,
    var bounds: LatLonBounds? = null,
    var tileSize: TileSize? = null,
    var attribution: String? = null,
    var authenticator: XweatherAuthenticator? = null,
    /**
     * Optional Android asset path packaged under `src/main/assets/` (app or MapsGL SDK AAR).
     * When set, [com.xweather.mapsgl.map.MapController.addSource] loads the GeoJSON into
     * [com.xweather.mapsgl.sources.GeoJSONSource.data] automatically.
     */
    var bundledAssetPath: String? = null,
) : SourceDescriptor {
    override val kind: DataSourceKind
        get() = DataSourceKind.GEOJSON

    /**
     * In-memory GeoJSON only — set [com.xweather.mapsgl.sources.GeoJSONSource.data] after [com.xweather.mapsgl.map.MapController.addSource].
     * Prefer this constructor over default-arg `GeoJSONSourceDescriptor(id = …)` when linking against a minified AAR.
     */
    constructor(id: String) : this(
        id = id,
        url = null,
        metadataUrl = null,
        minZoom = null,
        maxZoom = null,
        bounds = null,
        tileSize = null,
        attribution = null,
        authenticator = null,
        bundledAssetPath = null,
    )

    /**
     * Loads GeoJSON from [bundledAssetPath] under the host app's `src/main/assets/` when the source is added.
     * Example: `GeoJSONSourceDescriptor("countries", "geojson/conus.geojson")`.
     */
    constructor(id: String, bundledAssetPath: String) : this(
        id = id,
        url = null,
        metadataUrl = null,
        minZoom = null,
        maxZoom = null,
        bounds = null,
        tileSize = null,
        attribution = null,
        authenticator = null,
        bundledAssetPath = bundledAssetPath,
    )
}