package com.xweather.mapsgl.sources.data

import ImageRepresentable
import com.xweather.mapsgl.sources.DataPool
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.types.ColorBand
import com.xweather.mapsgl.types.SampleExpression
import com.xweather.mapsgl.types.Size
import padBitmap
import padBitmapRadar
import java.util.Date
import kotlin.math.atan2
import kotlin.math.sqrt

/**
 * EncodedData.kt
 *
 *  Represents encoded tile data such as PNG or JPEG images that contain indexed data or numerical values encoded into one or more color bands of an image.
 *
 * Adapted from IOS version
 * @author Jason Suto 01/09/24
 **/

/** @suppress */
open class EncodedData(
    data: ByteArray,
    blend: Boolean,
    var padding: Int,
    val id: String = "",
    /**
     * When true, [init] is not run: padded RGBA is produced in native ([com.xweather.mapsgl.NativeLibCache.splitAndPadEncodedTilesToByteArrays]
     * or [com.xweather.mapsgl.NativeLibCache.padEncodedRgbaToPaddedByteArray]) and assigned to [paddedData] before edge backfill
     * (see [XweatherEncodedTileSource]).
     */
    private val deferPadToNativePipeline: Boolean = false,
) : TileData {


    val stride = 4
    var dimension = DataPool.originalSize
    val originalSize = dimension
    var paddedData: ByteArray? = null
    private var _backfilledEdges: MutableList<String> = mutableListOf()
    private val isRadar = com.xweather.mapsgl.weather.WeatherSource.isRadarEncodedSourceId(id)

    init {
        if (blend) {
            dimension += (padding + padding)
        }
        if (!deferPadToNativePipeline && padding > 0) {
            throw IllegalStateException(
                "EncodedData requires deferPadToNativePipeline when padding > 0 (id=$id); " +
                    "use native padding + cache getData.",
            )
        }
        if (!deferPadToNativePipeline) {
            init(data)
        }
    }

    final override fun init(byteArrayOf: ByteArray) {
        // padding > 0 uses native only (see init block). Remaining path is padding == 0 (e.g. EncodedTimeSeriesData).
        paddedData = if (!isRadar) {
            padBitmap(byteArrayOf, originalSize, padding)
        } else {
            padBitmapRadar(byteArrayOf, originalSize, padding)
        }
    }

    private fun createImage(size: Size, channels: Int, data: ByteArray? = null): ImageRepresentable {
        val width = size.width
        val height = size.height

        val imageData = if (data == null) {
            ByteArray(width * height * channels)
        } else if (data.size != width * height * channels) {
            throw Error("mismatched image size. expected: ${data.size} but got: ${width * height * channels}")
        } else {
            data
        }

        return ImageRepresentable(width, height, imageData)
    }

    // MARK: Hashable Conformance
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other == null || javaClass != other.javaClass) return false
        return true
    }

    override fun hashCode(): Int {
        return 0
    }


    /**
     * Translates the backfill logic for time-series data.
     * Iterates through each time entry and performs the edge backfill on the underlying images.
     */
    fun backfillEdge(neighborData: EncodedData, dx: Int, dy: Int) {

        // Perform the actual byte copying logic
        // Note: You'll need a neighborData object of type EncodedData
        // to call the base backfillEdge defined in the parent class.

        // If your 'Entry' contains the EncodedData object:
        backfillEdgeWorker(neighborData, dx, dy)

        // If you are updating textures (equivalent to needsUpdate = true):

        //}
    }

    /**
     * Backfills the specified edge with data from the neighboring tile.
     * @param neighborData - The neighboring tile data.
     * @param dx - The x-coordinate of the neighbor relative to this tile (-1, 0, or 1).
     * @param dy - The y-coordinate of the neighbor relative to this tile (-1, 0, or 1).
     */
    fun backfillEdgeWorker(neighborData: EncodedData, dx: Int, dy: Int) {
        // Ensure dimensions match (originalSize is 512, dimension is 512 + padding*2)
        assert(neighborData.dimension == this.dimension) {
            "EncodedData mismatch - neighbor data must have the same dimension as instance data, " +
                    "${this.dimension} does not equal ${neighborData.dimension}"
        }

        // Don't backfill the same edge more than once
        val edgeKey = "$dx,$dy"
        if (_backfilledEdges.contains(edgeKey)) {
            return
        }

        val pad = this.padding
        val dim = this.dimension // This is already originalSize + pad + pad
        val source = neighborData.paddedData ?: return
        val dest = this.paddedData ?: return


        // Initial coordinates (defaulting to the 'core' data area)
        var sx = pad
        var sy = pad
        var tx = pad
        var ty = pad

        // Initial dimensions (defaulting to a corner block size)
        var w = pad
        var h = pad

        val opp = dim - pad
        val BYTESIZE = 4 // RGBA
        val rowWidthBytes = dim * BYTESIZE

        // Determine the source and target coordinates for the edge to backfill
        if (dx == -1) {
            // Neighbor is to the LEFT: Copy neighbor's right edge to our left padding
            sx = opp - pad
            tx = 0
        } else if (dx == 1) {
            // Neighbor is to the RIGHT: Copy neighbor's left edge to our right padding
            sx = pad
            tx = opp
        }

        if (dy == -1) {
            // Neighbor is ABOVE: Copy neighbor's bottom edge to our top padding
            sy = opp - pad
            ty = 0
        } else if (dy == 1) {
            // Neighbor is BELOW: Copy neighbor's top edge to our bottom padding
            sy = pad
            ty = opp
        }

        // Adjust the width and height if we are copying a full side rather than a corner
        if (dx == 0) {
            w = dim - (pad * 2)
        }
        if (dy == 0) {
            h = dim - (pad * 2)
        }

        // Perform the row-by-row copy (Equivalent to copyImage)
        for (i in 0 until h) {
            val sourceRowOffset = (sy + i) * rowWidthBytes + (sx * BYTESIZE)
            val destRowOffset = (ty + i) * rowWidthBytes + (tx * BYTESIZE)
            val length = w * BYTESIZE

            if (sourceRowOffset + length <= source.size && destRowOffset + length <= dest.size) {
                System.arraycopy(source, sourceRowOffset, dest, destRowOffset, length)
            }
        }

        _backfilledEdges.add(edgeKey)
    }
}


// MARK: - EncodedTimeSeriesData
/// Represents time-based encoded tile data structured into a time series.
/** @suppress */
class EncodedTimeSeriesData(series: List<Entry>) : EncodedData(byteArrayOf(), false, 0) {
    /// Represents a single entry in the time series.
    data class Entry(var date: Date, var inputData: ByteArray) {
        fun setData(data: ByteArray) {
            this.inputData = data
        }

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (javaClass != other?.javaClass) return false

            other as Entry

            if (date != other.date) return false
            if (!inputData.contentEquals(other.inputData)) return false

            return true
        }

        override fun hashCode(): Int {
            var result = date.hashCode()
            result = 31 * result + inputData.contentHashCode()
            return result
        }
    }

    /// An identifier for the time series.
    var entryID: String? = null

    /// The time series entries.
    var series: MutableList<Entry> = series.toMutableList()


    init {
        //super.init(byteArrayOf())
        this.series = series.toMutableList()
    }

    /// Sets the data for the time series entry with the specified date.
    fun setData(data: ByteArray, date: Date) {
        val index = this.series.indexOfFirst { it.date == date }
        if (index != -1) {
            this.series[index].setData(data)
        }
    }

    // MARK: Hashable Conformance
    // Notes From Slipp?
    // TODO: This is likely wrong, violating Liskov Substitution Principle and potentially causing issues with hashtable-based storage (`Dictionary`s, `Set`s, etc.).  See: https://forums.swift.org/t/implement-equatable-protocol-in-a-class-hierarchy/13844
    // 	Alternative: Make `EncodedData` & `EncodedTimeSeriesData` final classes or structs, with only associated protocols `EncodedDataProtocol` & `EncodedTimeSeriesDataProtcol` having an inheritence hierarchy.
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other == null || javaClass != other.javaClass) return false
        other as EncodedTimeSeriesData
        if (super.equals(other) && entryID == other.entryID && series == other.series) {
            return true
        }
        return false
    }

    override fun hashCode(): Int {
        var result = super.hashCode()
        result = 31 * result + (entryID?.hashCode() ?: 0)
        result = 31 * result + series.hashCode()
        return result
    }


}

/**
 * Evaluates this expression against an RGBA pixel using named channels.
 *
 * @param pixel RGBA pixel data as ByteArray (pixel.size >= 4). Each byte will be treated as an unsigned value (0-255).
 * @param channels Channels to use in order of relevance to the expression.
 *                 - NUMBER uses channels[0]
 *                 - VECTOR, SUM, DIFFERENCE, ANGLE use channels[0] and channels[1]
 * @param map Optional mapping function from an unsigned byte value (0-255) to a Double.
 * @return A single scalar value, or `null` if inputs are insufficient.
 */
fun SampleExpression.evaluate(
    pixel: ByteArray,
    channels: List<ColorBand>,
    map: (Int) -> Double = { it.toDouble() } // Parameter is Int (0-255)
): Double? {
    if (pixel.size < 4) return null

    // Helper to safely fetch and map a channel byte (0-255)
    fun getValueFromChannel(channel: ColorBand): Double? {
        if (channel.rawValue < 0 || channel.rawValue >= pixel.size) { // Basic bounds check
            // Log.w("SampleExpression", "Channel rawValue ${channel.rawValue} is out of bounds for pixel array size ${pixel.size}")
            return null
        }
        val unsignedByteValue = pixel[channel.rawValue].toInt() and 0xFF // Convert signed Byte to unsigned Int (0-255)
        return map(unsignedByteValue)
    }

    return when (this) {
        SampleExpression.NUMBER -> {
            val c0 = channels.firstOrNull() ?: return null
            getValueFromChannel(c0)
        }

        SampleExpression.VECTOR -> {
            if (channels.size < 2) return null
            val dx = getValueFromChannel(channels[0]) ?: return null
            val dy = getValueFromChannel(channels[1]) ?: return null
            sqrt(dx * dx + dy * dy) // In Kotlin, sqrt is a top-level function or extension
        }

        SampleExpression.SUM -> {
            if (channels.size < 2) return null
            val v0 = getValueFromChannel(channels[0]) ?: return null
            val v1 = getValueFromChannel(channels[1]) ?: return null
            v0 + v1
        }

        SampleExpression.DIFFERENCE -> {
            if (channels.size < 2) return null
            val v0 = getValueFromChannel(channels[0]) ?: return null
            val v1 = getValueFromChannel(channels[1]) ?: return null
            v0 - v1
        }

        SampleExpression.ANGLE -> {
            if (channels.size < 2) return null
            // atan2 arguments are typically (y, x)
            val yVal = getValueFromChannel(channels[1]) ?: return null
            val xVal = getValueFromChannel(channels[0]) ?: return null
            atan2(y = yVal, x = xVal)
        }

        SampleExpression.ENCODED_WIND_UV -> {
            if (channels.size < 2) return null
            val gRaw = getValueFromChannel(channels[0]) ?: return null
            val bRaw = getValueFromChannel(channels[1]) ?: return null
            val uWind = (gRaw / 255.0) * 107.28 - 53.64
            val vWind = (bRaw / 255.0) * 107.28 - 53.64
            Math.toDegrees(atan2(uWind, -vWind))
        }

        SampleExpression.CUSTOM -> {
            // For custom, just return the first provided channel by default.
            // Behavior for CUSTOM might need more specific definition in Kotlin.
            val c0 = channels.firstOrNull() ?: return null
            getValueFromChannel(c0)
        }
        // else -> null // Handle any other cases if your enum is more complex or not sealed
        SampleExpression.NO_DATA -> TODO()
    }
}

/**
 * Convenience: evaluates while linearly mapping unsigned byte values (0…255) into a target range.
 *
 * @param pixel RGBA pixel data as ByteArray (pixel.size >= 4).
 * @param channels Channels to use.
 * @param mappingRange The target range to map the 0-255 channel values into.
 * @return A single scalar value, or `null` if inputs are insufficient.
 */
fun SampleExpression.evaluate(
    pixel: ByteArray,
    channels: List<ColorBand>, // Assuming PixelChannel is typealias for ColorBand or similar
    mappingRange: ClosedFloatingPointRange<Double>
): Double? {
    val lo = mappingRange.start             // In Kotlin, use .start
    val hi = mappingRange.endInclusive    // In Kotlin, use .endInclusive
    val scale = hi - lo

    if (this == SampleExpression.ENCODED_WIND_UV) {
        return evaluate(pixel, channels) { it.toDouble() }
    }
    // The map function here takes an Int (0-255) and returns a Double
    return evaluate(pixel = pixel, channels = channels) { unsignedByteValue -> // Lambda parameter is Int (0-255)
        lo + (unsignedByteValue.toDouble() / 255.0) * scale
    }
}
