package com.xweather.mapsgl.sources

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.SystemClock
import com.mapbox.geojson.Feature
import com.mapbox.geojson.Point
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.style.ColorScaleOptions
import com.xweather.mapsgl.style.EncodedShaderPalette
import com.xweather.mapsgl.tiles.Tile
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.utils.formatDateArrayToString
import com.xweather.mapsgl.utils.parseDateArrayFromString
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Date
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sinh
import kotlin.math.tan
import android.graphics.Color as AndroidColorH

/**
 * Sidecar vector source for gridded/symbol layers backed by [XweatherEncodedTileSource].
 *
 * Mapbox requests geometry per tile via [requestTile]; features are placed on a global Web Mercator
 * world-pixel grid (512×2^zoom) for even screen spacing. Wind uses G/B u/v (`atan2(u,-v)`; [sampleFieldsFromEncodedRgb]).
 * Maritime `*_dir.fill` ([instancedQuadMonochromeWhite]) uses blue-only scalar degrees like JS `EXPRESSION_ANGLE`
 * (`norm * 360 - 180`, wrapped to 0–360°).
 */
class EncodedGridVectorTileSource(
    override val id: String,
    private val encodedSource: XweatherEncodedTileSource,
    gridSpacing: Double,
    iconEncodedColorScale: ColorScaleOptions? = null,
    iconEncodedScalarMax: Double? = null,
    /**
     * Mapbox symbol overlays need timeline meld invalidation so custom-geometry tiles refetch blended icons.
     * Instanced GL wind barbs meld on the GPU ([com.xweather.mapsgl.anim.Timeline.dataMeld]) and skip this work.
     */
    val timelineMeldInvalidatesMapboxTiles: Boolean = true,
    /**
     * When true, [buildInstancedWindBufferDualPhase] writes opaque white per-instance RGB (e.g. maritime wave/swell dir arrows).
     */
    private val instancedQuadMonochromeWhite: Boolean = false,
) : VectorTileSource(id, encodedSource.authenticator) {

    /**
     * World-pixel grid step at zoom-0 basis (see [placementStepPxAtZoom0]); updated from paint via
     * [syncGridSpacingFromPaint] (logical spacing × density × internal scale) for instanced icon parity.
     */
    private var spacing: Double = max(1.0, gridSpacing.toDouble().coerceAtLeast(1.0))

    companion object {
        /**
         * Instanced placement tightens the grid vs authored logical spacing × density (not part of public paint).
         */
        private const val INSTANCED_GRID_SPACING_INTERNAL_SCALE: Double = 0.5

        /** Bins map zoom for cache keys, grid spacing, and Mapbox zoom invalidation (must stay in sync). */
        const val DENSITY_ZOOM_BINS_PER_LEVEL: Double = 64.0

        fun densityKeyForMapZoom(mapZoom: Double): Int =
            (mapZoom * DENSITY_ZOOM_BINS_PER_LEVEL).toInt()

        /**
         * Integer placement zoom for [buildInstancedWindBufferDualPhase] / [buildViewportGridPoints] cache keys.
         *
         * Instanced wind renderers must use this in their **gather key** — not [densityKeyForMapZoom] (64 fractional
         * bins per zoom level). Matching [stablePlacementZoomInt]: small fractional zoom changes during animation
         * were invalidating gather while geometry stayed identical, forcing expensive full CPU rebuilds every frame.
         */
        fun instancingGatherPlacementKey(mapZoom: Double): Int {
            val nearest = mapZoom.roundToInt()
            val snapped =
                if (abs(mapZoom - nearest.toDouble()) <= 0.02) nearest
                else floor(mapZoom).toInt()
            return snapped.coerceAtLeast(0)
        }

        /**
         * Quantized key for visible camera bounds (pan / pitch / bearing). Must match [griddedVectorCacheKey]
         * so the map controller can invalidate when the viewport changes.
         */
        fun viewportKeyForVisibleBounds(bounds: VisibleGeoBounds): String {
            // Increase quantization sensitivity to reduce cache-key collisions between
            // very similar-but-not-identical visible bounds during zoom/pan.
            fun q(d: Double) = (d * 80.0).toInt()
            // When the viewport wraps the antimeridian (east < west), preserve a unique cache key
            // by expressing the eastern edge in the same unwrapped longitude frame.
            val eastUnwrapped = if (bounds.east < bounds.west) bounds.east + 360.0 else bounds.east
            return "vp${q(bounds.west)}_${q(bounds.south)}_${q(eastUnwrapped)}_${q(bounds.north)}"
        }

        // Timeline/per-frame visibility: aggregate icons computed across concurrent tile callbacks.
        private val computedIconsWindowCount = AtomicLong(0L)
        private val computedIconsWindowTiles = AtomicInteger(0)
        private val computedIconsLastLogMs = AtomicLong(0L)

        private fun logComputedIconsWindow(iconsComputed: Int) {
            if (iconsComputed <= 0) return
            val now = SystemClock.elapsedRealtime()
            computedIconsWindowCount.addAndGet(iconsComputed.toLong())
            computedIconsWindowTiles.incrementAndGet()

            // Approximate "per frame" window. Logs no faster than ~60Hz.
            val last = computedIconsLastLogMs.get()
            if (now - last < 16L) return
            if (!computedIconsLastLogMs.compareAndSet(last, now)) return

            val totalIcons = computedIconsWindowCount.getAndSet(0L)
            val totalTiles = computedIconsWindowTiles.getAndSet(0)
            //if (totalTiles > 0) {
            //    println(">> EncodedGridVector iconsComputed/frame~ total=$totalIcons tiles=$totalTiles avgPerTile=${totalIcons / totalTiles}")
            // }
        }
    }

    private val webMercatorMaxLat: Double = 85.05112878

    /** Cap to avoid huge loops on low-zoom tiles. */
    private val maxFeaturesPerSidecarTile: Int = 8000

    private data class TileUv(val tx: Int, val ty: Int, val u: Double, val v: Double)
    private data class GridPoint(val lon: Double, val lat: Double)

    /**
     * Sidecar vector features depend on quantized map zoom; keep separate from [vectorTileCache] keys
     * which do not include density.
     */
    private val griddedVectorDataCache = ConcurrentHashMap<String, VectorData>()

    /**
     * Static placement cache: reuses icon coordinates while camera/viewport are unchanged.
     * Timeline meld updates only recompute per-point properties from encoded data.
     */
    private val griddedGeometryCache = ConcurrentHashMap<String, List<GridPoint>>()

    /**
     * Mapbox [CustomGeometrySource] tiles we have pushed via [MapboxVectorSourceAdapter]; [VectorTileSource.tileCache]
     * is never filled for this source, so [VectorTileSource.invalidate] must be overridden to call
     * [notifyMapboxCustomGeometryTileInvalidation] for each known tile or panning will not refetch geometry.
     */
    private val customGeometryTileKeys = ConcurrentHashMap.newKeySet<String>()

    private fun trackCustomGeometryTile(x: Int, y: Int, z: Int) {
        customGeometryTileKeys.add("$z/$x/$y")
    }

    private fun parseTileKey(key: String): Triple<Int, Int, Int>? {
        val parts = key.split('/')
        if (parts.size != 3) return null
        val z = parts[0].toIntOrNull() ?: return null
        val x = parts[1].toIntOrNull() ?: return null
        val y = parts[2].toIntOrNull() ?: return null
        return Triple(x, y, z)
    }

    private var iconShaderPalette: EncodedShaderPalette.Cache? =
        iconEncodedColorScale?.let { EncodedShaderPalette.cacheForOptions(it) }

    private var iconShaderNormMax: Double =
        iconEncodedScalarMax
            ?: iconEncodedColorScale?.range?.endInclusive
            ?: 53.64

    /**
     * Rebuilds the CPU palette used for instanced wind barb/arrow RGB when [SamplePaint.colorScale] or
     * [SamplePaint.encodedScalarNormMax] changes. Safe to call when reusing a cached gridVector sidecar source.
     */
    fun applyIconColorOptions(scale: ColorScaleOptions?, encodedScalarMax: Double?) {
        iconShaderPalette = scale?.let { EncodedShaderPalette.cacheForOptions(it) }
        iconShaderNormMax = encodedScalarMax ?: scale?.range?.endInclusive ?: 53.64
    }

    /**
     * JS [GridPaint.spacing] is in logical px; instanced gridded placement uses `authored × density × 0.5`
     * (same density convention as [com.xweather.mapsgl.renderers.GridLayerRenderer] icon sizing). Safe when
     * reusing a cached sidecar: bumps [spacing] and invalidates placement caches when the effective value changes.
     */
    fun syncGridSpacingFromPaint(authoredSpacing: Double, displayDensity: Float) {
        val d = if (displayDensity > 0f) displayDensity.toDouble() else 1.0
        val next =
            max(1.0, authoredSpacing * d * INSTANCED_GRID_SPACING_INTERNAL_SCALE).coerceAtLeast(1.0)
        val unchanged = abs(spacing - next) <= 1e-9
        if (!unchanged) {
            spacing = next
        }
        // Constructor seeds [spacing] from logical grid spacing only; it often already equals [next], so we would
        // skip invalidate() and never push custom geometry — arrows stay blank until a pan/zoom invalidates.
        if (!unchanged || customGeometryTileKeys.isEmpty()) {
            invalidate()
        }
    }

    /**
     * Scalar normalization maximum used by instanced wind shaders (arrow stretch, etc).
     * Kept as an accessor so renderers can read the value without depending on
     * the internal shader naming.
     */
    internal val iconScalarNormMax: Double
        get() = iconShaderNormMax
    private val lastEncodedTileDrivenInvalidateMs = AtomicLong(0L)

    /** Mapbox-style world width/height in pixels at integer-equivalent zoom (512 × 2^zoom). */
    private fun worldSizePx(mapZoom: Double): Double = 512.0 * 2.0.pow(mapZoom)

    /**
     * Lon/lat from fractional position within tile (x,y,z), matching [pixelToLngLat] / [lonLatToTileUv].
     */
    private fun lngLatFromTileFrac(tx: Int, ty: Int, tz: Int, fx: Double, fy: Double): Pair<Double, Double> {
        val n = 2.0.pow(tz)
        val worldCol = tx + fx.coerceIn(0.0, 1.0)
        val worldRow = ty + fy.coerceIn(0.0, 1.0)
        val lonDeg = worldCol / n * 360.0 - 180.0
        val latRad = atan(sinh(PI * (1.0 - 2.0 * worldRow / n)))
        return Pair(lonDeg, Math.toDegrees(latRad))
    }

    /**
     * Placement grid step in **world pixels at zoom 0** (world width = 512px).
     *
     * Requirements:
     * - At zoom 0: spacing determines number of icons across the world.
     * - Each time zoom increases by 1: icons per distance unit double horizontally + vertically.
     *
     * Using a fixed step in "world pixels at floor(zoom)" satisfies this:
     * world width doubles each integer zoom, so count = worldWidth / step doubles too.
     */
    private fun placementStepPxAtZoom0(): Double =
        max(1.0, spacing.toDouble().coerceAtLeast(1.0))

    /**
     * Extra density only while [stablePlacementZoomInt] is 0. Do not gate on raw fractional zoom alone:
     * values like 0.986 snap to placement 1 (see [stablePlacementZoomInt]) but were still treated as
     * “below 1”, doubling grid density vs the placement scale — ~2× too dense on each axis near zoom 1.0.
     */
    private fun lowZoomDensityMultiplier(mapZoom: Double): Double =
        if (stablePlacementZoomInt(mapZoom) < 1) 2.0 else 1.0

    private fun densityKeyFromMapZoom(mapZoom: Double): Int =
        densityKeyForMapZoom(mapZoom)

    private fun binnedZoomFromDensityKey(key: Int): Double =
        key.toDouble() / DENSITY_ZOOM_BINS_PER_LEVEL

    /**
     * Stabilize integer zoom selection around boundaries (e.g. 0.999999 vs 1.000001)
     * so icon density does not flicker between adjacent levels.
     */
    private fun stablePlacementZoomInt(rawZoom: Double): Int =
        instancingGatherPlacementKey(rawZoom)

    /**
     * While [Timeline.dataMeld] is between 0 and 1, skip [griddedVectorDataCache] so each rebuild
     * uses the current meld (smooth crossfade). At endpoints, caching avoids redundant CPU work.
     */
    private fun shouldUseGriddedVectorDataCache(): Boolean {
        val m = Timeline.dataMeld
        return m <= 1e-3f || m >= 1f - 1e-3f
    }

    private fun griddedVectorCacheKey(
        coord: TileCoord,
        densityKey: Int,
        densityMultiplierKey: Int,
        visible: VisibleGeoBounds?
    ): String {
        val base = "${coord.hash()}/d$densityKey/m$densityMultiplierKey/v7"
        if (visible == null) return base
        return "${base}_${viewportKeyForVisibleBounds(visible)}"
    }

    private fun griddedGeometryCacheKey(
        x: Int,
        y: Int,
        z: Int,
        densityKey: Int,
        densityMultiplierKey: Int,
        visible: VisibleGeoBounds?,
        /** Non-zero only for left-anchored instanced wind arrows; must match [buildViewportGridPoints] margin. */
        viewportMarginWorldPx: Double = 0.0,
        /** Extra east extent as a fraction of viewport width; must match [buildViewportGridPoints]. */
        viewportExtraEastFraction: Double = 0.0,
    ): String {
        // Placement lon/lat use integer world scale ([stablePlacementZoomInt]); no fractional-zoom term.
        val vm = viewportMarginWorldPx.toInt().coerceAtLeast(0)
        val efScaled = (viewportExtraEastFraction * 10000.0).roundToInt().coerceIn(0, 10_000)
        val efPart = if (efScaled > 0) "_e$efScaled" else ""
        val base = "$z/$x/$y/d$densityKey/m$densityMultiplierKey/g6_vm$vm$efPart"
        if (visible == null) return base
        return "${base}_${viewportKeyForVisibleBounds(visible)}"
    }

    init {
        tileSize = encodedSource.tileSize
        bounds = encodedSource.bounds
        minZoom = encodedSource.minZoom
        // Let Mapbox request sidecar tiles up to full resolution. If encoded-data only exists
        // for lower zooms, we clamp sampling inside `sampleEncodedRgbAtLonLat(...)`.
        maxZoom = 21f
        encodedSource.addOnEncodedTileReadyListener {
            // Wind-barb icon color/direction is computed from encoded tiles. If sidecar tiles
            // were generated before encoded samples arrived, force a dynamic refresh now.
            if (customGeometryTileKeys.isEmpty()) return@addOnEncodedTileReadyListener
            val now = SystemClock.elapsedRealtime()
            val last = lastEncodedTileDrivenInvalidateMs.get()
            if (now - last < 50L) return@addOnEncodedTileReadyListener
            if (!lastEncodedTileDrivenInvalidateMs.compareAndSet(last, now)) return@addOnEncodedTileReadyListener
            invalidateDynamicIconData()
        }
    }

    override fun invalidate() {
        griddedVectorDataCache.clear()
        griddedGeometryCache.clear()
        // Invalidate cached computed features.
        // Explicitly invalidate all known custom-geometry tiles so Mapbox refetches per-camera update.
        val coords = customGeometryTileKeys.mapNotNull { parseTileKey(it) }
        if (coords.isNotEmpty()) {
            notifyMapboxCustomGeometryTilesInvalidation(coords)
        }
    }

    /**
     * Timeline-only invalidation: keep cached placement geometry, refresh only sampled icon properties.
     */
    fun invalidateDynamicIconData() {
        if (!timelineMeldInvalidatesMapboxTiles) return
        griddedVectorDataCache.clear()
        val coords = customGeometryTileKeys.mapNotNull { parseTileKey(it) }
        if (coords.isNotEmpty()) {
            notifyMapboxCustomGeometryTilesInvalidation(coords)
        }
    }

    private fun pixelToLngLat(
        tileCoord: TileCoord,
        xPx: Int,
        yPx: Int,
        width: Int,
        height: Int,
    ): Pair<Double, Double> {
        val n = 2.0.pow(tileCoord.z)
        val denomW = max(1, width - 1).toDouble()
        val denomH = max(1, height - 1).toDouble()
        val xFrac = xPx.toDouble() / denomW
        val yFrac = yPx.toDouble() / denomH

        val worldCol = tileCoord.x + xFrac
        val worldRow = tileCoord.y + yFrac

        val lonDeg = worldCol / n * 360.0 - 180.0
        val latRad = atan(sinh(PI * (1.0 - 2.0 * worldRow / n)))
        val latDeg = Math.toDegrees(latRad)
        return Pair(lonDeg, latDeg)
    }

    private fun lonLatToTileUv(lon: Double, latDeg: Double, z: Int): TileUv? {
        val n = 2.0.pow(z)
        val nInt = n.toInt()
        if (nInt <= 0) return null
        val latClamped = latDeg.coerceIn(-webMercatorMaxLat, webMercatorMaxLat)
        val latRad = Math.toRadians(latClamped)
        val cosLat = cos(latRad).coerceAtLeast(1e-12)
        val yMerc = ln(tan(latRad) + 1.0 / cosLat)
        var worldRow = (1.0 - yMerc / PI) * n / 2.0
        worldRow = worldRow.coerceIn(0.0, n - 1e-9)
        var worldCol = (lon + 180.0) / 360.0 * n
        worldCol %= n
        if (worldCol < 0) worldCol += n
        worldCol = worldCol.coerceIn(0.0, n - 1e-9)
        val tx = floor(worldCol).toInt().coerceIn(0, nInt - 1)
        val ty = floor(worldRow).toInt().coerceIn(0, nInt - 1)
        val u = (worldCol - tx).coerceIn(0.0, 1.0)
        val v = (worldRow - ty).coerceIn(0.0, 1.0)
        return TileUv(tx, ty, u, v)
    }

    /** Horizontal / vertical Web Mercator pixel coords at [wsz], matching [buildFeaturesFromEncodedData]. */
    private fun lonLatToWorldPixel(lon: Double, latDeg: Double, wsz: Double): Pair<Double, Double> {
        val wx = (lon + 180.0) / 360.0 * wsz
        val latClamped = latDeg.coerceIn(-webMercatorMaxLat, webMercatorMaxLat)
        val latRad = Math.toRadians(latClamped)
        val yMerc = ln(tan(latRad) + 1.0 / cos(latRad))
        val worldRowNorm = (1.0 - yMerc / PI) / 2.0
        val wy = worldRowNorm * wsz
        return wx to wy
    }

    /** Inverse of [lonLatToWorldPixel] for Web Mercator. */
    private fun worldPixelToLonLat(wx: Double, wy: Double, wsz: Double): Pair<Double, Double> {
        val lonDeg = (wx / wsz) * 360.0 - 180.0
        val latRad = atan(sinh(PI * (1.0 - 2.0 * (wy / wsz))))
        return lonDeg to Math.toDegrees(latRad)
    }

    /**
     * Axis-aligned world-pixel bounds for [bounds] corners, or null if bounds wrap the antimeridian (clip skipped).
     */
    private fun visibleWorldPixelAxes(
        bounds: VisibleGeoBounds,
        wsz: Double
    ): Pair<Pair<Double, Double>, Pair<Double, Double>>? {
        if (bounds.east < bounds.west) return null
        val corners =
            listOf(
                lonLatToWorldPixel(bounds.west, bounds.south, wsz),
                lonLatToWorldPixel(bounds.east, bounds.south, wsz),
                lonLatToWorldPixel(bounds.west, bounds.north, wsz),
                lonLatToWorldPixel(bounds.east, bounds.north, wsz),
            )
        val wxMin = corners.minOf { it.first }
        val wxMax = corners.maxOf { it.first }
        val wyMin = corners.minOf { it.second }
        val wyMax = corners.maxOf { it.second }
        return (wxMin to wxMax) to (wyMin to wyMax)
    }

    private fun tileCenterInVisibleGeo(x: Int, y: Int, z: Int, bounds: VisibleGeoBounds): Boolean {
        if (bounds.east < bounds.west) return true
        val (lonC, latC) = lngLatFromTileFrac(x, y, z, 0.5, 0.5)
        return lonC >= bounds.west && lonC <= bounds.east && latC >= bounds.south && latC <= bounds.north
    }

    private fun ensureEncodedPaddedRestored(tile: Tile<com.xweather.mapsgl.sources.DataType>) {
        val encodedData = tile.encodedData ?: return
        if (encodedData.paddedData != null) return
        val nativeKey = "${encodedSource.id}${tile.coordHash}"
        encodedSource.tileCache.nativeCache.getData(nativeKey)?.let { encodedData.paddedData = it }
    }

    private fun getEncodedTile(
        tx: Int,
        ty: Int,
        tz: Int,
        timeKey: String
    ): Tile<com.xweather.mapsgl.sources.DataType>? {
        val c = TileCoord(tx, ty, tz, 0, timeKey)
        val t = encodedSource.tileCache[c] ?: return null
        if (t.encodedData == null) return null
        ensureEncodedPaddedRestored(t)
        return t
    }

    private fun readRgbAtCorePixel(
        raw: ByteArray,
        dim: Int,
        pad: Int,
        core: Int,
        cx: Int,
        cy: Int,
    ): Triple<Double, Double, Double>? {
        if (cx < 0 || cy < 0 || cx >= core || cy >= core) return null
        val xPx = cx + pad
        val yPx = cy + pad
        val idx = (yPx * dim + xPx) * 4
        if (idx + 2 >= raw.size) return null
        val rRaw = (raw[idx].toInt() and 0xFF).toDouble()
        val gRaw = (raw[idx + 1].toInt() and 0xFF).toDouble()
        val bRaw = (raw[idx + 2].toInt() and 0xFF).toDouble()
        return Triple(rRaw, gRaw, bRaw)
    }

    private fun bilinearSampleRgb(
        raw: ByteArray,
        dim: Int,
        pad: Int,
        core: Int,
        px: Double,
        py: Double,
    ): Triple<Double, Double, Double>? {
        val maxC = (core - 1).coerceAtLeast(1).toDouble()
        val xC = px.coerceIn(0.0, maxC)
        val yC = py.coerceIn(0.0, maxC)
        val x0 = floor(xC).toInt()
        val y0 = floor(yC).toInt()
        val x1 = min(x0 + 1, core - 1)
        val y1 = min(y0 + 1, core - 1)
        val fx = xC - x0
        val fy = yC - y0
        val p00 = readRgbAtCorePixel(raw, dim, pad, core, x0, y0) ?: return null
        val p10 = readRgbAtCorePixel(raw, dim, pad, core, x1, y0) ?: return null
        val p01 = readRgbAtCorePixel(raw, dim, pad, core, x0, y1) ?: return null
        val p11 = readRgbAtCorePixel(raw, dim, pad, core, x1, y1) ?: return null
        fun lerp(a: Double, b: Double, t: Double) = a + (b - a) * t
        val r = lerp(lerp(p00.first, p10.first, fx), lerp(p01.first, p11.first, fx), fy)
        val g = lerp(lerp(p00.second, p10.second, fx), lerp(p01.second, p11.second, fx), fy)
        val b = lerp(lerp(p00.third, p10.third, fx), lerp(p01.third, p11.third, fx), fy)
        return Triple(r, g, b)
    }

    private fun applyEncodedShaderIconColor(feature: Feature, speed: Double) {
        val pal = iconShaderPalette ?: return
        val argb = EncodedShaderPalette.colorArgb(speed, pal, iconShaderNormMax)
        feature.addNumberProperty("shaderR", AndroidColorH.red(argb).toDouble())
        feature.addNumberProperty("shaderG", AndroidColorH.green(argb).toDouble())
        feature.addNumberProperty("shaderB", AndroidColorH.blue(argb).toDouble())
    }

    /** Converts a timeline phase index to the encoded-tile time string ([TileCoord.time] format). */
    /**
     * Cache/lookup time key for the global timeline tick at [phaseIndex].
     *
     * Must return the **layer's own canonical valid-time string**, not the raw global tick: encoded
     * tiles are downloaded and cached by [com.xweather.mapsgl.tiles.TilePyramid], which resolves
     * every global tick to this layer's nearest native valid time first
     * ([com.xweather.mapsgl.tiles.TilePyramid.matchTimesToLayerValidTimes]) and keys the tile by
     * that. Returning the un-snapped global tick made [getEncodedTile] miss every cached tile
     * whenever the global grid and the layer's native valid times did not line up exactly — the
     * grid sampler then found no data at any point, so instanced wind arrows/barbs rendered
     * nothing at all, silently and with no error logged. (Same cache-key-mismatch class as the
     * raster playback fix; the coarse progressive grid made the offset near-permanent instead of
     * intermittent, which is why the layer went from "sometimes invisible" to always invisible.)
     */
    private fun encodedTimeKeyForTimelinePhase(phaseIndex: Int): String? {
        val (globalLongs, globalStrings) = Timeline.globalTimeListsSnapshot()
        if (phaseIndex < 0 || phaseIndex >= globalStrings.size) return null
        val dates = parseDateArrayFromString(globalStrings[phaseIndex])
        if (dates.isEmpty()) return null
        val rawGlobalKey = formatDateArrayToString(listOf(dates.first()))

        val globalLong = globalLongs.getOrNull(phaseIndex) ?: return rawGlobalKey
        val layerLists = Timeline.sourceTimeHash[encodedSource.id] ?: return rawGlobalKey
        val (layerLongs, layerStrings) = layerLists.playbackTimeListsSnapshot()
        val n = min(layerLongs.size, layerStrings.size)
        if (n == 0) return rawGlobalKey

        // Resolution rule must match [TilePyramid.matchTimesToLayerValidTimes] *exactly* — exact hit,
        // else the next-largest valid time, else the last one. Using "nearest" instead looks
        // equivalent but breaks on ties: a global tick at 16:00 with layer times 15:00/17:00 snaps
        // to 15:00 by nearest and 17:00 by next-largest, and the pyramid only ever downloaded the
        // latter, so every lookup missed.
        val searchIdx = layerLongs.binarySearch(globalLong)
        val bestIdx = if (searchIdx >= 0) {
            searchIdx
        } else {
            val insertionPoint = -(searchIdx + 1)
            if (insertionPoint < n) insertionPoint else n - 1
        }
        return layerStrings.getOrNull(bestIdx) ?: rawGlobalKey
    }

    /**
     * Bilinear RGB sample at one validity time. See [sampleEncodedRgbAtLonLat] for meld-aware blending.
     */
    private fun sampleEncodedRgbSingleTime(
        lon: Double,
        latDeg: Double,
        z: Int,
        timeKey: String,
        preferredTileZoom: Int? = null,
    ): Triple<Double, Double, Double>? {
        // Sampling must NOT depend on camera/map zoom being the same as the encoded tile zooms we have cached.
        // Prefer the highest encoded zoom available; if those tiles aren't cached yet, fall back down the pyramid.
        val zMax = encodedSource.maxZoom.toInt().coerceAtLeast(0)
        val zMin = encodedSource.minZoom.toInt().coerceAtLeast(0)

        // Try highest-available first, then fall back; include the requested z (clamped) early as well.
        val primary = z.coerceAtMost(zMax).coerceAtLeast(zMin)
        val zs = LinkedHashSet<Int>()
        // [preferredTileZoom] is the zoom of the tiles the layer actually requested for this
        // viewport ([TileLayer.visibleTileCoordsForSidecarSampling]), which can exceed the source
        // metadata's [maxZoom] — the pyramid over-zooms rather than clamping. Restricting the walk
        // to metadata maxZoom therefore skipped every tile actually in the cache (all z5 while
        // zMax reported 4), so no grid point ever resolved and instanced wind arrows/barbs drew
        // nothing. Search the zoom we really have first, then the metadata pyramid as before.
        preferredTileZoom?.takeIf { it in 0..30 }?.let { zs.add(it) }
        zs.add(zMax)
        zs.add(primary)
        for (zz in (zMax - 1) downTo zMin) zs.add(zz)

        for (zData in zs) {
            val uv = lonLatToTileUv(lon, latDeg, zData) ?: continue

            for (dy in -1..1) {
                for (dx in -1..1) {
                    val u2 = uv.u - dx
                    val v2 = uv.v - dy
                    if (u2 < 0.0 || u2 >= 1.0) continue
                    if (v2 < 0.0 || v2 >= 1.0) continue

                    val tile = getEncodedTile(uv.tx + dx, uv.ty + dy, zData, timeKey) ?: continue
                    val ed = tile.encodedData ?: continue
                    val raw = ed.paddedData ?: continue
                    val core = ed.originalSize
                    val dim = ed.dimension
                    val pad = ed.padding
                    val denom = max(1, core - 1).toDouble()
                    val px = u2 * denom
                    val py = v2 * denom
                    bilinearSampleRgb(raw, dim, pad, core, px, py)?.let { return it }
                }
            }

            val tile = getEncodedTile(uv.tx, uv.ty, zData, timeKey) ?: continue
            val ed = tile.encodedData ?: continue
            val raw = ed.paddedData ?: continue
            val core = ed.originalSize
            val dim = ed.dimension
            val pad = ed.padding
            val denom = max(1, core - 1).toDouble()
            val px = uv.u * denom
            val py = uv.v * denom
            bilinearSampleRgb(raw, dim, pad, core, px, py)?.let { return it }
        }

        return null
    }

    /**
     * Data inspector for maritime `*_dir.fill`: bilinear sample at [lon]/[latDeg] using the same placement zoom as
     * [buildInstancedWindBufferDualPhase] ([stablePlacementZoomInt]\(mapZoom\)), then vector-blend phases like the GPU.
     * Nearest-neighbor tile bytes in [EncodedTileLayer] do not match instanced sampling.
     */
    fun inspectorSampleMaritimeDirDeg(lon: Double, latDeg: Double, mapZoom: Double): Float? {
        val z = stablePlacementZoomInt(mapZoom)
        val keyA = encodedTimeKeyForTimelinePhase(Timeline.currentPhaseA) ?: return null
        val keyB = encodedTimeKeyForTimelinePhase(Timeline.currentPhaseB) ?: return null
        val sampleA = sampleEncodedRgbSingleTime(lon, latDeg, z, keyA) ?: return null
        val sampleB = sampleEncodedRgbSingleTime(lon, latDeg, z, keyB) ?: return null
        val dirA = maritimeScalarDirDegFromBlueByte(sampleA.third)
        val dirB = maritimeScalarDirDegFromBlueByte(sampleB.third)
        val t = Timeline.dataMeld.toDouble().coerceIn(0.0, 1.0)
        return blendMetDirDegFromAngleUnitVectors(dirA, dirB, t).toFloat()
    }

    private fun blendMetDirDegFromAngleUnitVectors(dirA: Double, dirB: Double, t: Double): Double {
        val tt = t.coerceIn(0.0, 1.0)
        val rA = Math.toRadians(dirA - 90.0)
        val rB = Math.toRadians(dirB - 90.0)
        var mx = (1.0 - tt) * cos(rA) + tt * cos(rB)
        var my = (1.0 - tt) * sin(rA) + tt * sin(rB)
        val len = hypot(mx, my)
        if (len < 1e-9) return dirA
        mx /= len
        my /= len
        return (Math.toDegrees(atan2(my, mx)) + 90.0 + 360.0) % 360.0
    }

    /**
     * Samples encoded wind RGB (G/B carry u/v) and interpolates between timeline phases A and B using
     * [Timeline.dataMeld], matching raster layer meld. [fallbackTimeKey] is used when timeline strings are absent.
     */
    private fun sampleEncodedRgbAtLonLat(
        lon: Double,
        latDeg: Double,
        z: Int,
        fallbackTimeKey: String,
    ): Triple<Double, Double, Double>? {
        val keyA = encodedTimeKeyForTimelinePhase(Timeline.currentPhaseA) ?: fallbackTimeKey
        val keyB = encodedTimeKeyForTimelinePhase(Timeline.currentPhaseB) ?: fallbackTimeKey
        val t = Timeline.dataMeld.toDouble().coerceIn(0.0, 1.0)

        val sampleA = sampleEncodedRgbSingleTime(lon, latDeg, z, keyA)
        val sampleB = sampleEncodedRgbSingleTime(lon, latDeg, z, keyB)

        if (sampleA == null && sampleB == null) return null
        if (sampleA == null) return sampleB
        if (sampleB == null) return sampleA
        if (keyA == keyB || t <= 0.0) return sampleA
        if (t >= 1.0) return sampleB

        fun lerpChannel(a: Double, b: Double) = a + (b - a) * t
        return Triple(
            lerpChannel(sampleA.first, sampleB.first),
            lerpChannel(sampleA.second, sampleB.second),
            lerpChannel(sampleA.third, sampleB.third),
        )
    }

    override suspend fun requestTile(
        x: Int,
        y: Int,
        z: Int,
        mapZoomForDensity: Double?,
        visibleGeoBounds: VisibleGeoBounds?,
        intervalTime: Date?,
        countsForGlFillLoadIndicator: Boolean,
    ): VectorData? {
        val validTimeStr2 = formatDateArrayToString(listOf(validTime))
        val coord = TileCoord(x, y, z, 0, validTimeStr2)
        val rawZoom = mapZoomForDensity ?: z.toDouble()
        // Placement density changes only when zoom crosses an integer boundary.
        val placementZoomInt = stablePlacementZoomInt(rawZoom)
        val densityMultiplierKey = if (placementZoomInt < 1) 2 else 1
        val densityKey = placementZoomInt
        val cacheKey = griddedVectorCacheKey(coord, densityKey, densityMultiplierKey, visibleGeoBounds)
        val geometryKey =
            griddedGeometryCacheKey(x, y, z, densityKey, densityMultiplierKey, visibleGeoBounds, 0.0)
        val cachedData =
            if (shouldUseGriddedVectorDataCache()) griddedVectorDataCache[cacheKey] else null

        if (cachedData != null) {
            trackCustomGeometryTile(x, y, z)
            return cachedData
        }

        val points =
            griddedGeometryCache[geometryKey]
                ?: buildViewportGridPoints(
                    x = x,
                    y = y,
                    z = z,
                    cameraZoom = rawZoom,
                    visibleGeoBounds = visibleGeoBounds,
                    viewportMarginWorldPx = 0.0,
                ).also { griddedGeometryCache[geometryKey] = it }
        logComputedIconsWindow(points.size)
        val features = buildFeaturesForGridPoints(points, placementZoomInt, coord.time)

        val vectorData = VectorData(validTime, features)
        if (shouldUseGriddedVectorDataCache()) {
            griddedVectorDataCache[cacheKey] = vectorData
        }
        trackCustomGeometryTile(x, y, z)
        return vectorData
    }

    /**
     * Same feature generation as the Mapbox sidecar path, merged for OpenGL instanced drawing
     * (no Mapbox vector layer).
     */
    suspend fun mergeFeaturesForTiles(
        coords: List<TileCoord>,
        mapZoom: Double,
        visibleGeoBounds: VisibleGeoBounds?,
    ): List<Pair<TileCoord, Feature>> {
        val out = ArrayList<Pair<TileCoord, Feature>>(4096)
        for (c in coords) {
            val vd = requestTile(c.x, c.y, c.z, mapZoom, visibleGeoBounds) ?: continue
            for (f in vd.features) {
                out.add(c to f)
            }
        }
        return out
    }

    private data class WindSampleFields(val dirDeg: Double, val speedMs: Double)

    /** G/B bytes → u/v in fixed encoded span; direction = `atan2(u,-v)` (deg). Used for wind / conditions arrows. */
    private fun sampleFieldsFromEncodedRgb(rRaw: Double, gRaw: Double, bRaw: Double): WindSampleFields {
        val uWind = (gRaw / 255.0) * 107.28 - 53.64
        val vWind = (bRaw / 255.0) * 107.28 - 53.64
        val speedMs = kotlin.math.sqrt(uWind * uWind + vWind * vWind)
        val dirDeg = Math.toDegrees(kotlin.math.atan2(uWind, -vWind))
        return WindSampleFields(dirDeg, speedMs)
    }

    /**
     * JS `get_data_value.glsl` ANGLE: `deg = sample * 360 - 180`, then if `deg < 0` add 360; static speed 0.1.
     */
    private fun maritimeScalarDirDegFromBlueByte(bRaw: Double): Double {
        val norm = bRaw / 255.0
        var deg = norm * 360.0 - 180.0
        if (deg < 0.0) deg += 360.0
        return deg
    }

    private fun windSampleFromEncodedRgb(rgb: Triple<Double, Double, Double>?): WindSampleFields? {
        if (rgb == null) return null
        val (rRaw, gRaw, bRaw) = rgb
        return fieldsFromEncodedSampleRgb(rRaw, gRaw, bRaw)
    }

    private fun fieldsFromEncodedSampleRgb(rRaw: Double, gRaw: Double, bRaw: Double): WindSampleFields =
        if (instancedQuadMonochromeWhite) {
            WindSampleFields(maritimeScalarDirDegFromBlueByte(bRaw), 0.1)
        } else {
            sampleFieldsFromEncodedRgb(rRaw, gRaw, bRaw)
        }


    /**
     * JS [symbol-grid.vert.glsl] `NODATA`: `sampleColorValue(tex, dataChannel[0]) == noData` (angle grids use the
     * same channel as direction; we use the blue byte, matching [maritimeScalarDirDegFromBlueByte]). Omit the
     * instanced arrow if **any** available timeline sample at this grid point matches [SourceMetadata.noData].
     */
    private fun shouldOmitMaritimeGriddedArrowForNoData(
        sampleA: Triple<Double, Double, Double>?,
        sampleB: Triple<Double, Double, Double>?,
    ): Boolean {
        val nd = runCatching { encodedSource.metadata.noData }.getOrNull() ?: return false
        val sentinel = nd.coerceIn(0, 255)
        fun blueByteIsNoData(t: Triple<Double, Double, Double>): Boolean =
            (t.third.toInt() and 0xFF) == sentinel

        val aBad = sampleA?.let(::blueByteIsNoData) ?: false
        val bBad = sampleB?.let(::blueByteIsNoData) ?: false
        return when {
            sampleA == null && sampleB == null -> false
            sampleA == null -> bBad
            sampleB == null -> aBad
            else -> aBad || bBad
        }
    }

    private fun shaderRgbFloatsForWindSpeed(speedMs: Double): Triple<Float, Float, Float> {
        val pal = iconShaderPalette ?: return Triple(1f, 1f, 1f)
        val argb = EncodedShaderPalette.colorArgb(speedMs, pal, iconShaderNormMax)
        return Triple(
            AndroidColorH.red(argb) / 255f,
            AndroidColorH.green(argb) / 255f,
            AndroidColorH.blue(argb) / 255f,
        )
    }

    /**
     * Packed instanced wind barbs: **endpoint** phase A and B only (no [Timeline.dataMeld] in sampling).
     * Matches encoded raster layers: the GPU applies `dataMeld` each frame so timeline crossfade stays smooth
     * without rebuilding this buffer at playback frame rate.
     *
     * Layout per instance (**14** floats): `tileX, tileY, dirA, speedA, dirB, speedB, rgbaA, rgbaB`.
     *
     * @param viewportGridMarginWorldPx Expand the camera bounds by this many world pixels (at placement zoom) when
     *   placing grid anchors. Use `0` for barbs (fast). Use ~384 for left-anchored wind arrows so anchors just
     *   outside the viewport are still included when the quad intersects the screen; a global margin for all
     *   layers doubled grid work and slowed timeline animation.
     * @param viewportExtraEastFraction Expand only the **east** edge of the horizontal viewport span by this
     *   fraction of the span (e.g. `0.05` adds 5% width on the right) so left-anchored arrows stay visible longer
     *   when panning.
     */
    suspend fun buildInstancedWindBufferDualPhase(
        coords: List<TileCoord>,
        mapZoom: Double,
        visibleGeoBounds: VisibleGeoBounds?,
        maxInstances: Int,
        viewportGridMarginWorldPx: Double = 0.0,
        viewportExtraEastFraction: Double = 0.0,
        phaseA: Int = Timeline.currentPhaseA,
        phaseB: Int = Timeline.currentPhaseB,
    ): Pair<FloatArray, Int> = withContext(Dispatchers.Default) {
        val cap = maxInstances.coerceAtLeast(0)
        if (cap == 0 || coords.isEmpty()) return@withContext FloatArray(0) to 0

        val stride = 14
        val rawZoom = mapZoom
        val placementZoomInt = stablePlacementZoomInt(rawZoom)
        val densityMultiplierKey = if (placementZoomInt < 1) 2 else 1
        val densityKey = placementZoomInt

        val keyA = encodedTimeKeyForTimelinePhase(phaseA)
        val keyB = encodedTimeKeyForTimelinePhase(phaseB)
        val fallbackTime = formatDateArrayToString(listOf(validTime))
        val ka = keyA ?: fallbackTime
        val kb = keyB ?: fallbackTime

        // Placement grid lon/lat come from [buildViewportGridPoints] using integer placement zoom (stable geography).
        // Instance world pixels must use fractional map zoom so quads track Mapbox’s Mercator scale while zooming.
        val wszRender = worldSizePx(rawZoom)
        val out = FloatArray(cap * stride)
        var count = 0
        var w = 0

        for (c in coords) {
            val geometryKey =
                griddedGeometryCacheKey(
                    c.x,
                    c.y,
                    c.z,
                    densityKey,
                    densityMultiplierKey,
                    visibleGeoBounds,
                    viewportGridMarginWorldPx,
                    viewportExtraEastFraction,
                )
            val points =
                griddedGeometryCache[geometryKey]
                    ?: buildViewportGridPoints(
                        c.x,
                        c.y,
                        c.z,
                        rawZoom,
                        visibleGeoBounds,
                        viewportGridMarginWorldPx,
                        viewportExtraEastFraction,
                    ).also { pts ->
                        if (pts.isNotEmpty()) {
                            griddedGeometryCache[geometryKey] = pts
                        }
                    }

            for (pt in points) {
                if (count >= cap) return@withContext out to count

                val sampleA = sampleEncodedRgbSingleTime(pt.lon, pt.lat, placementZoomInt, ka, c.z)
                val sampleB = sampleEncodedRgbSingleTime(pt.lon, pt.lat, placementZoomInt, kb, c.z)
                val wA = windSampleFromEncodedRgb(sampleA)
                val wB = windSampleFromEncodedRgb(sampleB)
                if (wA == null && wB == null) continue

                // JS symbol-grid.vert: if (dd == noData) vSpeed = -1 → grid-field discards. Angle layers use
                // dataChannel[0] (blue for maritime dir); omit instances when that byte matches metadata noData.
                /*
                if (instancedQuadMonochromeWhite && shouldOmitMaritimeGriddedArrowForNoData(sampleA, sampleB) ) {
                    continue
                }
                */
                val dirA = wA?.dirDeg ?: wB!!.dirDeg
                val speedA = wA?.speedMs ?: wB!!.speedMs
                val dirB = wB?.dirDeg ?: wA!!.dirDeg
                val speedB = wB?.speedMs ?: wA!!.speedMs

                // [pt.lon] may be outside [-180,180] when the viewport grid used unwrapped world-x across the dateline.
                val (wx, wy) = lonLatToWorldPixel(pt.lon, pt.lat, wszRender)
                val (rA, gA, bA) =
                    if (instancedQuadMonochromeWhite) Triple(1f, 1f, 1f) else shaderRgbFloatsForWindSpeed(speedA)
                val (rB, gB, bB) =
                    if (instancedQuadMonochromeWhite) Triple(1f, 1f, 1f) else shaderRgbFloatsForWindSpeed(speedB)

                out[w++] = wx.toFloat()
                out[w++] = wy.toFloat()
                out[w++] = dirA.toFloat()
                out[w++] = speedA.toFloat()
                out[w++] = dirB.toFloat()
                out[w++] = speedB.toFloat()
                out[w++] = rA
                out[w++] = gA
                out[w++] = bA
                out[w++] = 1f
                out[w++] = rB
                out[w++] = gB
                out[w++] = bB
                out[w++] = 1f
                count++
            }
        }
        return@withContext out to count
    }

    /**
     * Placement is fully determined by camera zoom + camera bounds:
     * - Choose integer zoom grid \(zGrid = floor(cameraZoom)\)
     * - Use constant step in world pixels at zoom 0 ([placementStepPxAtZoom0])
     * - Populate grid centers inside the camera viewport, optionally expanded by [viewportMarginWorldPx]
     *   (instanced wind arrows pass a non-zero margin so left-anchored quads are not clipped at the viewport edge).
     * - [viewportExtraEastFraction] extends only the east edge of the horizontal span (fraction of span width).
     *
     * We still return features "per Mapbox tile" by intersecting the global viewport grid with that tile's
     * lon/lat bounds. Encoded data is sampled at those points, but does not influence placement.
     */
    private fun buildViewportGridPoints(
        x: Int,
        y: Int,
        z: Int,
        cameraZoom: Double,
        visibleGeoBounds: VisibleGeoBounds?,
        viewportMarginWorldPx: Double = 0.0,
        viewportExtraEastFraction: Double = 0.0,
    ): List<GridPoint> {
        val vb = visibleGeoBounds ?: return emptyList()
        val nTiles = 2.0.pow(z).toInt().coerceAtLeast(1)
        val xWrapped = ((x % nTiles) + nTiles) % nTiles

        // Integer world scale for the placement grid only. Using fractional zoom here made viewport bounds and
        // worldPixel→lon/lat depend on every zoom tick, so icons drifted (“swim”) relative to the map.
        // Geographic anchors stay fixed until [densityKey] / placement zoom changes; [buildInstancedWindBufferDualPhase]
        // still converts each point with [worldSizePx(rawZoom)] so screen spacing grows smoothly while zooming.
        val zGrid = stablePlacementZoomInt(cameraZoom)
        val wsz = worldSizePx(zGrid.toDouble())
        val step = placementStepPxAtZoom0() / lowZoomDensityMultiplier(cameraZoom)
        val half = step * 0.5
        val margin = viewportMarginWorldPx.coerceAtLeast(0.0)
        val eastFrac = viewportExtraEastFraction.coerceIn(0.0, 0.5)

        fun lonToWorldPixelUnwrappedX(lon: Double): Double =
        // Do not wrap modulo here; keep "unwrapped" world-x when the viewport crosses the antimeridian.
            // This ensures instanced-quad positions remain in the same world-copy frame as the Mapbox camera.
            lonLatToWorldPixel(lon, 0.0, wsz).first

        val wxWest = lonToWorldPixelUnwrappedX(vb.west)
        val wxEast = lonToWorldPixelUnwrappedX(vb.east)

        // Always derive horizontal coverage from unwrapped camera corners — never collapse to [0, wsz].
        // A longitude span ≥360° (common when zoomed out) or multiple visible world copies can make
        // [wxWest, wxEast] wider than one world width; the old `spanLon >= 360 → (0 to wsz)` branch only
        // iterated a single world copy and gridded symbols appeared once.
        val xIntervals: List<Pair<Double, Double>> =
            when {
                vb.east < vb.west -> {
                    // Unwrapped camera crosses the antimeridian in geographic west/east ordering.
                    listOf(wxWest to wxEast + wsz)
                }

                wxEast < wxWest - 1e-6 -> {
                    // east >= west in degrees but Mercator world-x decreases (rare corner orders):
                    // treat like a wrap across one world width.
                    listOf(wxWest to wxEast + wsz)
                }

                else -> {
                    listOf(min(wxWest, wxEast) to max(wxWest, wxEast))
                }
            }
        val (_, wySouth) = lonLatToWorldPixel(0.0, vb.south, wsz)
        val (_, wyNorth) = lonLatToWorldPixel(0.0, vb.north, wsz)
        val vyMin = min(wySouth, wyNorth)
        val vyMax = max(wySouth, wyNorth)

        val loWy = vyMin - margin
        val hiWy = vyMax + margin
        if (hiWy <= loWy + 1e-9) return emptyList()

        val points = ArrayList<GridPoint>(1024)
        val eps = 1e-6
        fun firstCenterAtOrAfter(lo: Double): Double {
            val k = kotlin.math.ceil(((lo - half) / step) - eps)
            return half + k * step
        }
        for ((vx0, vx1) in xIntervals) {
            // Allow loWx/hiWx outside [0, wsz] when the viewport spans the dateline.
            // Points will still be assigned to a tile via [lonLatToTileUv] modulo math,
            // but their world-pixel X will be correct for the current Mapbox world-copy.
            val span = kotlin.math.abs(vx1 - vx0)
            val loWx = vx0 - margin
            val hiWx = vx1 + margin + span * eastFrac
            if (hiWx <= loWx + 1e-9) continue
            var wxc = firstCenterAtOrAfter(loWx)
            while (wxc <= hiWx - eps) {
                var wyc = firstCenterAtOrAfter(loWy)
                while (wyc <= hiWy - eps) {
                    val (lon, lat) = worldPixelToLonLat(wxc, wyc, wsz)
                    val owner = lonLatToTileUv(lon, lat, z)
                    if (owner != null && owner.tx == xWrapped && owner.ty == y) {
                        points.add(GridPoint(lon, lat))
                        if (points.size >= maxFeaturesPerSidecarTile) return points
                    }
                    wyc += step
                }
                wxc += step
            }
        }
        return points
    }

    private fun buildFeaturesForGridPoints(
        points: List<GridPoint>,
        zGrid: Int,
        timeKey: String,
    ): MutableList<Feature> {
        if (points.isEmpty()) return mutableListOf()
        val features = ArrayList<Feature>(points.size)
        for (point in points) {
            val sample = sampleEncodedRgbAtLonLat(point.lon, point.lat, zGrid, timeKey)
            if (sample != null) {
                val feature = Feature.fromGeometry(Point.fromLngLat(point.lon, point.lat))
                val (rRaw, gRaw, bRaw) = sample
                val fields =
                    if (instancedQuadMonochromeWhite) {
                        WindSampleFields(maritimeScalarDirDegFromBlueByte(bRaw), 0.1)
                    } else {
                        sampleFieldsFromEncodedRgb(rRaw, gRaw, bRaw)
                    }
                val speed = fields.speedMs
                val dirDeg = fields.dirDeg
                feature.addNumberProperty("r", rRaw)
                feature.addNumberProperty("g", gRaw)
                feature.addNumberProperty("b", bRaw)
                feature.addNumberProperty("speed", speed)
                feature.addNumberProperty("dir", dirDeg)
                feature.addNumberProperty("age", rRaw)
                feature.addNumberProperty("hasSample", 1.0)
                applyEncodedShaderIconColor(feature, speed)
                features.add(feature)
            }
        }
        return features
    }

    private fun buildFeaturesForViewportGrid(
        x: Int,
        y: Int,
        z: Int,
        cameraZoom: Double,
        visibleGeoBounds: VisibleGeoBounds?,
        timeKey: String,
    ): MutableList<Feature> {
        val vb = visibleGeoBounds ?: return mutableListOf()

        val zGrid = stablePlacementZoomInt(cameraZoom)
        val wsz = worldSizePx(zGrid.toDouble())
        val step = placementStepPxAtZoom0() / lowZoomDensityMultiplier(cameraZoom)
        val half = step * 0.5
        val margin = step * 2.0

        fun lonToWorldWrappedX(lon: Double): Double {
            val turns = ((lon + 180.0) / 360.0)
            val wrappedTurns = ((turns % 1.0) + 1.0) % 1.0
            return wrappedTurns * wsz
        }

        val spanLon = kotlin.math.abs(vb.east - vb.west)
        val wxWest = lonToWorldWrappedX(vb.west)
        val wxEast = lonToWorldWrappedX(vb.east)
        val xIntervals: List<Pair<Double, Double>> =
            when {
                spanLon >= 360.0 -> listOf(0.0 to wsz)
                vb.east >= vb.west && wxEast >= wxWest -> listOf(wxWest to wxEast)
                else -> listOf(0.0 to wxEast, wxWest to wsz)
            }
        val (_, wySouth) = lonLatToWorldPixel(0.0, vb.south, wsz)
        val (_, wyNorth) = lonLatToWorldPixel(0.0, vb.north, wsz)
        val vyMin = min(wySouth, wyNorth)
        val vyMax = max(wySouth, wyNorth)

        // Placement is camera-only: generate over full viewport extent, independent of tile bounds.
        // Tile x/y/z are used only as deterministic "owner" assignment so each global point is
        // returned by exactly one custom-geometry tile request.
        val loWy = vyMin - margin
        val hiWy = vyMax + margin
        if (hiWy <= loWy + 1e-9) return mutableListOf()

        val features = ArrayList<Feature>(1024)
        // Snap to the *global* grid centers: wx = half + k*step (same for wy).
        // This avoids boundary gaps between adjacent tiles due to float rounding.
        val eps = 1e-6
        fun firstCenterAtOrAfter(lo: Double): Double {
            val k = kotlin.math.ceil(((lo - half) / step) - eps)
            return half + k * step
        }
        for ((vx0, vx1) in xIntervals) {
            val loWx = (vx0 - margin).coerceAtLeast(0.0)
            val hiWx = (vx1 + margin).coerceAtMost(wsz)
            if (hiWx <= loWx + 1e-9) continue
            var wxc = firstCenterAtOrAfter(loWx)
            while (wxc <= hiWx - eps) {
                var wyc = firstCenterAtOrAfter(loWy)
                while (wyc <= hiWy - eps) {
                    val (lon, lat) = worldPixelToLonLat(wxc, wyc, wsz)

                    val sample = sampleEncodedRgbAtLonLat(lon, lat, zGrid, timeKey)
                    if (sample != null) {
                        val feature = Feature.fromGeometry(Point.fromLngLat(lon, lat))
                        val (rRaw, gRaw, bRaw) = sample
                        val fields = fieldsFromEncodedSampleRgb(rRaw, gRaw, bRaw)
                        val speed = fields.speedMs
                        val dirDeg = fields.dirDeg
                        feature.addNumberProperty("r", rRaw)
                        feature.addNumberProperty("g", gRaw)
                        feature.addNumberProperty("b", bRaw)
                        feature.addNumberProperty("speed", speed)
                        feature.addNumberProperty("dir", dirDeg)
                        feature.addNumberProperty("age", rRaw)
                        feature.addNumberProperty("hasSample", 1.0)
                        applyEncodedShaderIconColor(feature, speed)
                        features.add(feature)
                        if (features.size >= maxFeaturesPerSidecarTile) return features
                    }
                    wyc += step
                }
                wxc += step
            }
        }

        return features
    }

    private fun resolveExactEncodedTile(coord: TileCoord): Tile<com.xweather.mapsgl.sources.DataType>? {
        fun ensurePaddedDataRestored(tile: Tile<com.xweather.mapsgl.sources.DataType>) {
            val encodedData = tile.encodedData ?: return
            if (encodedData.paddedData != null) return
            val nativeKey = "${encodedSource.id}${tile.coordHash}"
            val restored = encodedSource.tileCache.nativeCache.getData(nativeKey)
            if (restored != null) {
                encodedData.paddedData = restored
            }
        }

        encodedSource.tileCache[coord]?.let { exact ->
            if (exact.encodedData != null) {
                ensurePaddedDataRestored(exact)
                return exact
            }
        }

        val requestedMs = runCatching { validTime.time }.getOrElse { 0L }
        val timeMsCache = HashMap<String, Long?>()
        fun timeMs(timeStr: String): Long? =
            timeMsCache.getOrPut(timeStr) {
                val trimmed = timeStr.trim()
                val normalized = when {
                    trimmed.startsWith("[") -> trimmed
                    trimmed.startsWith("\"") && trimmed.endsWith("\"") -> "[$trimmed]"
                    trimmed.isEmpty() -> null
                    else -> "[\"$trimmed\"]"
                }
                normalized?.let { runCatching { parseDateArrayFromString(it).firstOrNull()?.time }?.getOrNull() }
            }

        val exactToleranceMs = 60_000L
        var bestCandidate: Tile<com.xweather.mapsgl.sources.DataType>? = null
        var bestDiff = Long.MAX_VALUE

        for (key in encodedSource.tileCache.keys) {
            val keyCoord = TileCoord.fromHash(key) ?: continue
            if (keyCoord.x != coord.x || keyCoord.y != coord.y || keyCoord.z != coord.z) continue
            val candidate = encodedSource.tileCache[keyCoord] ?: continue
            if (candidate.encodedData != null) {
                val candidateMs = timeMs(candidate.coord.time)
                if (candidateMs != null) {
                    val diff = kotlin.math.abs(candidateMs - requestedMs)
                    if (diff <= exactToleranceMs) {
                        if (diff < bestDiff) {
                            bestDiff = diff
                            bestCandidate = candidate
                        }
                    }
                }
            }
        }

        return bestCandidate?.also { ensurePaddedDataRestored(it) }
    }

    private fun resolveClosestEncodedTile(coord: TileCoord): Tile<com.xweather.mapsgl.sources.DataType>? {
        fun ensurePaddedDataRestored(tile: Tile<com.xweather.mapsgl.sources.DataType>) {
            val encodedData = tile.encodedData ?: return
            if (encodedData.paddedData != null) return
            val nativeKey = "${encodedSource.id}${tile.coordHash}"
            val restored = encodedSource.tileCache.nativeCache.getData(nativeKey)
            if (restored != null) {
                encodedData.paddedData = restored
            }
        }

        val requestedMs = runCatching { validTime.time }.getOrElse { 0L }
        val timeMsCache = HashMap<String, Long?>()
        fun timeMs(timeStr: String): Long? =
            timeMsCache.getOrPut(timeStr) {
                val trimmed = timeStr.trim()
                val normalized = when {
                    trimmed.startsWith("[") -> trimmed
                    trimmed.startsWith("\"") && trimmed.endsWith("\"") -> "[$trimmed]"
                    trimmed.isEmpty() -> null
                    else -> "[\"$trimmed\"]"
                }
                normalized?.let { runCatching { parseDateArrayFromString(it).firstOrNull()?.time }?.getOrNull() }
            }

        val maxFallbackDiffMs = 2 * 3600_000L

        var bestCandidate: Tile<com.xweather.mapsgl.sources.DataType>? = null
        var bestDiff = Long.MAX_VALUE

        for (key in encodedSource.tileCache.keys) {
            val keyCoord = TileCoord.fromHash(key) ?: continue
            if (keyCoord.x != coord.x || keyCoord.y != coord.y || keyCoord.z != coord.z) continue
            val candidate = encodedSource.tileCache[keyCoord] ?: continue
            if (candidate.encodedData != null) {
                val candidateMs = timeMs(candidate.coord.time)
                if (candidateMs != null) {
                    val diff = kotlin.math.abs(candidateMs - requestedMs)
                    if (diff < bestDiff) {
                        bestDiff = diff
                        bestCandidate = candidate
                    }
                }
            }
        }

        if (bestCandidate != null && bestDiff <= maxFallbackDiffMs) {
            ensurePaddedDataRestored(bestCandidate)
            return bestCandidate
        }

        return null
    }

    private fun buildFeaturesFromEncodedData(
        encodedTile: Tile<com.xweather.mapsgl.sources.DataType>,
        coord: TileCoord,
        x: Int,
        y: Int,
        z: Int,
        cameraZoom: Double,
        visibleGeoBounds: VisibleGeoBounds?,
    ): MutableList<Feature> {
        val encodedData = encodedTile.encodedData ?: return mutableListOf()
        if (encodedData.paddedData == null) return mutableListOf()
        val timeKey =
            if (encodedTile.coord.time.length >= 2) encodedTile.coord.time else coord.time
        // Grid is defined in world-pixel coordinates at integer zoom.
        val zGrid = stablePlacementZoomInt(cameraZoom)
        val stepUse = placementStepPxAtZoom0() / lowZoomDensityMultiplier(cameraZoom)
        val nData = 2.0.pow(z)
        val wsz = worldSizePx(zGrid.toDouble())
        val wxMinT = x / nData * wsz
        val wxMaxT = (x + 1) / nData * wsz
        val wyMinT = y / nData * wsz
        val wyMaxT = (y + 1) / nData * wsz
        val spanX = max(wxMaxT - wxMinT, 1e-9)
        val spanY = max(wyMaxT - wyMinT, 1e-9)
        val half = stepUse * 0.5
        val margin = stepUse * 2.0
        val visAxes = visibleGeoBounds?.let { vb -> visibleWorldPixelAxes(vb, wsz) }
        val loWx: Double
        val hiWx: Double
        val loWy: Double
        val hiWy: Double
        if (visAxes != null) {
            val (wxR, wyR) = visAxes
            loWx = max(wxMinT, wxR.first - margin)
            hiWx = min(wxMaxT, wxR.second + margin)
            loWy = max(wyMinT, wyR.first - margin)
            hiWy = min(wyMaxT, wyR.second + margin)
        } else {
            loWx = wxMinT
            hiWx = wxMaxT
            loWy = wyMinT
            hiWy = wyMaxT
        }
        val features = ArrayList<Feature>(1024)
        try {
            if (hiWx > loWx + 1e-9 && hiWy > loWy + 1e-9) {
                var wxc = floor(loWx / stepUse) * stepUse + half
                if (wxc < loWx - 1e-9) wxc += stepUse
                while (wxc < min(hiWx, wxMaxT) - 1e-9) {
                    var wyc = floor(loWy / stepUse) * stepUse + half
                    if (wyc < loWy - 1e-9) wyc += stepUse
                    while (wyc < min(hiWy, wyMaxT) - 1e-9) {
                        val fx = ((wxc - wxMinT) / spanX).coerceIn(0.0, 1.0)
                        val fy = ((wyc - wyMinT) / spanY).coerceIn(0.0, 1.0)
                        val (lon, lat) = lngLatFromTileFrac(x, y, z, fx, fy)
                        val sample = sampleEncodedRgbAtLonLat(lon, lat, z, timeKey)
                        if (sample != null) {
                            val (rRaw, gRaw, bRaw) = sample
                            val fields = fieldsFromEncodedSampleRgb(rRaw, gRaw, bRaw)
                            val speed = fields.speedMs
                            val dirDeg = fields.dirDeg
                            val feature = Feature.fromGeometry(Point.fromLngLat(lon, lat))
                            feature.addNumberProperty("r", rRaw)
                            feature.addNumberProperty("g", gRaw)
                            feature.addNumberProperty("b", bRaw)
                            feature.addNumberProperty("speed", speed)
                            feature.addNumberProperty("dir", dirDeg)
                            feature.addNumberProperty("age", rRaw)
                            applyEncodedShaderIconColor(feature, speed)
                            features.add(feature)
                            if (features.size >= maxFeaturesPerSidecarTile) return features
                        }
                        wyc += stepUse
                    }
                    wxc += stepUse
                }
            }
            if (features.isEmpty()) {
                val vb = visibleGeoBounds
                val allowCenterFallback =
                    vb == null || vb.east < vb.west || tileCenterInVisibleGeo(x, y, z, vb)
                if (allowCenterFallback) {
                    val (lonC, latC) = lngLatFromTileFrac(x, y, z, 0.5, 0.5)
                    sampleEncodedRgbAtLonLat(lonC, latC, z, timeKey)?.let { (rRaw, gRaw, bRaw) ->
                        val fields = sampleFieldsFromEncodedRgb(rRaw, gRaw, bRaw)
                        val speed = fields.speedMs
                        val dirDeg = fields.dirDeg
                        val feature = Feature.fromGeometry(Point.fromLngLat(lonC, latC))
                        feature.addNumberProperty("r", rRaw)
                        feature.addNumberProperty("g", gRaw)
                        feature.addNumberProperty("b", bRaw)
                        feature.addNumberProperty("speed", speed)
                        feature.addNumberProperty("dir", dirDeg)
                        feature.addNumberProperty("age", rRaw)
                        applyEncodedShaderIconColor(feature, speed)
                        features.add(feature)
                    }
                }
            }
            return features
        } finally {
            try {
                val nativeKey = "${encodedSource.id}${encodedTile.coordHash}"
                val padded = encodedData.paddedData
                if (padded != null && !encodedSource.tileCache.nativeCache.containsKey(nativeKey)) {
                    encodedSource.tileCache.nativeCache.putData(nativeKey, padded)
                }
            } catch (_: Throwable) {
            }
        }
    }

    private suspend fun buildFeaturesFromBitmapBytes(
        tileBytes: ByteArray,
        x: Int,
        y: Int,
        z: Int
    ): MutableList<Feature> {
        val bitmap: Bitmap = withContext(Dispatchers.IO) {
            BitmapFactory.decodeByteArray(tileBytes, 0, tileBytes.size)
                ?: throw IllegalArgumentException("Failed to decode encoded tile bitmap")
        }

        val width = bitmap.width
        val height = bitmap.height
        // Bitmap path uses a fixed pixel stride derived from the zoom0 spacing.
        val stepWorld = placementStepPxAtZoom0()
        val virtStep = max(1, (stepWorld / 512.0 * min(width, height)).roundToInt())
        val px = IntArray(width * height)
        bitmap.getPixels(px, 0, width, 0, 0, width, height)
        bitmap.recycle()

        val features = ArrayList<Feature>(max(1, (width / virtStep) * (height / virtStep)))
        val coordNoTime = TileCoord(x, y, z)
        for (yPx in 0 until height step virtStep) {
            for (xPx in 0 until width step virtStep) {
                val argb = px[yPx * width + xPx]
                val rRaw = ((argb shr 16) and 0xFF).toDouble()
                val gRaw = ((argb shr 8) and 0xFF).toDouble()
                val bRaw = (argb and 0xFF).toDouble()
                val fields = fieldsFromEncodedSampleRgb(rRaw, gRaw, bRaw)
                val speed = fields.speedMs
                val dirDeg = fields.dirDeg
                val (lon, lat) = pixelToLngLat(coordNoTime, xPx, yPx, width, height)
                val feature = Feature.fromGeometry(Point.fromLngLat(lon, lat))
                feature.addNumberProperty("r", rRaw)
                feature.addNumberProperty("g", gRaw)
                feature.addNumberProperty("b", bRaw)
                feature.addNumberProperty("speed", speed)
                feature.addNumberProperty("dir", dirDeg)
                feature.addNumberProperty("age", rRaw)
                applyEncodedShaderIconColor(feature, speed)
                features.add(feature)
            }
        }
        return features
    }
}
