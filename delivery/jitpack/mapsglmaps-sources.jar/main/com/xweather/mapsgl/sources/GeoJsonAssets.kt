package com.xweather.mapsgl.sources

import android.content.Context
import com.mapbox.geojson.FeatureCollection
import java.util.concurrent.ConcurrentHashMap

/**
 * Loads GeoJSON from inline JSON or Android asset paths (for example `stored_asset/conus.geojson`).
 *
 * Bound automatically when a [com.xweather.mapsgl.map.MapController] is constructed.
 */
internal object GeoJsonAssets {
    private val cacheByAssetPath = ConcurrentHashMap<String, FeatureCollection>()

    @Volatile
    private var appContext: Context? = null

    fun bind(context: Context) {
        appContext = context.applicationContext
    }

    /**
     * Parses [jsonOrAssetPath] as GeoJSON text, or loads an Android asset when the value looks like
     * a `.geojson` asset path (does not start with `{` or `[`).
     */
    fun parse(jsonOrAssetPath: String): FeatureCollection {
        val trimmed = jsonOrAssetPath.trim()
        if (trimmed.startsWith("{") || trimmed.startsWith("[")) {
            return FeatureCollection.fromJson(trimmed)
        }
        if (trimmed.endsWith(".geojson", ignoreCase = true)) {
            cacheByAssetPath.getOrPut(trimmed) { FeatureCollection.fromJson(loadAssetText(trimmed)) }
                .let { return it }
        }
        return FeatureCollection.fromJson(trimmed)
    }

    private fun loadAssetText(assetPath: String): String {
        val ctx = appContext
            ?: error(
                "MapsGL GeoJSON asset loader is not ready. Construct MapController before loading " +
                    "asset paths such as \"$assetPath\".",
            )
        return runCatching {
            ctx.assets.open(assetPath).bufferedReader().use { it.readText() }
        }.getOrElse { openErr ->
            runCatching {
                val sdkCtx = ctx.createPackageContext(ctx.packageName, 0)
                sdkCtx.assets.open(assetPath).bufferedReader().use { it.readText() }
            }.getOrElse {
                throw IllegalArgumentException(
                    "Could not open GeoJSON asset \"$assetPath\". Ensure the file is packaged under " +
                        "src/main/assets/ (app or MapsGL SDK AAR).",
                    openErr,
                )
            }
        }
    }
}
