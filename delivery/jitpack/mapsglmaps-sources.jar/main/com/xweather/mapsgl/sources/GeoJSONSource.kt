package com.xweather.mapsgl.sources

import com.mapbox.geojson.FeatureCollection
import com.xweather.mapsgl.anim.TileRequestManager
import com.xweather.mapsgl.anim.TileRequestOptions
import com.xweather.mapsgl.tiles.TileCache
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.types.DataSourceConsumer
import com.xweather.mapsgl.types.DataSourceKind
import com.xweather.mapsgl.utils.Signal
import com.xweather.mapsgl.utils.replaceVars
import com.xweather.mapsgl.weather.Authenticator
import com.xweather.mapsgl.weather.XweatherAuthenticator
import java.net.URL
import java.util.Date
import java.util.concurrent.atomic.AtomicInteger

/**
 * Runtime **GeoJSON** data source for map layers that consume geographic features (points, lines, polygons).
 *
 * Instances are created when you call [com.xweather.mapsgl.map.MapController.addSource] with a
 * [com.xweather.mapsgl.sources.source.spec.GeoJSONSourceDescriptor]. Retrieve the same instance with
 * [com.xweather.mapsgl.map.MapController.getSource] and cast to `GeoJSONSource` to update a remote [url],
 * assign in-memory [data], or refresh after changes.
 *
 * **Remote URL:** set [url] to a template string. [makeDataURL] expands `{startDate}` and `{endDate}` from
 * [timeRange] (ISO-style via [com.xweather.mapsgl.utils.replaceVars]), URL-encodes values, and—when
 * [authenticator] is an [XweatherAuthenticator]—merges `{accessKey}`, `{clientId}`, `{clientSecret}` and the
 * documentation segment `[CLIENT_ID]_[CLIENT_SECRET]` like tile sources. If the descriptor omitted
 * [com.xweather.mapsgl.sources.source.spec.GeoJSONSourceDescriptor.authenticator],
 * [com.xweather.mapsgl.map.MapController.addSource] attaches [com.xweather.mapsgl.weather.WeatherService.authenticator] automatically.
 *
 * **Inline data:** set [data] to a Mapbox [FeatureCollection] (for example from `FeatureCollection.fromJson(...)`).
 * You can use this together with or instead of a remote [url], depending on your pipeline.
 *
 * **Events:** [onLoadStart], [onLoadComplete], and related signals fire around load lifecycle (see each property).
 *
 * @property id Stable identifier matching the descriptor and any layers that reference this source.
 * @see com.xweather.mapsgl.sources.source.spec.GeoJSONSourceDescriptor
 */
// TODO: subclass TileSource hierarchy cleanup with MapController generic constraints
class GeoJSONSource(override val id: String) : TileSource<VectorData>() {
    override val kind: DataSourceKind = DataSourceKind.GEOJSON

    companion object {
        /**
         * Parses inline GeoJSON or loads an Android asset path (for example `stored_asset/conus.geojson`).
         *
         * Use this instead of [FeatureCollection.fromJson] when the argument may be an asset path.
         * Stock Mapbox GeoJSON parses the string as JSON and will crash on asset paths.
         */
        @JvmStatic
        fun parseJsonOrAsset(jsonOrAssetPath: String): FeatureCollection =
            GeoJsonAssets.parse(jsonOrAssetPath)
    }

    private val geoJsonStencilSeq = AtomicInteger(0)

    /**
     * Increments on every [data] assignment. [com.xweather.mapsgl.renderers.TileLayerRenderer] uses this
     * to avoid rebuilding GLES stencil meshes from GeoJSON on every frame for the same tile + data.
     */
    val geoJsonStencilSequence: Int
        get() = geoJsonStencilSeq.get()

    override var tileCache: TileCache<DataType> = TileCache()

    /**
     * Metadata is not implemented for this source type; calling this method throws [kotlin.NotImplementedError].
     *
     * @return never returns normally
     * @throws kotlin.NotImplementedError always
     */
    override fun getMetadataURL(): URL? {
        TODO("Not yet implemented")
    }

    override suspend fun requestTiles(
        coord: TileCoord,
        options: TileRequestOptions,
        currentDate: String,
        fromAnimation: Boolean,
        intervals: List<String>?,
        trackDownloadProgress: Boolean,
    ): Any {
        return 0
    }

    /**
     * Remote GeoJSON endpoint template, or `null` if the source is driven only by [data].
     * Placeholders follow [com.xweather.mapsgl.utils.replaceVars] (e.g. `{startDate}`, `{endDate}`).
     */
    var url: String? = null

    /**
     * Parsed GeoJSON features served directly by the app, or `null` when using only [url].
     * Assigning a new value notifies [onDataChange] and pushes geometry to the map style when this
     * source is bound (see [pushGeoJsonToMapStyle]).
     */
    var data: FeatureCollection? = null
        set(value) {
            field = value
            geoJsonStencilSeq.incrementAndGet()
            onDataChange.send(Unit)
            pushGeoJsonToMapStyle?.invoke(value)
        }

    /**
     * Set by the map implementation when this source is added so [data] updates apply to the style.
     */
    internal var pushGeoJsonToMapStyle: ((FeatureCollection?) -> Unit)? = null

    /** Optional attribution string for map credits. */
    var attribution: String? = null

    /**
     * Optional authenticator for remote requests. When this is an [XweatherAuthenticator], credential
     * placeholders in [url] are expanded in [makeDataURL].
     */
    var authenticator: Authenticator? = null

    /**
     * Active time window merged into URL variables as `startDate` and `endDate` when building a request URL.
     */
    override var timeRange: ClosedRange<Date>? = null

    /**
     * Optional list of valid observation times for time-enabled GeoJSON products (product-specific).
     */
    var validTimes: List<Date>? = null

    /**
     * Builds a resolved HTTP(S) [URL] from [url] and the given [variables], merged with [timeRange] bounds
     * and [XweatherAuthenticator.appendTileCredentialVariables] when applicable. Values are URL-encoded.
     *
     * @param variables Extra template variables for [replaceVars] (may be empty).
     * @return Parsed URL, or `null` if [url] is null or blank (inline [data]-only sources are valid).
     */
    fun makeDataURL(variables: Map<String, Any> = emptyMap()): URL? {
        val url = this.url?.takeIf { it.isNotBlank() } ?: return null

        val mergedVariables = variables.toMutableMap()
        timeRange?.let {
            mergedVariables["startDate"] = it.start
            mergedVariables["endDate"] = it.endInclusive
        }
        (authenticator as? XweatherAuthenticator)?.appendTileCredentialVariables(mergedVariables)
        val urlString = url.replaceVars(mergedVariables, true)

        return URL(urlString)
    }

    /**
     * Requests clients and the map stack to drop cached geometry for this source after [url] or [data] changes.
     * Full cache invalidation is still being wired; call this whenever you mutate URL or feature data.
     */
    fun invalidate() {
        // Implementation pending
    }

    override fun addConsumer(consumer: DataSourceConsumer) {}

    override fun removeConsumer(layerId: String) {}

    /** Dispatched when a load operation begins. */
    val onLoadStart = Signal.eventOnly<Unit>()

    /** Dispatched when a load operation finishes successfully. */
    val onLoadComplete = Signal.eventOnly<Unit>()

    /** Dispatched when metadata fetch starts (reserved for future metadata support). */
    val onMetadataLoadStart = Signal.eventOnly<Unit>()

    /** Dispatched when metadata has been parsed (reserved for future metadata support). */
    val onMetadataLoad = Signal.eventOnly<Unit>()

    /** Dispatched when metadata loading fails (reserved for future metadata support). */
    val onMetadataError = Signal.eventOnly<Unit>()

    /** Dispatched when [data] or derived features change. */
    val onDataChange = Signal.eventOnly<Unit>()
}
