package com.xweather.mapsgl.sources

/**
 * GPU uniform values for encoded-tile UV math (512 data + border padding in a square texture).
 * Keep in sync with [DataPool]; fragment shaders read these via [com.xweather.mapsgl.gl.programs.TriangleProgram].
 */
object EncodedTileShaderPadding {
    val dataSize: Float get() = DataPool.originalSize.toFloat()
    val padding: Float get() = DataPool.padding.toFloat()
    val totalSize: Float get() = DataPool.totalSize.toFloat()
}
