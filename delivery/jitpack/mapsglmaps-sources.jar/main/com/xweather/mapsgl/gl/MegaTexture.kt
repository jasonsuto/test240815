package com.xweather.mapsgl.gl

import android.opengl.GLES31
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.gl.worldObjects.MeshInfo
import java.nio.ByteBuffer
import java.nio.ByteOrder

class MegaTexture {
    var framebufferId = IntArray(1)
    var textureIds = IntArray(1)
    private val vertexArray = UnitQuad2DGeometry.genQuad1x1()
    private val textureArray = UnitQuad2DGeometry.genTexCoords1Quad()
    val vertexBuffer =
        ByteBuffer.allocateDirect(vertexArray.size * 4).run {
            order(ByteOrder.nativeOrder())
            asFloatBuffer()
        }

    val textureCoordinatesBuffer = ByteBuffer.allocateDirect(textureArray.size * 4).run {
        order(ByteOrder.nativeOrder())
        asFloatBuffer()
    }

    init {
        vertexBuffer.apply {
            clear()
            put(vertexArray)
            rewind()
        }

        textureCoordinatesBuffer.apply {
            clear()
            put(textureArray)
            rewind()
        }

    }

    fun createFramebuffer(width: Int, height: Int): Boolean {
        // Check if we need to delete the old framebuffer and texture.
        if (framebufferId[0] != 0) {
            GLES31.glDeleteFramebuffers(1, framebufferId, 0)
            framebufferId[0] = 0 // Reset the framebuffer ID.
        }

        if (textureIds[0] != 0) {
            GLES31.glDeleteTextures(1, textureIds, 0)
            textureIds[0] = 0 // Reset the texture ID.
        }

        // Generate new framebuffer and texture.
        GLES31.glGenFramebuffers(1, framebufferId, 0)
        GLES31.glGenTextures(1, textureIds, 0)
        GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, textureIds[0])

        GLES31.glTexImage2D(
            GLES31.GL_TEXTURE_2D, 0, GLES31.GL_RGBA,
            width, height,
            0, GLES31.GL_RGBA, GLES31.GL_UNSIGNED_BYTE, null
        )

        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MIN_FILTER, GLES31.GL_LINEAR)
        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MAG_FILTER, GLES31.GL_LINEAR)
        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_WRAP_S, GLES31.GL_CLAMP_TO_EDGE)
        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_WRAP_T, GLES31.GL_CLAMP_TO_EDGE)

        GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, framebufferId[0])
        GLES31.glFramebufferTexture2D(
            GLES31.GL_FRAMEBUFFER,
            GLES31.GL_COLOR_ATTACHMENT0,
            GLES31.GL_TEXTURE_2D,
            textureIds[0],
            0
        )

        if (GLES31.glCheckFramebufferStatus(GLES31.GL_FRAMEBUFFER) != GLES31.GL_FRAMEBUFFER_COMPLETE) {
            //throw RuntimeException("Framebuffer 0 is not complete")
            println("MegaTexture createFrameBuffer() Framebuffer 0 is not complete")
            return false
        }

        GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, 0)
        return true
    }

    fun drawTileToTexture(texUnit: Int) { //draw a tile to framebuffer
        if (pr.ON) pr.p(
            "MEGATEXTURE",
            pr.particles,
            "drawTileToTexture() drawing ONLY 1=========================================================="
        )
        GLES31.glDisable(GLES31.GL_BLEND)
        GLES31.glActiveTexture(GLES31.GL_TEXTURE0)
        GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, texUnit)
        GLES31.glDrawArrays(GLES31.GL_TRIANGLE_STRIP, 0, 4)
    }

    fun drawTilesToTexture(texUnit1: Int?, texUnit2: Int?) { //draw a tile to framebuffer
        GLES31.glDisable(GLES31.GL_BLEND)

        // Bind the first texture if it exists, otherwise unbind the texture unit.
        GLES31.glActiveTexture(GLES31.GL_TEXTURE0)
        if (texUnit1 != null) {
            GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, texUnit1)
        } else {
            GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, 0) // Unbind
        }

        // Bind the second texture if it exists, otherwise unbind the texture unit.
        GLES31.glActiveTexture(GLES31.GL_TEXTURE4)
        if (texUnit2 != null) {
            GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, texUnit2)
        } else {
            GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, 0) // Unbind
        }

        // It's good practice to reset the active texture unit to the first one
        // before drawing, as most operations default to TEXTURE0.
        GLES31.glActiveTexture(GLES31.GL_TEXTURE0)

        GLES31.glDrawArrays(GLES31.GL_TRIANGLE_STRIP, 0, 4)
    }

    fun cleanup() {
        if (pr.ON) pr.p("MegaTexture", pr.i13, "cleanup() called.")


        // Delete the framebuffer if it exists
        if (framebufferId[0] != 0) {
            GLES31.glDeleteFramebuffers(1, framebufferId, 0)
            if (pr.ON) pr.p("MegaTexture", pr.i13, "Deleted framebuffer ID: ${framebufferId[0]}")
            framebufferId[0] = 0 // Reset the ID
        } else {
            if (pr.ON) pr.p("MegaTexture", pr.i13, "Framebuffer ID was already 0.")
        }

        // Delete the texture if it exists
        if (textureIds[0] != 0) {
            GLES31.glDeleteTextures(1, textureIds, 0)
            if (pr.ON) pr.p("MegaTexture", pr.i13, "Deleted texture ID: ${textureIds[0]}")
            textureIds[0] = 0 // Reset the ID
        } else {
            if (pr.ON) pr.p("MegaTexture", pr.i13, "Texture ID was already 0.")
        }

        // Note: The NIO buffers (vertexBuffer, textureCoordinatesBuffer) are managed by the JVM's
        // garbage collector for their direct memory. You don't explicitly "delete" them in OpenGL terms.
        // They will be garbage collected when the MegaTexture instance itself is no longer referenced
        // and garbage collected.
    }
}

class BoundsInfo {
    var x1 = Float.MAX_VALUE
    private var x2 = Float.MIN_VALUE
    var y1 = Float.MAX_VALUE
    private var y2 = Float.MIN_VALUE
    private var lastX1: Float = 0f
    private var lastX2: Float = 0f
    private var lastY1: Float = 0f
    private var lastY2: Float = 0f
    var needsUpdate = true
    var numX = 0f
    var numY = 0f

    fun calcBounds(meshInfoList: List<MeshInfo>?) {
        if (meshInfoList.isNullOrEmpty()) {
            return
        }

        x1 = Float.MAX_VALUE
        x2 = Float.MIN_VALUE
        y1 = Float.MAX_VALUE
        y2 = Float.MIN_VALUE

        for (meshInfo in meshInfoList) {
            x1 = minOf(x1, meshInfo.x)
            x2 = maxOf(x2, meshInfo.x)
            y1 = minOf(y1, meshInfo.y)
            y2 = maxOf(y2, meshInfo.y)
        }

        numX = (x2 - x1) + 1
        numY = (y2 - y1) + 1

        if (x1 != lastX1 || x2 != lastX2 || y1 != lastY1 || y2 != lastY2) {
            needsUpdate = true
        }
        lastX1 = x1
        lastX2 = x2
        lastY1 = y1
        lastY2 = y2
    }
}