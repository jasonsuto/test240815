package com.xweather.mapsgl.gl.programs

import android.content.Context
import android.opengl.GLES31
import android.util.Log
import com.xweather.mapsgl.gl.geometries.bufferAttributes.AttributeKey
import com.xweather.mapsgl.gl.geometries.bufferAttributes.IBufferAttribute
import java.nio.FloatBuffer

open class MapboxTriangleProgram(
    context: Context,
    vertPath: String,
    fragPath: String,
    expression: String,
    type: Int,
    compPath: String? = null,
    extraDefines: List<String> = emptyList(),
) :
    TriangleProgram(context, vertPath, fragPath, expression, type, compPath, extraDefines)/*, Program, IRasterTileProgram*/ {

    open var matrixArray: FloatArray? = null

    override fun setupShaderInputs( //FIXME: This never runs...
        map: HashMap<AttributeKey, IBufferAttribute<*>>,
        iResolution: IntArray,
        iChannels: IntArray,
        iChannelResolutions: Array<IntArray>
    ) {
        //println("$TAG setupShaderInputs")
        handle?.let { hd ->

            /*
             * TODO Consolidate these when fixed
             */
            map[AttributeKey.Position]?.let {
                val attrHandle = GLES31.glGetAttribLocation(hd, AttributeKey.Position.toString())
                GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, attrHandle)
                GLES31.glEnableVertexAttribArray(attrHandle)
                GLES31.glVertexAttribPointer(
                    attrHandle,
                    it.stride,
                    it.glType,
                    it.normalized!!,
                    it.stride * it.typeByteWidth,
                    it.data as FloatBuffer
                )
            }

            // get handle to shape's transformation matrix
            val projectionMatrixHandle = GLES31.glGetUniformLocation(hd, "projectionMatrix").also {
                checkError("glGetUniformLocation")
            }

            // Apply the projection transformation
            GLES31.glUniformMatrix4fv(
                projectionMatrixHandle,
                1,
                false,
                matrixArray, //this is null?
                0
            )
        }
    }

    override fun setUniform(name: String, value: Any) {
        //if (uniforms[name] != null) {
        uniforms[name] = value
        // }

    }

    fun checkError(cmd: String? = null) {
        val msg = when (val error = GLES31.glGetError()) {
            GLES31.GL_NO_ERROR -> "$cmd -> A-ok"
            GLES31.GL_INVALID_ENUM -> "$cmd -> error in gl: GL_INVALID_ENUM"
            GLES31.GL_INVALID_VALUE -> "$cmd -> error in gl: GL_INVALID_VALUE"
            GLES31.GL_INVALID_OPERATION -> "$cmd -> error in gl: GL_INVALID_OPERATION"
            GLES31.GL_INVALID_FRAMEBUFFER_OPERATION -> "$cmd -> error in gl: GL_INVALID_FRAMEBUFFER_OPERATION"
            GLES31.GL_OUT_OF_MEMORY -> "$cmd -> error in gl: GL_OUT_OF_MEMORY"
            else -> "$cmd -> error in gl: $error"
        }

        Log.d(TAG, msg)
        if (msg.contains("error")) {
            throw RuntimeException(msg)
        }
    }

}