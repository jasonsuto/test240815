package com.xweather.mapsgl.gl.programs

import android.content.Context
import android.opengl.GLES31
import com.xweather.mapsgl.gl.geometries.bufferAttributes.AttributeKey
import com.xweather.mapsgl.gl.geometries.bufferAttributes.IBufferAttribute
import java.nio.FloatBuffer

/**
 *   RasterTileProgram.kt
 *
 *
 *   @author Jason Suto on 12/11/23.
 *
 */

class RasterTileProgram(
    context: Context?,
    vertPath: String,
    fragPath: String,
    expression: String,
    type: Int,
    compPath: String? = null,
    extraDefines: List<String> = emptyList(),
) :
    MapboxTriangleProgram(context!!, vertPath, fragPath, expression, type, compPath, extraDefines)/*, Program, IRasterTileProgram*/ {

    override var matrixArray: FloatArray? = null

    override fun setupShaderInputs(
        map: HashMap<AttributeKey, IBufferAttribute<*>>,
        iResolution: IntArray,
        iChannels: IntArray,
        iChannelResolutions: Array<IntArray>
    ) {
        super.setupShaderInputs(map, iResolution, iChannels, iChannelResolutions)
        handle?.let { hd ->

            map[AttributeKey.UV]?.let {
                val attrHandle = GLES31.glGetAttribLocation(hd, AttributeKey.UV.toString())
                GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, attrHandle)
                GLES31.glEnableVertexAttribArray(attrHandle)
                GLES31.glVertexAttribPointer(
                    attrHandle,
                    it.stride,
                    it.glType,
                    it.normalized!!,
                    it.stride * it.typeByteWidth,
                    it.data as FloatBuffer
                )
            }

            // Texture access in shader
            for (i in iChannels.indices) {
                val j = iChannels[i]
                val location = GLES31.glGetUniformLocation(hd, "iChannel$j")
                GLES31.glActiveTexture(GLES31.GL_TEXTURE0 + j)
                GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, iChannels[i])
                GLES31.glUniform1i(location, j)
            }
        }
    }
}