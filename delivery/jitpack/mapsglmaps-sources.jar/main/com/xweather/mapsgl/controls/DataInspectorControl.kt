package com.xweather.mapsgl.controls

import android.view.View
import android.view.ViewGroup
import androidx.constraintlayout.widget.ConstraintLayout
import com.mapbox.geojson.Point
import com.mapbox.maps.ScreenCoordinate
import com.xweather.mapsgl.data.DataInspectorResult
import com.xweather.mapsgl.events.MapControllerEvents
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.map.MapController
import com.xweather.mapsgl.map.mapbox.MapboxMapController.Companion.TAG
import com.xweather.mapsgl.weather.common.Presentation

/**
 * A data control that queries map layers at a target coordinate and presents a callout.
 *
 * `DataInspectorControl` owns a [CalloutView] anchored to a point within a host view. It
 * executes asynchronous feature queries, coalesces/throttles updates for animated timelines,
 * and formats results using layer-specific or default [Presentation]s.
 *
 * ## Usage
 * 1. Enable the control from [com.xweather.mapsgl.map.MapController.addDataInspectorControl].
 * 2. Call [show] with a screen point and WGS‑84 coordinate to display and populate the callout (or rely on map tap,
 *    which forwards to the same pipeline).
 * 3. Call [update] as the underlying data animates or changes to refresh values.
 * 4. Call [hide] to remove the callout and disable inspector mode ([on] becomes `false`).
 *
 * ## Off-screen anchor behavior
 * When the user pans or zooms, the controller reprojects the picked coordinate into [mapView] pixel space
 * and repositions the callout via [move]. If that pixel lies **outside** the map view bounds
 * (fully off-screen), behavior is controlled by [cancelCalloutWhenOffScreen] (default `true`):
 *
 * - **`true`**: The callout is **dismissed** (in-flight query cancelled, anchor cleared, UI deactivated).
 *   [on] remains `true` if it was already enabled so map taps can open a new inspection.
 * - **`false`**: **Legacy** behavior: the bubble is only hidden with [View.INVISIBLE] while the inspector
 *   stays logically active so timeline-driven updates can continue in the background.
 */
class DataInspectorControl(mapController: MapController) {
    private val mapView = mapController.mapView
    private var callOut: CalloutView? = CalloutView(mapController)

    /**
     * Whether the callout should be **fully dismissed** when its anchor pixel moves completely outside
     * the [mapView] rectangle during camera moves ([move] / [CalloutView.moveView]).
     *
     * Default is `true`:
     * - In-flight inspector work is cancelled.
     * - The callout UI is deactivated and anchor state cleared,
     *   but [on] is **not** set to `false`, so inspector mode stays on and the next map tap can show again.
     *
     * Set to `false` to restore the previous behavior: the view becomes [View.INVISIBLE] off-screen while
     * [isActive] remains `true`, preserving timeline refresh without showing the bubble.
     *
     * @see move
     * @see hide
     */
    var cancelCalloutWhenOffScreen: Boolean = true
        set(value) {
            field = value
            callOut?.cancelCalloutWhenAnchorOffScreen = value
        }

    internal val dIResult: DataInspectorResult = DataInspectorResult()
    internal val queryResult: DataInspectorResult = DataInspectorResult()
    internal val presentationsByLayerId: HashMap<String, Presentation> = hashMapOf()
    internal var on = false

    internal var targetCoordinate: Point?
        get() = callOut?.currentPoint
        set(value) {
            callOut?.currentPoint = value
        }

    internal val isActive: Boolean
        get() = callOut?.isActive() == true

    internal val hasMoved: Boolean
        get() = callOut?.moved == true

    val view: ConstraintLayout?
        get() = callOut?.view

    /** Keeps the callout above legend/timeline siblings on the activity root. */
    fun bringCalloutToFront() {
        val calloutView = callOut?.view ?: return
        val host = calloutView.parent as? ViewGroup ?: return
        host.bringChildToFront(calloutView)
    }

    private val onLayerAdded: (Any?) -> Unit = {
        if (pr.ON) println(">>> DataInspectorControl onLayerAdded")
        val isVector = it as Boolean
        val delay = if (isVector) 500L else 100L

        view?.postDelayed({
            callOut?.update(dIResult)
        }, delay)
    }
    private val onLayerRemoved: (Any?) -> Unit = { // this is in use
        if (pr.ON) pr.p("DataInspectorControl", pr.mapControllerEvent, "on(MapControllerEvents.onLayerRemoved)")
        callOut?.update(dIResult)
    }
    private val onLoadComplete: (Any?) -> Unit = {
        if (pr.ON) pr.p("DataInspectorControl", pr.mapControllerEvent, "on(MapControllerEvents.LOAD COMPLETE)")
        callOut?.update(dIResult)
    }
    private val onVisibilityChanged: (Any?) -> Unit = {
        if (pr.ON) pr.p("DataInspectorControl", pr.mapControllerEvent, "on(MapControllerEvents.VISIBILITY_CHANGED)")
        callOut?.update(dIResult)
    }
    private val onVectorLayerAdded: (Any?) -> Unit = { // this is in use
        if (pr.ON) pr.p("DataInspectorControl", pr.mapControllerEvent, "on(MapControllerEvents.VECTOR_LAYER_ADDED)")
        callOut?.update(dIResult)
    }

    private var mapLayoutListenerRegistered = false

    private val mapLayoutChangeListener =
        View.OnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            // Do not reposition during layout — that can re-enter ConstraintLayout and NPE listener lists.
            mapView.post {
                callOut?.refreshHostOffset()
                if (callOut?.isActive() == true) {
                    callOut?.moveView()
                }
            }
        }

    init {
        callOut?.cancelCalloutWhenAnchorOffScreen = cancelCalloutWhenOffScreen
        callOut?.dismissDueToOffScreenAction = { dismissCalloutKeepingControlEnabled() }
        initializeView(mapController)
        initializeListeners(mapController)
    }

    /** Shows (or updates) the callout at a screen point for a geographic coordinate.
    executes an async query to populate its contents.

    Parameters:
    - point: The anchor point in the host's coordinate system or convertible from its superview/window.
    - coordinate: The WGS‑84 coordinate to query.
     **/
    fun show(point: ScreenCoordinate, coordinate: Point) {
        on = true
        callOut?.setActive(true)
        if (pr.ON) pr.p(TAG, pr.vectorRefactor, "show() calling callout.show()")
        callOut?.show(coordinate, dIResult, point)
    }

    /**
     * Repositions the callout for a new anchor in **MapView** pixel space (same space [mapView] width/height).
     *
     * When the anchor is outside `0..<mapView.width` × `0..<mapView.height`, see [cancelCalloutWhenOffScreen]:
     * either dismiss or hide invisibly.
     *
     * @param point Screen anchor in pixels, consistent with Mapbox `pixelForCoordinate` output for this map view.
     * @see cancelCalloutWhenOffScreen
     */
    fun move(point: ScreenCoordinate) {
        if (pr.ON) pr.p("DataInspectorControl", pr.dIFix, "move() calling callout.moveView()")
        callOut?.moveView(point.x.toFloat(), point.y.toFloat())
    }

    /** Refreshes callout contents for the current `targetCoordinate`.
     **/
    fun update() {
        callOut?.update(dIResult)
    }

    /**
     * Hides the callout, cancels any in-flight inspector query, and disables inspector mode.
     *
     * Sets [on] to `false`, deactivates the UI, and clears [targetCoordinate]. Use [removeDataInspectorControl]
     * on [MapController] to also unregister listeners. This is stronger than off-screen dismiss, which keeps [on] true.
     *
     * @see cancelCalloutWhenOffScreen
     * @see com.xweather.mapsgl.map.MapController.removeDataInspectorControl
     */
    fun hide() {
        on = false
        callOut?.cancelInFlightInspectorQuery()
        callOut?.setActive(false)
        targetCoordinate = null

        //currentQueryTask?.cancel()
        //mapView.removeView(view)
        //callOut?.removeFromSuperview()
        //callOut = null
        //callOut = null
        // targetPoint = null
        //targetCoordinate = null
//		isQueryInFlight = false
    }

    /** Registers a presentation for a layer identifier.

    - Parameters:
    - layerId: The unique identifier of the layer.
    - presentation: The presentation rules to apply when formatting values.
     **/
    fun setPresentation(layerId: String, presentation: Presentation) {
        val preexisting: Boolean = presentationsByLayerId[layerId] != null
        presentationsByLayerId[layerId] = presentation
        if (preexisting && targetCoordinate != null) {
            showInternal(targetCoordinate!!)
        }
    }

    /** Removes any custom presentation associated with a layer identifier.

    - Parameter layerId: The unique identifier of the layer.
     **/
    fun removePresentation(layerId: String) {
        presentationsByLayerId.remove(layerId)
    }

    internal fun initializeView(mapController: MapController) {
        // Local Weather (and similar layouts) draw the legend on the activity root over the lower
        // map. A callout child of MapView is clipped at the MapView bottom (above the timeline) and
        // drawn under that legend — it looks like a horizontal slice through the bubble when panning.
        // Host on the MapView parent when possible, with a high Z so the full bubble stays visible.
        val callout = callOut ?: return
        val host = (mapView.parent as? ViewGroup) ?: mapView
        callout.attachToHost(host)
        mapView.clipChildren = false
        mapView.clipToPadding = false
        disableClipForCallout(host)

        val density = mapView.resources.displayMetrics.density
        callout.view.elevation = 56f * density
        host.addView(
            callout.view,
            ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ),
        )
        host.bringChildToFront(callout.view)

        if (!mapLayoutListenerRegistered) {
            mapView.addOnLayoutChangeListener(mapLayoutChangeListener)
            mapLayoutListenerRegistered = true
        }
    }

    private fun disableClipForCallout(root: View) {
        var v: View? = root
        while (v != null) {
            if (v is ViewGroup) {
                v.clipChildren = false
                v.clipToPadding = false
            }
            v = v.parent as? View
        }
    }

    internal fun initializeListeners(mapController: MapController) {
        mapController.on(MapControllerEvents.LAYER_ADDED, onLayerAdded)
        mapController.on(MapControllerEvents.LAYER_REMOVED, onLayerRemoved) // in use
        //mapController.on(MapControllerEvents.LOAD_COMPLETE, onLoadComplete)
        mapController.on(MapControllerEvents.VISIBILITY_CHANGED, onVisibilityChanged) // in use
        mapController.on(MapControllerEvents.VECTOR_LAYER_ADDED, onVectorLayerAdded) // in use
    }

    internal fun updateVector() {
        updateGridData()
        callOut?.view?.post {
            callOut?.flickerVis = View.VISIBLE
            callOut?.moveView()
        }
    }

    internal fun updateWithSameData() {
        callOut?.update(dIResult, false)
    }

    internal fun showInternal(point: Point) {
        callOut?.prepareForSpatialTap()
        callOut?.setActive(true)
        val px = mapView.mapboxMap.pixelForCoordinate(point)
        callOut?.show(point, dIResult, px)
    }

    private fun updateGridData() {
        callOut?.updateGridData(dIResult)
    }

    internal fun removeEvents(mapController: MapController) {
        mapController.off(MapControllerEvents.LAYER_ADDED, onLayerAdded)
        mapController.off(MapControllerEvents.LAYER_REMOVED, onLayerRemoved)
        //mapController.off(MapControllerEvents.LOAD_COMPLETE, onLoadComplete)
        mapController.off(MapControllerEvents.VISIBILITY_CHANGED, onVisibilityChanged)
        mapController.off(MapControllerEvents.VECTOR_LAYER_ADDED, onVectorLayerAdded) // in use
        if (mapLayoutListenerRegistered) {
            mapView.removeOnLayoutChangeListener(mapLayoutChangeListener)
            mapLayoutListenerRegistered = false
        }
    }

    /**
     * Closes the callout and clears the anchor without setting [on] to `false`.
     * Invoked from [CalloutView.moveView] when [cancelCalloutWhenOffScreen] is `true` and the anchor is off-screen.
     */
    private fun dismissCalloutKeepingControlEnabled() {
        val c = callOut ?: return
        c.cancelInFlightInspectorQuery()
        c.setActive(false)
        c.resetAfterOffScreenDismiss()
    }
}