package com.xweather.mapsgl.anim

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Formats timeline instants for on-screen labels using the device timezone and `en` locale,
 * matching MapsGL JS examples (`toLocaleDateString('en')` / `toLocaleTimeString('en')`).
 *
 * Tile requests still use UTC ISO strings from [Timeline.formatDateToUTCString].
 */
object TimelineDisplayFormatter {
    private val locale = Locale.US

    private val startEndFormatter = SimpleDateFormat("MM/dd/yyyy h:mm a", locale)
    private val currentTimeFormatter = SimpleDateFormat("h:mm a", locale)
    private val currentDateFormatter = SimpleDateFormat("EEE, MMM d", locale)

    /** Timeline range endpoints, e.g. `08/14/2026 8:43 AM` (device timezone). */
    fun formatStartEnd(date: Date): String = startEndFormatter.format(date)

    /** Playhead clock time, e.g. `8:43 AM` (device timezone). */
    fun formatCurrentTime(date: Date): String = currentTimeFormatter.format(date)

    /** Playhead date, e.g. `Fri, Aug 14` (device timezone). */
    fun formatCurrentDate(date: Date): String = currentDateFormatter.format(date)

    /** JS operational examples (`timeZone: 'UTC'`) — optional explicit UTC labels. */
    fun formatCurrentTimeUtc(date: Date): String =
        SimpleDateFormat("h:mm a", locale).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(date)

    /** UTC playhead date in the same `EEE, MMM d` pattern as [formatCurrentDate]. */
    fun formatCurrentDateUtc(date: Date): String =
        SimpleDateFormat("EEE, MMM d", locale).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(date)
}
