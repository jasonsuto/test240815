package com.xweather.mapsgl.anim

import androidx.annotation.Keep
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * A function that takes a progress value (from 0.0 to 1.0) and returns an eased value.
 */
typealias EasingCurve = (Double) -> Double

/**
 * Represents the supported easing curves used throughout MapsGL.
 */
@Keep
enum class Easing {
    LINEAR,
    QUADRATIC,
    CUBIC,
    ELASTIC,
    IN_QUAD,
    OUT_QUAD,
    IN_OUT_QUAD,
    IN_CUBIC,
    OUT_CUBIC,
    IN_OUT_CUBIC,
    IN_QUART,
    OUT_QUART,
    IN_OUT_QUART,
    IN_QUINT,
    OUT_QUINT,
    IN_OUT_QUINT,
    IN_SINE,
    OUT_SINE,
    IN_OUT_SINE,
    IN_EXPO,
    OUT_EXPO,
    IN_OUT_EXPO,
    IN_CIRC,
    OUT_CIRC,
    IN_OUT_CIRC,
    IN_SQUARE,
    OUT_SQUARE,
    IN_OUT_SQUARE,
    IN_SQRT,
    OUT_SQRT,
    IN_OUT_SQRT;

    /**
     * Evaluate the easing curve for a given progress value in the 0.0...1.0 range.
     * @param progress Normalized progress.
     * @return The eased progress.
     */
    fun value(at: Double): Double {
        val t = at.coerceIn(0.0, 1.0)

        return when (this) {
            LINEAR -> t
            QUADRATIC -> t * (-(t * t) * t + 4 * t * t - 6 * t + 4)
            CUBIC -> t * (4 * t * t - 9 * t + 6)
            ELASTIC -> t * (33.0 * t.pow(4.0) - 106.0 * t.pow(3.0) + 126.0 * t * t - 67.0 * t + 15.0)
            IN_QUAD -> t * t
            OUT_QUAD -> t * (2 - t)
            IN_OUT_QUAD -> if (t < 0.5) 2 * t * t else -1 + (4 - 2 * t) * t
            IN_CUBIC -> t * t * t
            OUT_CUBIC -> (t - 1).let { u -> u * u * u + 1 }
            IN_OUT_CUBIC -> if (t < 0.5) 4 * t * t * t else (t - 1).let { u -> u * (2 * t - 2) * (2 * t - 2) + 1 }
            IN_QUART -> t.pow(4)
            OUT_QUART -> (t - 1).let { u -> 1 - u * u * u * u }
            IN_OUT_QUART -> if (t < 0.5) 8 * t.pow(4) else (t - 1).let { u -> 1 - 8 * u * u * u * u }
            IN_QUINT -> t.pow(5)
            OUT_QUINT -> (t - 1).let { u -> 1 + u * u * u * u * u }
            IN_OUT_QUINT -> if (t < 0.5) 16 * t.pow(5) else (t - 1).let { u -> 1 + 16 * u * u * u * u * u }
            IN_SINE -> -cos(t * (PI / 2)) + 1
            OUT_SINE -> sin(t * (PI / 2))
            IN_OUT_SINE -> -(cos(PI * t) - 1) / 2
            IN_EXPO -> 2.0.pow(10 * (t - 1))
            OUT_EXPO -> (-2.0).pow(-10 * t) + 1
            IN_OUT_EXPO -> {
                var u = t / 0.5
                if (u < 1) 2.0.pow(10 * (u - 1)) / 2
                else {
                    u -= 1
                    (-(2.0.pow(-10 * u)) + 2) / 2
                }
            }

            IN_CIRC -> -sqrt(1 - t * t) + 1
            OUT_CIRC -> (t - 1).let { u -> sqrt(1 - u * u) }
            IN_OUT_CIRC -> {
                var u = t / 0.5
                if (u < 1) -(sqrt(1 - u * u) - 1) / 2
                else {
                    u -= 2
                    (sqrt(1 - u * u) + 1) / 2
                }
            }

            IN_SQUARE -> t.pow(2)
            OUT_SQUARE -> 1 - (1 - t).pow(2)
            IN_OUT_SQUARE -> if (t < 0.5) 2 * t * t else -1 + (4 - 2 * t) * t
            IN_SQRT -> 1 - (1 - t).pow(0.5)
            OUT_SQRT -> t.pow(0.5)
            IN_OUT_SQRT -> if (t < 0.5) (1 - (1 - 2 * t).pow(0.5)) / 2 else ((2 * t - 1).pow(0.5) + 1) / 2
        }
    }
}

/**
 * A factory for creating EasingCurve functions.
 */
@Keep
object EasingCurveFactory {

    /**
     * Produce a sampling curve function for an existing `Easing` method.
     */
    fun curve(forEasing: Easing): EasingCurve {
        return { t -> forEasing.value(t) }
    }

    /**
     * Produce a cubic-bezier easing curve.
     */
    fun cubicBezier(x1: Double, y1: Double, x2: Double, y2: Double): EasingCurve {
        // Note: Logging is handled differently in Android.
        // A simple `println` or a proper logging framework like `Log.w` would be used here.
        if (x1.isNaN() || y1.isNaN() || x2.isNaN() || y2.isNaN()) {
            println("Warning: Cubic bezier requires four numeric control points but received [$x1, $y1, $x2, $y2].")
        }

        if (x1 < 0 || x1 > 1 || x2 < 0 || x2 > 1) {
            println("Warning: Cubic bezier x control points must be in 0...1 but received [$x1, $x2]. Values will be clamped.")
        }

        val clampedX1 = x1.coerceIn(0.0, 1.0)
        val clampedX2 = x2.coerceIn(0.0, 1.0)

        fun a(a1: Double, a2: Double): Double = 1.0 - 3 * a2 + 3 * a1
        fun b(a1: Double, a2: Double): Double = 3 * a2 - 6 * a1
        fun c(a1: Double): Double = 3 * a1

        fun calcBezier(t: Double, a1: Double, a2: Double): Double =
            ((a(a1, a2) * t + b(a1, a2)) * t + c(a1)) * t

        fun getSlope(t: Double, a1: Double, a2: Double): Double =
            3 * a(a1, a2) * t * t + 2 * b(a1, a2) * t + c(a1)

        fun solveCurveX(x: Double): Double {
            var guess = x
            for (i in 0..3) {
                val slope = getSlope(guess, clampedX1, clampedX2)
                if (slope == 0.0) break
                val currentX = calcBezier(guess, clampedX1, clampedX2) - x
                guess -= currentX / slope
            }
            return guess
        }

        return { x ->
            if (clampedX1 == y1 && clampedX2 == y2) {
                x // Linear bezier
            } else {
                calcBezier(solveCurveX(x), y1, y2)
            }
        }
    }
}
