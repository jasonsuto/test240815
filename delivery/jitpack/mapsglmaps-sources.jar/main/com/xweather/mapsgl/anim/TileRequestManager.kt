package com.xweather.mapsgl.anim

import com.mapbox.maps.extension.observable.model.Response
import com.xweather.mapsgl.AbortController
import com.xweather.mapsgl.Partial
import com.xweather.mapsgl.Promise
import com.xweather.mapsgl.data.series.TimeInterval
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.map.MapController
import com.xweather.mapsgl.sources.TileSource
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.types.URLRequest
import com.xweather.mapsgl.weather.AuthenticatorError
import com.xweather.mapsgl.weather.AuthenticatorException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import kotlin.coroutines.cancellation.CancellationException


/**
 *  TileRequestManager.kt
 *
 *  Created by Jason Suto on 12/12/23.
 *  Based on the IOS version.
 */

//TODO: AnyAuthenticator(), AbortSignal(), AbortController,

/** @suppress **/
typealias Headers = HashMap<Any, Any>

private val TAG = "TileRequestManager"

/** @suppress **/
const val MAX_RETRIES = 1

/** @suppress **/
typealias TimeSeriesDataState = Map<String, Boolean>

@Suppress("Dokka")
private data class RequestInfo(
    val coord: TileCoord,
    val interval: TimeInterval?
)

// The pending tile requests and their time intervals when applicable.
private var _pendingRequests: MutableMap<RequestInfo, TileResponse> = mutableMapOf()

/**
 * A response from a tile request.
 *
 * @property data The response data (often an image).
 * @property headers The response headers.
 * @suppress
 */

data class TileResponse(var data: Any, val headers: Headers, val isRadar: Boolean = false)
/**
 * @suppress
 * A function that fetches a tile from the given URL and options.
 *
 * @param coord The tile coordinate to load.
 * @param url The tile URL to load.
 * @param options The tile request options.
 * @returns A promise that resolves with the response.
 */
typealias TileFetcher = (coord: TileCoord, url: String, options: Partial<TileRequestOptions>) -> Promise<Response>

/**
 * This class is responsible for keeping track of the time series intervals and which time intervals
 * we have data for for each tile. This information is then used to determine which intervals we can actually
 * show during an animation, which should only happen if we have data for all visible tiles for the
 * requested time interval.
 *
 * @template Data The type of data stored in a tile.
 * @suppress
 */
class TileRequestManager<Data>(
    private val source: TileSource<TileData>? = null,
    private var _tileFetcher: TileFetcher? = null
) {
    private val _pending = mutableMapOf<String, MutableSet<Int>>()
    private val _state = mutableMapOf<String, TimeSeriesDataState>()
    private val _requests = mutableMapOf<String, AbortController>()
    private val _retries = mutableMapOf<String, Int>()
    private var credential: String? = null
    private var minutesLeft: Double = -1.0
    val bundleID = MapController.packageName
    //private val client_id_key =  "${source?.account?.id} ${source?.account?.secret}"

    var totalRequests = 0

    val pending: MutableMap<String, MutableSet<Int>>
        get() = _pending

    /**
     * Returns the pending tile requests and their time intervals when applicable.
     */
    val totalPending: Int
        get() = _requests.size

    /**
     * Sets the tile fetcher function to use for loading tiles.
     * The fetcher function should return a Promise that resolves with a Response object.
     *
     * @param tileFetcher
     */
    fun setTileFetcher(tileFetcher: TileFetcher) {
        this._tileFetcher = tileFetcher
    }

    /**
     * Performs a tile request for the given tile coordinate and options.
     *
     * If the tile request fails, it will retry up to MAX_RETRIES times or reject the promise after MAX_RETRIES times.
     *
     * Called from ImageTileSource.requestTile()
     * @param coord The tile coordinate to load.
     * @param options The tile request options.
     * @returns A promise that resolves with the response data and headers.
     */
// Returns `null` if all the work requested (`coord` + `options.intervals` combination) is already pending, and no new request is needed.
    suspend fun loadTile(
        coord: TileCoord, // Keep coord for potential logging/error context if needed
        request: URLRequest
    ): TileResponse? { // Return nullable TileResponse directly
        // No need for internal coroutineScope or async/await here
        try {
            val response = fetchTile(request) // Directly call the suspending fetch function
            // Optional: Add logging here if needed, using the coord
            // Log.d(TAG, "loadTile completed for ${coord.hash()}")
            return response // Return the result (or null if fetchTile failed)
        } catch (error: Throwable) {
            // Cancellation must propagate — mapping it to null caused single-interval retry storms
            // that raced overlapping multi-interval batches on the same representative tile.
            if (error is CancellationException) throw error

            //print("TileRequestManager response is ${error.message}")
            //print(">>>> TileRequestManager response is ${error.cause}")

            // Log or handle specific errors if necessary
            if (error is IOException && error.message?.contains("AuthenticationError") == true) { // Example check
                // Consider re-throwing a specific exception if needed upstream
                throw AuthenticatorException(AuthenticatorError.InvalidAuthToken)
            } else {
                // Rethrow other errors or return null depending on desired handling
                // Returning null might be sufficient if the caller handles it
                return null // Indicate failure
                // Or rethrow: throw error
            }
        }
    }

    private fun addPendingTask(
        task:/* Task<TileResponse, Error>*/ TileResponse,
        coord: TileCoord,
        intervals: List<TimeInterval>?
    ) {
        // for (interval in intervals) {
        _pendingRequests[RequestInfo(coord, /*interval*/ null)] = task
        // }
    }

    /**
     * Fetches a tile from the given URL and options.
     *
     * @param coord The tile coordinate to load.
     * @param url The tile URL to load.
     * @param options The tile request options.
     * @returns A promise that resolves with the response.
     */
    private suspend fun fetchTile(request: URLRequest): TileResponse? = withContext(Dispatchers.IO) {
        var tileResponse: TileResponse? = null
        if (pr.ON) {
            pr.p(TAG, pr.serverReq, request.urlString)
            pr.p(TAG, pr.serverReq, "REQUESTING: ${request.body}")
        }

        val response = request.execute()
        when (response.data) {
            is ByteArray -> {
                tileResponse = TileResponse(response.data, Headers(response.headers))
            }
        }
        return@withContext tileResponse
    }

    /**
     * Returns whether the given tile coordinate is pending for the given time interval.
     *
     * @param coord The tile coordinate to check.
     * @param interval The time interval to check, or `0` for data sources not time-based.
     * @returns `true` if the tile is pending, `false` otherwise.
     */
    fun isPending(coord: TileCoord, interval: Int): Boolean {
        val item = _pending[coord.hash()]
        return item?.contains(interval) ?: false
    }

    /**
     * Sets the pending state for the given tile coordinate and time intervals.
     *
     * @param coord The tile coordinate to set the pending state for.
     * @param intervals The time intervals to set the pending state for.
     * @param pending Whether the tile is pending or not.
     */
    fun setPending(coord: TileCoord, intervals: List<Int>?, pending: Boolean) {
        val item = _pending.getOrPut(coord.hash()) { mutableSetOf() }
        if (intervals != null) {
            if (pending) {
                item.addAll(intervals)
            } else {
                item.removeAll(intervals)
            }
        }
        if (item.isEmpty()) {
            _pending.remove(coord.hash())
        }
    }

    /**
     * Aborts the tile request for the given request hash string.
     * @param hash
     */
    fun abort(hash: String) {
        val request = this._requests[hash];
        request?.abort("Requested Abort")
    }
}