package no.ecc.vectortile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.GeometryFactory;

import vector_tile.VectorTile;

/**
 * {@link VectorTileDecoder} that skips MVT attributes no consumer asked for, instead of
 * materialising every tag on every feature and filtering afterwards.
 *
 * <p>The stock decoder builds a full {@code HashMap} per feature and wraps it unmodifiable
 * ({@code VectorTileDecoder.parseFeature}). A heap dump taken inside the play burst showed that
 * costing ~1.95M {@code HashMap$Node} + ~893k {@code UnmodifiableEntry} + ~1.26M {@code String}
 * — the properties were then immediately discarded by the allowlist filter in
 * {@code VectorTileSource.parseVectorTile}. Filtering at decode time means the entries are never
 * allocated at all.
 *
 * <p>Lives in {@code no.ecc.vectortile} so it can reuse the library's package-private
 * {@link VectorTileDecoder#decodeGeometry} and emit real {@link VectorTileDecoder.Feature}
 * instances — every existing call site keeps working with no type changes.
 *
 * <p>Key matching mirrors the allowlist semantics it replaces: a dot-notated MVT key such as
 * {@code report.areaAC} is retained when {@code report} is allowed, because
 * {@code VectorTileSource} rebuilds those into nested dictionaries after decode.
 */
public final class PruningVectorTileDecoder {

    /** Per-layer allowlist. Returning {@code null} means "this layer needs every attribute". */
    public interface AllowedKeys {
        Set<String> forLayer(String layerName);
    }

    private PruningVectorTileDecoder() {
    }

    public static List<VectorTileDecoder.Feature> decode(byte[] data, AllowedKeys allowed)
            throws IOException {
        VectorTile.Tile tile = VectorTile.Tile.parseFrom(data);
        GeometryFactory gf = new GeometryFactory();
        List<VectorTileDecoder.Feature> out = new ArrayList<VectorTileDecoder.Feature>();

        for (VectorTile.Tile.Layer layer : tile.getLayersList()) {
            String layerName = layer.getName();
            int extent = layer.getExtent();
            // Callers set autoScale=false; keep tile-local coordinates.
            double scale = 1.0;

            List<String> keys = layer.getKeysList();
            Set<String> allowedForLayer = allowed == null ? null : allowed.forLayer(layerName);

            // Resolve the allowlist once per layer against the key table, so the per-feature loop
            // is an array lookup rather than a string comparison per tag.
            boolean[] keep = null;
            if (allowedForLayer != null) {
                keep = new boolean[keys.size()];
                for (int i = 0; i < keys.size(); i++) {
                    String key = keys.get(i);
                    int dot = key.indexOf('.');
                    keep[i] = allowedForLayer.contains(dot < 0 ? key : key.substring(0, dot));
                }
            }

            List<Object> values = new ArrayList<Object>(layer.getValuesCount());
            for (VectorTile.Tile.Value value : layer.getValuesList()) {
                if (value.hasBoolValue()) {
                    values.add(value.getBoolValue());
                } else if (value.hasDoubleValue()) {
                    values.add(value.getDoubleValue());
                } else if (value.hasFloatValue()) {
                    values.add(value.getFloatValue());
                } else if (value.hasIntValue()) {
                    values.add(value.getIntValue());
                } else if (value.hasSintValue()) {
                    values.add(value.getSintValue());
                } else if (value.hasUintValue()) {
                    values.add(value.getUintValue());
                } else if (value.hasStringValue()) {
                    values.add(value.getStringValue());
                } else {
                    values.add(null);
                }
            }

            for (VectorTile.Tile.Feature feature : layer.getFeaturesList()) {
                int tagsCount = feature.getTagsCount();
                Map<String, Object> attributes = null;
                int tagIdx = 0;
                while (tagIdx + 1 < tagsCount) {
                    int keyIdx = feature.getTags(tagIdx);
                    int valIdx = feature.getTags(tagIdx + 1);
                    tagIdx += 2;
                    if (keyIdx < 0 || keyIdx >= keys.size()) {
                        continue;
                    }
                    if (keep != null && !keep[keyIdx]) {
                        continue;
                    }
                    if (attributes == null) {
                        attributes = new HashMap<String, Object>(Math.max(2, tagsCount / 2));
                    }
                    attributes.put(keys.get(keyIdx),
                            valIdx >= 0 && valIdx < values.size() ? values.get(valIdx) : null);
                }

                Geometry geometry = VectorTileDecoder.decodeGeometry(
                        gf, feature.getType(), feature.getGeometryList(), scale);
                if (geometry == null) {
                    geometry = gf.createGeometryCollection(new Geometry[0]);
                }

                Map<String, Object> attrs = attributes == null
                        ? Collections.<String, Object>emptyMap()
                        : Collections.unmodifiableMap(attributes);
                out.add(new VectorTileDecoder.Feature(
                        layerName, extent, geometry, attrs, feature.getId()));
            }
        }
        return out;
    }
}
